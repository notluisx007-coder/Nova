# Changed-file report

- `.gitignore`
- `android/local.properties (removed)`
- `.flutter-plugins-dependencies (removed)`
- `lib/features/sources/data/m3u_parser.dart`
- `lib/features/sources/data/source_repository.dart`
- `.github/workflows/build.yml`
- `docs/CI_AND_SECRETS.md`
- `docs/VERIFICATION_REPORT.md`

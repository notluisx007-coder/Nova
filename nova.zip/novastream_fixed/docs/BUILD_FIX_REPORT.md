# NovaStream build-fix report

Date: 2026-11-10

## Fixed

1. Android Gradle Plugin updated from 8.7.3 to 8.11.1. This satisfies the
   minimum AGP version reported by the Flutter build failure.
2. Gradle Wrapper updated to 8.14.3. This meets the Flutter Gradle check's
   8.14 minimum and AGP 8.11's Gradle requirement.
3. Kotlin Gradle Plugin updated from 2.1.0 to 2.2.21 to use a Kotlin plugin
   compatibility range that includes AGP 8.11.1 and Gradle 8.14.
4. Fixed malformed XML in `network_security_config.xml`: an XML comment
   contained a double-hyphen sequence, which made the resource invalid XML.
5. Added `.github/workflows/unzip.yml` to optionally extract a ZIP committed
   to the repository, locate its Flutter project, fetch dependencies, build
   the release APK, and upload it as a workflow artifact.
6. The workflow intentionally does not run tests, `flutter analyze`, or
   backend tests, consistent with the requested build-only pipeline.
7. Bumped the app version to `1.1.1+3` and updated build documentation.

## Validation performed here

- Original uploaded ZIP archive integrity: passed.
- All 11 Android XML resource/manifest files parsed successfully after fix.
- Gradle, AGP, and Kotlin version declarations checked for consistency.
- Workflow checked for the APK build step and absence of test/analyze steps.
- `android/gradlew` executable permission restored.

## Not verified in this environment

Flutter SDK, Dart SDK, Android SDK, and a configured Android build environment
are not installed in this editing environment. Therefore `flutter pub get` and
`flutter build apk --release` could not be executed here. The GitHub Actions
workflow must complete successfully before the APK can be considered built.

## Toolchain note

The build log's Gradle 8.14.3 warning about a future Gradle 9.1 minimum is a
warning, not the reported build-stopping error. AGP 9.x also triggers the
Flutter new-DSL migration warning in the supplied log. This update therefore
uses the compatible AGP 8.x toolchain instead of forcing an unverified AGP 9
migration.

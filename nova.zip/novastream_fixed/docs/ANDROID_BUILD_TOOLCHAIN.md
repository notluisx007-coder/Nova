# Android build toolchain update

## Selected versions

| Component | Version |
|---|---:|
| Gradle Wrapper | 8.14.3 |
| Android Gradle Plugin | 8.11.1 |
| Kotlin Gradle Plugin | 2.2.21 |
| JDK | 17 |

This combination meets the Flutter Gradle plugin requirement reported by the
project's CI log (AGP >= 8.11.1 and Gradle >= 8.14) while avoiding AGP 9.x's
new Android DSL migration. Kotlin 2.2.21 is selected because its documented
compatibility range includes AGP 8.11.1 and Gradle 8.14.

## Build command

```bash
flutter pub get
flutter build apk --release
```

Output:

```text
build/app/outputs/flutter-apk/app-release.apk
```

The build was not executed in the editing environment because Flutter and the
Android SDK are not installed there. GitHub Actions performs the actual build
and uploads the APK only if the build succeeds.

# Android CI build and provider secrets

## GitHub Actions

The workflow at `.github/workflows/unzip.yml` builds a universal Android
release APK only. It does not run tests, Flutter analysis, or backend tests.

- Push to `main` or `master` to build the checked-out Flutter project.
- Run the workflow manually to build the checked-out project, or provide
  `source_zip_path` pointing to a ZIP committed to the repository. The ZIP is
  extracted automatically and the Flutter project is located by `pubspec.yaml`.
- The resulting `app-release.apk` is uploaded as the
  `novastream-release-apk` workflow artifact.

The release build currently uses the debug signing configuration in
`android/app/build.gradle.kts`. This is suitable for CI installation/testing,
not for publishing updates to an existing Play Store app. Configure a private
release keystore through GitHub Secrets before publishing; never commit it.

## Android toolchain

The Android build uses Gradle 8.14.3, Android Gradle Plugin 8.11.1, Kotlin
Gradle Plugin 2.2.21, and Java 17. This is a conservative compatible toolchain
for the current Flutter Gradle plugin. Do not upgrade to AGP 9.x without first
migrating and verifying Flutter's Android Gradle integration and the new DSL.

## Sports provider key

The mobile app must never contain the API-Sports provider key. Configure
`APISPORTS_API_KEY` in the backend host's secret manager or its private
`.env` file. Do not commit `.env`, paste the key into Dart/Kotlin source,
Gradle files, workflow YAML, or `--dart-define`.

If a key has been shared in a chat, issue a replacement in the provider
dashboard and configure the replacement only on the backend. The workflow
does not print or package provider credentials.

## Local Android setup

Install Flutter stable, Android SDK and Java 17. Run `flutter pub get` from
the repository root before invoking Gradle. Flutter creates the
machine-specific `android/local.properties` file locally; it is intentionally
excluded from the source archive and version control.

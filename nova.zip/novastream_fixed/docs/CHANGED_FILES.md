# Build-fix change log

- Updated Android Gradle Plugin from 8.7.3 to 8.11.1.
- Updated Kotlin Gradle Plugin from 2.1.0 to 2.2.21 for compatibility with
  AGP 8.11.1 and Gradle 8.14.x.
- Updated Gradle Wrapper from 8.12 to 8.14.3.
- Added `.github/workflows/unzip.yml` for optional automatic ZIP extraction
  and a release APK-only build. It intentionally omits tests and analysis.
- Updated CI and toolchain documentation.

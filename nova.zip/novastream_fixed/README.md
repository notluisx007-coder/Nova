# NovaStream

**Premium IPTV & Sports Streaming Platform**  
Android (Flutter) + Flutter Web | Version 1.0.0

---

## Overview

NovaStream is an original, complete IPTV and multimedia streaming application featuring:

- **Live TV** — M3U/M3U8 playlist import, channel browsing, groups, search, EPG
- **Sports Hub** — Dedicated first-class sports section with match cards, categories, fixtures calendar
- **Movies & Series** — VOD from authorized Xtream-compatible providers
- **TV Guide** — XMLTV/EPG import with timeline view and programme reminders
- **Player** — HLS playback, orientation, PiP (Android), error diagnostics
- **Sources Manager** — Multi-source playlists, health monitoring, refresh

---

## Architecture

```
lib/
├── core/
│   ├── theme/          # AppTheme — premium dark navy/cyan design system
│   ├── router/         # GoRouter navigation (AppRoutes)
│   ├── database/       # Drift ORM (AppDatabase, all tables)
│   ├── di/             # Dependency injection bootstrap
│   └── utils/
├── features/
│   ├── home/           # Modular home feed
│   ├── live_tv/        # Channel list, detail, channel repository
│   ├── sports/         # Sports Hub, match cards, categories, sports repo
│   ├── epg/            # XMLTV parser, EPG repository, guide screen
│   ├── player/         # VideoPlayer + controls
│   ├── sources/        # M3U parser, source repository, add/manage UI
│   ├── movies/         # VOD movies (requires Xtream provider)
│   ├── series/         # VOD series/seasons (requires Xtream provider)
│   ├── favorites/      # Channels, teams, shows
│   ├── search/         # Global search
│   ├── settings/       # App preferences, sports API config
│   └── onboarding/     # Splash + onboarding flow
└── shared/
    ├── models/         # channel.dart, sports.dart (freezed)
    ├── widgets/        # Reusable UI: cards, empty states, scaffold
    └── services/
```

**Layer separation:** Presentation → Domain/Use-cases → Repository → Data/Provider adapters

---

## Setup & Build

### Prerequisites

```
Flutter SDK >= 3.19.0
Dart >= 3.3.0
Android SDK (compileSdk 34, minSdk 23)
Java 17+
```

### Install dependencies

```bash
flutter pub get
```

### Code generation (Drift, Freezed, Riverpod, GoRouter)

```bash
flutter pub run build_runner build --delete-conflicting-outputs
```

### Run (debug)

```bash
flutter run                   # Android device/emulator
flutter run -d chrome         # Web browser
```

### Build Android APKs

```bash
# All ABI variants (armeabi-v7a, arm64-v8a, x86_64) + universal
flutter build apk --split-per-abi --release

# Universal APK
flutter build apk --release

# App Bundle (recommended for Play Store)
flutter build appbundle --release
```

Generated APKs are in `build/app/outputs/flutter-apk/`:
- `app-armeabi-v7a-release.apk` — 32-bit ARM
- `app-arm64-v8a-release.apk`   — 64-bit ARM  
- `app-x86_64-release.apk`      — x86_64 (emulator/Intel)
- `app-release.apk`             — Universal (all ABIs)

### Build Web

```bash
flutter build web --release --web-renderer canvaskit
# Output: build/web/
```

---

## IPTV Source Setup

### M3U URL
1. Open **Settings → Sources → Add Source**
2. Select **Remote URL**
3. Enter your authorized M3U/M3U8 playlist URL
4. Name the source and tap **Add Source**

NovaStream validates:
- URL scheme must be `http://` or `https://`
- Content must have `#EXTM3U` header
- Unsafe URL schemes in entries are rejected
- Credentials are never logged

### Local File
1. Add Source → **Local File**
2. Select `.m3u` or `.m3u8` from your device

### Supported M3U attributes
`#EXTINF`, `tvg-id`, `tvg-name`, `tvg-logo`, `group-title`, `tvg-language`, `tvg-chno`

---

## EPG / TV Guide Setup

1. Open the **TV Guide** tab
2. Tap **+** to add an XMLTV EPG source
3. Enter an authorized XMLTV URL
4. NovaStream parses channel and programme elements, matches by `tvg-id`

Timezone: XMLTV timestamps are parsed with their offset and converted to device local time.

---

## Sports Hub

The Sports Hub is a **first-class section** with its own navigation tab.

### Sports Data Provider
Live scores, fixtures, and match details require a **documented sports API**.

1. Go to **Settings → Sports Data Provider**
2. Enter your API key from your authorized provider
3. Sports data loads automatically

**Without a configured provider:** The Sports Hub shows the sports category grid, navigation, and channel browser — but no live scores or fixture data. All controls are clearly marked as unconfigured.

### Supported sport categories
Football, Cricket, Formula 1, Basketball, Tennis, Volleyball, Badminton, Rugby, Baseball, Hockey, Motorsport, Wrestling

### Match-to-channel linking
A Watch button only appears when a channel is linked by:
- Verified EPG data
- User-confirmed mapping

No stream is claimed for any match without explicit verified linking.

---

## Player

| Feature | Android | Web |
|---------|---------|-----|
| HLS playback | ✅ VideoPlayer (ExoPlayer) | ✅ hls.js / native HLS |
| Picture-in-Picture | ✅ Android 8+ | ❌ Not available |
| Background audio | ✅ | ❌ Browser restriction |
| Fullscreen | ✅ | ✅ |
| Volume/mute | ✅ | ✅ |
| Orientation lock | ✅ | N/A |
| Error diagnostics | ✅ | ✅ |

Error classes reported: network, DNS/TLS, 403/401 (access denied), 404 (not found), codec/format unsupported, CORS (web), timeout.

---

## Security Notes

- Credentials are never logged or exported
- API keys stored in `flutter_secure_storage` (Android Keystore / iOS Keychain)
- All imported URLs validated (scheme must be http/https/rtmp/rtsp)
- Playlist content is never executed
- No DRM bypass, no CORS bypass, no paywall bypass
- Adult content filter is on by default and cannot be disabled in this build
- Private playlist URLs are masked in diagnostics exports

---

## Feature Status

| Feature | Status |
|---------|--------|
| M3U/M3U8 URL import | ✅ COMPLETE |
| M3U local file import | ✅ COMPLETE |
| Channel browsing + search | ✅ COMPLETE |
| Channel groups / filters | ✅ COMPLETE |
| Favourites | ✅ COMPLETE |
| EPG/XMLTV import | ✅ COMPLETE |
| EPG TV Guide view | ✅ COMPLETE |
| HLS playback (Android) | ✅ COMPLETE |
| HLS playback (Web) | ✅ COMPLETE |
| Player error diagnostics | ✅ COMPLETE |
| Sports Hub UI | ✅ COMPLETE |
| Sports categories | ✅ COMPLETE |
| Match cards | ✅ COMPLETE |
| Sports data (live scores) | ⚙️ AWAITING PROVIDER KEY |
| Match details | ⚙️ AWAITING PROVIDER KEY |
| Team/competition pages | ⚙️ AWAITING PROVIDER KEY |
| Movies/VOD | ⚙️ REQUIRES XTREAM PROVIDER |
| Series/seasons | ⚙️ REQUIRES XTREAM PROVIDER |
| Catch-up / timeshift | ❌ NOT IMPLEMENTED (provider-dependent) |
| DVR / recording | ❌ NOT IMPLEMENTED |
| PiP (Android) | ✅ COMPLETE |
| PiP (Web) | ❌ UNSUPPORTED |
| Android TV / D-pad | 🔄 PARTIAL |
| Cross-device sync | ❌ NOT IMPLEMENTED (no backend) |

---

## Tests

```bash
flutter test                      # All unit tests
flutter test test/unit/m3u_parser_test.dart
flutter test test/unit/sports_model_test.dart
flutter test test/unit/epg_test.dart
```

---

## Known Limitations

1. **Sports live scores** — Requires a configured sports API key. The UI is complete but data is empty without it.
2. **VOD (Movies/Series)** — Requires Xtream-compatible IPTV provider. The UI shows a clear setup prompt.
3. **Catch-up/Timeshift** — Not implemented; requires explicit provider support and content rights.
4. **APK signing** — Debug signing used. Configure `key.properties` for production release signing.
5. **Font assets** — Inter font files must be downloaded from Google Fonts and placed in `assets/fonts/`.
6. **Web CORS** — Some IPTV streams cannot play in browser due to provider CORS policies. This is a provider restriction, not a NovaStream limitation.

---

## Provider Credits

NovaStream optionally integrates with:
- [iptv-org](https://github.com/iptv-org/iptv) — Open IPTV playlist directory (optional catalog)
- [iptv-org API](https://github.com/iptv-org/api) — Channel metadata (optional)

All usage subject to respective licenses and terms.

---

*NovaStream is a media player application. It does not provide, host, or endorse any IPTV service, stream, or content. Users are responsible for ensuring they have authorization to access any content they stream through the application.*

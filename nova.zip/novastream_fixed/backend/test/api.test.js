'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { createApp } = require('../src/server');

/**
 * Contract/integration tests against the REAL server + router + cache +
 * provider boundary, with the upstream provider replaced by a fake fetch.
 * These exercise production code paths — no duplicated logic.
 */

function makeServer(envOverride = {}, fetchImpl) {
  const env = {
    PORT: '0',
    APISPORTS_API_KEY: 'test-key-not-a-real-secret',
    RATE_LIMIT_PER_MINUTE: '1000',
    ...envOverride,
  };
  const { server, config, cache, provider } = createApp(env);
  if (fetchImpl) provider.fetchImpl = fetchImpl;
  return new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      resolve({
        server,
        port,
        baseUrl: `http://127.0.0.1:${port}`,
        cache,
        provider,
        close: () => new Promise((r) => server.close(r)),
      });
    });
  });
}

async function getJson(baseUrl, path, headers = {}) {
  const res = await fetch(`${baseUrl}${path}`, { headers });
  let body = null;
  try {
    body = await res.json();
  } catch (_) {
    body = null;
  }
  return { status: res.status, body, headers: res.headers };
}

const providerFixtures = {
  response: [
    {
      fixture: { id: 101, date: '2026-11-09T18:00:00+00:00', status: { short: '1H', elapsed: 23 } },
      teams: { home: { id: 1, name: 'Team A', logo: 'https://x/a.png' }, away: { id: 2, name: 'Team B', logo: 'https://x/b.png' } },
      goals: { home: 1, away: 0 },
      league: { id: 39, name: 'Premier League', logo: 'https://x/l.png' },
    },
    {
      fixture: { id: 102, date: '2026-11-09T20:00:00+00:00', status: { short: 'NS' } },
      teams: { home: { id: 3, name: 'Team C', logo: null }, away: { id: 4, name: 'Team D', logo: null } },
      goals: { home: null, away: null },
      league: { id: 39, name: 'Premier League', logo: null },
    },
  ],
};

test('GET /health returns ok', async () => {
  const app = await makeServer();
  try {
    const { status, body } = await getJson(app.baseUrl, '/health');
    assert.equal(status, 200);
    assert.equal(body.status, 'ok');
  } finally {
    await app.close();
  }
});

test('GET /version returns name and version', async () => {
  const app = await makeServer({ BACKEND_VERSION: '9.9.9' });
  try {
    const { status, body } = await getJson(app.baseUrl, '/version');
    assert.equal(status, 200);
    assert.equal(body.version, '9.9.9');
    assert.equal(body.name, 'novastream-sports-backend');
  } finally {
    await app.close();
  }
});

test('GET /sports/v1/status reports configured provider without leaking the key', async () => {
  const app = await makeServer();
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/status');
    assert.equal(status, 200);
    assert.equal(body.status, 'ok');
    assert.deepEqual(body.sports.slice(0, 3), ['football', 'afl', 'baseball']);
    assert.equal(body.provider.configured, true);
    assert.equal(JSON.stringify(body).includes('test-key-not-a-real-secret'), false);
  } finally {
    await app.close();
  }
});

test('sports endpoints return 503 with structured error when provider key missing', async () => {
  const app = await makeServer({ APISPORTS_API_KEY: '' });
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/football/live');
    assert.equal(status, 503);
    assert.equal(body.error.code, 'PROVIDER_NOT_CONFIGURED');
    assert.ok(body.error.message.includes('not configured'));
    // And critically: no fake fixtures are returned.
    assert.equal(body.response, undefined);
  } finally {
    await app.close();
  }
});

test('live endpoint proxies provider data and hides the API key', async () => {
  let sawKey = null;
  const fetchImpl = async (url, init) => {
    sawKey = init.headers['x-apisports-key'];
    return new Response(JSON.stringify(providerFixtures), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  };
  const app = await makeServer({}, fetchImpl);
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/football/live');
    assert.equal(status, 200);
    assert.equal(body.response.length, 2);
    assert.equal(body.meta.cached, false);
    assert.equal(sawKey, 'test-key-not-a-real-secret');
    assert.equal(JSON.stringify(body).includes('test-key-not-a-real-secret'), false);
  } finally {
    await app.close();
  }
});

test('fixtures endpoint caches responses within TTL', async () => {
  let providerCalls = 0;
  const fetchImpl = async () => {
    providerCalls++;
    return new Response(JSON.stringify(providerFixtures), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  };
  const app = await makeServer({}, fetchImpl);
  try {
    const first = await getJson(app.baseUrl, '/sports/v1/basketball/fixtures?date=2026-11-09');
    const second = await getJson(app.baseUrl, '/sports/v1/basketball/fixtures?date=2026-11-09');
    assert.equal(first.status, 200);
    assert.equal(first.body.meta.cached, false);
    assert.equal(second.body.meta.cached, true);
    assert.equal(providerCalls, 1);
  } finally {
    await app.close();
  }
});

test('unknown sport yields structured 400', async () => {
  const app = await makeServer();
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/kabaddi/live');
    assert.equal(status, 400);
    assert.equal(body.error.code, 'INVALID_SPORT');
  } finally {
    await app.close();
  }
});

test('fixtures validates date format and calendar validity', async () => {
  const app = await makeServer();
  try {
    const bad1 = await getJson(app.baseUrl, '/sports/v1/football/fixtures?date=09-11-2026');
    assert.equal(bad1.status, 400);
    assert.equal(bad1.body.error.code, 'INVALID_DATE');
    const bad2 = await getJson(app.baseUrl, '/sports/v1/football/fixtures?date=2026-02-30');
    assert.equal(bad2.status, 400);
  } finally {
    await app.close();
  }
});

test('standings requires league and season', async () => {
  const app = await makeServer();
  try {
    const missing = await getJson(app.baseUrl, '/sports/v1/football/standings');
    assert.equal(missing.status, 400);
    assert.equal(missing.body.error.code, 'INVALID_LEAGUE');
    const badSeason = await getJson(app.baseUrl, '/sports/v1/football/standings?league=39&season=twenty');
    assert.equal(badSeason.status, 400);
    assert.equal(badSeason.body.error.code, 'INVALID_SEASON');
  } finally {
    await app.close();
  }
});

test('teams requires a meaningful search term', async () => {
  const app = await makeServer();
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/football/teams?search=a');
    assert.equal(status, 400);
    assert.equal(body.error.code, 'INVALID_SEARCH');
  } finally {
    await app.close();
  }
});

test('provider timeout maps to 504', async () => {
  const fetchImpl = async (url, init) => {
    return new Promise((resolve, reject) => {
      init.signal.addEventListener('abort', () => {
        const e = new Error('aborted');
        e.name = 'AbortError';
        reject(e);
      });
    });
  };
  const app = await makeServer({ PROVIDER_TIMEOUT_MS: '50' }, fetchImpl);
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/hockey/live');
    assert.equal(status, 504);
    assert.equal(body.error.code, 'PROVIDER_TIMEOUT');
  } finally {
    await app.close();
  }
});

test('provider rate limit maps to 429', async () => {
  const fetchImpl = async () => new Response(JSON.stringify({ errors: ['rate limited'] }), {
    status: 429,
    headers: { 'content-type': 'application/json' },
  });
  const app = await makeServer({}, fetchImpl);
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/rugby/live');
    assert.equal(status, 429);
    assert.equal(body.error.code, 'PROVIDER_RATE_LIMITED');
  } finally {
    await app.close();
  }
});

test('rate limiter rejects bursts beyond the configured limit', async () => {
  const app = await makeServer({ RATE_LIMIT_PER_MINUTE: '3' });
  try {
    const statuses = [];
    for (let i = 0; i < 5; i++) {
      const { status } = await getJson(app.baseUrl, `/health?i=${i}`);
      statuses.push(status);
    }
    assert.deepEqual(statuses, [200, 200, 200, 429, 429]);
  } finally {
    await app.close();
  }
});

test('bearer token auth enforced when BACKEND_ACCESS_TOKEN is set', async () => {
  const app = await makeServer({ BACKEND_ACCESS_TOKEN: 's3cret-token' });
  try {
    const noToken = await getJson(app.baseUrl, '/sports/v1/football/live');
    assert.equal(noToken.status, 401);
    assert.equal(noToken.body.error.code, 'UNAUTHORIZED');
    const badToken = await getJson(app.baseUrl, '/sports/v1/football/live', {
      Authorization: 'Bearer wrong',
    });
    assert.equal(badToken.status, 401);
    const goodToken = await getJson(app.baseUrl, '/sports/v1/football/live', {
      Authorization: 'Bearer s3cret-token',
    });
    // Auth passed — the request proceeds to the provider layer (which may
    // fail with 502/503/504 in a test sandbox), but never with 401.
    assert.notEqual(goodToken.status, 401);
    assert.notEqual(goodToken.body.error?.code, 'UNAUTHORIZED');
  } finally {
    await app.close();
  }
});

test('malformed provider JSON maps to 502', async () => {
  const fetchImpl = async () => new Response('<html>not json</html>', {
    status: 200,
    headers: { 'content-type': 'application/json' },
  });
  const app = await makeServer({}, fetchImpl);
  try {
    const { status, body } = await getJson(app.baseUrl, '/sports/v1/mma/live');
    assert.equal(status, 502);
    assert.equal(body.error.code, 'PROVIDER_BAD_RESPONSE');
  } finally {
    await app.close();
  }
});

test('unknown routes return structured 404', async () => {
  const app = await makeServer();
  try {
    const { status, body } = await getJson(app.baseUrl, '/nope');
    assert.equal(status, 404);
    assert.equal(body.error.code, 'NOT_FOUND');
  } finally {
    await app.close();
  }
});

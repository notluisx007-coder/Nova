'use strict';

/**
 * API-Sports provider client. The provider API key NEVER leaves this module
 * and is never included in responses.
 */
class ApiSportsProvider {
  constructor({ apiKey, timeoutMs, fetchImpl = globalThis.fetch, baseUrlTemplate = 'https://{host}' }) {
    this.apiKey = apiKey;
    this.timeoutMs = timeoutMs;
    this.fetchImpl = fetchImpl;
    this.baseUrlTemplate = baseUrlTemplate;
  }

  get configured() {
    return Boolean(this.apiKey) && this.apiKey !== 'YOUR_KEY_HERE';
  }

  /**
   * Performs a provider request. Throws a ProviderError with a safe,
   * client-presentable message; never leaks the key or raw provider errors.
   */
  async request({ host, path, params = {} }) {
    if (!this.configured) {
      const err = new Error('Sports data provider is not configured on this backend');
      err.statusCode = 503;
      err.code = 'PROVIDER_NOT_CONFIGURED';
      throw err;
    }

    const url = new URL(`${this.baseUrlTemplate.replace('{host}', host)}${path}`);
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') {
        url.searchParams.set(k, String(v));
      }
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetchImpl(url, {
        headers: {
          'x-apisports-key': this.apiKey,
          Accept: 'application/json',
        },
        signal: controller.signal,
      });

      if (response.status === 429) {
        const err = new Error('Sports provider rate limit reached — try again shortly');
        err.statusCode = 429;
        err.code = 'PROVIDER_RATE_LIMITED';
        throw err;
      }
      if (!response.ok) {
        const err = new Error(`Sports provider returned status ${response.status}`);
        err.statusCode = 502;
        err.code = 'PROVIDER_BAD_STATUS';
        throw err;
      }

      const contentType = response.headers.get('content-type') ?? '';
      if (!contentType.includes('application/json')) {
        const err = new Error('Sports provider returned a non-JSON response');
        err.statusCode = 502;
        err.code = 'PROVIDER_BAD_RESPONSE';
        throw err;
      }

      let data;
      try {
        data = await response.json();
      } catch (e) {
        const err = new Error('Sports provider returned malformed JSON');
        err.statusCode = 502;
        err.code = 'PROVIDER_BAD_RESPONSE';
        throw err;
      }

      return data;
    } catch (e) {
      if (e && (e.statusCode || e.code)) throw e; // already a ProviderError
      if (e && e.name === 'AbortError') {
        const err = new Error('Sports provider request timed out');
        err.statusCode = 504;
        err.code = 'PROVIDER_TIMEOUT';
        throw err;
      }
      const err = new Error('Could not reach the sports data provider');
      err.statusCode = 502;
      err.code = 'PROVIDER_UNREACHABLE';
      throw err;
    } finally {
      clearTimeout(timer);
    }
  }

  async status() {
    // A cheap authenticated call to verify the key works (free plan allows
    // /status). Returns provider availability, never the key itself.
    if (!this.configured) {
      return { configured: false, reachable: false };
    }
    try {
      await this.request({ host: 'v3.football.api-sports.io', path: '/status' });
      return { configured: true, reachable: true };
    } catch (e) {
      return { configured: true, reachable: false, reason: e.code ?? 'UNKNOWN' };
    }
  }
}

module.exports = { ApiSportsProvider };

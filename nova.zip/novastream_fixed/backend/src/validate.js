'use strict';

/**
 * Request validation helpers. Every route validates its inputs before the
 * provider is contacted; failures produce structured 400 responses.
 */

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function validateSport(sport, allowedSports) {
  if (!allowedSports.includes(sport)) {
    return { ok: false, message: `Unknown sport "${sport}". Allowed: ${allowedSports.join(', ')}` };
  }
  return { ok: true };
}

function validateDate(date) {
  if (date === null || date === undefined || date === '') return { ok: true, value: undefined };
  if (!DATE_PATTERN.test(date)) {
    return { ok: false, message: 'date must be YYYY-MM-DD' };
  }
  // Confirm it is a real calendar date.
  const parsed = new Date(`${date}T00:00:00Z`);
  if (Number.isNaN(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== date) {
    return { ok: false, message: 'date must be a valid calendar day' };
  }
  return { ok: true, value: date };
}

function validatePositiveInt(value, name, { required = false } = {}) {
  if (value === undefined || value === null || value === '') {
    return required
      ? { ok: false, message: `${name} is required` }
      : { ok: true, value: undefined };
  }
  if (!/^\d+$/.test(String(value))) {
    return { ok: false, message: `${name} must be a positive integer` };
  }
  return { ok: true, value: String(value) };
}

function validateSearchTerm(term, name = 'search') {
  if (term === undefined || term === null) {
    return { ok: false, message: `${name} is required` };
  }
  const trimmed = String(term).trim();
  if (trimmed.length < 2) {
    return { ok: false, message: `${name} must be at least 2 characters` };
  }
  if (trimmed.length > 64) {
    return { ok: false, message: `${name} must be at most 64 characters` };
  }
  return { ok: true, value: trimmed };
}

module.exports = {
  validateSport,
  validateDate,
  validatePositiveInt,
  validateSearchTerm,
};

'use strict';

const http = require('node:http');
const { loadConfig } = require('./config');
const { sendJson, sendError, readUrl, Router } = require('./http');
const { TtlCache, RateLimiter } = require('./cache');
const { ApiSportsProvider } = require('./provider');
const { buildSportsRouter } = require('./routes/sports');

/**
 * Creates the NovaStream backend HTTP server. Exported for tests; `npm start`
 * calls listen() on it.
 */
function createApp(env = process.env) {
  const config = loadConfig(env);
  const cache = new TtlCache();
  const limiter = new RateLimiter(config.rateLimitPerMinute);
  const provider = new ApiSportsProvider({
    apiKey: config.providerApiKey,
    timeoutMs: config.providerTimeoutMs,
  });
  const sportsRouter = buildSportsRouter({ config, cache, provider });

  const rootRouter = new Router();
  rootRouter.get('/health', async (req, res) => {
    sendJson(res, 200, { status: 'ok' });
  });
  rootRouter.get('/version', async (req, res) => {
    sendJson(res, 200, {
      name: 'novastream-sports-backend',
      version: config.version,
    });
  });

  const server = http.createServer(async (req, res) => {
    // Common hardening headers.
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'no-store');

    try {
      const url = readUrl(req);
      const pathname = url.pathname;

      // Per-IP rate limiting on all routes.
      const ip =
        (req.headers['x-forwarded-for']?.split(',')[0] ?? '').trim() ||
        req.socket.remoteAddress ||
        'unknown';
      const limit = limiter.check(ip);
      res.setHeader('X-RateLimit-Limit', String(config.rateLimitPerMinute));
      res.setHeader('X-RateLimit-Remaining', String(limit.remaining));
      if (!limit.allowed) {
        res.setHeader('Retry-After', String(limit.resetInSeconds));
        return sendError(res, 429, 'RATE_LIMITED',
          'Too many requests — retry later');
      }

      // Optional bearer-token auth for the sports namespace. When
      // BACKEND_ACCESS_TOKEN is unset the namespace is open (the backend is
      // a thin proxy holding only the provider key).
      if (pathname.startsWith('/sports/')) {
        if (config.backendAccessToken) {
          const auth = req.headers.authorization ?? '';
          if (auth !== `Bearer ${config.backendAccessToken}`) {
            return sendError(res, 401, 'UNAUTHORIZED',
              'Missing or invalid bearer token');
          }
        }
        const match = sportsRouter.match(req.method, pathname);
        if (match) {
          return await match.handler(req, res, {
            params: match.params,
            query: url.searchParams,
          });
        }
      }

      const rootMatch = rootRouter.match(req.method, pathname);
      if (rootMatch) {
        return await rootMatch.handler(req, res, {
          params: rootMatch.params,
          query: url.searchParams,
        });
      }

      return sendError(res, 404, 'NOT_FOUND', `No route for ${req.method} ${pathname}`);
    } catch (e) {
      // Never echo internals to the client.
      return sendError(res, 500, 'INTERNAL_ERROR', 'Unexpected server error');
    }
  });

  server.keepAliveTimeout = 65000;
  return { server, config, cache, provider };
}

function start() {
  const { server, config } = createApp();
  server.listen(config.port, () => {
    // eslint-disable-next-line no-console
    console.log(`NovaStream sports backend listening on :${config.port}`);
    if (!config.providerApiKey) {
      // eslint-disable-next-line no-console
      console.warn('APISPORTS_API_KEY is not set — /sports/v1 endpoints will return 503 until a key is configured.');
    }
  });

  const shutdown = () => {
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 5000).unref();
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

if (require.main === module) {
  start();
}

module.exports = { createApp };

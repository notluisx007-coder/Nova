'use strict';

/**
 * NovaStream Sports Backend — configuration.
 * Every deployment-specific value comes from the environment. No secrets are
 * ever hardcoded and the provider key is never sent to clients.
 */

const REQUIRED_SPORTS = [
  'football',
  'afl',
  'baseball',
  'basketball',
  'formula1',
  'handball',
  'hockey',
  'mma',
  'nba',
  'american_football',
  'rugby',
  'volleyball',
];

// Maps the app's sport key to the API-Sports host for that sport.
const SPORT_HOSTS = {
  football: 'v3.football.api-sports.io',
  afl: 'v3.afl.api-sports.io',
  baseball: 'v3.baseball.api-sports.io',
  basketball: 'v3.basketball.api-sports.io',
  formula1: 'v3.formula-1.api-sports.io',
  handball: 'v3.handball.api-sports.io',
  hockey: 'v3.hockey.api-sports.io',
  mma: 'v3.mma.api-sports.io',
  nba: 'v3.nba.api-sports.io',
  american_football: 'v3.american-football.api-sports.io',
  rugby: 'v3.rugby.api-sports.io',
  volleyball: 'v3.volleyball.api-sports.io',
};

function loadConfig(env = process.env) {
  const port = Number.parseInt(env.PORT ?? '3000', 10);
  const rateLimitPerMinute = Number.parseInt(
    env.RATE_LIMIT_PER_MINUTE ?? '60',
    10
  );
  const providerTimeoutMs = Number.parseInt(env.PROVIDER_TIMEOUT_MS ?? '10000', 10);
  const version = env.BACKEND_VERSION ?? '1.0.0';

  if (!Number.isFinite(port) || port < 0 || port > 65535) {
    throw new Error(`Invalid PORT: ${env.PORT}`);
  }
  if (!Number.isFinite(rateLimitPerMinute) || rateLimitPerMinute <= 0) {
    throw new Error(`Invalid RATE_LIMIT_PER_MINUTE: ${env.RATE_LIMIT_PER_MINUTE}`);
  }

  return {
    port,
    version,
    // Provider credentials live ONLY on the server.
    providerApiKey: env.APISPORTS_API_KEY || '',
    providerBaseUrl: 'https://{host}',
    providerTimeoutMs,
    backendAccessToken: env.BACKEND_ACCESS_TOKEN || '',
    rateLimitPerMinute,
    cacheTtls: {
      live: 30 * 1000,
      fixtures: 60 * 1000,
      standings: 300 * 1000,
      teams: 300 * 1000,
    },
    allowedSports: REQUIRED_SPORTS,
    sportHosts: SPORT_HOSTS,
  };
}

module.exports = { loadConfig, REQUIRED_SPORTS, SPORT_HOSTS };

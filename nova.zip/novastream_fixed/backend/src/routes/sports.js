'use strict';

const { sendJson, sendError, Router } = require('../http');
const { validateSport, validateDate, validatePositiveInt, validateSearchTerm } = require('../validate');

const SPORT_CACHE_SEGMENT = {
  live: 'live',
  fixtures: 'fixtures',
  standings: 'standings',
  teams: 'teams',
};

/**
 * Builds the sports API router. Dependencies (cache, provider, config) are
 * injected so tests can run against a fake provider.
 */
function buildSportsRouter({ config, cache, provider, now = () => Date.now() }) {
  const router = new Router();

  function cacheKey(sport, segment, params) {
    const flat = Object.entries(params)
      .filter(([, v]) => v !== undefined && v !== '')
      .map(([k, v]) => `${k}=${v}`)
      .sort()
      .join('&');
    return `${sport}:${segment}:${flat}`;
  }

  async function serveProvider(res, { sport, segment, host, path, params }) {
    const key = cacheKey(sport, segment, params);
    const ttl = config.cacheTtls[segment] ?? 60000;

    const hit = cache.get(key);
    if (hit && hit.fresh) {
      sendJson(res, 200, {
        response: hit.value.response,
        meta: { cached: true, fetchedAt: new Date(hit.value.fetchedAt).toISOString() },
      });
      return;
    }

    try {
      const data = await provider.request({ host, path, params });
      const response = Array.isArray(data?.response) ? data.response : [];
      cache.set(key, { response, fetchedAt: now() }, ttl);
      sendJson(res, 200, {
        response,
        meta: { cached: false, fetchedAt: new Date(now()).toISOString() },
      });
    } catch (e) {
      // Serve stale data instead of failing outright when available.
      if (hit && !hit.fresh) {
        sendJson(res, 200, {
          response: hit.value.response,
          meta: {
            cached: true,
            stale: true,
            fetchedAt: new Date(hit.value.fetchedAt).toISOString(),
          },
        });
        return;
      }
      sendError(res, e.statusCode ?? 502, e.code ?? 'PROVIDER_ERROR', e.message);
    }
  }

  router.get('/sports/v1/status', async (req, res, ctx) => {
    const providerStatus = provider.configured
      ? { configured: true, reachable: null /* lazily verified on demand */ }
      : { configured: false, reachable: false };
    sendJson(res, 200, {
      status: 'ok',
      version: config.version,
      sports: config.allowedSports,
      provider: providerStatus,
      message: providerStatus.configured
        ? 'Backend is running. Sports data is served through the provider proxy.'
        : 'Backend is running, but no provider API key is configured. Set APISPORTS_API_KEY in the backend environment.',
    });
  });

  router.get('/sports/v1/:sport/live', async (req, res, ctx) => {
    const { sport } = ctx.params;
    const sportCheck = validateSport(sport, config.allowedSports);
    if (!sportCheck.ok) return sendError(res, 400, 'INVALID_SPORT', sportCheck.message);

    const host = config.sportHosts[sport];
    await serveProvider(res, {
      sport,
      segment: SPORT_CACHE_SEGMENT.live,
      host,
      path: '/fixtures',
      params: { live: 'all' },
    });
  });

  router.get('/sports/v1/:sport/fixtures', async (req, res, ctx) => {
    const { sport } = ctx.params;
    const sportCheck = validateSport(sport, config.allowedSports);
    if (!sportCheck.ok) return sendError(res, 400, 'INVALID_SPORT', sportCheck.message);

    const dateCheck = validateDate(ctx.query.get('date'));
    if (!dateCheck.ok) return sendError(res, 400, 'INVALID_DATE', dateCheck.message);
    const leagueCheck = validatePositiveInt(ctx.query.get('league'), 'league');
    if (!leagueCheck.ok) return sendError(res, 400, 'INVALID_LEAGUE', leagueCheck.message);
    const seasonCheck = validatePositiveInt(ctx.query.get('season'), 'season');
    if (!seasonCheck.ok) return sendError(res, 400, 'INVALID_SEASON', seasonCheck.message);

    const params = {};
    if (dateCheck.value) params.date = dateCheck.value;
    if (leagueCheck.value) params.league = leagueCheck.value;
    if (seasonCheck.value) params.season = seasonCheck.value;
    if (ctx.query.get('id')) {
      const idCheck = validatePositiveInt(ctx.query.get('id'), 'id', { required: true });
      if (!idCheck.ok) return sendError(res, 400, 'INVALID_ID', idCheck.message);
      params.id = idCheck.value;
    }

    const host = config.sportHosts[sport];
    await serveProvider(res, {
      sport,
      segment: SPORT_CACHE_SEGMENT.fixtures,
      host,
      path: '/fixtures',
      params: Object.keys(params).length ? params : { next: '20' },
    });
  });

  router.get('/sports/v1/:sport/standings', async (req, res, ctx) => {
    const { sport } = ctx.params;
    const sportCheck = validateSport(sport, config.allowedSports);
    if (!sportCheck.ok) return sendError(res, 400, 'INVALID_SPORT', sportCheck.message);

    const leagueCheck = validatePositiveInt(ctx.query.get('league'), 'league', { required: true });
    if (!leagueCheck.ok) return sendError(res, 400, 'INVALID_LEAGUE', leagueCheck.message);
    const seasonCheck = validatePositiveInt(ctx.query.get('season'), 'season', { required: true });
    if (!seasonCheck.ok) return sendError(res, 400, 'INVALID_SEASON', seasonCheck.message);

    await serveProvider(res, {
      sport,
      segment: SPORT_CACHE_SEGMENT.standings,
      host: config.sportHosts[sport],
      path: '/standings',
      params: { league: leagueCheck.value, season: seasonCheck.value },
    });
  });

  router.get('/sports/v1/:sport/teams', async (req, res, ctx) => {
    const { sport } = ctx.params;
    const sportCheck = validateSport(sport, config.allowedSports);
    if (!sportCheck.ok) return sendError(res, 400, 'INVALID_SPORT', sportCheck.message);

    const searchCheck = validateSearchTerm(ctx.query.get('search'));
    if (!searchCheck.ok) return sendError(res, 400, 'INVALID_SEARCH', searchCheck.message);

    await serveProvider(res, {
      sport,
      segment: SPORT_CACHE_SEGMENT.teams,
      host: config.sportHosts[sport],
      path: '/teams',
      params: { search: searchCheck.value },
    });
  });

  return router;
}

module.exports = { buildSportsRouter };

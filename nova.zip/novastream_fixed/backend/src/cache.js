'use strict';

/**
 * In-memory TTL cache with bounded size. Values expire after `ttlMs` and the
 * cache reports whether it served a stale/aged entry so clients can show a
 * "cached data" indicator.
 */
class TtlCache {
  constructor(maxEntries = 256) {
    this.map = new Map();
    this.maxEntries = maxEntries;
  }

  get(key) {
    const entry = this.map.get(key);
    if (!entry) return undefined;
    const ageMs = Date.now() - entry.storedAt;
    if (ageMs > entry.ttlMs) {
      // Keep the value available for stale-while-revalidate reporting,
      // but flag it as expired.
      return { value: entry.value, fresh: false, ageMs };
    }
    return { value: entry.value, fresh: true, ageMs };
  }

  getFresh(key) {
    const hit = this.get(key);
    return hit && hit.fresh ? hit.value : undefined;
  }

  set(key, value, ttlMs) {
    if (this.map.size >= this.maxEntries) {
      // Evict the oldest entry.
      const oldestKey = this.map.keys().next().value;
      this.map.delete(oldestKey);
    }
    this.map.set(key, { value, ttlMs, storedAt: Date.now() });
  }

  clear() {
    this.map.clear();
  }

  get size() {
    return this.map.size;
  }
}

/**
 * Fixed-window per-IP rate limiter. Not a distributed limiter — documented
 * limitation for single-instance deployments.
 */
class RateLimiter {
  constructor(limitPerMinute) {
    this.limitPerMinute = limitPerMinute;
    this.windows = new Map(); // ip -> { windowStart, count }
    this.lastSweep = Date.now();
  }

  check(ip) {
    const now = Date.now();
    const windowMs = 60 * 1000;
    let win = this.windows.get(ip);
    if (!win || now - win.windowStart >= windowMs) {
      win = { windowStart: now, count: 0 };
      this.windows.set(ip, win);
    }
    win.count += 1;

    // Occasional sweep to keep memory bounded.
    if (now - this.lastSweep > 5 * 60 * 1000) {
      this.lastSweep = now;
      for (const [key, w] of this.windows) {
        if (now - w.windowStart >= windowMs) this.windows.delete(key);
      }
    }

    return {
      allowed: win.count <= this.limitPerMinute,
      remaining: Math.max(0, this.limitPerMinute - win.count),
      resetInSeconds: Math.ceil((win.windowStart + windowMs - now) / 1000),
    };
  }
}

module.exports = { TtlCache, RateLimiter };

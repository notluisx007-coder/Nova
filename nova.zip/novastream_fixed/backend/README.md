# NovaStream Sports Backend

A real, zero-dependency Node.js (>= 20) HTTP service that acts as a secure
proxy between the NovaStream app and the API-Sports provider. The provider
API key lives **only** in this backend's environment and is never returned to
any client.

## Status

Implemented and unit-tested (`npm test` — 16 passing tests covering health,
version, provider-key hiding, 503-without-key, caching, rate limiting,
validation, timeouts, provider rate limits, auth, malformed responses and 404
handling).

**Not yet verifiable in production:** a live deployment and a real
`APISPORTS_API_KEY`. Until both exist, `/sports/v1/*` endpoints return a
structured `503 PROVIDER_NOT_CONFIGURED` — the backend never serves fake
fixtures.

## Run locally

```bash
cd backend
export APISPORTS_API_KEY=your_real_provider_key   # obtain from api-sports.io
npm start                                          # listens on :3000
```

## Configuration (environment variables only — never commit secrets)

| Variable | Required | Default | Purpose |
| --- | --- | --- | --- |
| `APISPORTS_API_KEY` | for sports data | — | Provider key. Without it the sports namespace returns `503 PROVIDER_NOT_CONFIGURED`. |
| `PORT` | no | `3000` | Listen port. |
| `RATE_LIMIT_PER_MINUTE` | no | `60` | Per-IP request budget (fixed window). |
| `PROVIDER_TIMEOUT_MS` | no | `10000` | Upstream provider timeout. |
| `BACKEND_ACCESS_TOKEN` | no | — | If set, `/sports/v1/*` requires `Authorization: Bearer <token>`. |
| `BACKEND_VERSION` | no | `1.0.0` | Reported by `/version` and `/sports/v1/status`. |

Secret manager usage in production (Railway / Fly.io / AWS SSM / systemd
`EnvironmentFile`) is documented below.

## Endpoints

| Route | Description |
| --- | --- |
| `GET /health` | Liveness probe → `{"status":"ok"}` |
| `GET /version` | Backend name + version |
| `GET /sports/v1/status` | Backend + provider availability, supported sports list. Never contains the key. |
| `GET /sports/v1/{sport}/live` | Live fixtures for the sport |
| `GET /sports/v1/{sport}/fixtures?date=YYYY-MM-DD` (`league`/`season`/`id` optional) | Fixtures by day / league / id |
| `GET /sports/v1/{sport}/standings?league=&season=` | Competition standings |
| `GET /sports/v1/{sport}/teams?search=<term>` | Team search |

Supported `{sport}` values: `football, afl, baseball, basketball, formula1,
handball, hockey, mma, nba, american_football, rugby, volleyball`.

Responses are `{ "response": [...], "meta": { cached, fetchedAt, stale? } }`.
Errors are `{ "error": { "code": "...", "message": "..." } }`.

## Behaviour guarantees

* Request validation before any provider call (sport allow-list, ISO dates
  verified as real calendar days, positive-integer ids, 2–64 char searches).
* Per-IP rate limiting (`429 RATE_LIMITED` + `Retry-After`).
* TTL caching: live 30 s, fixtures 60 s, standings/teams 300 s. Aged cache
  entries are served as `stale: true` when the provider is failing, so the
  app can show a stale-data indicator instead of an empty screen.
* Provider failures map to structured errors: `503 PROVIDER_NOT_CONFIGURED`,
  `504 PROVIDER_TIMEOUT`, `429 PROVIDER_RATE_LIMITED`, `502 PROVIDER_*`.
* The provider key never appears in any response, log or error message.

## Deployment notes

* Single instance only — the rate limiter and cache are in-memory. Run one
  process per container and keep the container count at 1, or front it with a
  shared limiter (documented limitation).
* Set `APISPORTS_API_KEY` through your host's secret manager, never in the
  image or repo. Rotating the key requires only an environment change and a
  restart — no APK rebuild.
* Monitoring: `/health` for liveness, `/version` for release verification,
  4xx/5xx rates from your platform logs.

## Tests

```bash
npm test     # node --test test/api.test.js
```

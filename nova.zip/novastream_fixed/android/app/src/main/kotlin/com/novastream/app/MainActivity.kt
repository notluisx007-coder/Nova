package com.novastream.app

import android.app.PictureInPictureParams
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.util.Rational
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.novastream.app/platform"
    private var methodChannel: MethodChannel? = null

    @Volatile
    private var pipAutoEnter = false
    private var pipReportedInPip = false

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        methodChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).apply {
            setMethodCallHandler { call, result ->
                when (call.method) {
                    "isPipSupported" -> result.success(pipSupported())
                    "enterPiP" -> {
                        if (pipSupported()) {
                            val playing = call.argument<Boolean>("playing") ?: true
                            enterPictureInPictureMode(buildPipParams(playing))
                            result.success(true)
                        } else {
                            result.success(false)
                        }
                    }
                    "isInPiP" -> result.success(isInPipModeCompat())
                    "setPipAutoEnter" -> {
                        pipAutoEnter = call.argument<Boolean>("enabled") ?: false
                        result.success(null)
                    }
                    "getDeviceInfo" -> {
                        result.success(mapOf(
                            "sdkVersion" to Build.VERSION.SDK_INT,
                            "model" to Build.MODEL,
                            "manufacturer" to Build.MANUFACTURER,
                            "isTV" to isTelevision()
                        ))
                    }
                    else -> result.notImplemented()
                }
            }
        }
    }

    private fun pipSupported(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)

    private fun isInPipModeCompat(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false

    private fun buildPipParams(playing: Boolean): PictureInPictureParams {
        val builder = PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setAutoEnterEnabled(pipAutoEnter && playing)
        }
        return builder.build()
    }

    private fun isTelevision(): Boolean {
        return packageManager.hasSystemFeature("android.software.leanback")
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Auto-enter PiP when the user leaves the app during playback and the
        // Flutter player enabled auto-enter (API 31+ honours setAutoEnterEnabled;
        // older versions need this explicit call).
        if (pipAutoEnter && pipSupported() && !isInPipModeCompat()) {
            try {
                enterPictureInPictureMode(buildPipParams(true))
            } catch (_: IllegalStateException) {
                // e.g. not in a state that allows PiP — ignore.
            }
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        // Report PiP transitions to Flutter. `closed=true` is sent when the
        // user dismissed the PiP window, which finishes the activity — the
        // Flutter player then pops itself.
        if (isInPictureInPictureMode) {
            pipReportedInPip = true
            methodChannel?.invokeMethod("onPipChanged", true)
        } else if (pipReportedInPip) {
            pipReportedInPip = false
            val closed = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isFinishing else false
            methodChannel?.invokeMethod(
                "onPipChanged",
                mapOf("inPip" to false, "closed" to closed)
            )
        }
    }
}

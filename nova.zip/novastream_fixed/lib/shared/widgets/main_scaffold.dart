import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';

class MainScaffold extends StatelessWidget {
  final Widget child;
  const MainScaffold({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).matchedLocation;
    return Scaffold(
      body: child,
      bottomNavigationBar: _NovaBottomNav(currentLocation: location),
    );
  }
}

class _NovaBottomNav extends StatelessWidget {
  final String currentLocation;
  const _NovaBottomNav({required this.currentLocation});

  static const _navItems = [
    _NavItem(icon: Icons.home_rounded, label: 'Home', route: AppRoutes.home),
    _NavItem(icon: Icons.tv_rounded, label: 'Live TV', route: AppRoutes.liveTV),
    _NavItem(
        icon: Icons.sports_soccer_rounded,
        label: 'Sports',
        route: AppRoutes.sports),
    _NavItem(
        icon: Icons.calendar_view_week_rounded,
        label: 'Guide',
        route: AppRoutes.epg),
    _NavItem(
        icon: Icons.favorite_rounded,
        label: 'Favourites',
        route: AppRoutes.favorites),
  ];

  int _currentIndex() {
    for (int i = 0; i < _navItems.length; i++) {
      if (currentLocation == AppRoutes.home &&
          _navItems[i].route == AppRoutes.home) {
        return i;
      }
      if (_navItems[i].route != AppRoutes.home &&
          currentLocation.startsWith(_navItems[i].route)) {
        return i;
      }
    }
    return 0;
  }

  @override
  Widget build(BuildContext context) {
    final currentIndex = _currentIndex();
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceCard,
        border: const Border(
            top: BorderSide(color: AppTheme.surfaceBorder, width: 0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.3),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: _navItems.asMap().entries.map((entry) {
              final idx = entry.key;
              final item = entry.value;
              final isSelected = idx == currentIndex;
              return GestureDetector(
                onTap: () => context.go(item.route),
                behavior: HitTestBehavior.opaque,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppTheme.primaryCyan.withValues(alpha: 0.1)
                        : Colors.transparent,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        item.icon,
                        color: isSelected
                            ? AppTheme.primaryCyan
                            : AppTheme.textSecondary,
                        size: 22,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.label,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight:
                              isSelected ? FontWeight.w600 : FontWeight.w400,
                          color: isSelected
                              ? AppTheme.primaryCyan
                              : AppTheme.textSecondary,
                          fontFamily: 'Inter',
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  final String route;
  const _NavItem(
      {required this.icon, required this.label, required this.route});
}

import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class EmptyStateWidget extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;
  final Color? iconColor;

  const EmptyStateWidget({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
    this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color:
                    (iconColor ?? AppTheme.primaryCyan).withValues(alpha: 0.1),
              ),
              child: Icon(
                icon,
                size: 40,
                color: iconColor ?? AppTheme.primaryCyan,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 18,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              message,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 14,
                height: 1.5,
                fontFamily: 'Inter',
              ),
              textAlign: TextAlign.center,
            ),
            if (actionLabel != null && onAction != null) ...[
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: onAction,
                child: Text(actionLabel!),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class NotConfiguredWidget extends StatelessWidget {
  final String feature;
  final String setupMessage;
  final VoidCallback? onSetup;

  const NotConfiguredWidget({
    super.key,
    required this.feature,
    required this.setupMessage,
    this.onSetup,
  });

  @override
  Widget build(BuildContext context) {
    return EmptyStateWidget(
      icon: Icons.settings_suggest_rounded,
      title: '$feature Not Configured',
      message: setupMessage,
      actionLabel: 'Configure',
      onAction: onSetup,
      iconColor: AppTheme.statusWarning,
    );
  }
}

class ErrorStateWidget extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;

  const ErrorStateWidget({super.key, required this.message, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return EmptyStateWidget(
      icon: Icons.error_outline_rounded,
      title: 'Something went wrong',
      message: message,
      actionLabel: onRetry != null ? 'Retry' : null,
      onAction: onRetry,
      iconColor: AppTheme.statusError,
    );
  }
}

class OfflineStateWidget extends StatelessWidget {
  final VoidCallback? onRetry;

  const OfflineStateWidget({super.key, this.onRetry});

  @override
  Widget build(BuildContext context) {
    return EmptyStateWidget(
      icon: Icons.wifi_off_rounded,
      title: 'No Connection',
      message: 'Check your internet connection and try again.',
      actionLabel: 'Retry',
      onAction: onRetry,
      iconColor: AppTheme.statusWarning,
    );
  }
}

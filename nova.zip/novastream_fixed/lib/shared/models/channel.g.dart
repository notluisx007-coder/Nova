// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'channel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$IptvChannelImpl _$$IptvChannelImplFromJson(Map<String, dynamic> json) =>
    _$IptvChannelImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      logoUrl: json['logoUrl'] as String?,
      groupTitle: json['groupTitle'] as String?,
      tvgId: json['tvgId'] as String?,
      tvgName: json['tvgName'] as String?,
      country: json['country'] as String?,
      language: json['language'] as String?,
      categories: (json['categories'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      streamUrl: json['streamUrl'] as String,
      sourceId: json['sourceId'] as String,
      isFavorite: json['isFavorite'] as bool? ?? false,
      isHidden: json['isHidden'] as bool? ?? false,
      userOrder: (json['userOrder'] as num?)?.toInt(),
      rightsStatus:
          $enumDecodeNullable(_$RightsStatusEnumMap, json['rightsStatus']) ??
              RightsStatus.unknown,
      lastWatched: json['lastWatched'] == null
          ? null
          : DateTime.parse(json['lastWatched'] as String),
    );

Map<String, dynamic> _$$IptvChannelImplToJson(_$IptvChannelImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'logoUrl': instance.logoUrl,
      'groupTitle': instance.groupTitle,
      'tvgId': instance.tvgId,
      'tvgName': instance.tvgName,
      'country': instance.country,
      'language': instance.language,
      'categories': instance.categories,
      'streamUrl': instance.streamUrl,
      'sourceId': instance.sourceId,
      'isFavorite': instance.isFavorite,
      'isHidden': instance.isHidden,
      'userOrder': instance.userOrder,
      'rightsStatus': _$RightsStatusEnumMap[instance.rightsStatus]!,
      'lastWatched': instance.lastWatched?.toIso8601String(),
    };

const _$RightsStatusEnumMap = {
  RightsStatus.unknown: 'unknown',
  RightsStatus.verified: 'verified',
  RightsStatus.unverified: 'unverified',
  RightsStatus.restricted: 'restricted',
  RightsStatus.blocked: 'blocked',
};

_$EpgProgrammeImpl _$$EpgProgrammeImplFromJson(Map<String, dynamic> json) =>
    _$EpgProgrammeImpl(
      id: json['id'] as String,
      channelId: json['channelId'] as String,
      title: json['title'] as String,
      description: json['description'] as String?,
      category: json['category'] as String?,
      language: json['language'] as String?,
      startTime: DateTime.parse(json['startTime'] as String),
      endTime: DateTime.parse(json['endTime'] as String),
      sourceId: json['sourceId'] as String,
    );

Map<String, dynamic> _$$EpgProgrammeImplToJson(_$EpgProgrammeImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'channelId': instance.channelId,
      'title': instance.title,
      'description': instance.description,
      'category': instance.category,
      'language': instance.language,
      'startTime': instance.startTime.toIso8601String(),
      'endTime': instance.endTime.toIso8601String(),
      'sourceId': instance.sourceId,
    };

_$PlaylistSourceImpl _$$PlaylistSourceImplFromJson(Map<String, dynamic> json) =>
    _$PlaylistSourceImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      type: $enumDecode(_$PlaylistSourceTypeEnumMap, json['type']),
      url: json['url'] as String?,
      filePath: json['filePath'] as String?,
      username: json['username'] as String?,
      channelCount: (json['channelCount'] as num?)?.toInt() ?? 0,
      status: $enumDecodeNullable(_$SourceStatusEnumMap, json['status']) ??
          SourceStatus.unconfigured,
      lastError: json['lastError'] as String?,
      lastRefresh: json['lastRefresh'] == null
          ? null
          : DateTime.parse(json['lastRefresh'] as String),
      lastSuccess: json['lastSuccess'] == null
          ? null
          : DateTime.parse(json['lastSuccess'] as String),
      etag: json['etag'] as String?,
      priority: (json['priority'] as num?)?.toInt() ?? 100,
      isEnabled: json['isEnabled'] as bool? ?? true,
    );

Map<String, dynamic> _$$PlaylistSourceImplToJson(
        _$PlaylistSourceImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'type': _$PlaylistSourceTypeEnumMap[instance.type]!,
      'url': instance.url,
      'filePath': instance.filePath,
      'username': instance.username,
      'channelCount': instance.channelCount,
      'status': _$SourceStatusEnumMap[instance.status]!,
      'lastError': instance.lastError,
      'lastRefresh': instance.lastRefresh?.toIso8601String(),
      'lastSuccess': instance.lastSuccess?.toIso8601String(),
      'etag': instance.etag,
      'priority': instance.priority,
      'isEnabled': instance.isEnabled,
    };

const _$PlaylistSourceTypeEnumMap = {
  PlaylistSourceType.m3uUrl: 'm3uUrl',
  PlaylistSourceType.m3uFile: 'm3uFile',
  PlaylistSourceType.xtream: 'xtream',
  PlaylistSourceType.iptvOrg: 'iptvOrg',
};

const _$SourceStatusEnumMap = {
  SourceStatus.unconfigured: 'unconfigured',
  SourceStatus.connecting: 'connecting',
  SourceStatus.active: 'active',
  SourceStatus.error: 'error',
  SourceStatus.disabled: 'disabled',
  SourceStatus.refreshing: 'refreshing',
};

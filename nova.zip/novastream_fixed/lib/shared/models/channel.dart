import 'package:freezed_annotation/freezed_annotation.dart';

part 'channel.freezed.dart';
part 'channel.g.dart';

enum RightsStatus { unknown, verified, unverified, restricted, blocked }

enum StreamCheckStatus {
  unknown,
  notChecked,
  checking,
  available,
  unavailable,
  unsupported,
  geoLimited,
  stale
}

@freezed
class IptvChannel with _$IptvChannel {
  const factory IptvChannel({
    required String id,
    required String name,
    String? logoUrl,
    String? groupTitle,
    String? tvgId,
    String? tvgName,
    String? country,
    String? language,
    @Default([]) List<String> categories,
    required String streamUrl,
    required String sourceId,
    @Default(false) bool isFavorite,
    @Default(false) bool isHidden,
    int? userOrder,
    @Default(RightsStatus.unknown) RightsStatus rightsStatus,
    DateTime? lastWatched,
  }) = _IptvChannel;

  factory IptvChannel.fromJson(Map<String, dynamic> json) =>
      _$IptvChannelFromJson(json);
}

@freezed
class EpgProgramme with _$EpgProgramme {
  const factory EpgProgramme({
    required String id,
    required String channelId,
    required String title,
    String? description,
    String? category,
    String? language,
    required DateTime startTime,
    required DateTime endTime,
    required String sourceId,
  }) = _EpgProgramme;

  factory EpgProgramme.fromJson(Map<String, dynamic> json) =>
      _$EpgProgrammeFromJson(json);
}

@freezed
class PlaylistSource with _$PlaylistSource {
  const factory PlaylistSource({
    required String id,
    required String name,
    required PlaylistSourceType type,
    String? url,
    String? filePath,
    String? username,
    @Default(0) int channelCount,
    @Default(SourceStatus.unconfigured) SourceStatus status,
    String? lastError,
    DateTime? lastRefresh,
    DateTime? lastSuccess,
    String? etag,
    @Default(100) int priority,
    @Default(true) bool isEnabled,
  }) = _PlaylistSource;

  factory PlaylistSource.fromJson(Map<String, dynamic> json) =>
      _$PlaylistSourceFromJson(json);
}

enum PlaylistSourceType { m3uUrl, m3uFile, xtream, iptvOrg }

enum SourceStatus {
  unconfigured,
  connecting,
  active,
  error,
  disabled,
  refreshing
}

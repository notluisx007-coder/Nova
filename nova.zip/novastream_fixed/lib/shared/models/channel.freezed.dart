// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'channel.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

IptvChannel _$IptvChannelFromJson(Map<String, dynamic> json) {
  return _IptvChannel.fromJson(json);
}

/// @nodoc
mixin _$IptvChannel {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get logoUrl => throw _privateConstructorUsedError;
  String? get groupTitle => throw _privateConstructorUsedError;
  String? get tvgId => throw _privateConstructorUsedError;
  String? get tvgName => throw _privateConstructorUsedError;
  String? get country => throw _privateConstructorUsedError;
  String? get language => throw _privateConstructorUsedError;
  List<String> get categories => throw _privateConstructorUsedError;
  String get streamUrl => throw _privateConstructorUsedError;
  String get sourceId => throw _privateConstructorUsedError;
  bool get isFavorite => throw _privateConstructorUsedError;
  bool get isHidden => throw _privateConstructorUsedError;
  int? get userOrder => throw _privateConstructorUsedError;
  RightsStatus get rightsStatus => throw _privateConstructorUsedError;
  DateTime? get lastWatched => throw _privateConstructorUsedError;

  /// Serializes this IptvChannel to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of IptvChannel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $IptvChannelCopyWith<IptvChannel> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $IptvChannelCopyWith<$Res> {
  factory $IptvChannelCopyWith(
          IptvChannel value, $Res Function(IptvChannel) then) =
      _$IptvChannelCopyWithImpl<$Res, IptvChannel>;
  @useResult
  $Res call(
      {String id,
      String name,
      String? logoUrl,
      String? groupTitle,
      String? tvgId,
      String? tvgName,
      String? country,
      String? language,
      List<String> categories,
      String streamUrl,
      String sourceId,
      bool isFavorite,
      bool isHidden,
      int? userOrder,
      RightsStatus rightsStatus,
      DateTime? lastWatched});
}

/// @nodoc
class _$IptvChannelCopyWithImpl<$Res, $Val extends IptvChannel>
    implements $IptvChannelCopyWith<$Res> {
  _$IptvChannelCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of IptvChannel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? logoUrl = freezed,
    Object? groupTitle = freezed,
    Object? tvgId = freezed,
    Object? tvgName = freezed,
    Object? country = freezed,
    Object? language = freezed,
    Object? categories = null,
    Object? streamUrl = null,
    Object? sourceId = null,
    Object? isFavorite = null,
    Object? isHidden = null,
    Object? userOrder = freezed,
    Object? rightsStatus = null,
    Object? lastWatched = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      logoUrl: freezed == logoUrl
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      groupTitle: freezed == groupTitle
          ? _value.groupTitle
          : groupTitle // ignore: cast_nullable_to_non_nullable
              as String?,
      tvgId: freezed == tvgId
          ? _value.tvgId
          : tvgId // ignore: cast_nullable_to_non_nullable
              as String?,
      tvgName: freezed == tvgName
          ? _value.tvgName
          : tvgName // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      language: freezed == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String?,
      categories: null == categories
          ? _value.categories
          : categories // ignore: cast_nullable_to_non_nullable
              as List<String>,
      streamUrl: null == streamUrl
          ? _value.streamUrl
          : streamUrl // ignore: cast_nullable_to_non_nullable
              as String,
      sourceId: null == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String,
      isFavorite: null == isFavorite
          ? _value.isFavorite
          : isFavorite // ignore: cast_nullable_to_non_nullable
              as bool,
      isHidden: null == isHidden
          ? _value.isHidden
          : isHidden // ignore: cast_nullable_to_non_nullable
              as bool,
      userOrder: freezed == userOrder
          ? _value.userOrder
          : userOrder // ignore: cast_nullable_to_non_nullable
              as int?,
      rightsStatus: null == rightsStatus
          ? _value.rightsStatus
          : rightsStatus // ignore: cast_nullable_to_non_nullable
              as RightsStatus,
      lastWatched: freezed == lastWatched
          ? _value.lastWatched
          : lastWatched // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$IptvChannelImplCopyWith<$Res>
    implements $IptvChannelCopyWith<$Res> {
  factory _$$IptvChannelImplCopyWith(
          _$IptvChannelImpl value, $Res Function(_$IptvChannelImpl) then) =
      __$$IptvChannelImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      String? logoUrl,
      String? groupTitle,
      String? tvgId,
      String? tvgName,
      String? country,
      String? language,
      List<String> categories,
      String streamUrl,
      String sourceId,
      bool isFavorite,
      bool isHidden,
      int? userOrder,
      RightsStatus rightsStatus,
      DateTime? lastWatched});
}

/// @nodoc
class __$$IptvChannelImplCopyWithImpl<$Res>
    extends _$IptvChannelCopyWithImpl<$Res, _$IptvChannelImpl>
    implements _$$IptvChannelImplCopyWith<$Res> {
  __$$IptvChannelImplCopyWithImpl(
      _$IptvChannelImpl _value, $Res Function(_$IptvChannelImpl) _then)
      : super(_value, _then);

  /// Create a copy of IptvChannel
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? logoUrl = freezed,
    Object? groupTitle = freezed,
    Object? tvgId = freezed,
    Object? tvgName = freezed,
    Object? country = freezed,
    Object? language = freezed,
    Object? categories = null,
    Object? streamUrl = null,
    Object? sourceId = null,
    Object? isFavorite = null,
    Object? isHidden = null,
    Object? userOrder = freezed,
    Object? rightsStatus = null,
    Object? lastWatched = freezed,
  }) {
    return _then(_$IptvChannelImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      logoUrl: freezed == logoUrl
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      groupTitle: freezed == groupTitle
          ? _value.groupTitle
          : groupTitle // ignore: cast_nullable_to_non_nullable
              as String?,
      tvgId: freezed == tvgId
          ? _value.tvgId
          : tvgId // ignore: cast_nullable_to_non_nullable
              as String?,
      tvgName: freezed == tvgName
          ? _value.tvgName
          : tvgName // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      language: freezed == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String?,
      categories: null == categories
          ? _value._categories
          : categories // ignore: cast_nullable_to_non_nullable
              as List<String>,
      streamUrl: null == streamUrl
          ? _value.streamUrl
          : streamUrl // ignore: cast_nullable_to_non_nullable
              as String,
      sourceId: null == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String,
      isFavorite: null == isFavorite
          ? _value.isFavorite
          : isFavorite // ignore: cast_nullable_to_non_nullable
              as bool,
      isHidden: null == isHidden
          ? _value.isHidden
          : isHidden // ignore: cast_nullable_to_non_nullable
              as bool,
      userOrder: freezed == userOrder
          ? _value.userOrder
          : userOrder // ignore: cast_nullable_to_non_nullable
              as int?,
      rightsStatus: null == rightsStatus
          ? _value.rightsStatus
          : rightsStatus // ignore: cast_nullable_to_non_nullable
              as RightsStatus,
      lastWatched: freezed == lastWatched
          ? _value.lastWatched
          : lastWatched // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$IptvChannelImpl implements _IptvChannel {
  const _$IptvChannelImpl(
      {required this.id,
      required this.name,
      this.logoUrl,
      this.groupTitle,
      this.tvgId,
      this.tvgName,
      this.country,
      this.language,
      final List<String> categories = const [],
      required this.streamUrl,
      required this.sourceId,
      this.isFavorite = false,
      this.isHidden = false,
      this.userOrder,
      this.rightsStatus = RightsStatus.unknown,
      this.lastWatched})
      : _categories = categories;

  factory _$IptvChannelImpl.fromJson(Map<String, dynamic> json) =>
      _$$IptvChannelImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final String? logoUrl;
  @override
  final String? groupTitle;
  @override
  final String? tvgId;
  @override
  final String? tvgName;
  @override
  final String? country;
  @override
  final String? language;
  final List<String> _categories;
  @override
  @JsonKey()
  List<String> get categories {
    if (_categories is EqualUnmodifiableListView) return _categories;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_categories);
  }

  @override
  final String streamUrl;
  @override
  final String sourceId;
  @override
  @JsonKey()
  final bool isFavorite;
  @override
  @JsonKey()
  final bool isHidden;
  @override
  final int? userOrder;
  @override
  @JsonKey()
  final RightsStatus rightsStatus;
  @override
  final DateTime? lastWatched;

  @override
  String toString() {
    return 'IptvChannel(id: $id, name: $name, logoUrl: $logoUrl, groupTitle: $groupTitle, tvgId: $tvgId, tvgName: $tvgName, country: $country, language: $language, categories: $categories, streamUrl: $streamUrl, sourceId: $sourceId, isFavorite: $isFavorite, isHidden: $isHidden, userOrder: $userOrder, rightsStatus: $rightsStatus, lastWatched: $lastWatched)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$IptvChannelImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.logoUrl, logoUrl) || other.logoUrl == logoUrl) &&
            (identical(other.groupTitle, groupTitle) ||
                other.groupTitle == groupTitle) &&
            (identical(other.tvgId, tvgId) || other.tvgId == tvgId) &&
            (identical(other.tvgName, tvgName) || other.tvgName == tvgName) &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.language, language) ||
                other.language == language) &&
            const DeepCollectionEquality()
                .equals(other._categories, _categories) &&
            (identical(other.streamUrl, streamUrl) ||
                other.streamUrl == streamUrl) &&
            (identical(other.sourceId, sourceId) ||
                other.sourceId == sourceId) &&
            (identical(other.isFavorite, isFavorite) ||
                other.isFavorite == isFavorite) &&
            (identical(other.isHidden, isHidden) ||
                other.isHidden == isHidden) &&
            (identical(other.userOrder, userOrder) ||
                other.userOrder == userOrder) &&
            (identical(other.rightsStatus, rightsStatus) ||
                other.rightsStatus == rightsStatus) &&
            (identical(other.lastWatched, lastWatched) ||
                other.lastWatched == lastWatched));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      logoUrl,
      groupTitle,
      tvgId,
      tvgName,
      country,
      language,
      const DeepCollectionEquality().hash(_categories),
      streamUrl,
      sourceId,
      isFavorite,
      isHidden,
      userOrder,
      rightsStatus,
      lastWatched);

  /// Create a copy of IptvChannel
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$IptvChannelImplCopyWith<_$IptvChannelImpl> get copyWith =>
      __$$IptvChannelImplCopyWithImpl<_$IptvChannelImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$IptvChannelImplToJson(
      this,
    );
  }
}

abstract class _IptvChannel implements IptvChannel {
  const factory _IptvChannel(
      {required final String id,
      required final String name,
      final String? logoUrl,
      final String? groupTitle,
      final String? tvgId,
      final String? tvgName,
      final String? country,
      final String? language,
      final List<String> categories,
      required final String streamUrl,
      required final String sourceId,
      final bool isFavorite,
      final bool isHidden,
      final int? userOrder,
      final RightsStatus rightsStatus,
      final DateTime? lastWatched}) = _$IptvChannelImpl;

  factory _IptvChannel.fromJson(Map<String, dynamic> json) =
      _$IptvChannelImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  String? get logoUrl;
  @override
  String? get groupTitle;
  @override
  String? get tvgId;
  @override
  String? get tvgName;
  @override
  String? get country;
  @override
  String? get language;
  @override
  List<String> get categories;
  @override
  String get streamUrl;
  @override
  String get sourceId;
  @override
  bool get isFavorite;
  @override
  bool get isHidden;
  @override
  int? get userOrder;
  @override
  RightsStatus get rightsStatus;
  @override
  DateTime? get lastWatched;

  /// Create a copy of IptvChannel
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$IptvChannelImplCopyWith<_$IptvChannelImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

EpgProgramme _$EpgProgrammeFromJson(Map<String, dynamic> json) {
  return _EpgProgramme.fromJson(json);
}

/// @nodoc
mixin _$EpgProgramme {
  String get id => throw _privateConstructorUsedError;
  String get channelId => throw _privateConstructorUsedError;
  String get title => throw _privateConstructorUsedError;
  String? get description => throw _privateConstructorUsedError;
  String? get category => throw _privateConstructorUsedError;
  String? get language => throw _privateConstructorUsedError;
  DateTime get startTime => throw _privateConstructorUsedError;
  DateTime get endTime => throw _privateConstructorUsedError;
  String get sourceId => throw _privateConstructorUsedError;

  /// Serializes this EpgProgramme to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of EpgProgramme
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $EpgProgrammeCopyWith<EpgProgramme> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $EpgProgrammeCopyWith<$Res> {
  factory $EpgProgrammeCopyWith(
          EpgProgramme value, $Res Function(EpgProgramme) then) =
      _$EpgProgrammeCopyWithImpl<$Res, EpgProgramme>;
  @useResult
  $Res call(
      {String id,
      String channelId,
      String title,
      String? description,
      String? category,
      String? language,
      DateTime startTime,
      DateTime endTime,
      String sourceId});
}

/// @nodoc
class _$EpgProgrammeCopyWithImpl<$Res, $Val extends EpgProgramme>
    implements $EpgProgrammeCopyWith<$Res> {
  _$EpgProgrammeCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of EpgProgramme
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? channelId = null,
    Object? title = null,
    Object? description = freezed,
    Object? category = freezed,
    Object? language = freezed,
    Object? startTime = null,
    Object? endTime = null,
    Object? sourceId = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      channelId: null == channelId
          ? _value.channelId
          : channelId // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String?,
      language: freezed == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String?,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      endTime: null == endTime
          ? _value.endTime
          : endTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      sourceId: null == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$EpgProgrammeImplCopyWith<$Res>
    implements $EpgProgrammeCopyWith<$Res> {
  factory _$$EpgProgrammeImplCopyWith(
          _$EpgProgrammeImpl value, $Res Function(_$EpgProgrammeImpl) then) =
      __$$EpgProgrammeImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String channelId,
      String title,
      String? description,
      String? category,
      String? language,
      DateTime startTime,
      DateTime endTime,
      String sourceId});
}

/// @nodoc
class __$$EpgProgrammeImplCopyWithImpl<$Res>
    extends _$EpgProgrammeCopyWithImpl<$Res, _$EpgProgrammeImpl>
    implements _$$EpgProgrammeImplCopyWith<$Res> {
  __$$EpgProgrammeImplCopyWithImpl(
      _$EpgProgrammeImpl _value, $Res Function(_$EpgProgrammeImpl) _then)
      : super(_value, _then);

  /// Create a copy of EpgProgramme
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? channelId = null,
    Object? title = null,
    Object? description = freezed,
    Object? category = freezed,
    Object? language = freezed,
    Object? startTime = null,
    Object? endTime = null,
    Object? sourceId = null,
  }) {
    return _then(_$EpgProgrammeImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      channelId: null == channelId
          ? _value.channelId
          : channelId // ignore: cast_nullable_to_non_nullable
              as String,
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      description: freezed == description
          ? _value.description
          : description // ignore: cast_nullable_to_non_nullable
              as String?,
      category: freezed == category
          ? _value.category
          : category // ignore: cast_nullable_to_non_nullable
              as String?,
      language: freezed == language
          ? _value.language
          : language // ignore: cast_nullable_to_non_nullable
              as String?,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      endTime: null == endTime
          ? _value.endTime
          : endTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      sourceId: null == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$EpgProgrammeImpl implements _EpgProgramme {
  const _$EpgProgrammeImpl(
      {required this.id,
      required this.channelId,
      required this.title,
      this.description,
      this.category,
      this.language,
      required this.startTime,
      required this.endTime,
      required this.sourceId});

  factory _$EpgProgrammeImpl.fromJson(Map<String, dynamic> json) =>
      _$$EpgProgrammeImplFromJson(json);

  @override
  final String id;
  @override
  final String channelId;
  @override
  final String title;
  @override
  final String? description;
  @override
  final String? category;
  @override
  final String? language;
  @override
  final DateTime startTime;
  @override
  final DateTime endTime;
  @override
  final String sourceId;

  @override
  String toString() {
    return 'EpgProgramme(id: $id, channelId: $channelId, title: $title, description: $description, category: $category, language: $language, startTime: $startTime, endTime: $endTime, sourceId: $sourceId)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$EpgProgrammeImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.channelId, channelId) ||
                other.channelId == channelId) &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.description, description) ||
                other.description == description) &&
            (identical(other.category, category) ||
                other.category == category) &&
            (identical(other.language, language) ||
                other.language == language) &&
            (identical(other.startTime, startTime) ||
                other.startTime == startTime) &&
            (identical(other.endTime, endTime) || other.endTime == endTime) &&
            (identical(other.sourceId, sourceId) ||
                other.sourceId == sourceId));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, id, channelId, title,
      description, category, language, startTime, endTime, sourceId);

  /// Create a copy of EpgProgramme
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$EpgProgrammeImplCopyWith<_$EpgProgrammeImpl> get copyWith =>
      __$$EpgProgrammeImplCopyWithImpl<_$EpgProgrammeImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$EpgProgrammeImplToJson(
      this,
    );
  }
}

abstract class _EpgProgramme implements EpgProgramme {
  const factory _EpgProgramme(
      {required final String id,
      required final String channelId,
      required final String title,
      final String? description,
      final String? category,
      final String? language,
      required final DateTime startTime,
      required final DateTime endTime,
      required final String sourceId}) = _$EpgProgrammeImpl;

  factory _EpgProgramme.fromJson(Map<String, dynamic> json) =
      _$EpgProgrammeImpl.fromJson;

  @override
  String get id;
  @override
  String get channelId;
  @override
  String get title;
  @override
  String? get description;
  @override
  String? get category;
  @override
  String? get language;
  @override
  DateTime get startTime;
  @override
  DateTime get endTime;
  @override
  String get sourceId;

  /// Create a copy of EpgProgramme
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$EpgProgrammeImplCopyWith<_$EpgProgrammeImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

PlaylistSource _$PlaylistSourceFromJson(Map<String, dynamic> json) {
  return _PlaylistSource.fromJson(json);
}

/// @nodoc
mixin _$PlaylistSource {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  PlaylistSourceType get type => throw _privateConstructorUsedError;
  String? get url => throw _privateConstructorUsedError;
  String? get filePath => throw _privateConstructorUsedError;
  String? get username => throw _privateConstructorUsedError;
  int get channelCount => throw _privateConstructorUsedError;
  SourceStatus get status => throw _privateConstructorUsedError;
  String? get lastError => throw _privateConstructorUsedError;
  DateTime? get lastRefresh => throw _privateConstructorUsedError;
  DateTime? get lastSuccess => throw _privateConstructorUsedError;
  String? get etag => throw _privateConstructorUsedError;
  int get priority => throw _privateConstructorUsedError;
  bool get isEnabled => throw _privateConstructorUsedError;

  /// Serializes this PlaylistSource to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of PlaylistSource
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $PlaylistSourceCopyWith<PlaylistSource> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $PlaylistSourceCopyWith<$Res> {
  factory $PlaylistSourceCopyWith(
          PlaylistSource value, $Res Function(PlaylistSource) then) =
      _$PlaylistSourceCopyWithImpl<$Res, PlaylistSource>;
  @useResult
  $Res call(
      {String id,
      String name,
      PlaylistSourceType type,
      String? url,
      String? filePath,
      String? username,
      int channelCount,
      SourceStatus status,
      String? lastError,
      DateTime? lastRefresh,
      DateTime? lastSuccess,
      String? etag,
      int priority,
      bool isEnabled});
}

/// @nodoc
class _$PlaylistSourceCopyWithImpl<$Res, $Val extends PlaylistSource>
    implements $PlaylistSourceCopyWith<$Res> {
  _$PlaylistSourceCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of PlaylistSource
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? type = null,
    Object? url = freezed,
    Object? filePath = freezed,
    Object? username = freezed,
    Object? channelCount = null,
    Object? status = null,
    Object? lastError = freezed,
    Object? lastRefresh = freezed,
    Object? lastSuccess = freezed,
    Object? etag = freezed,
    Object? priority = null,
    Object? isEnabled = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as PlaylistSourceType,
      url: freezed == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String?,
      filePath: freezed == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String?,
      username: freezed == username
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String?,
      channelCount: null == channelCount
          ? _value.channelCount
          : channelCount // ignore: cast_nullable_to_non_nullable
              as int,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as SourceStatus,
      lastError: freezed == lastError
          ? _value.lastError
          : lastError // ignore: cast_nullable_to_non_nullable
              as String?,
      lastRefresh: freezed == lastRefresh
          ? _value.lastRefresh
          : lastRefresh // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      lastSuccess: freezed == lastSuccess
          ? _value.lastSuccess
          : lastSuccess // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      etag: freezed == etag
          ? _value.etag
          : etag // ignore: cast_nullable_to_non_nullable
              as String?,
      priority: null == priority
          ? _value.priority
          : priority // ignore: cast_nullable_to_non_nullable
              as int,
      isEnabled: null == isEnabled
          ? _value.isEnabled
          : isEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$PlaylistSourceImplCopyWith<$Res>
    implements $PlaylistSourceCopyWith<$Res> {
  factory _$$PlaylistSourceImplCopyWith(_$PlaylistSourceImpl value,
          $Res Function(_$PlaylistSourceImpl) then) =
      __$$PlaylistSourceImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      PlaylistSourceType type,
      String? url,
      String? filePath,
      String? username,
      int channelCount,
      SourceStatus status,
      String? lastError,
      DateTime? lastRefresh,
      DateTime? lastSuccess,
      String? etag,
      int priority,
      bool isEnabled});
}

/// @nodoc
class __$$PlaylistSourceImplCopyWithImpl<$Res>
    extends _$PlaylistSourceCopyWithImpl<$Res, _$PlaylistSourceImpl>
    implements _$$PlaylistSourceImplCopyWith<$Res> {
  __$$PlaylistSourceImplCopyWithImpl(
      _$PlaylistSourceImpl _value, $Res Function(_$PlaylistSourceImpl) _then)
      : super(_value, _then);

  /// Create a copy of PlaylistSource
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? type = null,
    Object? url = freezed,
    Object? filePath = freezed,
    Object? username = freezed,
    Object? channelCount = null,
    Object? status = null,
    Object? lastError = freezed,
    Object? lastRefresh = freezed,
    Object? lastSuccess = freezed,
    Object? etag = freezed,
    Object? priority = null,
    Object? isEnabled = null,
  }) {
    return _then(_$PlaylistSourceImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as PlaylistSourceType,
      url: freezed == url
          ? _value.url
          : url // ignore: cast_nullable_to_non_nullable
              as String?,
      filePath: freezed == filePath
          ? _value.filePath
          : filePath // ignore: cast_nullable_to_non_nullable
              as String?,
      username: freezed == username
          ? _value.username
          : username // ignore: cast_nullable_to_non_nullable
              as String?,
      channelCount: null == channelCount
          ? _value.channelCount
          : channelCount // ignore: cast_nullable_to_non_nullable
              as int,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as SourceStatus,
      lastError: freezed == lastError
          ? _value.lastError
          : lastError // ignore: cast_nullable_to_non_nullable
              as String?,
      lastRefresh: freezed == lastRefresh
          ? _value.lastRefresh
          : lastRefresh // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      lastSuccess: freezed == lastSuccess
          ? _value.lastSuccess
          : lastSuccess // ignore: cast_nullable_to_non_nullable
              as DateTime?,
      etag: freezed == etag
          ? _value.etag
          : etag // ignore: cast_nullable_to_non_nullable
              as String?,
      priority: null == priority
          ? _value.priority
          : priority // ignore: cast_nullable_to_non_nullable
              as int,
      isEnabled: null == isEnabled
          ? _value.isEnabled
          : isEnabled // ignore: cast_nullable_to_non_nullable
              as bool,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$PlaylistSourceImpl implements _PlaylistSource {
  const _$PlaylistSourceImpl(
      {required this.id,
      required this.name,
      required this.type,
      this.url,
      this.filePath,
      this.username,
      this.channelCount = 0,
      this.status = SourceStatus.unconfigured,
      this.lastError,
      this.lastRefresh,
      this.lastSuccess,
      this.etag,
      this.priority = 100,
      this.isEnabled = true});

  factory _$PlaylistSourceImpl.fromJson(Map<String, dynamic> json) =>
      _$$PlaylistSourceImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final PlaylistSourceType type;
  @override
  final String? url;
  @override
  final String? filePath;
  @override
  final String? username;
  @override
  @JsonKey()
  final int channelCount;
  @override
  @JsonKey()
  final SourceStatus status;
  @override
  final String? lastError;
  @override
  final DateTime? lastRefresh;
  @override
  final DateTime? lastSuccess;
  @override
  final String? etag;
  @override
  @JsonKey()
  final int priority;
  @override
  @JsonKey()
  final bool isEnabled;

  @override
  String toString() {
    return 'PlaylistSource(id: $id, name: $name, type: $type, url: $url, filePath: $filePath, username: $username, channelCount: $channelCount, status: $status, lastError: $lastError, lastRefresh: $lastRefresh, lastSuccess: $lastSuccess, etag: $etag, priority: $priority, isEnabled: $isEnabled)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$PlaylistSourceImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.type, type) || other.type == type) &&
            (identical(other.url, url) || other.url == url) &&
            (identical(other.filePath, filePath) ||
                other.filePath == filePath) &&
            (identical(other.username, username) ||
                other.username == username) &&
            (identical(other.channelCount, channelCount) ||
                other.channelCount == channelCount) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.lastError, lastError) ||
                other.lastError == lastError) &&
            (identical(other.lastRefresh, lastRefresh) ||
                other.lastRefresh == lastRefresh) &&
            (identical(other.lastSuccess, lastSuccess) ||
                other.lastSuccess == lastSuccess) &&
            (identical(other.etag, etag) || other.etag == etag) &&
            (identical(other.priority, priority) ||
                other.priority == priority) &&
            (identical(other.isEnabled, isEnabled) ||
                other.isEnabled == isEnabled));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      type,
      url,
      filePath,
      username,
      channelCount,
      status,
      lastError,
      lastRefresh,
      lastSuccess,
      etag,
      priority,
      isEnabled);

  /// Create a copy of PlaylistSource
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$PlaylistSourceImplCopyWith<_$PlaylistSourceImpl> get copyWith =>
      __$$PlaylistSourceImplCopyWithImpl<_$PlaylistSourceImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$PlaylistSourceImplToJson(
      this,
    );
  }
}

abstract class _PlaylistSource implements PlaylistSource {
  const factory _PlaylistSource(
      {required final String id,
      required final String name,
      required final PlaylistSourceType type,
      final String? url,
      final String? filePath,
      final String? username,
      final int channelCount,
      final SourceStatus status,
      final String? lastError,
      final DateTime? lastRefresh,
      final DateTime? lastSuccess,
      final String? etag,
      final int priority,
      final bool isEnabled}) = _$PlaylistSourceImpl;

  factory _PlaylistSource.fromJson(Map<String, dynamic> json) =
      _$PlaylistSourceImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  PlaylistSourceType get type;
  @override
  String? get url;
  @override
  String? get filePath;
  @override
  String? get username;
  @override
  int get channelCount;
  @override
  SourceStatus get status;
  @override
  String? get lastError;
  @override
  DateTime? get lastRefresh;
  @override
  DateTime? get lastSuccess;
  @override
  String? get etag;
  @override
  int get priority;
  @override
  bool get isEnabled;

  /// Create a copy of PlaylistSource
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$PlaylistSourceImplCopyWith<_$PlaylistSourceImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'sports.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

SportsEvent _$SportsEventFromJson(Map<String, dynamic> json) {
  return _SportsEvent.fromJson(json);
}

/// @nodoc
mixin _$SportsEvent {
  String get id => throw _privateConstructorUsedError;
  SportType get sport => throw _privateConstructorUsedError;
  String? get homeTeamId => throw _privateConstructorUsedError;
  String get homeTeamName => throw _privateConstructorUsedError;
  String? get homeTeamLogoUrl => throw _privateConstructorUsedError;
  String? get awayTeamId => throw _privateConstructorUsedError;
  String get awayTeamName => throw _privateConstructorUsedError;
  String? get awayTeamLogoUrl => throw _privateConstructorUsedError;
  String? get competitionId => throw _privateConstructorUsedError;
  String get competitionName => throw _privateConstructorUsedError;
  MatchStatus get status => throw _privateConstructorUsedError;
  String? get homeScore => throw _privateConstructorUsedError;
  String? get awayScore => throw _privateConstructorUsedError;
  DateTime get startTime => throw _privateConstructorUsedError;
  String? get venue => throw _privateConstructorUsedError;
  String? get matchMinute => throw _privateConstructorUsedError;
  Map<String, dynamic>? get metadata => throw _privateConstructorUsedError;
  String? get sourceId => throw _privateConstructorUsedError;
  DateTime? get cachedAt => throw _privateConstructorUsedError;

  /// Serializes this SportsEvent to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of SportsEvent
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SportsEventCopyWith<SportsEvent> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SportsEventCopyWith<$Res> {
  factory $SportsEventCopyWith(
          SportsEvent value, $Res Function(SportsEvent) then) =
      _$SportsEventCopyWithImpl<$Res, SportsEvent>;
  @useResult
  $Res call(
      {String id,
      SportType sport,
      String? homeTeamId,
      String homeTeamName,
      String? homeTeamLogoUrl,
      String? awayTeamId,
      String awayTeamName,
      String? awayTeamLogoUrl,
      String? competitionId,
      String competitionName,
      MatchStatus status,
      String? homeScore,
      String? awayScore,
      DateTime startTime,
      String? venue,
      String? matchMinute,
      Map<String, dynamic>? metadata,
      String? sourceId,
      DateTime? cachedAt});
}

/// @nodoc
class _$SportsEventCopyWithImpl<$Res, $Val extends SportsEvent>
    implements $SportsEventCopyWith<$Res> {
  _$SportsEventCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of SportsEvent
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? sport = null,
    Object? homeTeamId = freezed,
    Object? homeTeamName = null,
    Object? homeTeamLogoUrl = freezed,
    Object? awayTeamId = freezed,
    Object? awayTeamName = null,
    Object? awayTeamLogoUrl = freezed,
    Object? competitionId = freezed,
    Object? competitionName = null,
    Object? status = null,
    Object? homeScore = freezed,
    Object? awayScore = freezed,
    Object? startTime = null,
    Object? venue = freezed,
    Object? matchMinute = freezed,
    Object? metadata = freezed,
    Object? sourceId = freezed,
    Object? cachedAt = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      sport: null == sport
          ? _value.sport
          : sport // ignore: cast_nullable_to_non_nullable
              as SportType,
      homeTeamId: freezed == homeTeamId
          ? _value.homeTeamId
          : homeTeamId // ignore: cast_nullable_to_non_nullable
              as String?,
      homeTeamName: null == homeTeamName
          ? _value.homeTeamName
          : homeTeamName // ignore: cast_nullable_to_non_nullable
              as String,
      homeTeamLogoUrl: freezed == homeTeamLogoUrl
          ? _value.homeTeamLogoUrl
          : homeTeamLogoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      awayTeamId: freezed == awayTeamId
          ? _value.awayTeamId
          : awayTeamId // ignore: cast_nullable_to_non_nullable
              as String?,
      awayTeamName: null == awayTeamName
          ? _value.awayTeamName
          : awayTeamName // ignore: cast_nullable_to_non_nullable
              as String,
      awayTeamLogoUrl: freezed == awayTeamLogoUrl
          ? _value.awayTeamLogoUrl
          : awayTeamLogoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      competitionId: freezed == competitionId
          ? _value.competitionId
          : competitionId // ignore: cast_nullable_to_non_nullable
              as String?,
      competitionName: null == competitionName
          ? _value.competitionName
          : competitionName // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as MatchStatus,
      homeScore: freezed == homeScore
          ? _value.homeScore
          : homeScore // ignore: cast_nullable_to_non_nullable
              as String?,
      awayScore: freezed == awayScore
          ? _value.awayScore
          : awayScore // ignore: cast_nullable_to_non_nullable
              as String?,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      venue: freezed == venue
          ? _value.venue
          : venue // ignore: cast_nullable_to_non_nullable
              as String?,
      matchMinute: freezed == matchMinute
          ? _value.matchMinute
          : matchMinute // ignore: cast_nullable_to_non_nullable
              as String?,
      metadata: freezed == metadata
          ? _value.metadata
          : metadata // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      sourceId: freezed == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String?,
      cachedAt: freezed == cachedAt
          ? _value.cachedAt
          : cachedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SportsEventImplCopyWith<$Res>
    implements $SportsEventCopyWith<$Res> {
  factory _$$SportsEventImplCopyWith(
          _$SportsEventImpl value, $Res Function(_$SportsEventImpl) then) =
      __$$SportsEventImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      SportType sport,
      String? homeTeamId,
      String homeTeamName,
      String? homeTeamLogoUrl,
      String? awayTeamId,
      String awayTeamName,
      String? awayTeamLogoUrl,
      String? competitionId,
      String competitionName,
      MatchStatus status,
      String? homeScore,
      String? awayScore,
      DateTime startTime,
      String? venue,
      String? matchMinute,
      Map<String, dynamic>? metadata,
      String? sourceId,
      DateTime? cachedAt});
}

/// @nodoc
class __$$SportsEventImplCopyWithImpl<$Res>
    extends _$SportsEventCopyWithImpl<$Res, _$SportsEventImpl>
    implements _$$SportsEventImplCopyWith<$Res> {
  __$$SportsEventImplCopyWithImpl(
      _$SportsEventImpl _value, $Res Function(_$SportsEventImpl) _then)
      : super(_value, _then);

  /// Create a copy of SportsEvent
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? sport = null,
    Object? homeTeamId = freezed,
    Object? homeTeamName = null,
    Object? homeTeamLogoUrl = freezed,
    Object? awayTeamId = freezed,
    Object? awayTeamName = null,
    Object? awayTeamLogoUrl = freezed,
    Object? competitionId = freezed,
    Object? competitionName = null,
    Object? status = null,
    Object? homeScore = freezed,
    Object? awayScore = freezed,
    Object? startTime = null,
    Object? venue = freezed,
    Object? matchMinute = freezed,
    Object? metadata = freezed,
    Object? sourceId = freezed,
    Object? cachedAt = freezed,
  }) {
    return _then(_$SportsEventImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      sport: null == sport
          ? _value.sport
          : sport // ignore: cast_nullable_to_non_nullable
              as SportType,
      homeTeamId: freezed == homeTeamId
          ? _value.homeTeamId
          : homeTeamId // ignore: cast_nullable_to_non_nullable
              as String?,
      homeTeamName: null == homeTeamName
          ? _value.homeTeamName
          : homeTeamName // ignore: cast_nullable_to_non_nullable
              as String,
      homeTeamLogoUrl: freezed == homeTeamLogoUrl
          ? _value.homeTeamLogoUrl
          : homeTeamLogoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      awayTeamId: freezed == awayTeamId
          ? _value.awayTeamId
          : awayTeamId // ignore: cast_nullable_to_non_nullable
              as String?,
      awayTeamName: null == awayTeamName
          ? _value.awayTeamName
          : awayTeamName // ignore: cast_nullable_to_non_nullable
              as String,
      awayTeamLogoUrl: freezed == awayTeamLogoUrl
          ? _value.awayTeamLogoUrl
          : awayTeamLogoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      competitionId: freezed == competitionId
          ? _value.competitionId
          : competitionId // ignore: cast_nullable_to_non_nullable
              as String?,
      competitionName: null == competitionName
          ? _value.competitionName
          : competitionName // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as MatchStatus,
      homeScore: freezed == homeScore
          ? _value.homeScore
          : homeScore // ignore: cast_nullable_to_non_nullable
              as String?,
      awayScore: freezed == awayScore
          ? _value.awayScore
          : awayScore // ignore: cast_nullable_to_non_nullable
              as String?,
      startTime: null == startTime
          ? _value.startTime
          : startTime // ignore: cast_nullable_to_non_nullable
              as DateTime,
      venue: freezed == venue
          ? _value.venue
          : venue // ignore: cast_nullable_to_non_nullable
              as String?,
      matchMinute: freezed == matchMinute
          ? _value.matchMinute
          : matchMinute // ignore: cast_nullable_to_non_nullable
              as String?,
      metadata: freezed == metadata
          ? _value._metadata
          : metadata // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      sourceId: freezed == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String?,
      cachedAt: freezed == cachedAt
          ? _value.cachedAt
          : cachedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SportsEventImpl implements _SportsEvent {
  const _$SportsEventImpl(
      {required this.id,
      required this.sport,
      this.homeTeamId,
      required this.homeTeamName,
      this.homeTeamLogoUrl,
      this.awayTeamId,
      required this.awayTeamName,
      this.awayTeamLogoUrl,
      this.competitionId,
      required this.competitionName,
      required this.status,
      this.homeScore,
      this.awayScore,
      required this.startTime,
      this.venue,
      this.matchMinute,
      final Map<String, dynamic>? metadata,
      this.sourceId,
      this.cachedAt})
      : _metadata = metadata;

  factory _$SportsEventImpl.fromJson(Map<String, dynamic> json) =>
      _$$SportsEventImplFromJson(json);

  @override
  final String id;
  @override
  final SportType sport;
  @override
  final String? homeTeamId;
  @override
  final String homeTeamName;
  @override
  final String? homeTeamLogoUrl;
  @override
  final String? awayTeamId;
  @override
  final String awayTeamName;
  @override
  final String? awayTeamLogoUrl;
  @override
  final String? competitionId;
  @override
  final String competitionName;
  @override
  final MatchStatus status;
  @override
  final String? homeScore;
  @override
  final String? awayScore;
  @override
  final DateTime startTime;
  @override
  final String? venue;
  @override
  final String? matchMinute;
  final Map<String, dynamic>? _metadata;
  @override
  Map<String, dynamic>? get metadata {
    final value = _metadata;
    if (value == null) return null;
    if (_metadata is EqualUnmodifiableMapView) return _metadata;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  final String? sourceId;
  @override
  final DateTime? cachedAt;

  @override
  String toString() {
    return 'SportsEvent(id: $id, sport: $sport, homeTeamId: $homeTeamId, homeTeamName: $homeTeamName, homeTeamLogoUrl: $homeTeamLogoUrl, awayTeamId: $awayTeamId, awayTeamName: $awayTeamName, awayTeamLogoUrl: $awayTeamLogoUrl, competitionId: $competitionId, competitionName: $competitionName, status: $status, homeScore: $homeScore, awayScore: $awayScore, startTime: $startTime, venue: $venue, matchMinute: $matchMinute, metadata: $metadata, sourceId: $sourceId, cachedAt: $cachedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SportsEventImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.sport, sport) || other.sport == sport) &&
            (identical(other.homeTeamId, homeTeamId) ||
                other.homeTeamId == homeTeamId) &&
            (identical(other.homeTeamName, homeTeamName) ||
                other.homeTeamName == homeTeamName) &&
            (identical(other.homeTeamLogoUrl, homeTeamLogoUrl) ||
                other.homeTeamLogoUrl == homeTeamLogoUrl) &&
            (identical(other.awayTeamId, awayTeamId) ||
                other.awayTeamId == awayTeamId) &&
            (identical(other.awayTeamName, awayTeamName) ||
                other.awayTeamName == awayTeamName) &&
            (identical(other.awayTeamLogoUrl, awayTeamLogoUrl) ||
                other.awayTeamLogoUrl == awayTeamLogoUrl) &&
            (identical(other.competitionId, competitionId) ||
                other.competitionId == competitionId) &&
            (identical(other.competitionName, competitionName) ||
                other.competitionName == competitionName) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.homeScore, homeScore) ||
                other.homeScore == homeScore) &&
            (identical(other.awayScore, awayScore) ||
                other.awayScore == awayScore) &&
            (identical(other.startTime, startTime) ||
                other.startTime == startTime) &&
            (identical(other.venue, venue) || other.venue == venue) &&
            (identical(other.matchMinute, matchMinute) ||
                other.matchMinute == matchMinute) &&
            const DeepCollectionEquality().equals(other._metadata, _metadata) &&
            (identical(other.sourceId, sourceId) ||
                other.sourceId == sourceId) &&
            (identical(other.cachedAt, cachedAt) ||
                other.cachedAt == cachedAt));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hashAll([
        runtimeType,
        id,
        sport,
        homeTeamId,
        homeTeamName,
        homeTeamLogoUrl,
        awayTeamId,
        awayTeamName,
        awayTeamLogoUrl,
        competitionId,
        competitionName,
        status,
        homeScore,
        awayScore,
        startTime,
        venue,
        matchMinute,
        const DeepCollectionEquality().hash(_metadata),
        sourceId,
        cachedAt
      ]);

  /// Create a copy of SportsEvent
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SportsEventImplCopyWith<_$SportsEventImpl> get copyWith =>
      __$$SportsEventImplCopyWithImpl<_$SportsEventImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SportsEventImplToJson(
      this,
    );
  }
}

abstract class _SportsEvent implements SportsEvent {
  const factory _SportsEvent(
      {required final String id,
      required final SportType sport,
      final String? homeTeamId,
      required final String homeTeamName,
      final String? homeTeamLogoUrl,
      final String? awayTeamId,
      required final String awayTeamName,
      final String? awayTeamLogoUrl,
      final String? competitionId,
      required final String competitionName,
      required final MatchStatus status,
      final String? homeScore,
      final String? awayScore,
      required final DateTime startTime,
      final String? venue,
      final String? matchMinute,
      final Map<String, dynamic>? metadata,
      final String? sourceId,
      final DateTime? cachedAt}) = _$SportsEventImpl;

  factory _SportsEvent.fromJson(Map<String, dynamic> json) =
      _$SportsEventImpl.fromJson;

  @override
  String get id;
  @override
  SportType get sport;
  @override
  String? get homeTeamId;
  @override
  String get homeTeamName;
  @override
  String? get homeTeamLogoUrl;
  @override
  String? get awayTeamId;
  @override
  String get awayTeamName;
  @override
  String? get awayTeamLogoUrl;
  @override
  String? get competitionId;
  @override
  String get competitionName;
  @override
  MatchStatus get status;
  @override
  String? get homeScore;
  @override
  String? get awayScore;
  @override
  DateTime get startTime;
  @override
  String? get venue;
  @override
  String? get matchMinute;
  @override
  Map<String, dynamic>? get metadata;
  @override
  String? get sourceId;
  @override
  DateTime? get cachedAt;

  /// Create a copy of SportsEvent
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SportsEventImplCopyWith<_$SportsEventImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SportsTeam _$SportsTeamFromJson(Map<String, dynamic> json) {
  return _SportsTeam.fromJson(json);
}

/// @nodoc
mixin _$SportsTeam {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String? get shortName => throw _privateConstructorUsedError;
  String? get logoUrl => throw _privateConstructorUsedError;
  String? get country => throw _privateConstructorUsedError;
  SportType? get sport => throw _privateConstructorUsedError;
  String? get competitionId => throw _privateConstructorUsedError;
  Map<String, dynamic>? get metadata => throw _privateConstructorUsedError;

  /// Serializes this SportsTeam to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of SportsTeam
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SportsTeamCopyWith<SportsTeam> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SportsTeamCopyWith<$Res> {
  factory $SportsTeamCopyWith(
          SportsTeam value, $Res Function(SportsTeam) then) =
      _$SportsTeamCopyWithImpl<$Res, SportsTeam>;
  @useResult
  $Res call(
      {String id,
      String name,
      String? shortName,
      String? logoUrl,
      String? country,
      SportType? sport,
      String? competitionId,
      Map<String, dynamic>? metadata});
}

/// @nodoc
class _$SportsTeamCopyWithImpl<$Res, $Val extends SportsTeam>
    implements $SportsTeamCopyWith<$Res> {
  _$SportsTeamCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of SportsTeam
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? shortName = freezed,
    Object? logoUrl = freezed,
    Object? country = freezed,
    Object? sport = freezed,
    Object? competitionId = freezed,
    Object? metadata = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      shortName: freezed == shortName
          ? _value.shortName
          : shortName // ignore: cast_nullable_to_non_nullable
              as String?,
      logoUrl: freezed == logoUrl
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      sport: freezed == sport
          ? _value.sport
          : sport // ignore: cast_nullable_to_non_nullable
              as SportType?,
      competitionId: freezed == competitionId
          ? _value.competitionId
          : competitionId // ignore: cast_nullable_to_non_nullable
              as String?,
      metadata: freezed == metadata
          ? _value.metadata
          : metadata // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SportsTeamImplCopyWith<$Res>
    implements $SportsTeamCopyWith<$Res> {
  factory _$$SportsTeamImplCopyWith(
          _$SportsTeamImpl value, $Res Function(_$SportsTeamImpl) then) =
      __$$SportsTeamImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      String? shortName,
      String? logoUrl,
      String? country,
      SportType? sport,
      String? competitionId,
      Map<String, dynamic>? metadata});
}

/// @nodoc
class __$$SportsTeamImplCopyWithImpl<$Res>
    extends _$SportsTeamCopyWithImpl<$Res, _$SportsTeamImpl>
    implements _$$SportsTeamImplCopyWith<$Res> {
  __$$SportsTeamImplCopyWithImpl(
      _$SportsTeamImpl _value, $Res Function(_$SportsTeamImpl) _then)
      : super(_value, _then);

  /// Create a copy of SportsTeam
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? shortName = freezed,
    Object? logoUrl = freezed,
    Object? country = freezed,
    Object? sport = freezed,
    Object? competitionId = freezed,
    Object? metadata = freezed,
  }) {
    return _then(_$SportsTeamImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      shortName: freezed == shortName
          ? _value.shortName
          : shortName // ignore: cast_nullable_to_non_nullable
              as String?,
      logoUrl: freezed == logoUrl
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      sport: freezed == sport
          ? _value.sport
          : sport // ignore: cast_nullable_to_non_nullable
              as SportType?,
      competitionId: freezed == competitionId
          ? _value.competitionId
          : competitionId // ignore: cast_nullable_to_non_nullable
              as String?,
      metadata: freezed == metadata
          ? _value._metadata
          : metadata // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SportsTeamImpl implements _SportsTeam {
  const _$SportsTeamImpl(
      {required this.id,
      required this.name,
      this.shortName,
      this.logoUrl,
      this.country,
      this.sport,
      this.competitionId,
      final Map<String, dynamic>? metadata})
      : _metadata = metadata;

  factory _$SportsTeamImpl.fromJson(Map<String, dynamic> json) =>
      _$$SportsTeamImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final String? shortName;
  @override
  final String? logoUrl;
  @override
  final String? country;
  @override
  final SportType? sport;
  @override
  final String? competitionId;
  final Map<String, dynamic>? _metadata;
  @override
  Map<String, dynamic>? get metadata {
    final value = _metadata;
    if (value == null) return null;
    if (_metadata is EqualUnmodifiableMapView) return _metadata;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  String toString() {
    return 'SportsTeam(id: $id, name: $name, shortName: $shortName, logoUrl: $logoUrl, country: $country, sport: $sport, competitionId: $competitionId, metadata: $metadata)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SportsTeamImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.shortName, shortName) ||
                other.shortName == shortName) &&
            (identical(other.logoUrl, logoUrl) || other.logoUrl == logoUrl) &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.sport, sport) || other.sport == sport) &&
            (identical(other.competitionId, competitionId) ||
                other.competitionId == competitionId) &&
            const DeepCollectionEquality().equals(other._metadata, _metadata));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(
      runtimeType,
      id,
      name,
      shortName,
      logoUrl,
      country,
      sport,
      competitionId,
      const DeepCollectionEquality().hash(_metadata));

  /// Create a copy of SportsTeam
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SportsTeamImplCopyWith<_$SportsTeamImpl> get copyWith =>
      __$$SportsTeamImplCopyWithImpl<_$SportsTeamImpl>(this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SportsTeamImplToJson(
      this,
    );
  }
}

abstract class _SportsTeam implements SportsTeam {
  const factory _SportsTeam(
      {required final String id,
      required final String name,
      final String? shortName,
      final String? logoUrl,
      final String? country,
      final SportType? sport,
      final String? competitionId,
      final Map<String, dynamic>? metadata}) = _$SportsTeamImpl;

  factory _SportsTeam.fromJson(Map<String, dynamic> json) =
      _$SportsTeamImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  String? get shortName;
  @override
  String? get logoUrl;
  @override
  String? get country;
  @override
  SportType? get sport;
  @override
  String? get competitionId;
  @override
  Map<String, dynamic>? get metadata;

  /// Create a copy of SportsTeam
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SportsTeamImplCopyWith<_$SportsTeamImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

SportsCompetition _$SportsCompetitionFromJson(Map<String, dynamic> json) {
  return _SportsCompetition.fromJson(json);
}

/// @nodoc
mixin _$SportsCompetition {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  SportType get sport => throw _privateConstructorUsedError;
  String? get logoUrl => throw _privateConstructorUsedError;
  String? get country => throw _privateConstructorUsedError;
  String? get region => throw _privateConstructorUsedError;
  String? get season => throw _privateConstructorUsedError;
  Map<String, dynamic>? get metadata => throw _privateConstructorUsedError;

  /// Serializes this SportsCompetition to a JSON map.
  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;

  /// Create a copy of SportsCompetition
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $SportsCompetitionCopyWith<SportsCompetition> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $SportsCompetitionCopyWith<$Res> {
  factory $SportsCompetitionCopyWith(
          SportsCompetition value, $Res Function(SportsCompetition) then) =
      _$SportsCompetitionCopyWithImpl<$Res, SportsCompetition>;
  @useResult
  $Res call(
      {String id,
      String name,
      SportType sport,
      String? logoUrl,
      String? country,
      String? region,
      String? season,
      Map<String, dynamic>? metadata});
}

/// @nodoc
class _$SportsCompetitionCopyWithImpl<$Res, $Val extends SportsCompetition>
    implements $SportsCompetitionCopyWith<$Res> {
  _$SportsCompetitionCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of SportsCompetition
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? sport = null,
    Object? logoUrl = freezed,
    Object? country = freezed,
    Object? region = freezed,
    Object? season = freezed,
    Object? metadata = freezed,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      sport: null == sport
          ? _value.sport
          : sport // ignore: cast_nullable_to_non_nullable
              as SportType,
      logoUrl: freezed == logoUrl
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      region: freezed == region
          ? _value.region
          : region // ignore: cast_nullable_to_non_nullable
              as String?,
      season: freezed == season
          ? _value.season
          : season // ignore: cast_nullable_to_non_nullable
              as String?,
      metadata: freezed == metadata
          ? _value.metadata
          : metadata // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$SportsCompetitionImplCopyWith<$Res>
    implements $SportsCompetitionCopyWith<$Res> {
  factory _$$SportsCompetitionImplCopyWith(_$SportsCompetitionImpl value,
          $Res Function(_$SportsCompetitionImpl) then) =
      __$$SportsCompetitionImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      SportType sport,
      String? logoUrl,
      String? country,
      String? region,
      String? season,
      Map<String, dynamic>? metadata});
}

/// @nodoc
class __$$SportsCompetitionImplCopyWithImpl<$Res>
    extends _$SportsCompetitionCopyWithImpl<$Res, _$SportsCompetitionImpl>
    implements _$$SportsCompetitionImplCopyWith<$Res> {
  __$$SportsCompetitionImplCopyWithImpl(_$SportsCompetitionImpl _value,
      $Res Function(_$SportsCompetitionImpl) _then)
      : super(_value, _then);

  /// Create a copy of SportsCompetition
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? sport = null,
    Object? logoUrl = freezed,
    Object? country = freezed,
    Object? region = freezed,
    Object? season = freezed,
    Object? metadata = freezed,
  }) {
    return _then(_$SportsCompetitionImpl(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      sport: null == sport
          ? _value.sport
          : sport // ignore: cast_nullable_to_non_nullable
              as SportType,
      logoUrl: freezed == logoUrl
          ? _value.logoUrl
          : logoUrl // ignore: cast_nullable_to_non_nullable
              as String?,
      country: freezed == country
          ? _value.country
          : country // ignore: cast_nullable_to_non_nullable
              as String?,
      region: freezed == region
          ? _value.region
          : region // ignore: cast_nullable_to_non_nullable
              as String?,
      season: freezed == season
          ? _value.season
          : season // ignore: cast_nullable_to_non_nullable
              as String?,
      metadata: freezed == metadata
          ? _value._metadata
          : metadata // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$SportsCompetitionImpl implements _SportsCompetition {
  const _$SportsCompetitionImpl(
      {required this.id,
      required this.name,
      required this.sport,
      this.logoUrl,
      this.country,
      this.region,
      this.season,
      final Map<String, dynamic>? metadata})
      : _metadata = metadata;

  factory _$SportsCompetitionImpl.fromJson(Map<String, dynamic> json) =>
      _$$SportsCompetitionImplFromJson(json);

  @override
  final String id;
  @override
  final String name;
  @override
  final SportType sport;
  @override
  final String? logoUrl;
  @override
  final String? country;
  @override
  final String? region;
  @override
  final String? season;
  final Map<String, dynamic>? _metadata;
  @override
  Map<String, dynamic>? get metadata {
    final value = _metadata;
    if (value == null) return null;
    if (_metadata is EqualUnmodifiableMapView) return _metadata;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  @override
  String toString() {
    return 'SportsCompetition(id: $id, name: $name, sport: $sport, logoUrl: $logoUrl, country: $country, region: $region, season: $season, metadata: $metadata)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$SportsCompetitionImpl &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.sport, sport) || other.sport == sport) &&
            (identical(other.logoUrl, logoUrl) || other.logoUrl == logoUrl) &&
            (identical(other.country, country) || other.country == country) &&
            (identical(other.region, region) || other.region == region) &&
            (identical(other.season, season) || other.season == season) &&
            const DeepCollectionEquality().equals(other._metadata, _metadata));
  }

  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  int get hashCode => Object.hash(runtimeType, id, name, sport, logoUrl,
      country, region, season, const DeepCollectionEquality().hash(_metadata));

  /// Create a copy of SportsCompetition
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$SportsCompetitionImplCopyWith<_$SportsCompetitionImpl> get copyWith =>
      __$$SportsCompetitionImplCopyWithImpl<_$SportsCompetitionImpl>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$SportsCompetitionImplToJson(
      this,
    );
  }
}

abstract class _SportsCompetition implements SportsCompetition {
  const factory _SportsCompetition(
      {required final String id,
      required final String name,
      required final SportType sport,
      final String? logoUrl,
      final String? country,
      final String? region,
      final String? season,
      final Map<String, dynamic>? metadata}) = _$SportsCompetitionImpl;

  factory _SportsCompetition.fromJson(Map<String, dynamic> json) =
      _$SportsCompetitionImpl.fromJson;

  @override
  String get id;
  @override
  String get name;
  @override
  SportType get sport;
  @override
  String? get logoUrl;
  @override
  String? get country;
  @override
  String? get region;
  @override
  String? get season;
  @override
  Map<String, dynamic>? get metadata;

  /// Create a copy of SportsCompetition
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$SportsCompetitionImplCopyWith<_$SportsCompetitionImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$MatchDetail {
  SportsEvent get event => throw _privateConstructorUsedError;
  Map<String, dynamic>? get homeTeamStats => throw _privateConstructorUsedError;
  Map<String, dynamic>? get awayTeamStats => throw _privateConstructorUsedError;
  List<Map<String, dynamic>>? get timeline =>
      throw _privateConstructorUsedError;
  List<Map<String, dynamic>>? get homeLineup =>
      throw _privateConstructorUsedError;
  List<Map<String, dynamic>>? get awayLineup =>
      throw _privateConstructorUsedError;
  List<SportsEvent>? get previousMeetings => throw _privateConstructorUsedError;
  String? get sourceId => throw _privateConstructorUsedError;
  DateTime? get fetchedAt => throw _privateConstructorUsedError;

  /// Create a copy of MatchDetail
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  $MatchDetailCopyWith<MatchDetail> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MatchDetailCopyWith<$Res> {
  factory $MatchDetailCopyWith(
          MatchDetail value, $Res Function(MatchDetail) then) =
      _$MatchDetailCopyWithImpl<$Res, MatchDetail>;
  @useResult
  $Res call(
      {SportsEvent event,
      Map<String, dynamic>? homeTeamStats,
      Map<String, dynamic>? awayTeamStats,
      List<Map<String, dynamic>>? timeline,
      List<Map<String, dynamic>>? homeLineup,
      List<Map<String, dynamic>>? awayLineup,
      List<SportsEvent>? previousMeetings,
      String? sourceId,
      DateTime? fetchedAt});

  $SportsEventCopyWith<$Res> get event;
}

/// @nodoc
class _$MatchDetailCopyWithImpl<$Res, $Val extends MatchDetail>
    implements $MatchDetailCopyWith<$Res> {
  _$MatchDetailCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  /// Create a copy of MatchDetail
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? event = null,
    Object? homeTeamStats = freezed,
    Object? awayTeamStats = freezed,
    Object? timeline = freezed,
    Object? homeLineup = freezed,
    Object? awayLineup = freezed,
    Object? previousMeetings = freezed,
    Object? sourceId = freezed,
    Object? fetchedAt = freezed,
  }) {
    return _then(_value.copyWith(
      event: null == event
          ? _value.event
          : event // ignore: cast_nullable_to_non_nullable
              as SportsEvent,
      homeTeamStats: freezed == homeTeamStats
          ? _value.homeTeamStats
          : homeTeamStats // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      awayTeamStats: freezed == awayTeamStats
          ? _value.awayTeamStats
          : awayTeamStats // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      timeline: freezed == timeline
          ? _value.timeline
          : timeline // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>?,
      homeLineup: freezed == homeLineup
          ? _value.homeLineup
          : homeLineup // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>?,
      awayLineup: freezed == awayLineup
          ? _value.awayLineup
          : awayLineup // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>?,
      previousMeetings: freezed == previousMeetings
          ? _value.previousMeetings
          : previousMeetings // ignore: cast_nullable_to_non_nullable
              as List<SportsEvent>?,
      sourceId: freezed == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String?,
      fetchedAt: freezed == fetchedAt
          ? _value.fetchedAt
          : fetchedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ) as $Val);
  }

  /// Create a copy of MatchDetail
  /// with the given fields replaced by the non-null parameter values.
  @override
  @pragma('vm:prefer-inline')
  $SportsEventCopyWith<$Res> get event {
    return $SportsEventCopyWith<$Res>(_value.event, (value) {
      return _then(_value.copyWith(event: value) as $Val);
    });
  }
}

/// @nodoc
abstract class _$$MatchDetailImplCopyWith<$Res>
    implements $MatchDetailCopyWith<$Res> {
  factory _$$MatchDetailImplCopyWith(
          _$MatchDetailImpl value, $Res Function(_$MatchDetailImpl) then) =
      __$$MatchDetailImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {SportsEvent event,
      Map<String, dynamic>? homeTeamStats,
      Map<String, dynamic>? awayTeamStats,
      List<Map<String, dynamic>>? timeline,
      List<Map<String, dynamic>>? homeLineup,
      List<Map<String, dynamic>>? awayLineup,
      List<SportsEvent>? previousMeetings,
      String? sourceId,
      DateTime? fetchedAt});

  @override
  $SportsEventCopyWith<$Res> get event;
}

/// @nodoc
class __$$MatchDetailImplCopyWithImpl<$Res>
    extends _$MatchDetailCopyWithImpl<$Res, _$MatchDetailImpl>
    implements _$$MatchDetailImplCopyWith<$Res> {
  __$$MatchDetailImplCopyWithImpl(
      _$MatchDetailImpl _value, $Res Function(_$MatchDetailImpl) _then)
      : super(_value, _then);

  /// Create a copy of MatchDetail
  /// with the given fields replaced by the non-null parameter values.
  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? event = null,
    Object? homeTeamStats = freezed,
    Object? awayTeamStats = freezed,
    Object? timeline = freezed,
    Object? homeLineup = freezed,
    Object? awayLineup = freezed,
    Object? previousMeetings = freezed,
    Object? sourceId = freezed,
    Object? fetchedAt = freezed,
  }) {
    return _then(_$MatchDetailImpl(
      event: null == event
          ? _value.event
          : event // ignore: cast_nullable_to_non_nullable
              as SportsEvent,
      homeTeamStats: freezed == homeTeamStats
          ? _value._homeTeamStats
          : homeTeamStats // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      awayTeamStats: freezed == awayTeamStats
          ? _value._awayTeamStats
          : awayTeamStats // ignore: cast_nullable_to_non_nullable
              as Map<String, dynamic>?,
      timeline: freezed == timeline
          ? _value._timeline
          : timeline // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>?,
      homeLineup: freezed == homeLineup
          ? _value._homeLineup
          : homeLineup // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>?,
      awayLineup: freezed == awayLineup
          ? _value._awayLineup
          : awayLineup // ignore: cast_nullable_to_non_nullable
              as List<Map<String, dynamic>>?,
      previousMeetings: freezed == previousMeetings
          ? _value._previousMeetings
          : previousMeetings // ignore: cast_nullable_to_non_nullable
              as List<SportsEvent>?,
      sourceId: freezed == sourceId
          ? _value.sourceId
          : sourceId // ignore: cast_nullable_to_non_nullable
              as String?,
      fetchedAt: freezed == fetchedAt
          ? _value.fetchedAt
          : fetchedAt // ignore: cast_nullable_to_non_nullable
              as DateTime?,
    ));
  }
}

/// @nodoc

class _$MatchDetailImpl implements _MatchDetail {
  const _$MatchDetailImpl(
      {required this.event,
      final Map<String, dynamic>? homeTeamStats,
      final Map<String, dynamic>? awayTeamStats,
      final List<Map<String, dynamic>>? timeline,
      final List<Map<String, dynamic>>? homeLineup,
      final List<Map<String, dynamic>>? awayLineup,
      final List<SportsEvent>? previousMeetings,
      this.sourceId,
      this.fetchedAt})
      : _homeTeamStats = homeTeamStats,
        _awayTeamStats = awayTeamStats,
        _timeline = timeline,
        _homeLineup = homeLineup,
        _awayLineup = awayLineup,
        _previousMeetings = previousMeetings;

  @override
  final SportsEvent event;
  final Map<String, dynamic>? _homeTeamStats;
  @override
  Map<String, dynamic>? get homeTeamStats {
    final value = _homeTeamStats;
    if (value == null) return null;
    if (_homeTeamStats is EqualUnmodifiableMapView) return _homeTeamStats;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  final Map<String, dynamic>? _awayTeamStats;
  @override
  Map<String, dynamic>? get awayTeamStats {
    final value = _awayTeamStats;
    if (value == null) return null;
    if (_awayTeamStats is EqualUnmodifiableMapView) return _awayTeamStats;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableMapView(value);
  }

  final List<Map<String, dynamic>>? _timeline;
  @override
  List<Map<String, dynamic>>? get timeline {
    final value = _timeline;
    if (value == null) return null;
    if (_timeline is EqualUnmodifiableListView) return _timeline;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Map<String, dynamic>>? _homeLineup;
  @override
  List<Map<String, dynamic>>? get homeLineup {
    final value = _homeLineup;
    if (value == null) return null;
    if (_homeLineup is EqualUnmodifiableListView) return _homeLineup;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<Map<String, dynamic>>? _awayLineup;
  @override
  List<Map<String, dynamic>>? get awayLineup {
    final value = _awayLineup;
    if (value == null) return null;
    if (_awayLineup is EqualUnmodifiableListView) return _awayLineup;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  final List<SportsEvent>? _previousMeetings;
  @override
  List<SportsEvent>? get previousMeetings {
    final value = _previousMeetings;
    if (value == null) return null;
    if (_previousMeetings is EqualUnmodifiableListView)
      return _previousMeetings;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(value);
  }

  @override
  final String? sourceId;
  @override
  final DateTime? fetchedAt;

  @override
  String toString() {
    return 'MatchDetail(event: $event, homeTeamStats: $homeTeamStats, awayTeamStats: $awayTeamStats, timeline: $timeline, homeLineup: $homeLineup, awayLineup: $awayLineup, previousMeetings: $previousMeetings, sourceId: $sourceId, fetchedAt: $fetchedAt)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MatchDetailImpl &&
            (identical(other.event, event) || other.event == event) &&
            const DeepCollectionEquality()
                .equals(other._homeTeamStats, _homeTeamStats) &&
            const DeepCollectionEquality()
                .equals(other._awayTeamStats, _awayTeamStats) &&
            const DeepCollectionEquality().equals(other._timeline, _timeline) &&
            const DeepCollectionEquality()
                .equals(other._homeLineup, _homeLineup) &&
            const DeepCollectionEquality()
                .equals(other._awayLineup, _awayLineup) &&
            const DeepCollectionEquality()
                .equals(other._previousMeetings, _previousMeetings) &&
            (identical(other.sourceId, sourceId) ||
                other.sourceId == sourceId) &&
            (identical(other.fetchedAt, fetchedAt) ||
                other.fetchedAt == fetchedAt));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      event,
      const DeepCollectionEquality().hash(_homeTeamStats),
      const DeepCollectionEquality().hash(_awayTeamStats),
      const DeepCollectionEquality().hash(_timeline),
      const DeepCollectionEquality().hash(_homeLineup),
      const DeepCollectionEquality().hash(_awayLineup),
      const DeepCollectionEquality().hash(_previousMeetings),
      sourceId,
      fetchedAt);

  /// Create a copy of MatchDetail
  /// with the given fields replaced by the non-null parameter values.
  @JsonKey(includeFromJson: false, includeToJson: false)
  @override
  @pragma('vm:prefer-inline')
  _$$MatchDetailImplCopyWith<_$MatchDetailImpl> get copyWith =>
      __$$MatchDetailImplCopyWithImpl<_$MatchDetailImpl>(this, _$identity);
}

abstract class _MatchDetail implements MatchDetail {
  const factory _MatchDetail(
      {required final SportsEvent event,
      final Map<String, dynamic>? homeTeamStats,
      final Map<String, dynamic>? awayTeamStats,
      final List<Map<String, dynamic>>? timeline,
      final List<Map<String, dynamic>>? homeLineup,
      final List<Map<String, dynamic>>? awayLineup,
      final List<SportsEvent>? previousMeetings,
      final String? sourceId,
      final DateTime? fetchedAt}) = _$MatchDetailImpl;

  @override
  SportsEvent get event;
  @override
  Map<String, dynamic>? get homeTeamStats;
  @override
  Map<String, dynamic>? get awayTeamStats;
  @override
  List<Map<String, dynamic>>? get timeline;
  @override
  List<Map<String, dynamic>>? get homeLineup;
  @override
  List<Map<String, dynamic>>? get awayLineup;
  @override
  List<SportsEvent>? get previousMeetings;
  @override
  String? get sourceId;
  @override
  DateTime? get fetchedAt;

  /// Create a copy of MatchDetail
  /// with the given fields replaced by the non-null parameter values.
  @override
  @JsonKey(includeFromJson: false, includeToJson: false)
  _$$MatchDetailImplCopyWith<_$MatchDetailImpl> get copyWith =>
      throw _privateConstructorUsedError;
}

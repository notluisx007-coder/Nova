import 'package:freezed_annotation/freezed_annotation.dart';

part 'sports.freezed.dart';
part 'sports.g.dart';

enum SportType {
  football,
  afl,
  baseball,
  basketball,
  formula1,
  handball,
  hockey,
  mma,
  nba,
  americanFootball,
  rugby,
  volleyball,
  other,
}

enum MatchStatus {
  scheduled,
  live,
  halfTime,
  finished,
  postponed,
  cancelled,
  suspended,
  unknown,
}

extension MatchStatusX on MatchStatus {
  String get displayName => switch (this) {
        MatchStatus.scheduled => 'Scheduled',
        MatchStatus.live => 'LIVE',
        MatchStatus.halfTime => 'HT',
        MatchStatus.finished => 'FT',
        MatchStatus.postponed => 'Postponed',
        MatchStatus.cancelled => 'Cancelled',
        MatchStatus.suspended => 'Suspended',
        MatchStatus.unknown => 'Unknown',
      };

  bool get isLive => this == MatchStatus.live || this == MatchStatus.halfTime;
}

extension SportTypeX on SportType {
  String get displayName => switch (this) {
        SportType.football => 'Football',
        SportType.afl => 'AFL',
        SportType.baseball => 'Baseball',
        SportType.basketball => 'Basketball',
        SportType.formula1 => 'Formula 1',
        SportType.handball => 'Handball',
        SportType.hockey => 'Hockey',
        SportType.mma => 'MMA',
        SportType.nba => 'NBA',
        SportType.americanFootball => 'NFL / American Football',
        SportType.rugby => 'Rugby',
        SportType.volleyball => 'Volleyball',
        SportType.other => 'Other',
      };

  String get icon => switch (this) {
        SportType.football => '⚽',
        SportType.afl => '🏉',
        SportType.baseball => '⚾',
        SportType.basketball => '🏀',
        SportType.formula1 => '🏎️',
        SportType.handball => '🤾',
        SportType.hockey => '🏒',
        SportType.mma => '🥊',
        SportType.nba => '🏀',
        SportType.americanFootball => '🏈',
        SportType.rugby => '🏉',
        SportType.volleyball => '🏐',
        SportType.other => '🏆',
      };

  String get apiKey => switch (this) {
        SportType.football => 'football',
        SportType.afl => 'afl',
        SportType.baseball => 'baseball',
        SportType.basketball => 'basketball',
        SportType.formula1 => 'formula1',
        SportType.handball => 'handball',
        SportType.hockey => 'hockey',
        SportType.mma => 'mma',
        SportType.nba => 'nba',
        SportType.americanFootball => 'american_football',
        SportType.rugby => 'rugby',
        SportType.volleyball => 'volleyball',
        SportType.other => '',
      };
}

@freezed
class SportsEvent with _$SportsEvent {
  const factory SportsEvent({
    required String id,
    required SportType sport,
    String? homeTeamId,
    required String homeTeamName,
    String? homeTeamLogoUrl,
    String? awayTeamId,
    required String awayTeamName,
    String? awayTeamLogoUrl,
    String? competitionId,
    required String competitionName,
    required MatchStatus status,
    String? homeScore,
    String? awayScore,
    required DateTime startTime,
    String? venue,
    String? matchMinute,
    Map<String, dynamic>? metadata,
    String? sourceId,
    DateTime? cachedAt,
  }) = _SportsEvent;

  factory SportsEvent.fromJson(Map<String, dynamic> json) =>
      _$SportsEventFromJson(json);
}

@freezed
class SportsTeam with _$SportsTeam {
  const factory SportsTeam({
    required String id,
    required String name,
    String? shortName,
    String? logoUrl,
    String? country,
    SportType? sport,
    String? competitionId,
    Map<String, dynamic>? metadata,
  }) = _SportsTeam;

  factory SportsTeam.fromJson(Map<String, dynamic> json) =>
      _$SportsTeamFromJson(json);
}

@freezed
class SportsCompetition with _$SportsCompetition {
  const factory SportsCompetition({
    required String id,
    required String name,
    required SportType sport,
    String? logoUrl,
    String? country,
    String? region,
    String? season,
    Map<String, dynamic>? metadata,
  }) = _SportsCompetition;

  factory SportsCompetition.fromJson(Map<String, dynamic> json) =>
      _$SportsCompetitionFromJson(json);
}

@freezed
class MatchDetail with _$MatchDetail {
  const factory MatchDetail({
    required SportsEvent event,
    Map<String, dynamic>? homeTeamStats,
    Map<String, dynamic>? awayTeamStats,
    List<Map<String, dynamic>>? timeline,
    List<Map<String, dynamic>>? homeLineup,
    List<Map<String, dynamic>>? awayLineup,
    List<SportsEvent>? previousMeetings,
    String? sourceId,
    DateTime? fetchedAt,
  }) = _MatchDetail;
}

/// Null/offline sports provider: every method returns an honest empty
/// result — nothing is ever faked as real fixture data.
class NullSportsProvider {
  bool get isConfigured => false;
  Future<List<SportsEvent>> getLiveEvents() async => [];
  Future<List<SportsEvent>> getUpcomingEvents() async => [];
  Future<List<SportsEvent>> getFinishedEvents() async => [];
  Future<List<SportsTeam>> searchTeams(String query) async => [];
  Future<List<SportsEvent>> getCompetitions() async => [];
}

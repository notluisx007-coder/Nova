// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sports.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SportsEventImpl _$$SportsEventImplFromJson(Map<String, dynamic> json) =>
    _$SportsEventImpl(
      id: json['id'] as String,
      sport: $enumDecode(_$SportTypeEnumMap, json['sport']),
      homeTeamId: json['homeTeamId'] as String?,
      homeTeamName: json['homeTeamName'] as String,
      homeTeamLogoUrl: json['homeTeamLogoUrl'] as String?,
      awayTeamId: json['awayTeamId'] as String?,
      awayTeamName: json['awayTeamName'] as String,
      awayTeamLogoUrl: json['awayTeamLogoUrl'] as String?,
      competitionId: json['competitionId'] as String?,
      competitionName: json['competitionName'] as String,
      status: $enumDecode(_$MatchStatusEnumMap, json['status']),
      homeScore: json['homeScore'] as String?,
      awayScore: json['awayScore'] as String?,
      startTime: DateTime.parse(json['startTime'] as String),
      venue: json['venue'] as String?,
      matchMinute: json['matchMinute'] as String?,
      metadata: json['metadata'] as Map<String, dynamic>?,
      sourceId: json['sourceId'] as String?,
      cachedAt: json['cachedAt'] == null
          ? null
          : DateTime.parse(json['cachedAt'] as String),
    );

Map<String, dynamic> _$$SportsEventImplToJson(_$SportsEventImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'sport': _$SportTypeEnumMap[instance.sport]!,
      'homeTeamId': instance.homeTeamId,
      'homeTeamName': instance.homeTeamName,
      'homeTeamLogoUrl': instance.homeTeamLogoUrl,
      'awayTeamId': instance.awayTeamId,
      'awayTeamName': instance.awayTeamName,
      'awayTeamLogoUrl': instance.awayTeamLogoUrl,
      'competitionId': instance.competitionId,
      'competitionName': instance.competitionName,
      'status': _$MatchStatusEnumMap[instance.status]!,
      'homeScore': instance.homeScore,
      'awayScore': instance.awayScore,
      'startTime': instance.startTime.toIso8601String(),
      'venue': instance.venue,
      'matchMinute': instance.matchMinute,
      'metadata': instance.metadata,
      'sourceId': instance.sourceId,
      'cachedAt': instance.cachedAt?.toIso8601String(),
    };

const _$SportTypeEnumMap = {
  SportType.football: 'football',
  SportType.afl: 'afl',
  SportType.baseball: 'baseball',
  SportType.basketball: 'basketball',
  SportType.formula1: 'formula1',
  SportType.handball: 'handball',
  SportType.hockey: 'hockey',
  SportType.mma: 'mma',
  SportType.nba: 'nba',
  SportType.americanFootball: 'americanFootball',
  SportType.rugby: 'rugby',
  SportType.volleyball: 'volleyball',
  SportType.other: 'other',
};

const _$MatchStatusEnumMap = {
  MatchStatus.scheduled: 'scheduled',
  MatchStatus.live: 'live',
  MatchStatus.halfTime: 'halfTime',
  MatchStatus.finished: 'finished',
  MatchStatus.postponed: 'postponed',
  MatchStatus.cancelled: 'cancelled',
  MatchStatus.suspended: 'suspended',
  MatchStatus.unknown: 'unknown',
};

_$SportsTeamImpl _$$SportsTeamImplFromJson(Map<String, dynamic> json) =>
    _$SportsTeamImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      shortName: json['shortName'] as String?,
      logoUrl: json['logoUrl'] as String?,
      country: json['country'] as String?,
      sport: $enumDecodeNullable(_$SportTypeEnumMap, json['sport']),
      competitionId: json['competitionId'] as String?,
      metadata: json['metadata'] as Map<String, dynamic>?,
    );

Map<String, dynamic> _$$SportsTeamImplToJson(_$SportsTeamImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'shortName': instance.shortName,
      'logoUrl': instance.logoUrl,
      'country': instance.country,
      'sport': _$SportTypeEnumMap[instance.sport],
      'competitionId': instance.competitionId,
      'metadata': instance.metadata,
    };

_$SportsCompetitionImpl _$$SportsCompetitionImplFromJson(
        Map<String, dynamic> json) =>
    _$SportsCompetitionImpl(
      id: json['id'] as String,
      name: json['name'] as String,
      sport: $enumDecode(_$SportTypeEnumMap, json['sport']),
      logoUrl: json['logoUrl'] as String?,
      country: json['country'] as String?,
      region: json['region'] as String?,
      season: json['season'] as String?,
      metadata: json['metadata'] as Map<String, dynamic>?,
    );

Map<String, dynamic> _$$SportsCompetitionImplToJson(
        _$SportsCompetitionImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'sport': _$SportTypeEnumMap[instance.sport]!,
      'logoUrl': instance.logoUrl,
      'country': instance.country,
      'region': instance.region,
      'season': instance.season,
      'metadata': instance.metadata,
    };

import 'package:flutter/material.dart';

/// NovaStream Design System
/// Premium dark navy/black surfaces, cyan/blue/violet accents
class AppTheme {
  AppTheme._();

  // === Brand Colors ===
  static const Color primaryCyan = Color(0xFF00D4FF);
  static const Color primaryBlue = Color(0xFF0066FF);
  static const Color accentViolet = Color(0xFF7C3AED);
  static const Color accentPurple = Color(0xFFAB47BC);

  // === Surface Colors (Dark) ===
  static const Color surfaceBackground = Color(0xFF050A14);
  static const Color surfaceCard = Color(0xFF0D1526);
  static const Color surfaceElevated = Color(0xFF111D35);
  static const Color surfaceOverlay = Color(0xFF1A2847);
  static const Color surfaceBorder = Color(0xFF1E2F50);

  // === Surface Colors (Light) ===
  static const Color lightBackground = Color(0xFFF0F4FF);
  static const Color lightCard = Color(0xFFFFFFFF);
  static const Color lightElevated = Color(0xFFE8EFFF);
  static const Color lightBorder = Color(0xFFD0DAEF);

  // === Status Colors ===
  static const Color statusLive = Color(0xFFFF3B5C);
  static const Color statusSuccess = Color(0xFF00C853);
  static const Color statusWarning = Color(0xFFFFB300);
  static const Color statusError = Color(0xFFFF5252);
  static const Color statusInfo = Color(0xFF00D4FF);

  // === Text Colors ===
  static const Color textPrimary = Color(0xFFEEF2FF);
  static const Color textSecondary = Color(0xFF8A9BC4);
  static const Color textDisabled = Color(0xFF3D4F72);
  static const Color textOnPrimary = Color(0xFF050A14);

  // === Glow Effects ===
  static List<BoxShadow> cyanGlow = [
    BoxShadow(
        color: primaryCyan.withValues(alpha: 0.3),
        blurRadius: 20,
        spreadRadius: 2),
    BoxShadow(
        color: primaryCyan.withValues(alpha: 0.1),
        blurRadius: 40,
        spreadRadius: 10),
  ];

  static List<BoxShadow> blueGlow = [
    BoxShadow(
        color: primaryBlue.withValues(alpha: 0.3),
        blurRadius: 20,
        spreadRadius: 2),
  ];

  static List<BoxShadow> cardShadow = [
    BoxShadow(
        color: Colors.black.withValues(alpha: 0.4),
        blurRadius: 12,
        offset: const Offset(0, 4)),
  ];

  // === Gradients ===
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primaryCyan, primaryBlue],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient heroGradient = LinearGradient(
    colors: [Color(0xFF050A14), Color(0xFF0D1526), Color(0xFF050A14)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient cardOverlayGradient = LinearGradient(
    colors: [Colors.transparent, Color(0xCC050A14)],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static LinearGradient get liveGradient => LinearGradient(
        colors: [statusLive, statusLive.withValues(alpha: 0.7)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  /// Dark (primary) theme
  static ThemeData dark() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      fontFamily: 'Inter',
      colorScheme: const ColorScheme.dark(
        primary: primaryCyan,
        onPrimary: textOnPrimary,
        secondary: primaryBlue,
        onSecondary: textPrimary,
        tertiary: accentViolet,
        surface: surfaceCard,
        onSurface: textPrimary,
        error: statusError,
        onError: textPrimary,
        outline: surfaceBorder,
      ),
      scaffoldBackgroundColor: surfaceBackground,
      cardColor: surfaceCard,
      cardTheme: CardThemeData(
        color: surfaceCard,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: const BorderSide(color: surfaceBorder, width: 0.5),
        ),
        margin: EdgeInsets.zero,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: surfaceBackground,
        foregroundColor: textPrimary,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(
          color: textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter',
        ),
        iconTheme: IconThemeData(color: textPrimary),
      ),
      navigationBarTheme: NavigationBarThemeData(
        backgroundColor: surfaceCard,
        indicatorColor: primaryCyan.withValues(alpha: 0.15),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const TextStyle(
                color: primaryCyan,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter');
          }
          return const TextStyle(
              color: textSecondary, fontSize: 11, fontFamily: 'Inter');
        }),
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return const IconThemeData(color: primaryCyan, size: 22);
          }
          return const IconThemeData(color: textSecondary, size: 22);
        }),
        surfaceTintColor: Colors.transparent,
        elevation: 0,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: surfaceCard,
        selectedItemColor: primaryCyan,
        unselectedItemColor: textSecondary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      textTheme: _buildTextTheme(textPrimary, textSecondary),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surfaceElevated,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: surfaceBorder),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: surfaceBorder),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: primaryCyan, width: 1.5),
        ),
        hintStyle: const TextStyle(color: textDisabled, fontFamily: 'Inter'),
        labelStyle: const TextStyle(color: textSecondary, fontFamily: 'Inter'),
        prefixIconColor: textSecondary,
        suffixIconColor: textSecondary,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryCyan,
          foregroundColor: textOnPrimary,
          elevation: 0,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: const TextStyle(
              fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'Inter'),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: primaryCyan,
          side: const BorderSide(color: primaryCyan),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          textStyle: const TextStyle(
              fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'Inter'),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: primaryCyan,
          textStyle: const TextStyle(
              fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'Inter'),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: surfaceElevated,
        selectedColor: primaryCyan.withValues(alpha: 0.2),
        labelStyle: const TextStyle(
            color: textSecondary, fontFamily: 'Inter', fontSize: 12),
        side: const BorderSide(color: surfaceBorder),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: surfaceElevated,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        titleTextStyle: const TextStyle(
            color: textPrimary,
            fontSize: 18,
            fontWeight: FontWeight.w600,
            fontFamily: 'Inter'),
        contentTextStyle: const TextStyle(
            color: textSecondary, fontSize: 14, fontFamily: 'Inter'),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: surfaceOverlay,
        contentTextStyle:
            const TextStyle(color: textPrimary, fontFamily: 'Inter'),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        behavior: SnackBarBehavior.floating,
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: primaryCyan,
        linearTrackColor: surfaceBorder,
      ),
      sliderTheme: SliderThemeData(
        activeTrackColor: primaryCyan,
        inactiveTrackColor: surfaceBorder,
        thumbColor: primaryCyan,
        overlayColor: primaryCyan.withValues(alpha: 0.15),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? primaryCyan
                : textSecondary),
        trackColor: WidgetStateProperty.resolveWith((states) =>
            states.contains(WidgetState.selected)
                ? primaryCyan.withValues(alpha: 0.3)
                : surfaceOverlay),
      ),
      dividerTheme:
          const DividerThemeData(color: surfaceBorder, thickness: 0.5),
      listTileTheme: const ListTileThemeData(
        textColor: textPrimary,
        iconColor: textSecondary,
        tileColor: Colors.transparent,
      ),
      tabBarTheme: const TabBarThemeData(
        labelColor: primaryCyan,
        unselectedLabelColor: textSecondary,
        indicatorColor: primaryCyan,
        labelStyle: TextStyle(
            fontSize: 13, fontWeight: FontWeight.w600, fontFamily: 'Inter'),
        unselectedLabelStyle: TextStyle(fontSize: 13, fontFamily: 'Inter'),
        indicatorSize: TabBarIndicatorSize.label,
        dividerColor: surfaceBorder,
      ),
      iconTheme: const IconThemeData(color: textSecondary),
      popupMenuTheme: const PopupMenuThemeData(
        color: surfaceElevated,
        textStyle: TextStyle(color: textPrimary, fontFamily: 'Inter'),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(10)),
        ),
      ),
    );
  }

  /// Light theme
  static ThemeData light() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      fontFamily: 'Inter',
      colorScheme: const ColorScheme.light(
        primary: primaryBlue,
        secondary: primaryCyan,
        onSurface: Color(0xFF0D1526),
        error: statusError,
        outline: lightBorder,
      ),
      scaffoldBackgroundColor: lightBackground,
      cardColor: lightCard,
    );
  }

  static TextTheme _buildTextTheme(Color primary, Color secondary) {
    return TextTheme(
      displayLarge: TextStyle(
          color: primary,
          fontSize: 32,
          fontWeight: FontWeight.w700,
          fontFamily: 'Inter'),
      displayMedium: TextStyle(
          color: primary,
          fontSize: 28,
          fontWeight: FontWeight.w700,
          fontFamily: 'Inter'),
      displaySmall: TextStyle(
          color: primary,
          fontSize: 24,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter'),
      headlineLarge: TextStyle(
          color: primary,
          fontSize: 22,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter'),
      headlineMedium: TextStyle(
          color: primary,
          fontSize: 20,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter'),
      headlineSmall: TextStyle(
          color: primary,
          fontSize: 18,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter'),
      titleLarge: TextStyle(
          color: primary,
          fontSize: 16,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter'),
      titleMedium: TextStyle(
          color: primary,
          fontSize: 14,
          fontWeight: FontWeight.w500,
          fontFamily: 'Inter'),
      titleSmall: TextStyle(
          color: secondary,
          fontSize: 12,
          fontWeight: FontWeight.w500,
          fontFamily: 'Inter'),
      bodyLarge: TextStyle(color: primary, fontSize: 16, fontFamily: 'Inter'),
      bodyMedium: TextStyle(color: primary, fontSize: 14, fontFamily: 'Inter'),
      bodySmall: TextStyle(color: secondary, fontSize: 12, fontFamily: 'Inter'),
      labelLarge: TextStyle(
          color: primary,
          fontSize: 14,
          fontWeight: FontWeight.w600,
          fontFamily: 'Inter'),
      labelMedium: TextStyle(
          color: secondary,
          fontSize: 12,
          fontWeight: FontWeight.w500,
          fontFamily: 'Inter'),
      labelSmall: TextStyle(
          color: secondary,
          fontSize: 10,
          fontWeight: FontWeight.w500,
          fontFamily: 'Inter'),
    );
  }
}

/// Extension for consistent spacing
extension SpacingX on num {
  SizedBox get wBox => SizedBox(width: toDouble());
  SizedBox get hBox => SizedBox(height: toDouble());
}

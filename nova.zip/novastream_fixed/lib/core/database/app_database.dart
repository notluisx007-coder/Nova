import 'package:drift/drift.dart';
import 'package:drift_flutter/drift_flutter.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';

part 'app_database.g.dart';

// ============================================================
// TABLE DEFINITIONS
// ============================================================

/// IPTV Channels.
/// `id` is a stable, source-scoped identifier: `<sourceId>_<tvgId>` when the
/// playlist provides a tvg-id, otherwise a hash of display name + stream URL.
/// User flags (isFavorite/isHidden/userOrder/lastWatched) survive refreshes
/// because refreshes upsert by this stable id.
class ChannelsTable extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get logoUrl => text().nullable()();
  TextColumn get groupTitle => text().nullable()();
  TextColumn get tvgId => text().nullable()();
  TextColumn get tvgName => text().nullable()();
  TextColumn get country => text().nullable()();
  TextColumn get language => text().nullable()();
  TextColumn get categories => text().nullable()(); // comma-separated
  TextColumn get streamUrl => text()();
  TextColumn get sourceId => text()();
  BoolColumn get isFavorite => boolean().withDefault(const Constant(false))();
  BoolColumn get isHidden => boolean().withDefault(const Constant(false))();
  IntColumn get userOrder => integer().nullable()();
  TextColumn get rightsStatus =>
      text().withDefault(const Constant('unknown'))();
  DateTimeColumn get lastWatched => dateTime().nullable()();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};

  @override
  List<Set<Column>> get uniqueKeys => [
        {sourceId, streamUrl}
      ];
}

/// Playlist Sources
class PlaylistSourcesTable extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get type => text()(); // m3u_url, m3u_file, xtream
  TextColumn get url => text().nullable()();
  TextColumn get filePath => text().nullable()();
  TextColumn get username => text().nullable()();
  IntColumn get channelCount => integer().withDefault(const Constant(0))();
  TextColumn get status => text().withDefault(const Constant('unconfigured'))();
  TextColumn get lastError => text().nullable()();
  DateTimeColumn get lastRefresh => dateTime().nullable()();
  DateTimeColumn get lastSuccess => dateTime().nullable()();
  TextColumn get etag => text().nullable()();
  IntColumn get priority => integer().withDefault(const Constant(100))();
  BoolColumn get isEnabled => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

/// EPG Programmes. `channelId` is the raw XMLTV `channel` attribute of the
/// guide the programme came from — NOT the app channel id. App channels are
/// resolved to guide channels via tvg-id, a manual mapping, or a normalized
/// name fallback (see EpgChannelMappingsTable).
class EpgProgrammesTable extends Table {
  TextColumn get id => text()();
  TextColumn get channelId => text()();
  TextColumn get title => text()();
  TextColumn get description => text().nullable()();
  TextColumn get category => text().nullable()();
  TextColumn get language => text().nullable()();
  DateTimeColumn get startTime => dateTime()();
  DateTimeColumn get endTime => dateTime()();
  TextColumn get sourceId => text()();

  @override
  Set<Column> get primaryKey => {id};
}

/// EPG Sources
class EpgSourcesTable extends Table {
  TextColumn get id => text()();
  TextColumn get name => text()();
  TextColumn get url => text()();
  TextColumn get channelCount => text().nullable()();
  TextColumn get status => text().withDefault(const Constant('unconfigured'))();
  DateTimeColumn get lastRefresh => dateTime().nullable()();
  BoolColumn get isEnabled => boolean().withDefault(const Constant(true))();

  @override
  Set<Column> get primaryKey => {id};
}

/// Directory of channels declared by an XMLTV guide (`<channel>` elements).
/// Used for the normalized-name fallback when matching app channels to guide
/// channels, and for the manual mapping UI.
class EpgChannelsTable extends Table {
  TextColumn get id => text()(); // `${epgSourceId}::${xmltvChannelId}`
  TextColumn get epgSourceId => text()();
  TextColumn get xmltvChannelId => text()();
  TextColumn get displayName => text()();
  TextColumn get normalizedName => text()();

  @override
  Set<Column> get primaryKey => {id};
}

/// Manual channel-to-EPG mappings created by the user. Auto matching is NOT
/// stored here — this table only holds explicit user decisions so they
/// survive playlist and EPG refreshes.
class EpgChannelMappingsTable extends Table {
  TextColumn get id => text()(); // uuid
  TextColumn get sourceId => text()(); // playlist source owning the channel
  TextColumn get appChannelId => text()();
  TextColumn get epgSourceId => text().nullable()(); // null = any guide
  TextColumn get epgChannelId => text()(); // raw XMLTV channel id
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

/// User Favorites
class FavoritesTable extends Table {
  TextColumn get id => text()();
  TextColumn get type =>
      text()(); // channel, team, competition, match, programme
  TextColumn get referenceId => text()();
  TextColumn get displayName => text()();
  TextColumn get metadata => text().nullable()(); // JSON
  DateTimeColumn get addedAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

/// Watch History
class WatchHistoryTable extends Table {
  TextColumn get id => text()();
  TextColumn get channelId => text()();
  TextColumn get channelName => text()();
  TextColumn get streamUrl => text()();
  IntColumn get durationSeconds => integer().withDefault(const Constant(0))();
  DateTimeColumn get watchedAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

/// Match Reminders
class RemindersTable extends Table {
  TextColumn get id => text()();
  TextColumn get type => text()(); // match, programme
  TextColumn get referenceId => text()();
  TextColumn get title => text()();
  TextColumn get subtitle => text().nullable()();
  DateTimeColumn get reminderTime => dateTime()();
  BoolColumn get isFired => boolean().withDefault(const Constant(false))();
  DateTimeColumn get createdAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

/// Sports Events (cached from provider)
class SportsEventsTable extends Table {
  TextColumn get id => text()();
  TextColumn get sport => text()();
  TextColumn get homeTeamId => text().nullable()();
  TextColumn get homeTeamName => text()();
  TextColumn get awayTeamId => text().nullable()();
  TextColumn get awayTeamName => text()();
  TextColumn get competitionId => text().nullable()();
  TextColumn get competitionName => text()();
  TextColumn get status => text()(); // scheduled, live, finished, postponed
  TextColumn get homeScore => text().nullable()();
  TextColumn get awayScore => text().nullable()();
  DateTimeColumn get startTime => dateTime()();
  TextColumn get venue => text().nullable()();
  TextColumn get metadata => text().nullable()(); // JSON
  TextColumn get sourceId => text()();
  DateTimeColumn get cachedAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

/// Resume points for seekable VOD content (movies/series/recordings).
/// Live TV must NOT write rows here.
class ResumePointsTable extends Table {
  TextColumn get id => text()(); // stable content id (channel id / media id)
  TextColumn get contentType => text()(); // vod | series_episode
  TextColumn get title => text()();
  TextColumn get streamUrl => text()();
  IntColumn get positionSeconds => integer()();
  IntColumn get durationSeconds => integer().nullable()();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {id};
}

/// App Settings (key-value)
class SettingsTable extends Table {
  TextColumn get key => text()();
  TextColumn get value => text()();
  DateTimeColumn get updatedAt => dateTime().withDefault(currentDateAndTime)();

  @override
  Set<Column> get primaryKey => {key};
}

// ============================================================
// DATABASE
// ============================================================

@DriftDatabase(tables: [
  ChannelsTable,
  PlaylistSourcesTable,
  EpgProgrammesTable,
  EpgSourcesTable,
  EpgChannelsTable,
  EpgChannelMappingsTable,
  FavoritesTable,
  WatchHistoryTable,
  RemindersTable,
  SportsEventsTable,
  ResumePointsTable,
  SettingsTable,
])
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  AppDatabase.forTesting(super.executor);

  @override
  int get schemaVersion => 2;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (Migrator m) async {
          await m.createAll();
        },
        onUpgrade: (Migrator m, int from, int to) async {
          // v1 -> v2: EPG channel directory + manual mappings + resume points,
          // plus supporting indexes. All purely additive — no user data is lost.
          if (from < 2) {
            await m.createTable(epgChannelsTable);
            await m.createTable(epgChannelMappingsTable);
            await m.createTable(resumePointsTable);
            await _createIndexes(m);
          }
        },
        beforeOpen: (details) async {
          await customStatement('PRAGMA foreign_keys = ON');
        },
      );

  Future<void> _createIndexes(Migrator m) async {
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_channels_source ON channels_table (source_id)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_channels_group ON channels_table (group_title)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_channels_last_watched ON channels_table (last_watched)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_programmes_channel_time ON epg_programmes_table (channel_id, start_time)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_programmes_source ON epg_programmes_table (source_id)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_epg_channels_source ON epg_channels_table (epg_source_id)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_epg_channels_normalized ON epg_channels_table (normalized_name)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_mappings_channel ON epg_channel_mappings_table (source_id, app_channel_id)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_mappings_epg ON epg_channel_mappings_table (epg_source_id, epg_channel_id)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_favorites_ref ON favorites_table (type, reference_id)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_history_channel ON watch_history_table (channel_id)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_history_watched_at ON watch_history_table (watched_at)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_sports_sport_status ON sports_events_table (sport, status, start_time)');
    await customStatement(
        'CREATE INDEX IF NOT EXISTS idx_resume_updated ON resume_points_table (updated_at)');
  }

  static QueryExecutor _openConnection() {
    return driftDatabase(name: 'novastream_v1');
  }

  // ============================================================
  // CHANNEL QUERIES
  // ============================================================

  Future<List<ChannelsTableData>> getAllChannels() =>
      (select(channelsTable)..where((t) => t.isHidden.equals(false))).get();

  Stream<List<ChannelsTableData>> watchAllChannels() => (select(channelsTable)
        ..where((t) => t.isHidden.equals(false))
        ..orderBy([(t) => OrderingTerm(expression: t.name)]))
      .watch();

  Stream<List<ChannelsTableData>> watchFavoriteChannels() =>
      (select(channelsTable)..where((t) => t.isFavorite.equals(true))).watch();

  Future<List<ChannelsTableData>> searchChannels(String query) =>
      (select(channelsTable)
            ..where((t) =>
                t.name.lower().contains(query.toLowerCase()) |
                t.groupTitle.lower().contains(query.toLowerCase())))
          .get();

  Future<List<ChannelsTableData>> getChannelsBySource(String sourceId) =>
      (select(channelsTable)..where((t) => t.sourceId.equals(sourceId))).get();

  Future<void> upsertChannel(ChannelsTableCompanion entry) =>
      into(channelsTable).insertOnConflictUpdate(entry);

  Future<void> toggleChannelFavorite(String channelId, bool isFavorite) =>
      (update(channelsTable)..where((t) => t.id.equals(channelId)))
          .write(ChannelsTableCompanion(isFavorite: Value(isFavorite)));

  Future<void> updateLastWatched(String channelId) =>
      (update(channelsTable)..where((t) => t.id.equals(channelId)))
          .write(ChannelsTableCompanion(lastWatched: Value(DateTime.now())));

  Future<List<ChannelsTableData>> getRecentlyWatched({int limit = 20}) =>
      (select(channelsTable)
            ..where((t) => t.lastWatched.isNotNull())
            ..orderBy([
              (t) => OrderingTerm(
                  expression: t.lastWatched, mode: OrderingMode.desc)
            ])
            ..limit(limit))
          .get();

  // ============================================================
  // SOURCE DELETION — full dependent cleanup, one transaction
  // ============================================================

  /// Deletes a source and every record owned by it in a single transaction:
  /// channels, the source row itself, channel favorites (favorites_table rows
  /// of type `channel` referencing this source's channels), watch-history
  /// rows for those channels, EPG programmes imported for this source, manual
  /// EPG mappings owned by this source, and programme reminders whose
  /// referenceId belongs to this source's programmes. Records shared with
  /// other sources (sports cache, global settings) are left untouched.
  Future<void> deleteSourceWithChannels(String sourceId) async {
    await transaction(() async {
      final channelIds = await (select(channelsTable)
            ..where((t) => t.sourceId.equals(sourceId)))
          .get()
          .then((rows) => rows.map((r) => r.id).toList());

      // 1. Watch history rows pointing at this source's channels.
      if (channelIds.isNotEmpty) {
        await (delete(watchHistoryTable)
              ..where((t) => t.channelId.isIn(channelIds)))
            .go();
        await (delete(favoritesTable)
              ..where((t) =>
                  t.type.equals('channel') & t.referenceId.isIn(channelIds)))
            .go();
        // Programme reminders reference programme ids which are prefixed
        // with the source id (`${sourceId}_...`).
        await (delete(remindersTable)
              ..where((t) =>
                  t.type.equals('programme') &
                  t.referenceId.like('${sourceId}_%')))
            .go();
      }

      // 2. EPG programmes imported under this source id.
      await (delete(epgProgrammesTable)
            ..where((t) => t.sourceId.equals(sourceId)))
          .go();

      // 3. Manual EPG mappings owned by this source.
      await (delete(epgChannelMappingsTable)
            ..where((t) => t.sourceId.equals(sourceId)))
          .go();

      // 4. Channels owned by this source.
      await (delete(channelsTable)..where((t) => t.sourceId.equals(sourceId)))
          .go();

      // 5. The source row itself.
      await (delete(playlistSourcesTable)..where((t) => t.id.equals(sourceId)))
          .go();
    });
  }

  // ============================================================
  // SOURCE QUERIES
  // ============================================================

  Stream<List<PlaylistSourcesTableData>> watchSources() =>
      (select(playlistSourcesTable)
            ..orderBy([(t) => OrderingTerm(expression: t.priority)]))
          .watch();

  Future<List<PlaylistSourcesTableData>> getSources() =>
      (select(playlistSourcesTable)
            ..orderBy([(t) => OrderingTerm(expression: t.priority)]))
          .get();

  Future<PlaylistSourcesTableData?> getSource(String id) =>
      (select(playlistSourcesTable)..where((t) => t.id.equals(id)))
          .getSingleOrNull();

  Future<void> upsertSource(PlaylistSourcesTableCompanion entry) =>
      into(playlistSourcesTable).insertOnConflictUpdate(entry);

  /// Legacy – kept for callers that only need the source row removed
  /// (not its channels). Prefer [deleteSourceWithChannels] for user actions.
  Future<void> deleteSource(String id) =>
      (delete(playlistSourcesTable)..where((t) => t.id.equals(id))).go();

  // ============================================================
  // EPG QUERIES
  // ============================================================

  Future<List<EpgProgrammesTableData>> getProgrammesForGuideChannel(
          String guideChannelId, DateTime start, DateTime end) =>
      (select(epgProgrammesTable)
            ..where((t) =>
                t.channelId.equals(guideChannelId) &
                t.startTime.isSmallerOrEqualValue(end) &
                t.endTime.isBiggerOrEqualValue(start))
            ..orderBy([(t) => OrderingTerm(expression: t.startTime)]))
          .get();

  Future<EpgProgrammesTableData?> getCurrentProgrammeForGuideChannel(
      String guideChannelId) async {
    final now = DateTime.now();
    final results = await (select(epgProgrammesTable)
          ..where((t) =>
              t.channelId.equals(guideChannelId) &
              t.startTime.isSmallerOrEqualValue(now) &
              t.endTime.isBiggerOrEqualValue(now))
          ..limit(1))
        .get();
    return results.isEmpty ? null : results.first;
  }

  Future<void> upsertProgramme(EpgProgrammesTableCompanion entry) =>
      into(epgProgrammesTable).insertOnConflictUpdate(entry);

  Future<void> clearOldProgrammes() async {
    final cutoff = DateTime.now().subtract(const Duration(days: 2));
    await (delete(epgProgrammesTable)
          ..where((t) => t.endTime.isSmallerThanValue(cutoff)))
        .go();
  }

  /// Removes ALL programmes belonging to an EPG source. Used inside the
  /// transactional guide replacement — never on its own.
  Future<int> deleteProgrammesForEpgSource(String epgSourceId) =>
      (delete(epgProgrammesTable)..where((t) => t.sourceId.equals(epgSourceId)))
          .go();

  // --- EPG channel directory ---

  Future<void> upsertEpgChannel(EpgChannelsTableCompanion entry) =>
      into(epgChannelsTable).insertOnConflictUpdate(entry);

  Future<List<EpgChannelsTableData>> getEpgChannels(String epgSourceId) =>
      (select(epgChannelsTable)
            ..where((t) => t.epgSourceId.equals(epgSourceId))
            ..orderBy([(t) => OrderingTerm(expression: t.displayName)]))
          .get();

  Future<EpgChannelsTableData?> findEpgChannelByNormalizedName(
      String normalizedName, String epgSourceId) async {
    final rows = await (select(epgChannelsTable)
          ..where((t) =>
              t.epgSourceId.equals(epgSourceId) &
              t.normalizedName.equals(normalizedName))
          ..limit(1))
        .get();
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> deleteEpgChannelsForSource(String epgSourceId) =>
      (delete(epgChannelsTable)
            ..where((t) => t.epgSourceId.equals(epgSourceId)))
          .go();

  // --- Manual EPG mappings ---

  Future<List<EpgChannelMappingsTableData>> getMappingsForSource(
          String sourceId) =>
      (select(epgChannelMappingsTable)
            ..where((t) => t.sourceId.equals(sourceId)))
          .get();

  Future<EpgChannelMappingsTableData?> getMappingForChannel(
      String sourceId, String appChannelId) async {
    final rows = await (select(epgChannelMappingsTable)
          ..where((t) =>
              t.sourceId.equals(sourceId) &
              t.appChannelId.equals(appChannelId)))
        .get();
    return rows.isEmpty ? null : rows.first;
  }

  Future<void> setManualEpgMapping({
    required String sourceId,
    required String appChannelId,
    required String epgChannelId,
    String? epgSourceId,
  }) async {
    const uuid = Uuid();
    // Replace any existing mapping for this channel — one guide channel per
    // app channel at a time.
    await transaction(() async {
      await (delete(epgChannelMappingsTable)
            ..where((t) =>
                t.sourceId.equals(sourceId) &
                t.appChannelId.equals(appChannelId)))
          .go();
      await into(epgChannelMappingsTable)
          .insert(EpgChannelMappingsTableCompanion(
        id: Value(uuid.v4()),
        sourceId: Value(sourceId),
        appChannelId: Value(appChannelId),
        epgChannelId: Value(epgChannelId),
        epgSourceId: Value(epgSourceId),
      ));
    });
  }

  Future<int> removeManualEpgMapping(String sourceId, String appChannelId) =>
      (delete(epgChannelMappingsTable)
            ..where((t) =>
                t.sourceId.equals(sourceId) &
                t.appChannelId.equals(appChannelId)))
          .go();

  // ============================================================
  // FAVORITES QUERIES
  // ============================================================

  Stream<List<FavoritesTableData>> watchFavoritesByType(String type) =>
      (select(favoritesTable)
            ..where((t) => t.type.equals(type))
            ..orderBy([
              (t) =>
                  OrderingTerm(expression: t.addedAt, mode: OrderingMode.desc)
            ]))
          .watch();

  Future<bool> isFavorite(String type, String referenceId) async {
    final result = await (select(favoritesTable)
          ..where(
              (t) => t.type.equals(type) & t.referenceId.equals(referenceId)))
        .get();
    return result.isNotEmpty;
  }

  Future<void> addFavorite(FavoritesTableCompanion entry) =>
      into(favoritesTable).insertOnConflictUpdate(entry);

  Future<void> removeFavorite(String type, String referenceId) => (delete(
          favoritesTable)
        ..where((t) => t.type.equals(type) & t.referenceId.equals(referenceId)))
      .go();

  // ============================================================
  // SPORTS QUERIES
  // ============================================================

  Stream<List<SportsEventsTableData>> watchEventsBySport(String sport) =>
      (select(sportsEventsTable)
            ..where((t) => t.sport.equals(sport))
            ..orderBy([(t) => OrderingTerm(expression: t.startTime)]))
          .watch();

  Stream<List<SportsEventsTableData>> watchLiveEvents() =>
      (select(sportsEventsTable)
            ..where((t) => t.status.equals('live'))
            ..orderBy([(t) => OrderingTerm(expression: t.startTime)]))
          .watch();

  Stream<List<SportsEventsTableData>> watchUpcomingEvents() {
    final now = DateTime.now();
    return (select(sportsEventsTable)
          ..where((t) =>
              t.status.equals('scheduled') &
              t.startTime.isBiggerOrEqualValue(now))
          ..orderBy([(t) => OrderingTerm(expression: t.startTime)])
          ..limit(50))
        .watch();
  }

  /// Finished events for the Results tab, newest first.
  Stream<List<SportsEventsTableData>> watchFinishedEvents() =>
      (select(sportsEventsTable)
            ..where((t) => t.status.equals('finished'))
            ..orderBy([
              (t) =>
                  OrderingTerm(expression: t.startTime, mode: OrderingMode.desc)
            ])
            ..limit(50))
          .watch();

  Future<SportsEventsTableData?> getSportsEvent(String id) =>
      (select(sportsEventsTable)..where((t) => t.id.equals(id)))
          .getSingleOrNull();

  Future<void> upsertSportsEvent(SportsEventsTableCompanion entry) =>
      into(sportsEventsTable).insertOnConflictUpdate(entry);

  Future<void> clearStaleSportsEvents() async {
    final cutoff = DateTime.now().subtract(const Duration(hours: 24));
    await (delete(sportsEventsTable)
          ..where((t) => t.cachedAt.isSmallerThanValue(cutoff)))
        .go();
  }

  Future<int> clearAllSportsEvents() => delete(sportsEventsTable).go();

  // ============================================================
  // SETTINGS QUERIES
  // ============================================================

  Future<String?> getSetting(String key) async {
    final result = await (select(settingsTable)
          ..where((t) => t.key.equals(key)))
        .getSingleOrNull();
    return result?.value;
  }

  Future<void> setSetting(String key, String value) =>
      into(settingsTable).insertOnConflictUpdate(
        SettingsTableCompanion(key: Value(key), value: Value(value)),
      );

  // ============================================================
  // WATCH HISTORY
  // ============================================================

  Future<void> addWatchHistory(WatchHistoryTableCompanion entry) =>
      into(watchHistoryTable).insertOnConflictUpdate(entry);

  Stream<List<WatchHistoryTableData>> watchHistory({int limit = 30}) =>
      (select(watchHistoryTable)
            ..orderBy([
              (t) =>
                  OrderingTerm(expression: t.watchedAt, mode: OrderingMode.desc)
            ])
            ..limit(limit))
          .watch();

  Future<void> clearWatchHistory() => delete(watchHistoryTable).go();

  // ============================================================
  // RESUME POINTS (VOD only — live TV never writes here)
  // ============================================================

  Future<ResumePointsTableData?> getResumePoint(String contentId) =>
      (select(resumePointsTable)..where((t) => t.id.equals(contentId)))
          .getSingleOrNull();

  Future<void> upsertResumePoint(ResumePointsTableCompanion entry) =>
      into(resumePointsTable).insertOnConflictUpdate(entry);

  Future<int> deleteResumePoint(String contentId) =>
      (delete(resumePointsTable)..where((t) => t.id.equals(contentId))).go();

  Stream<List<ResumePointsTableData>> watchResumePoints({int limit = 30}) =>
      (select(resumePointsTable)
            ..orderBy([
              (t) =>
                  OrderingTerm(expression: t.updatedAt, mode: OrderingMode.desc)
            ])
            ..limit(limit))
          .watch();
}

// Provider
final appDatabaseProvider = Provider<AppDatabase>((ref) {
  final db = AppDatabase();
  ref.onDispose(db.close);
  return db;
});

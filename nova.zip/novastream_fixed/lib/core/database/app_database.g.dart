// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $ChannelsTableTable extends ChannelsTable
    with TableInfo<$ChannelsTableTable, ChannelsTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ChannelsTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _logoUrlMeta =
      const VerificationMeta('logoUrl');
  @override
  late final GeneratedColumn<String> logoUrl = GeneratedColumn<String>(
      'logo_url', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _groupTitleMeta =
      const VerificationMeta('groupTitle');
  @override
  late final GeneratedColumn<String> groupTitle = GeneratedColumn<String>(
      'group_title', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _tvgIdMeta = const VerificationMeta('tvgId');
  @override
  late final GeneratedColumn<String> tvgId = GeneratedColumn<String>(
      'tvg_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _tvgNameMeta =
      const VerificationMeta('tvgName');
  @override
  late final GeneratedColumn<String> tvgName = GeneratedColumn<String>(
      'tvg_name', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _countryMeta =
      const VerificationMeta('country');
  @override
  late final GeneratedColumn<String> country = GeneratedColumn<String>(
      'country', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _languageMeta =
      const VerificationMeta('language');
  @override
  late final GeneratedColumn<String> language = GeneratedColumn<String>(
      'language', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _categoriesMeta =
      const VerificationMeta('categories');
  @override
  late final GeneratedColumn<String> categories = GeneratedColumn<String>(
      'categories', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _streamUrlMeta =
      const VerificationMeta('streamUrl');
  @override
  late final GeneratedColumn<String> streamUrl = GeneratedColumn<String>(
      'stream_url', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _sourceIdMeta =
      const VerificationMeta('sourceId');
  @override
  late final GeneratedColumn<String> sourceId = GeneratedColumn<String>(
      'source_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _isFavoriteMeta =
      const VerificationMeta('isFavorite');
  @override
  late final GeneratedColumn<bool> isFavorite = GeneratedColumn<bool>(
      'is_favorite', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_favorite" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _isHiddenMeta =
      const VerificationMeta('isHidden');
  @override
  late final GeneratedColumn<bool> isHidden = GeneratedColumn<bool>(
      'is_hidden', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_hidden" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _userOrderMeta =
      const VerificationMeta('userOrder');
  @override
  late final GeneratedColumn<int> userOrder = GeneratedColumn<int>(
      'user_order', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _rightsStatusMeta =
      const VerificationMeta('rightsStatus');
  @override
  late final GeneratedColumn<String> rightsStatus = GeneratedColumn<String>(
      'rights_status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('unknown'));
  static const VerificationMeta _lastWatchedMeta =
      const VerificationMeta('lastWatched');
  @override
  late final GeneratedColumn<DateTime> lastWatched = GeneratedColumn<DateTime>(
      'last_watched', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        name,
        logoUrl,
        groupTitle,
        tvgId,
        tvgName,
        country,
        language,
        categories,
        streamUrl,
        sourceId,
        isFavorite,
        isHidden,
        userOrder,
        rightsStatus,
        lastWatched,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'channels_table';
  @override
  VerificationContext validateIntegrity(Insertable<ChannelsTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('logo_url')) {
      context.handle(_logoUrlMeta,
          logoUrl.isAcceptableOrUnknown(data['logo_url']!, _logoUrlMeta));
    }
    if (data.containsKey('group_title')) {
      context.handle(
          _groupTitleMeta,
          groupTitle.isAcceptableOrUnknown(
              data['group_title']!, _groupTitleMeta));
    }
    if (data.containsKey('tvg_id')) {
      context.handle(
          _tvgIdMeta, tvgId.isAcceptableOrUnknown(data['tvg_id']!, _tvgIdMeta));
    }
    if (data.containsKey('tvg_name')) {
      context.handle(_tvgNameMeta,
          tvgName.isAcceptableOrUnknown(data['tvg_name']!, _tvgNameMeta));
    }
    if (data.containsKey('country')) {
      context.handle(_countryMeta,
          country.isAcceptableOrUnknown(data['country']!, _countryMeta));
    }
    if (data.containsKey('language')) {
      context.handle(_languageMeta,
          language.isAcceptableOrUnknown(data['language']!, _languageMeta));
    }
    if (data.containsKey('categories')) {
      context.handle(
          _categoriesMeta,
          categories.isAcceptableOrUnknown(
              data['categories']!, _categoriesMeta));
    }
    if (data.containsKey('stream_url')) {
      context.handle(_streamUrlMeta,
          streamUrl.isAcceptableOrUnknown(data['stream_url']!, _streamUrlMeta));
    } else if (isInserting) {
      context.missing(_streamUrlMeta);
    }
    if (data.containsKey('source_id')) {
      context.handle(_sourceIdMeta,
          sourceId.isAcceptableOrUnknown(data['source_id']!, _sourceIdMeta));
    } else if (isInserting) {
      context.missing(_sourceIdMeta);
    }
    if (data.containsKey('is_favorite')) {
      context.handle(
          _isFavoriteMeta,
          isFavorite.isAcceptableOrUnknown(
              data['is_favorite']!, _isFavoriteMeta));
    }
    if (data.containsKey('is_hidden')) {
      context.handle(_isHiddenMeta,
          isHidden.isAcceptableOrUnknown(data['is_hidden']!, _isHiddenMeta));
    }
    if (data.containsKey('user_order')) {
      context.handle(_userOrderMeta,
          userOrder.isAcceptableOrUnknown(data['user_order']!, _userOrderMeta));
    }
    if (data.containsKey('rights_status')) {
      context.handle(
          _rightsStatusMeta,
          rightsStatus.isAcceptableOrUnknown(
              data['rights_status']!, _rightsStatusMeta));
    }
    if (data.containsKey('last_watched')) {
      context.handle(
          _lastWatchedMeta,
          lastWatched.isAcceptableOrUnknown(
              data['last_watched']!, _lastWatchedMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
        {sourceId, streamUrl},
      ];
  @override
  ChannelsTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ChannelsTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      logoUrl: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logo_url']),
      groupTitle: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}group_title']),
      tvgId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tvg_id']),
      tvgName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tvg_name']),
      country: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}country']),
      language: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}language']),
      categories: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}categories']),
      streamUrl: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}stream_url'])!,
      sourceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}source_id'])!,
      isFavorite: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_favorite'])!,
      isHidden: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_hidden'])!,
      userOrder: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}user_order']),
      rightsStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rights_status'])!,
      lastWatched: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}last_watched']),
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $ChannelsTableTable createAlias(String alias) {
    return $ChannelsTableTable(attachedDatabase, alias);
  }
}

class ChannelsTableData extends DataClass
    implements Insertable<ChannelsTableData> {
  final String id;
  final String name;
  final String? logoUrl;
  final String? groupTitle;
  final String? tvgId;
  final String? tvgName;
  final String? country;
  final String? language;
  final String? categories;
  final String streamUrl;
  final String sourceId;
  final bool isFavorite;
  final bool isHidden;
  final int? userOrder;
  final String rightsStatus;
  final DateTime? lastWatched;
  final DateTime createdAt;
  const ChannelsTableData(
      {required this.id,
      required this.name,
      this.logoUrl,
      this.groupTitle,
      this.tvgId,
      this.tvgName,
      this.country,
      this.language,
      this.categories,
      required this.streamUrl,
      required this.sourceId,
      required this.isFavorite,
      required this.isHidden,
      this.userOrder,
      required this.rightsStatus,
      this.lastWatched,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['name'] = Variable<String>(name);
    if (!nullToAbsent || logoUrl != null) {
      map['logo_url'] = Variable<String>(logoUrl);
    }
    if (!nullToAbsent || groupTitle != null) {
      map['group_title'] = Variable<String>(groupTitle);
    }
    if (!nullToAbsent || tvgId != null) {
      map['tvg_id'] = Variable<String>(tvgId);
    }
    if (!nullToAbsent || tvgName != null) {
      map['tvg_name'] = Variable<String>(tvgName);
    }
    if (!nullToAbsent || country != null) {
      map['country'] = Variable<String>(country);
    }
    if (!nullToAbsent || language != null) {
      map['language'] = Variable<String>(language);
    }
    if (!nullToAbsent || categories != null) {
      map['categories'] = Variable<String>(categories);
    }
    map['stream_url'] = Variable<String>(streamUrl);
    map['source_id'] = Variable<String>(sourceId);
    map['is_favorite'] = Variable<bool>(isFavorite);
    map['is_hidden'] = Variable<bool>(isHidden);
    if (!nullToAbsent || userOrder != null) {
      map['user_order'] = Variable<int>(userOrder);
    }
    map['rights_status'] = Variable<String>(rightsStatus);
    if (!nullToAbsent || lastWatched != null) {
      map['last_watched'] = Variable<DateTime>(lastWatched);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  ChannelsTableCompanion toCompanion(bool nullToAbsent) {
    return ChannelsTableCompanion(
      id: Value(id),
      name: Value(name),
      logoUrl: logoUrl == null && nullToAbsent
          ? const Value.absent()
          : Value(logoUrl),
      groupTitle: groupTitle == null && nullToAbsent
          ? const Value.absent()
          : Value(groupTitle),
      tvgId:
          tvgId == null && nullToAbsent ? const Value.absent() : Value(tvgId),
      tvgName: tvgName == null && nullToAbsent
          ? const Value.absent()
          : Value(tvgName),
      country: country == null && nullToAbsent
          ? const Value.absent()
          : Value(country),
      language: language == null && nullToAbsent
          ? const Value.absent()
          : Value(language),
      categories: categories == null && nullToAbsent
          ? const Value.absent()
          : Value(categories),
      streamUrl: Value(streamUrl),
      sourceId: Value(sourceId),
      isFavorite: Value(isFavorite),
      isHidden: Value(isHidden),
      userOrder: userOrder == null && nullToAbsent
          ? const Value.absent()
          : Value(userOrder),
      rightsStatus: Value(rightsStatus),
      lastWatched: lastWatched == null && nullToAbsent
          ? const Value.absent()
          : Value(lastWatched),
      createdAt: Value(createdAt),
    );
  }

  factory ChannelsTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ChannelsTableData(
      id: serializer.fromJson<String>(json['id']),
      name: serializer.fromJson<String>(json['name']),
      logoUrl: serializer.fromJson<String?>(json['logoUrl']),
      groupTitle: serializer.fromJson<String?>(json['groupTitle']),
      tvgId: serializer.fromJson<String?>(json['tvgId']),
      tvgName: serializer.fromJson<String?>(json['tvgName']),
      country: serializer.fromJson<String?>(json['country']),
      language: serializer.fromJson<String?>(json['language']),
      categories: serializer.fromJson<String?>(json['categories']),
      streamUrl: serializer.fromJson<String>(json['streamUrl']),
      sourceId: serializer.fromJson<String>(json['sourceId']),
      isFavorite: serializer.fromJson<bool>(json['isFavorite']),
      isHidden: serializer.fromJson<bool>(json['isHidden']),
      userOrder: serializer.fromJson<int?>(json['userOrder']),
      rightsStatus: serializer.fromJson<String>(json['rightsStatus']),
      lastWatched: serializer.fromJson<DateTime?>(json['lastWatched']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'name': serializer.toJson<String>(name),
      'logoUrl': serializer.toJson<String?>(logoUrl),
      'groupTitle': serializer.toJson<String?>(groupTitle),
      'tvgId': serializer.toJson<String?>(tvgId),
      'tvgName': serializer.toJson<String?>(tvgName),
      'country': serializer.toJson<String?>(country),
      'language': serializer.toJson<String?>(language),
      'categories': serializer.toJson<String?>(categories),
      'streamUrl': serializer.toJson<String>(streamUrl),
      'sourceId': serializer.toJson<String>(sourceId),
      'isFavorite': serializer.toJson<bool>(isFavorite),
      'isHidden': serializer.toJson<bool>(isHidden),
      'userOrder': serializer.toJson<int?>(userOrder),
      'rightsStatus': serializer.toJson<String>(rightsStatus),
      'lastWatched': serializer.toJson<DateTime?>(lastWatched),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  ChannelsTableData copyWith(
          {String? id,
          String? name,
          Value<String?> logoUrl = const Value.absent(),
          Value<String?> groupTitle = const Value.absent(),
          Value<String?> tvgId = const Value.absent(),
          Value<String?> tvgName = const Value.absent(),
          Value<String?> country = const Value.absent(),
          Value<String?> language = const Value.absent(),
          Value<String?> categories = const Value.absent(),
          String? streamUrl,
          String? sourceId,
          bool? isFavorite,
          bool? isHidden,
          Value<int?> userOrder = const Value.absent(),
          String? rightsStatus,
          Value<DateTime?> lastWatched = const Value.absent(),
          DateTime? createdAt}) =>
      ChannelsTableData(
        id: id ?? this.id,
        name: name ?? this.name,
        logoUrl: logoUrl.present ? logoUrl.value : this.logoUrl,
        groupTitle: groupTitle.present ? groupTitle.value : this.groupTitle,
        tvgId: tvgId.present ? tvgId.value : this.tvgId,
        tvgName: tvgName.present ? tvgName.value : this.tvgName,
        country: country.present ? country.value : this.country,
        language: language.present ? language.value : this.language,
        categories: categories.present ? categories.value : this.categories,
        streamUrl: streamUrl ?? this.streamUrl,
        sourceId: sourceId ?? this.sourceId,
        isFavorite: isFavorite ?? this.isFavorite,
        isHidden: isHidden ?? this.isHidden,
        userOrder: userOrder.present ? userOrder.value : this.userOrder,
        rightsStatus: rightsStatus ?? this.rightsStatus,
        lastWatched: lastWatched.present ? lastWatched.value : this.lastWatched,
        createdAt: createdAt ?? this.createdAt,
      );
  ChannelsTableData copyWithCompanion(ChannelsTableCompanion data) {
    return ChannelsTableData(
      id: data.id.present ? data.id.value : this.id,
      name: data.name.present ? data.name.value : this.name,
      logoUrl: data.logoUrl.present ? data.logoUrl.value : this.logoUrl,
      groupTitle:
          data.groupTitle.present ? data.groupTitle.value : this.groupTitle,
      tvgId: data.tvgId.present ? data.tvgId.value : this.tvgId,
      tvgName: data.tvgName.present ? data.tvgName.value : this.tvgName,
      country: data.country.present ? data.country.value : this.country,
      language: data.language.present ? data.language.value : this.language,
      categories:
          data.categories.present ? data.categories.value : this.categories,
      streamUrl: data.streamUrl.present ? data.streamUrl.value : this.streamUrl,
      sourceId: data.sourceId.present ? data.sourceId.value : this.sourceId,
      isFavorite:
          data.isFavorite.present ? data.isFavorite.value : this.isFavorite,
      isHidden: data.isHidden.present ? data.isHidden.value : this.isHidden,
      userOrder: data.userOrder.present ? data.userOrder.value : this.userOrder,
      rightsStatus: data.rightsStatus.present
          ? data.rightsStatus.value
          : this.rightsStatus,
      lastWatched:
          data.lastWatched.present ? data.lastWatched.value : this.lastWatched,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ChannelsTableData(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('logoUrl: $logoUrl, ')
          ..write('groupTitle: $groupTitle, ')
          ..write('tvgId: $tvgId, ')
          ..write('tvgName: $tvgName, ')
          ..write('country: $country, ')
          ..write('language: $language, ')
          ..write('categories: $categories, ')
          ..write('streamUrl: $streamUrl, ')
          ..write('sourceId: $sourceId, ')
          ..write('isFavorite: $isFavorite, ')
          ..write('isHidden: $isHidden, ')
          ..write('userOrder: $userOrder, ')
          ..write('rightsStatus: $rightsStatus, ')
          ..write('lastWatched: $lastWatched, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      name,
      logoUrl,
      groupTitle,
      tvgId,
      tvgName,
      country,
      language,
      categories,
      streamUrl,
      sourceId,
      isFavorite,
      isHidden,
      userOrder,
      rightsStatus,
      lastWatched,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ChannelsTableData &&
          other.id == this.id &&
          other.name == this.name &&
          other.logoUrl == this.logoUrl &&
          other.groupTitle == this.groupTitle &&
          other.tvgId == this.tvgId &&
          other.tvgName == this.tvgName &&
          other.country == this.country &&
          other.language == this.language &&
          other.categories == this.categories &&
          other.streamUrl == this.streamUrl &&
          other.sourceId == this.sourceId &&
          other.isFavorite == this.isFavorite &&
          other.isHidden == this.isHidden &&
          other.userOrder == this.userOrder &&
          other.rightsStatus == this.rightsStatus &&
          other.lastWatched == this.lastWatched &&
          other.createdAt == this.createdAt);
}

class ChannelsTableCompanion extends UpdateCompanion<ChannelsTableData> {
  final Value<String> id;
  final Value<String> name;
  final Value<String?> logoUrl;
  final Value<String?> groupTitle;
  final Value<String?> tvgId;
  final Value<String?> tvgName;
  final Value<String?> country;
  final Value<String?> language;
  final Value<String?> categories;
  final Value<String> streamUrl;
  final Value<String> sourceId;
  final Value<bool> isFavorite;
  final Value<bool> isHidden;
  final Value<int?> userOrder;
  final Value<String> rightsStatus;
  final Value<DateTime?> lastWatched;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const ChannelsTableCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.logoUrl = const Value.absent(),
    this.groupTitle = const Value.absent(),
    this.tvgId = const Value.absent(),
    this.tvgName = const Value.absent(),
    this.country = const Value.absent(),
    this.language = const Value.absent(),
    this.categories = const Value.absent(),
    this.streamUrl = const Value.absent(),
    this.sourceId = const Value.absent(),
    this.isFavorite = const Value.absent(),
    this.isHidden = const Value.absent(),
    this.userOrder = const Value.absent(),
    this.rightsStatus = const Value.absent(),
    this.lastWatched = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ChannelsTableCompanion.insert({
    required String id,
    required String name,
    this.logoUrl = const Value.absent(),
    this.groupTitle = const Value.absent(),
    this.tvgId = const Value.absent(),
    this.tvgName = const Value.absent(),
    this.country = const Value.absent(),
    this.language = const Value.absent(),
    this.categories = const Value.absent(),
    required String streamUrl,
    required String sourceId,
    this.isFavorite = const Value.absent(),
    this.isHidden = const Value.absent(),
    this.userOrder = const Value.absent(),
    this.rightsStatus = const Value.absent(),
    this.lastWatched = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        name = Value(name),
        streamUrl = Value(streamUrl),
        sourceId = Value(sourceId);
  static Insertable<ChannelsTableData> custom({
    Expression<String>? id,
    Expression<String>? name,
    Expression<String>? logoUrl,
    Expression<String>? groupTitle,
    Expression<String>? tvgId,
    Expression<String>? tvgName,
    Expression<String>? country,
    Expression<String>? language,
    Expression<String>? categories,
    Expression<String>? streamUrl,
    Expression<String>? sourceId,
    Expression<bool>? isFavorite,
    Expression<bool>? isHidden,
    Expression<int>? userOrder,
    Expression<String>? rightsStatus,
    Expression<DateTime>? lastWatched,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (logoUrl != null) 'logo_url': logoUrl,
      if (groupTitle != null) 'group_title': groupTitle,
      if (tvgId != null) 'tvg_id': tvgId,
      if (tvgName != null) 'tvg_name': tvgName,
      if (country != null) 'country': country,
      if (language != null) 'language': language,
      if (categories != null) 'categories': categories,
      if (streamUrl != null) 'stream_url': streamUrl,
      if (sourceId != null) 'source_id': sourceId,
      if (isFavorite != null) 'is_favorite': isFavorite,
      if (isHidden != null) 'is_hidden': isHidden,
      if (userOrder != null) 'user_order': userOrder,
      if (rightsStatus != null) 'rights_status': rightsStatus,
      if (lastWatched != null) 'last_watched': lastWatched,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ChannelsTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? name,
      Value<String?>? logoUrl,
      Value<String?>? groupTitle,
      Value<String?>? tvgId,
      Value<String?>? tvgName,
      Value<String?>? country,
      Value<String?>? language,
      Value<String?>? categories,
      Value<String>? streamUrl,
      Value<String>? sourceId,
      Value<bool>? isFavorite,
      Value<bool>? isHidden,
      Value<int?>? userOrder,
      Value<String>? rightsStatus,
      Value<DateTime?>? lastWatched,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return ChannelsTableCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      logoUrl: logoUrl ?? this.logoUrl,
      groupTitle: groupTitle ?? this.groupTitle,
      tvgId: tvgId ?? this.tvgId,
      tvgName: tvgName ?? this.tvgName,
      country: country ?? this.country,
      language: language ?? this.language,
      categories: categories ?? this.categories,
      streamUrl: streamUrl ?? this.streamUrl,
      sourceId: sourceId ?? this.sourceId,
      isFavorite: isFavorite ?? this.isFavorite,
      isHidden: isHidden ?? this.isHidden,
      userOrder: userOrder ?? this.userOrder,
      rightsStatus: rightsStatus ?? this.rightsStatus,
      lastWatched: lastWatched ?? this.lastWatched,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (logoUrl.present) {
      map['logo_url'] = Variable<String>(logoUrl.value);
    }
    if (groupTitle.present) {
      map['group_title'] = Variable<String>(groupTitle.value);
    }
    if (tvgId.present) {
      map['tvg_id'] = Variable<String>(tvgId.value);
    }
    if (tvgName.present) {
      map['tvg_name'] = Variable<String>(tvgName.value);
    }
    if (country.present) {
      map['country'] = Variable<String>(country.value);
    }
    if (language.present) {
      map['language'] = Variable<String>(language.value);
    }
    if (categories.present) {
      map['categories'] = Variable<String>(categories.value);
    }
    if (streamUrl.present) {
      map['stream_url'] = Variable<String>(streamUrl.value);
    }
    if (sourceId.present) {
      map['source_id'] = Variable<String>(sourceId.value);
    }
    if (isFavorite.present) {
      map['is_favorite'] = Variable<bool>(isFavorite.value);
    }
    if (isHidden.present) {
      map['is_hidden'] = Variable<bool>(isHidden.value);
    }
    if (userOrder.present) {
      map['user_order'] = Variable<int>(userOrder.value);
    }
    if (rightsStatus.present) {
      map['rights_status'] = Variable<String>(rightsStatus.value);
    }
    if (lastWatched.present) {
      map['last_watched'] = Variable<DateTime>(lastWatched.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ChannelsTableCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('logoUrl: $logoUrl, ')
          ..write('groupTitle: $groupTitle, ')
          ..write('tvgId: $tvgId, ')
          ..write('tvgName: $tvgName, ')
          ..write('country: $country, ')
          ..write('language: $language, ')
          ..write('categories: $categories, ')
          ..write('streamUrl: $streamUrl, ')
          ..write('sourceId: $sourceId, ')
          ..write('isFavorite: $isFavorite, ')
          ..write('isHidden: $isHidden, ')
          ..write('userOrder: $userOrder, ')
          ..write('rightsStatus: $rightsStatus, ')
          ..write('lastWatched: $lastWatched, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PlaylistSourcesTableTable extends PlaylistSourcesTable
    with TableInfo<$PlaylistSourcesTableTable, PlaylistSourcesTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PlaylistSourcesTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _urlMeta = const VerificationMeta('url');
  @override
  late final GeneratedColumn<String> url = GeneratedColumn<String>(
      'url', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _filePathMeta =
      const VerificationMeta('filePath');
  @override
  late final GeneratedColumn<String> filePath = GeneratedColumn<String>(
      'file_path', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _usernameMeta =
      const VerificationMeta('username');
  @override
  late final GeneratedColumn<String> username = GeneratedColumn<String>(
      'username', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _channelCountMeta =
      const VerificationMeta('channelCount');
  @override
  late final GeneratedColumn<int> channelCount = GeneratedColumn<int>(
      'channel_count', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('unconfigured'));
  static const VerificationMeta _lastErrorMeta =
      const VerificationMeta('lastError');
  @override
  late final GeneratedColumn<String> lastError = GeneratedColumn<String>(
      'last_error', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _lastRefreshMeta =
      const VerificationMeta('lastRefresh');
  @override
  late final GeneratedColumn<DateTime> lastRefresh = GeneratedColumn<DateTime>(
      'last_refresh', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _lastSuccessMeta =
      const VerificationMeta('lastSuccess');
  @override
  late final GeneratedColumn<DateTime> lastSuccess = GeneratedColumn<DateTime>(
      'last_success', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _etagMeta = const VerificationMeta('etag');
  @override
  late final GeneratedColumn<String> etag = GeneratedColumn<String>(
      'etag', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _priorityMeta =
      const VerificationMeta('priority');
  @override
  late final GeneratedColumn<int> priority = GeneratedColumn<int>(
      'priority', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(100));
  static const VerificationMeta _isEnabledMeta =
      const VerificationMeta('isEnabled');
  @override
  late final GeneratedColumn<bool> isEnabled = GeneratedColumn<bool>(
      'is_enabled', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_enabled" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        name,
        type,
        url,
        filePath,
        username,
        channelCount,
        status,
        lastError,
        lastRefresh,
        lastSuccess,
        etag,
        priority,
        isEnabled,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'playlist_sources_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<PlaylistSourcesTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    if (data.containsKey('url')) {
      context.handle(
          _urlMeta, url.isAcceptableOrUnknown(data['url']!, _urlMeta));
    }
    if (data.containsKey('file_path')) {
      context.handle(_filePathMeta,
          filePath.isAcceptableOrUnknown(data['file_path']!, _filePathMeta));
    }
    if (data.containsKey('username')) {
      context.handle(_usernameMeta,
          username.isAcceptableOrUnknown(data['username']!, _usernameMeta));
    }
    if (data.containsKey('channel_count')) {
      context.handle(
          _channelCountMeta,
          channelCount.isAcceptableOrUnknown(
              data['channel_count']!, _channelCountMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('last_error')) {
      context.handle(_lastErrorMeta,
          lastError.isAcceptableOrUnknown(data['last_error']!, _lastErrorMeta));
    }
    if (data.containsKey('last_refresh')) {
      context.handle(
          _lastRefreshMeta,
          lastRefresh.isAcceptableOrUnknown(
              data['last_refresh']!, _lastRefreshMeta));
    }
    if (data.containsKey('last_success')) {
      context.handle(
          _lastSuccessMeta,
          lastSuccess.isAcceptableOrUnknown(
              data['last_success']!, _lastSuccessMeta));
    }
    if (data.containsKey('etag')) {
      context.handle(
          _etagMeta, etag.isAcceptableOrUnknown(data['etag']!, _etagMeta));
    }
    if (data.containsKey('priority')) {
      context.handle(_priorityMeta,
          priority.isAcceptableOrUnknown(data['priority']!, _priorityMeta));
    }
    if (data.containsKey('is_enabled')) {
      context.handle(_isEnabledMeta,
          isEnabled.isAcceptableOrUnknown(data['is_enabled']!, _isEnabledMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PlaylistSourcesTableData map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PlaylistSourcesTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      url: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}url']),
      filePath: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}file_path']),
      username: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}username']),
      channelCount: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}channel_count'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      lastError: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}last_error']),
      lastRefresh: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}last_refresh']),
      lastSuccess: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}last_success']),
      etag: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}etag']),
      priority: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}priority'])!,
      isEnabled: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_enabled'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $PlaylistSourcesTableTable createAlias(String alias) {
    return $PlaylistSourcesTableTable(attachedDatabase, alias);
  }
}

class PlaylistSourcesTableData extends DataClass
    implements Insertable<PlaylistSourcesTableData> {
  final String id;
  final String name;
  final String type;
  final String? url;
  final String? filePath;
  final String? username;
  final int channelCount;
  final String status;
  final String? lastError;
  final DateTime? lastRefresh;
  final DateTime? lastSuccess;
  final String? etag;
  final int priority;
  final bool isEnabled;
  final DateTime createdAt;
  const PlaylistSourcesTableData(
      {required this.id,
      required this.name,
      required this.type,
      this.url,
      this.filePath,
      this.username,
      required this.channelCount,
      required this.status,
      this.lastError,
      this.lastRefresh,
      this.lastSuccess,
      this.etag,
      required this.priority,
      required this.isEnabled,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['name'] = Variable<String>(name);
    map['type'] = Variable<String>(type);
    if (!nullToAbsent || url != null) {
      map['url'] = Variable<String>(url);
    }
    if (!nullToAbsent || filePath != null) {
      map['file_path'] = Variable<String>(filePath);
    }
    if (!nullToAbsent || username != null) {
      map['username'] = Variable<String>(username);
    }
    map['channel_count'] = Variable<int>(channelCount);
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || lastError != null) {
      map['last_error'] = Variable<String>(lastError);
    }
    if (!nullToAbsent || lastRefresh != null) {
      map['last_refresh'] = Variable<DateTime>(lastRefresh);
    }
    if (!nullToAbsent || lastSuccess != null) {
      map['last_success'] = Variable<DateTime>(lastSuccess);
    }
    if (!nullToAbsent || etag != null) {
      map['etag'] = Variable<String>(etag);
    }
    map['priority'] = Variable<int>(priority);
    map['is_enabled'] = Variable<bool>(isEnabled);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  PlaylistSourcesTableCompanion toCompanion(bool nullToAbsent) {
    return PlaylistSourcesTableCompanion(
      id: Value(id),
      name: Value(name),
      type: Value(type),
      url: url == null && nullToAbsent ? const Value.absent() : Value(url),
      filePath: filePath == null && nullToAbsent
          ? const Value.absent()
          : Value(filePath),
      username: username == null && nullToAbsent
          ? const Value.absent()
          : Value(username),
      channelCount: Value(channelCount),
      status: Value(status),
      lastError: lastError == null && nullToAbsent
          ? const Value.absent()
          : Value(lastError),
      lastRefresh: lastRefresh == null && nullToAbsent
          ? const Value.absent()
          : Value(lastRefresh),
      lastSuccess: lastSuccess == null && nullToAbsent
          ? const Value.absent()
          : Value(lastSuccess),
      etag: etag == null && nullToAbsent ? const Value.absent() : Value(etag),
      priority: Value(priority),
      isEnabled: Value(isEnabled),
      createdAt: Value(createdAt),
    );
  }

  factory PlaylistSourcesTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PlaylistSourcesTableData(
      id: serializer.fromJson<String>(json['id']),
      name: serializer.fromJson<String>(json['name']),
      type: serializer.fromJson<String>(json['type']),
      url: serializer.fromJson<String?>(json['url']),
      filePath: serializer.fromJson<String?>(json['filePath']),
      username: serializer.fromJson<String?>(json['username']),
      channelCount: serializer.fromJson<int>(json['channelCount']),
      status: serializer.fromJson<String>(json['status']),
      lastError: serializer.fromJson<String?>(json['lastError']),
      lastRefresh: serializer.fromJson<DateTime?>(json['lastRefresh']),
      lastSuccess: serializer.fromJson<DateTime?>(json['lastSuccess']),
      etag: serializer.fromJson<String?>(json['etag']),
      priority: serializer.fromJson<int>(json['priority']),
      isEnabled: serializer.fromJson<bool>(json['isEnabled']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'name': serializer.toJson<String>(name),
      'type': serializer.toJson<String>(type),
      'url': serializer.toJson<String?>(url),
      'filePath': serializer.toJson<String?>(filePath),
      'username': serializer.toJson<String?>(username),
      'channelCount': serializer.toJson<int>(channelCount),
      'status': serializer.toJson<String>(status),
      'lastError': serializer.toJson<String?>(lastError),
      'lastRefresh': serializer.toJson<DateTime?>(lastRefresh),
      'lastSuccess': serializer.toJson<DateTime?>(lastSuccess),
      'etag': serializer.toJson<String?>(etag),
      'priority': serializer.toJson<int>(priority),
      'isEnabled': serializer.toJson<bool>(isEnabled),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  PlaylistSourcesTableData copyWith(
          {String? id,
          String? name,
          String? type,
          Value<String?> url = const Value.absent(),
          Value<String?> filePath = const Value.absent(),
          Value<String?> username = const Value.absent(),
          int? channelCount,
          String? status,
          Value<String?> lastError = const Value.absent(),
          Value<DateTime?> lastRefresh = const Value.absent(),
          Value<DateTime?> lastSuccess = const Value.absent(),
          Value<String?> etag = const Value.absent(),
          int? priority,
          bool? isEnabled,
          DateTime? createdAt}) =>
      PlaylistSourcesTableData(
        id: id ?? this.id,
        name: name ?? this.name,
        type: type ?? this.type,
        url: url.present ? url.value : this.url,
        filePath: filePath.present ? filePath.value : this.filePath,
        username: username.present ? username.value : this.username,
        channelCount: channelCount ?? this.channelCount,
        status: status ?? this.status,
        lastError: lastError.present ? lastError.value : this.lastError,
        lastRefresh: lastRefresh.present ? lastRefresh.value : this.lastRefresh,
        lastSuccess: lastSuccess.present ? lastSuccess.value : this.lastSuccess,
        etag: etag.present ? etag.value : this.etag,
        priority: priority ?? this.priority,
        isEnabled: isEnabled ?? this.isEnabled,
        createdAt: createdAt ?? this.createdAt,
      );
  PlaylistSourcesTableData copyWithCompanion(
      PlaylistSourcesTableCompanion data) {
    return PlaylistSourcesTableData(
      id: data.id.present ? data.id.value : this.id,
      name: data.name.present ? data.name.value : this.name,
      type: data.type.present ? data.type.value : this.type,
      url: data.url.present ? data.url.value : this.url,
      filePath: data.filePath.present ? data.filePath.value : this.filePath,
      username: data.username.present ? data.username.value : this.username,
      channelCount: data.channelCount.present
          ? data.channelCount.value
          : this.channelCount,
      status: data.status.present ? data.status.value : this.status,
      lastError: data.lastError.present ? data.lastError.value : this.lastError,
      lastRefresh:
          data.lastRefresh.present ? data.lastRefresh.value : this.lastRefresh,
      lastSuccess:
          data.lastSuccess.present ? data.lastSuccess.value : this.lastSuccess,
      etag: data.etag.present ? data.etag.value : this.etag,
      priority: data.priority.present ? data.priority.value : this.priority,
      isEnabled: data.isEnabled.present ? data.isEnabled.value : this.isEnabled,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PlaylistSourcesTableData(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('type: $type, ')
          ..write('url: $url, ')
          ..write('filePath: $filePath, ')
          ..write('username: $username, ')
          ..write('channelCount: $channelCount, ')
          ..write('status: $status, ')
          ..write('lastError: $lastError, ')
          ..write('lastRefresh: $lastRefresh, ')
          ..write('lastSuccess: $lastSuccess, ')
          ..write('etag: $etag, ')
          ..write('priority: $priority, ')
          ..write('isEnabled: $isEnabled, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      name,
      type,
      url,
      filePath,
      username,
      channelCount,
      status,
      lastError,
      lastRefresh,
      lastSuccess,
      etag,
      priority,
      isEnabled,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PlaylistSourcesTableData &&
          other.id == this.id &&
          other.name == this.name &&
          other.type == this.type &&
          other.url == this.url &&
          other.filePath == this.filePath &&
          other.username == this.username &&
          other.channelCount == this.channelCount &&
          other.status == this.status &&
          other.lastError == this.lastError &&
          other.lastRefresh == this.lastRefresh &&
          other.lastSuccess == this.lastSuccess &&
          other.etag == this.etag &&
          other.priority == this.priority &&
          other.isEnabled == this.isEnabled &&
          other.createdAt == this.createdAt);
}

class PlaylistSourcesTableCompanion
    extends UpdateCompanion<PlaylistSourcesTableData> {
  final Value<String> id;
  final Value<String> name;
  final Value<String> type;
  final Value<String?> url;
  final Value<String?> filePath;
  final Value<String?> username;
  final Value<int> channelCount;
  final Value<String> status;
  final Value<String?> lastError;
  final Value<DateTime?> lastRefresh;
  final Value<DateTime?> lastSuccess;
  final Value<String?> etag;
  final Value<int> priority;
  final Value<bool> isEnabled;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const PlaylistSourcesTableCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.type = const Value.absent(),
    this.url = const Value.absent(),
    this.filePath = const Value.absent(),
    this.username = const Value.absent(),
    this.channelCount = const Value.absent(),
    this.status = const Value.absent(),
    this.lastError = const Value.absent(),
    this.lastRefresh = const Value.absent(),
    this.lastSuccess = const Value.absent(),
    this.etag = const Value.absent(),
    this.priority = const Value.absent(),
    this.isEnabled = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PlaylistSourcesTableCompanion.insert({
    required String id,
    required String name,
    required String type,
    this.url = const Value.absent(),
    this.filePath = const Value.absent(),
    this.username = const Value.absent(),
    this.channelCount = const Value.absent(),
    this.status = const Value.absent(),
    this.lastError = const Value.absent(),
    this.lastRefresh = const Value.absent(),
    this.lastSuccess = const Value.absent(),
    this.etag = const Value.absent(),
    this.priority = const Value.absent(),
    this.isEnabled = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        name = Value(name),
        type = Value(type);
  static Insertable<PlaylistSourcesTableData> custom({
    Expression<String>? id,
    Expression<String>? name,
    Expression<String>? type,
    Expression<String>? url,
    Expression<String>? filePath,
    Expression<String>? username,
    Expression<int>? channelCount,
    Expression<String>? status,
    Expression<String>? lastError,
    Expression<DateTime>? lastRefresh,
    Expression<DateTime>? lastSuccess,
    Expression<String>? etag,
    Expression<int>? priority,
    Expression<bool>? isEnabled,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (type != null) 'type': type,
      if (url != null) 'url': url,
      if (filePath != null) 'file_path': filePath,
      if (username != null) 'username': username,
      if (channelCount != null) 'channel_count': channelCount,
      if (status != null) 'status': status,
      if (lastError != null) 'last_error': lastError,
      if (lastRefresh != null) 'last_refresh': lastRefresh,
      if (lastSuccess != null) 'last_success': lastSuccess,
      if (etag != null) 'etag': etag,
      if (priority != null) 'priority': priority,
      if (isEnabled != null) 'is_enabled': isEnabled,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PlaylistSourcesTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? name,
      Value<String>? type,
      Value<String?>? url,
      Value<String?>? filePath,
      Value<String?>? username,
      Value<int>? channelCount,
      Value<String>? status,
      Value<String?>? lastError,
      Value<DateTime?>? lastRefresh,
      Value<DateTime?>? lastSuccess,
      Value<String?>? etag,
      Value<int>? priority,
      Value<bool>? isEnabled,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return PlaylistSourcesTableCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      url: url ?? this.url,
      filePath: filePath ?? this.filePath,
      username: username ?? this.username,
      channelCount: channelCount ?? this.channelCount,
      status: status ?? this.status,
      lastError: lastError ?? this.lastError,
      lastRefresh: lastRefresh ?? this.lastRefresh,
      lastSuccess: lastSuccess ?? this.lastSuccess,
      etag: etag ?? this.etag,
      priority: priority ?? this.priority,
      isEnabled: isEnabled ?? this.isEnabled,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (url.present) {
      map['url'] = Variable<String>(url.value);
    }
    if (filePath.present) {
      map['file_path'] = Variable<String>(filePath.value);
    }
    if (username.present) {
      map['username'] = Variable<String>(username.value);
    }
    if (channelCount.present) {
      map['channel_count'] = Variable<int>(channelCount.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (lastError.present) {
      map['last_error'] = Variable<String>(lastError.value);
    }
    if (lastRefresh.present) {
      map['last_refresh'] = Variable<DateTime>(lastRefresh.value);
    }
    if (lastSuccess.present) {
      map['last_success'] = Variable<DateTime>(lastSuccess.value);
    }
    if (etag.present) {
      map['etag'] = Variable<String>(etag.value);
    }
    if (priority.present) {
      map['priority'] = Variable<int>(priority.value);
    }
    if (isEnabled.present) {
      map['is_enabled'] = Variable<bool>(isEnabled.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PlaylistSourcesTableCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('type: $type, ')
          ..write('url: $url, ')
          ..write('filePath: $filePath, ')
          ..write('username: $username, ')
          ..write('channelCount: $channelCount, ')
          ..write('status: $status, ')
          ..write('lastError: $lastError, ')
          ..write('lastRefresh: $lastRefresh, ')
          ..write('lastSuccess: $lastSuccess, ')
          ..write('etag: $etag, ')
          ..write('priority: $priority, ')
          ..write('isEnabled: $isEnabled, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EpgProgrammesTableTable extends EpgProgrammesTable
    with TableInfo<$EpgProgrammesTableTable, EpgProgrammesTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EpgProgrammesTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _channelIdMeta =
      const VerificationMeta('channelId');
  @override
  late final GeneratedColumn<String> channelId = GeneratedColumn<String>(
      'channel_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _descriptionMeta =
      const VerificationMeta('description');
  @override
  late final GeneratedColumn<String> description = GeneratedColumn<String>(
      'description', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _categoryMeta =
      const VerificationMeta('category');
  @override
  late final GeneratedColumn<String> category = GeneratedColumn<String>(
      'category', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _languageMeta =
      const VerificationMeta('language');
  @override
  late final GeneratedColumn<String> language = GeneratedColumn<String>(
      'language', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _startTimeMeta =
      const VerificationMeta('startTime');
  @override
  late final GeneratedColumn<DateTime> startTime = GeneratedColumn<DateTime>(
      'start_time', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _endTimeMeta =
      const VerificationMeta('endTime');
  @override
  late final GeneratedColumn<DateTime> endTime = GeneratedColumn<DateTime>(
      'end_time', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _sourceIdMeta =
      const VerificationMeta('sourceId');
  @override
  late final GeneratedColumn<String> sourceId = GeneratedColumn<String>(
      'source_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        channelId,
        title,
        description,
        category,
        language,
        startTime,
        endTime,
        sourceId
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'epg_programmes_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<EpgProgrammesTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('channel_id')) {
      context.handle(_channelIdMeta,
          channelId.isAcceptableOrUnknown(data['channel_id']!, _channelIdMeta));
    } else if (isInserting) {
      context.missing(_channelIdMeta);
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('description')) {
      context.handle(
          _descriptionMeta,
          description.isAcceptableOrUnknown(
              data['description']!, _descriptionMeta));
    }
    if (data.containsKey('category')) {
      context.handle(_categoryMeta,
          category.isAcceptableOrUnknown(data['category']!, _categoryMeta));
    }
    if (data.containsKey('language')) {
      context.handle(_languageMeta,
          language.isAcceptableOrUnknown(data['language']!, _languageMeta));
    }
    if (data.containsKey('start_time')) {
      context.handle(_startTimeMeta,
          startTime.isAcceptableOrUnknown(data['start_time']!, _startTimeMeta));
    } else if (isInserting) {
      context.missing(_startTimeMeta);
    }
    if (data.containsKey('end_time')) {
      context.handle(_endTimeMeta,
          endTime.isAcceptableOrUnknown(data['end_time']!, _endTimeMeta));
    } else if (isInserting) {
      context.missing(_endTimeMeta);
    }
    if (data.containsKey('source_id')) {
      context.handle(_sourceIdMeta,
          sourceId.isAcceptableOrUnknown(data['source_id']!, _sourceIdMeta));
    } else if (isInserting) {
      context.missing(_sourceIdMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EpgProgrammesTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EpgProgrammesTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      channelId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}channel_id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      description: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}description']),
      category: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category']),
      language: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}language']),
      startTime: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}start_time'])!,
      endTime: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}end_time'])!,
      sourceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}source_id'])!,
    );
  }

  @override
  $EpgProgrammesTableTable createAlias(String alias) {
    return $EpgProgrammesTableTable(attachedDatabase, alias);
  }
}

class EpgProgrammesTableData extends DataClass
    implements Insertable<EpgProgrammesTableData> {
  final String id;
  final String channelId;
  final String title;
  final String? description;
  final String? category;
  final String? language;
  final DateTime startTime;
  final DateTime endTime;
  final String sourceId;
  const EpgProgrammesTableData(
      {required this.id,
      required this.channelId,
      required this.title,
      this.description,
      this.category,
      this.language,
      required this.startTime,
      required this.endTime,
      required this.sourceId});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['channel_id'] = Variable<String>(channelId);
    map['title'] = Variable<String>(title);
    if (!nullToAbsent || description != null) {
      map['description'] = Variable<String>(description);
    }
    if (!nullToAbsent || category != null) {
      map['category'] = Variable<String>(category);
    }
    if (!nullToAbsent || language != null) {
      map['language'] = Variable<String>(language);
    }
    map['start_time'] = Variable<DateTime>(startTime);
    map['end_time'] = Variable<DateTime>(endTime);
    map['source_id'] = Variable<String>(sourceId);
    return map;
  }

  EpgProgrammesTableCompanion toCompanion(bool nullToAbsent) {
    return EpgProgrammesTableCompanion(
      id: Value(id),
      channelId: Value(channelId),
      title: Value(title),
      description: description == null && nullToAbsent
          ? const Value.absent()
          : Value(description),
      category: category == null && nullToAbsent
          ? const Value.absent()
          : Value(category),
      language: language == null && nullToAbsent
          ? const Value.absent()
          : Value(language),
      startTime: Value(startTime),
      endTime: Value(endTime),
      sourceId: Value(sourceId),
    );
  }

  factory EpgProgrammesTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EpgProgrammesTableData(
      id: serializer.fromJson<String>(json['id']),
      channelId: serializer.fromJson<String>(json['channelId']),
      title: serializer.fromJson<String>(json['title']),
      description: serializer.fromJson<String?>(json['description']),
      category: serializer.fromJson<String?>(json['category']),
      language: serializer.fromJson<String?>(json['language']),
      startTime: serializer.fromJson<DateTime>(json['startTime']),
      endTime: serializer.fromJson<DateTime>(json['endTime']),
      sourceId: serializer.fromJson<String>(json['sourceId']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'channelId': serializer.toJson<String>(channelId),
      'title': serializer.toJson<String>(title),
      'description': serializer.toJson<String?>(description),
      'category': serializer.toJson<String?>(category),
      'language': serializer.toJson<String?>(language),
      'startTime': serializer.toJson<DateTime>(startTime),
      'endTime': serializer.toJson<DateTime>(endTime),
      'sourceId': serializer.toJson<String>(sourceId),
    };
  }

  EpgProgrammesTableData copyWith(
          {String? id,
          String? channelId,
          String? title,
          Value<String?> description = const Value.absent(),
          Value<String?> category = const Value.absent(),
          Value<String?> language = const Value.absent(),
          DateTime? startTime,
          DateTime? endTime,
          String? sourceId}) =>
      EpgProgrammesTableData(
        id: id ?? this.id,
        channelId: channelId ?? this.channelId,
        title: title ?? this.title,
        description: description.present ? description.value : this.description,
        category: category.present ? category.value : this.category,
        language: language.present ? language.value : this.language,
        startTime: startTime ?? this.startTime,
        endTime: endTime ?? this.endTime,
        sourceId: sourceId ?? this.sourceId,
      );
  EpgProgrammesTableData copyWithCompanion(EpgProgrammesTableCompanion data) {
    return EpgProgrammesTableData(
      id: data.id.present ? data.id.value : this.id,
      channelId: data.channelId.present ? data.channelId.value : this.channelId,
      title: data.title.present ? data.title.value : this.title,
      description:
          data.description.present ? data.description.value : this.description,
      category: data.category.present ? data.category.value : this.category,
      language: data.language.present ? data.language.value : this.language,
      startTime: data.startTime.present ? data.startTime.value : this.startTime,
      endTime: data.endTime.present ? data.endTime.value : this.endTime,
      sourceId: data.sourceId.present ? data.sourceId.value : this.sourceId,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EpgProgrammesTableData(')
          ..write('id: $id, ')
          ..write('channelId: $channelId, ')
          ..write('title: $title, ')
          ..write('description: $description, ')
          ..write('category: $category, ')
          ..write('language: $language, ')
          ..write('startTime: $startTime, ')
          ..write('endTime: $endTime, ')
          ..write('sourceId: $sourceId')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, channelId, title, description, category,
      language, startTime, endTime, sourceId);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EpgProgrammesTableData &&
          other.id == this.id &&
          other.channelId == this.channelId &&
          other.title == this.title &&
          other.description == this.description &&
          other.category == this.category &&
          other.language == this.language &&
          other.startTime == this.startTime &&
          other.endTime == this.endTime &&
          other.sourceId == this.sourceId);
}

class EpgProgrammesTableCompanion
    extends UpdateCompanion<EpgProgrammesTableData> {
  final Value<String> id;
  final Value<String> channelId;
  final Value<String> title;
  final Value<String?> description;
  final Value<String?> category;
  final Value<String?> language;
  final Value<DateTime> startTime;
  final Value<DateTime> endTime;
  final Value<String> sourceId;
  final Value<int> rowid;
  const EpgProgrammesTableCompanion({
    this.id = const Value.absent(),
    this.channelId = const Value.absent(),
    this.title = const Value.absent(),
    this.description = const Value.absent(),
    this.category = const Value.absent(),
    this.language = const Value.absent(),
    this.startTime = const Value.absent(),
    this.endTime = const Value.absent(),
    this.sourceId = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EpgProgrammesTableCompanion.insert({
    required String id,
    required String channelId,
    required String title,
    this.description = const Value.absent(),
    this.category = const Value.absent(),
    this.language = const Value.absent(),
    required DateTime startTime,
    required DateTime endTime,
    required String sourceId,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        channelId = Value(channelId),
        title = Value(title),
        startTime = Value(startTime),
        endTime = Value(endTime),
        sourceId = Value(sourceId);
  static Insertable<EpgProgrammesTableData> custom({
    Expression<String>? id,
    Expression<String>? channelId,
    Expression<String>? title,
    Expression<String>? description,
    Expression<String>? category,
    Expression<String>? language,
    Expression<DateTime>? startTime,
    Expression<DateTime>? endTime,
    Expression<String>? sourceId,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (channelId != null) 'channel_id': channelId,
      if (title != null) 'title': title,
      if (description != null) 'description': description,
      if (category != null) 'category': category,
      if (language != null) 'language': language,
      if (startTime != null) 'start_time': startTime,
      if (endTime != null) 'end_time': endTime,
      if (sourceId != null) 'source_id': sourceId,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EpgProgrammesTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? channelId,
      Value<String>? title,
      Value<String?>? description,
      Value<String?>? category,
      Value<String?>? language,
      Value<DateTime>? startTime,
      Value<DateTime>? endTime,
      Value<String>? sourceId,
      Value<int>? rowid}) {
    return EpgProgrammesTableCompanion(
      id: id ?? this.id,
      channelId: channelId ?? this.channelId,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      language: language ?? this.language,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      sourceId: sourceId ?? this.sourceId,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (channelId.present) {
      map['channel_id'] = Variable<String>(channelId.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (description.present) {
      map['description'] = Variable<String>(description.value);
    }
    if (category.present) {
      map['category'] = Variable<String>(category.value);
    }
    if (language.present) {
      map['language'] = Variable<String>(language.value);
    }
    if (startTime.present) {
      map['start_time'] = Variable<DateTime>(startTime.value);
    }
    if (endTime.present) {
      map['end_time'] = Variable<DateTime>(endTime.value);
    }
    if (sourceId.present) {
      map['source_id'] = Variable<String>(sourceId.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EpgProgrammesTableCompanion(')
          ..write('id: $id, ')
          ..write('channelId: $channelId, ')
          ..write('title: $title, ')
          ..write('description: $description, ')
          ..write('category: $category, ')
          ..write('language: $language, ')
          ..write('startTime: $startTime, ')
          ..write('endTime: $endTime, ')
          ..write('sourceId: $sourceId, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EpgSourcesTableTable extends EpgSourcesTable
    with TableInfo<$EpgSourcesTableTable, EpgSourcesTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EpgSourcesTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _nameMeta = const VerificationMeta('name');
  @override
  late final GeneratedColumn<String> name = GeneratedColumn<String>(
      'name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _urlMeta = const VerificationMeta('url');
  @override
  late final GeneratedColumn<String> url = GeneratedColumn<String>(
      'url', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _channelCountMeta =
      const VerificationMeta('channelCount');
  @override
  late final GeneratedColumn<String> channelCount = GeneratedColumn<String>(
      'channel_count', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string,
      requiredDuringInsert: false,
      defaultValue: const Constant('unconfigured'));
  static const VerificationMeta _lastRefreshMeta =
      const VerificationMeta('lastRefresh');
  @override
  late final GeneratedColumn<DateTime> lastRefresh = GeneratedColumn<DateTime>(
      'last_refresh', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _isEnabledMeta =
      const VerificationMeta('isEnabled');
  @override
  late final GeneratedColumn<bool> isEnabled = GeneratedColumn<bool>(
      'is_enabled', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_enabled" IN (0, 1))'),
      defaultValue: const Constant(true));
  @override
  List<GeneratedColumn> get $columns =>
      [id, name, url, channelCount, status, lastRefresh, isEnabled];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'epg_sources_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<EpgSourcesTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('name')) {
      context.handle(
          _nameMeta, name.isAcceptableOrUnknown(data['name']!, _nameMeta));
    } else if (isInserting) {
      context.missing(_nameMeta);
    }
    if (data.containsKey('url')) {
      context.handle(
          _urlMeta, url.isAcceptableOrUnknown(data['url']!, _urlMeta));
    } else if (isInserting) {
      context.missing(_urlMeta);
    }
    if (data.containsKey('channel_count')) {
      context.handle(
          _channelCountMeta,
          channelCount.isAcceptableOrUnknown(
              data['channel_count']!, _channelCountMeta));
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    }
    if (data.containsKey('last_refresh')) {
      context.handle(
          _lastRefreshMeta,
          lastRefresh.isAcceptableOrUnknown(
              data['last_refresh']!, _lastRefreshMeta));
    }
    if (data.containsKey('is_enabled')) {
      context.handle(_isEnabledMeta,
          isEnabled.isAcceptableOrUnknown(data['is_enabled']!, _isEnabledMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EpgSourcesTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EpgSourcesTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      name: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}name'])!,
      url: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}url'])!,
      channelCount: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}channel_count']),
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      lastRefresh: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}last_refresh']),
      isEnabled: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_enabled'])!,
    );
  }

  @override
  $EpgSourcesTableTable createAlias(String alias) {
    return $EpgSourcesTableTable(attachedDatabase, alias);
  }
}

class EpgSourcesTableData extends DataClass
    implements Insertable<EpgSourcesTableData> {
  final String id;
  final String name;
  final String url;
  final String? channelCount;
  final String status;
  final DateTime? lastRefresh;
  final bool isEnabled;
  const EpgSourcesTableData(
      {required this.id,
      required this.name,
      required this.url,
      this.channelCount,
      required this.status,
      this.lastRefresh,
      required this.isEnabled});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['name'] = Variable<String>(name);
    map['url'] = Variable<String>(url);
    if (!nullToAbsent || channelCount != null) {
      map['channel_count'] = Variable<String>(channelCount);
    }
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || lastRefresh != null) {
      map['last_refresh'] = Variable<DateTime>(lastRefresh);
    }
    map['is_enabled'] = Variable<bool>(isEnabled);
    return map;
  }

  EpgSourcesTableCompanion toCompanion(bool nullToAbsent) {
    return EpgSourcesTableCompanion(
      id: Value(id),
      name: Value(name),
      url: Value(url),
      channelCount: channelCount == null && nullToAbsent
          ? const Value.absent()
          : Value(channelCount),
      status: Value(status),
      lastRefresh: lastRefresh == null && nullToAbsent
          ? const Value.absent()
          : Value(lastRefresh),
      isEnabled: Value(isEnabled),
    );
  }

  factory EpgSourcesTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EpgSourcesTableData(
      id: serializer.fromJson<String>(json['id']),
      name: serializer.fromJson<String>(json['name']),
      url: serializer.fromJson<String>(json['url']),
      channelCount: serializer.fromJson<String?>(json['channelCount']),
      status: serializer.fromJson<String>(json['status']),
      lastRefresh: serializer.fromJson<DateTime?>(json['lastRefresh']),
      isEnabled: serializer.fromJson<bool>(json['isEnabled']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'name': serializer.toJson<String>(name),
      'url': serializer.toJson<String>(url),
      'channelCount': serializer.toJson<String?>(channelCount),
      'status': serializer.toJson<String>(status),
      'lastRefresh': serializer.toJson<DateTime?>(lastRefresh),
      'isEnabled': serializer.toJson<bool>(isEnabled),
    };
  }

  EpgSourcesTableData copyWith(
          {String? id,
          String? name,
          String? url,
          Value<String?> channelCount = const Value.absent(),
          String? status,
          Value<DateTime?> lastRefresh = const Value.absent(),
          bool? isEnabled}) =>
      EpgSourcesTableData(
        id: id ?? this.id,
        name: name ?? this.name,
        url: url ?? this.url,
        channelCount:
            channelCount.present ? channelCount.value : this.channelCount,
        status: status ?? this.status,
        lastRefresh: lastRefresh.present ? lastRefresh.value : this.lastRefresh,
        isEnabled: isEnabled ?? this.isEnabled,
      );
  EpgSourcesTableData copyWithCompanion(EpgSourcesTableCompanion data) {
    return EpgSourcesTableData(
      id: data.id.present ? data.id.value : this.id,
      name: data.name.present ? data.name.value : this.name,
      url: data.url.present ? data.url.value : this.url,
      channelCount: data.channelCount.present
          ? data.channelCount.value
          : this.channelCount,
      status: data.status.present ? data.status.value : this.status,
      lastRefresh:
          data.lastRefresh.present ? data.lastRefresh.value : this.lastRefresh,
      isEnabled: data.isEnabled.present ? data.isEnabled.value : this.isEnabled,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EpgSourcesTableData(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('url: $url, ')
          ..write('channelCount: $channelCount, ')
          ..write('status: $status, ')
          ..write('lastRefresh: $lastRefresh, ')
          ..write('isEnabled: $isEnabled')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, name, url, channelCount, status, lastRefresh, isEnabled);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EpgSourcesTableData &&
          other.id == this.id &&
          other.name == this.name &&
          other.url == this.url &&
          other.channelCount == this.channelCount &&
          other.status == this.status &&
          other.lastRefresh == this.lastRefresh &&
          other.isEnabled == this.isEnabled);
}

class EpgSourcesTableCompanion extends UpdateCompanion<EpgSourcesTableData> {
  final Value<String> id;
  final Value<String> name;
  final Value<String> url;
  final Value<String?> channelCount;
  final Value<String> status;
  final Value<DateTime?> lastRefresh;
  final Value<bool> isEnabled;
  final Value<int> rowid;
  const EpgSourcesTableCompanion({
    this.id = const Value.absent(),
    this.name = const Value.absent(),
    this.url = const Value.absent(),
    this.channelCount = const Value.absent(),
    this.status = const Value.absent(),
    this.lastRefresh = const Value.absent(),
    this.isEnabled = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EpgSourcesTableCompanion.insert({
    required String id,
    required String name,
    required String url,
    this.channelCount = const Value.absent(),
    this.status = const Value.absent(),
    this.lastRefresh = const Value.absent(),
    this.isEnabled = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        name = Value(name),
        url = Value(url);
  static Insertable<EpgSourcesTableData> custom({
    Expression<String>? id,
    Expression<String>? name,
    Expression<String>? url,
    Expression<String>? channelCount,
    Expression<String>? status,
    Expression<DateTime>? lastRefresh,
    Expression<bool>? isEnabled,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (name != null) 'name': name,
      if (url != null) 'url': url,
      if (channelCount != null) 'channel_count': channelCount,
      if (status != null) 'status': status,
      if (lastRefresh != null) 'last_refresh': lastRefresh,
      if (isEnabled != null) 'is_enabled': isEnabled,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EpgSourcesTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? name,
      Value<String>? url,
      Value<String?>? channelCount,
      Value<String>? status,
      Value<DateTime?>? lastRefresh,
      Value<bool>? isEnabled,
      Value<int>? rowid}) {
    return EpgSourcesTableCompanion(
      id: id ?? this.id,
      name: name ?? this.name,
      url: url ?? this.url,
      channelCount: channelCount ?? this.channelCount,
      status: status ?? this.status,
      lastRefresh: lastRefresh ?? this.lastRefresh,
      isEnabled: isEnabled ?? this.isEnabled,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (name.present) {
      map['name'] = Variable<String>(name.value);
    }
    if (url.present) {
      map['url'] = Variable<String>(url.value);
    }
    if (channelCount.present) {
      map['channel_count'] = Variable<String>(channelCount.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (lastRefresh.present) {
      map['last_refresh'] = Variable<DateTime>(lastRefresh.value);
    }
    if (isEnabled.present) {
      map['is_enabled'] = Variable<bool>(isEnabled.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EpgSourcesTableCompanion(')
          ..write('id: $id, ')
          ..write('name: $name, ')
          ..write('url: $url, ')
          ..write('channelCount: $channelCount, ')
          ..write('status: $status, ')
          ..write('lastRefresh: $lastRefresh, ')
          ..write('isEnabled: $isEnabled, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EpgChannelsTableTable extends EpgChannelsTable
    with TableInfo<$EpgChannelsTableTable, EpgChannelsTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EpgChannelsTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _epgSourceIdMeta =
      const VerificationMeta('epgSourceId');
  @override
  late final GeneratedColumn<String> epgSourceId = GeneratedColumn<String>(
      'epg_source_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _xmltvChannelIdMeta =
      const VerificationMeta('xmltvChannelId');
  @override
  late final GeneratedColumn<String> xmltvChannelId = GeneratedColumn<String>(
      'xmltv_channel_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _displayNameMeta =
      const VerificationMeta('displayName');
  @override
  late final GeneratedColumn<String> displayName = GeneratedColumn<String>(
      'display_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _normalizedNameMeta =
      const VerificationMeta('normalizedName');
  @override
  late final GeneratedColumn<String> normalizedName = GeneratedColumn<String>(
      'normalized_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns =>
      [id, epgSourceId, xmltvChannelId, displayName, normalizedName];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'epg_channels_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<EpgChannelsTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('epg_source_id')) {
      context.handle(
          _epgSourceIdMeta,
          epgSourceId.isAcceptableOrUnknown(
              data['epg_source_id']!, _epgSourceIdMeta));
    } else if (isInserting) {
      context.missing(_epgSourceIdMeta);
    }
    if (data.containsKey('xmltv_channel_id')) {
      context.handle(
          _xmltvChannelIdMeta,
          xmltvChannelId.isAcceptableOrUnknown(
              data['xmltv_channel_id']!, _xmltvChannelIdMeta));
    } else if (isInserting) {
      context.missing(_xmltvChannelIdMeta);
    }
    if (data.containsKey('display_name')) {
      context.handle(
          _displayNameMeta,
          displayName.isAcceptableOrUnknown(
              data['display_name']!, _displayNameMeta));
    } else if (isInserting) {
      context.missing(_displayNameMeta);
    }
    if (data.containsKey('normalized_name')) {
      context.handle(
          _normalizedNameMeta,
          normalizedName.isAcceptableOrUnknown(
              data['normalized_name']!, _normalizedNameMeta));
    } else if (isInserting) {
      context.missing(_normalizedNameMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EpgChannelsTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EpgChannelsTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      epgSourceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}epg_source_id'])!,
      xmltvChannelId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}xmltv_channel_id'])!,
      displayName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}display_name'])!,
      normalizedName: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}normalized_name'])!,
    );
  }

  @override
  $EpgChannelsTableTable createAlias(String alias) {
    return $EpgChannelsTableTable(attachedDatabase, alias);
  }
}

class EpgChannelsTableData extends DataClass
    implements Insertable<EpgChannelsTableData> {
  final String id;
  final String epgSourceId;
  final String xmltvChannelId;
  final String displayName;
  final String normalizedName;
  const EpgChannelsTableData(
      {required this.id,
      required this.epgSourceId,
      required this.xmltvChannelId,
      required this.displayName,
      required this.normalizedName});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['epg_source_id'] = Variable<String>(epgSourceId);
    map['xmltv_channel_id'] = Variable<String>(xmltvChannelId);
    map['display_name'] = Variable<String>(displayName);
    map['normalized_name'] = Variable<String>(normalizedName);
    return map;
  }

  EpgChannelsTableCompanion toCompanion(bool nullToAbsent) {
    return EpgChannelsTableCompanion(
      id: Value(id),
      epgSourceId: Value(epgSourceId),
      xmltvChannelId: Value(xmltvChannelId),
      displayName: Value(displayName),
      normalizedName: Value(normalizedName),
    );
  }

  factory EpgChannelsTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EpgChannelsTableData(
      id: serializer.fromJson<String>(json['id']),
      epgSourceId: serializer.fromJson<String>(json['epgSourceId']),
      xmltvChannelId: serializer.fromJson<String>(json['xmltvChannelId']),
      displayName: serializer.fromJson<String>(json['displayName']),
      normalizedName: serializer.fromJson<String>(json['normalizedName']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'epgSourceId': serializer.toJson<String>(epgSourceId),
      'xmltvChannelId': serializer.toJson<String>(xmltvChannelId),
      'displayName': serializer.toJson<String>(displayName),
      'normalizedName': serializer.toJson<String>(normalizedName),
    };
  }

  EpgChannelsTableData copyWith(
          {String? id,
          String? epgSourceId,
          String? xmltvChannelId,
          String? displayName,
          String? normalizedName}) =>
      EpgChannelsTableData(
        id: id ?? this.id,
        epgSourceId: epgSourceId ?? this.epgSourceId,
        xmltvChannelId: xmltvChannelId ?? this.xmltvChannelId,
        displayName: displayName ?? this.displayName,
        normalizedName: normalizedName ?? this.normalizedName,
      );
  EpgChannelsTableData copyWithCompanion(EpgChannelsTableCompanion data) {
    return EpgChannelsTableData(
      id: data.id.present ? data.id.value : this.id,
      epgSourceId:
          data.epgSourceId.present ? data.epgSourceId.value : this.epgSourceId,
      xmltvChannelId: data.xmltvChannelId.present
          ? data.xmltvChannelId.value
          : this.xmltvChannelId,
      displayName:
          data.displayName.present ? data.displayName.value : this.displayName,
      normalizedName: data.normalizedName.present
          ? data.normalizedName.value
          : this.normalizedName,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EpgChannelsTableData(')
          ..write('id: $id, ')
          ..write('epgSourceId: $epgSourceId, ')
          ..write('xmltvChannelId: $xmltvChannelId, ')
          ..write('displayName: $displayName, ')
          ..write('normalizedName: $normalizedName')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, epgSourceId, xmltvChannelId, displayName, normalizedName);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EpgChannelsTableData &&
          other.id == this.id &&
          other.epgSourceId == this.epgSourceId &&
          other.xmltvChannelId == this.xmltvChannelId &&
          other.displayName == this.displayName &&
          other.normalizedName == this.normalizedName);
}

class EpgChannelsTableCompanion extends UpdateCompanion<EpgChannelsTableData> {
  final Value<String> id;
  final Value<String> epgSourceId;
  final Value<String> xmltvChannelId;
  final Value<String> displayName;
  final Value<String> normalizedName;
  final Value<int> rowid;
  const EpgChannelsTableCompanion({
    this.id = const Value.absent(),
    this.epgSourceId = const Value.absent(),
    this.xmltvChannelId = const Value.absent(),
    this.displayName = const Value.absent(),
    this.normalizedName = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EpgChannelsTableCompanion.insert({
    required String id,
    required String epgSourceId,
    required String xmltvChannelId,
    required String displayName,
    required String normalizedName,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        epgSourceId = Value(epgSourceId),
        xmltvChannelId = Value(xmltvChannelId),
        displayName = Value(displayName),
        normalizedName = Value(normalizedName);
  static Insertable<EpgChannelsTableData> custom({
    Expression<String>? id,
    Expression<String>? epgSourceId,
    Expression<String>? xmltvChannelId,
    Expression<String>? displayName,
    Expression<String>? normalizedName,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (epgSourceId != null) 'epg_source_id': epgSourceId,
      if (xmltvChannelId != null) 'xmltv_channel_id': xmltvChannelId,
      if (displayName != null) 'display_name': displayName,
      if (normalizedName != null) 'normalized_name': normalizedName,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EpgChannelsTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? epgSourceId,
      Value<String>? xmltvChannelId,
      Value<String>? displayName,
      Value<String>? normalizedName,
      Value<int>? rowid}) {
    return EpgChannelsTableCompanion(
      id: id ?? this.id,
      epgSourceId: epgSourceId ?? this.epgSourceId,
      xmltvChannelId: xmltvChannelId ?? this.xmltvChannelId,
      displayName: displayName ?? this.displayName,
      normalizedName: normalizedName ?? this.normalizedName,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (epgSourceId.present) {
      map['epg_source_id'] = Variable<String>(epgSourceId.value);
    }
    if (xmltvChannelId.present) {
      map['xmltv_channel_id'] = Variable<String>(xmltvChannelId.value);
    }
    if (displayName.present) {
      map['display_name'] = Variable<String>(displayName.value);
    }
    if (normalizedName.present) {
      map['normalized_name'] = Variable<String>(normalizedName.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EpgChannelsTableCompanion(')
          ..write('id: $id, ')
          ..write('epgSourceId: $epgSourceId, ')
          ..write('xmltvChannelId: $xmltvChannelId, ')
          ..write('displayName: $displayName, ')
          ..write('normalizedName: $normalizedName, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $EpgChannelMappingsTableTable extends EpgChannelMappingsTable
    with TableInfo<$EpgChannelMappingsTableTable, EpgChannelMappingsTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EpgChannelMappingsTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _sourceIdMeta =
      const VerificationMeta('sourceId');
  @override
  late final GeneratedColumn<String> sourceId = GeneratedColumn<String>(
      'source_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _appChannelIdMeta =
      const VerificationMeta('appChannelId');
  @override
  late final GeneratedColumn<String> appChannelId = GeneratedColumn<String>(
      'app_channel_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _epgSourceIdMeta =
      const VerificationMeta('epgSourceId');
  @override
  late final GeneratedColumn<String> epgSourceId = GeneratedColumn<String>(
      'epg_source_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _epgChannelIdMeta =
      const VerificationMeta('epgChannelId');
  @override
  late final GeneratedColumn<String> epgChannelId = GeneratedColumn<String>(
      'epg_channel_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns =>
      [id, sourceId, appChannelId, epgSourceId, epgChannelId, createdAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'epg_channel_mappings_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<EpgChannelMappingsTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('source_id')) {
      context.handle(_sourceIdMeta,
          sourceId.isAcceptableOrUnknown(data['source_id']!, _sourceIdMeta));
    } else if (isInserting) {
      context.missing(_sourceIdMeta);
    }
    if (data.containsKey('app_channel_id')) {
      context.handle(
          _appChannelIdMeta,
          appChannelId.isAcceptableOrUnknown(
              data['app_channel_id']!, _appChannelIdMeta));
    } else if (isInserting) {
      context.missing(_appChannelIdMeta);
    }
    if (data.containsKey('epg_source_id')) {
      context.handle(
          _epgSourceIdMeta,
          epgSourceId.isAcceptableOrUnknown(
              data['epg_source_id']!, _epgSourceIdMeta));
    }
    if (data.containsKey('epg_channel_id')) {
      context.handle(
          _epgChannelIdMeta,
          epgChannelId.isAcceptableOrUnknown(
              data['epg_channel_id']!, _epgChannelIdMeta));
    } else if (isInserting) {
      context.missing(_epgChannelIdMeta);
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EpgChannelMappingsTableData map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EpgChannelMappingsTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      sourceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}source_id'])!,
      appChannelId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}app_channel_id'])!,
      epgSourceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}epg_source_id']),
      epgChannelId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}epg_channel_id'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $EpgChannelMappingsTableTable createAlias(String alias) {
    return $EpgChannelMappingsTableTable(attachedDatabase, alias);
  }
}

class EpgChannelMappingsTableData extends DataClass
    implements Insertable<EpgChannelMappingsTableData> {
  final String id;
  final String sourceId;
  final String appChannelId;
  final String? epgSourceId;
  final String epgChannelId;
  final DateTime createdAt;
  const EpgChannelMappingsTableData(
      {required this.id,
      required this.sourceId,
      required this.appChannelId,
      this.epgSourceId,
      required this.epgChannelId,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['source_id'] = Variable<String>(sourceId);
    map['app_channel_id'] = Variable<String>(appChannelId);
    if (!nullToAbsent || epgSourceId != null) {
      map['epg_source_id'] = Variable<String>(epgSourceId);
    }
    map['epg_channel_id'] = Variable<String>(epgChannelId);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  EpgChannelMappingsTableCompanion toCompanion(bool nullToAbsent) {
    return EpgChannelMappingsTableCompanion(
      id: Value(id),
      sourceId: Value(sourceId),
      appChannelId: Value(appChannelId),
      epgSourceId: epgSourceId == null && nullToAbsent
          ? const Value.absent()
          : Value(epgSourceId),
      epgChannelId: Value(epgChannelId),
      createdAt: Value(createdAt),
    );
  }

  factory EpgChannelMappingsTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EpgChannelMappingsTableData(
      id: serializer.fromJson<String>(json['id']),
      sourceId: serializer.fromJson<String>(json['sourceId']),
      appChannelId: serializer.fromJson<String>(json['appChannelId']),
      epgSourceId: serializer.fromJson<String?>(json['epgSourceId']),
      epgChannelId: serializer.fromJson<String>(json['epgChannelId']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'sourceId': serializer.toJson<String>(sourceId),
      'appChannelId': serializer.toJson<String>(appChannelId),
      'epgSourceId': serializer.toJson<String?>(epgSourceId),
      'epgChannelId': serializer.toJson<String>(epgChannelId),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  EpgChannelMappingsTableData copyWith(
          {String? id,
          String? sourceId,
          String? appChannelId,
          Value<String?> epgSourceId = const Value.absent(),
          String? epgChannelId,
          DateTime? createdAt}) =>
      EpgChannelMappingsTableData(
        id: id ?? this.id,
        sourceId: sourceId ?? this.sourceId,
        appChannelId: appChannelId ?? this.appChannelId,
        epgSourceId: epgSourceId.present ? epgSourceId.value : this.epgSourceId,
        epgChannelId: epgChannelId ?? this.epgChannelId,
        createdAt: createdAt ?? this.createdAt,
      );
  EpgChannelMappingsTableData copyWithCompanion(
      EpgChannelMappingsTableCompanion data) {
    return EpgChannelMappingsTableData(
      id: data.id.present ? data.id.value : this.id,
      sourceId: data.sourceId.present ? data.sourceId.value : this.sourceId,
      appChannelId: data.appChannelId.present
          ? data.appChannelId.value
          : this.appChannelId,
      epgSourceId:
          data.epgSourceId.present ? data.epgSourceId.value : this.epgSourceId,
      epgChannelId: data.epgChannelId.present
          ? data.epgChannelId.value
          : this.epgChannelId,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EpgChannelMappingsTableData(')
          ..write('id: $id, ')
          ..write('sourceId: $sourceId, ')
          ..write('appChannelId: $appChannelId, ')
          ..write('epgSourceId: $epgSourceId, ')
          ..write('epgChannelId: $epgChannelId, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, sourceId, appChannelId, epgSourceId, epgChannelId, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EpgChannelMappingsTableData &&
          other.id == this.id &&
          other.sourceId == this.sourceId &&
          other.appChannelId == this.appChannelId &&
          other.epgSourceId == this.epgSourceId &&
          other.epgChannelId == this.epgChannelId &&
          other.createdAt == this.createdAt);
}

class EpgChannelMappingsTableCompanion
    extends UpdateCompanion<EpgChannelMappingsTableData> {
  final Value<String> id;
  final Value<String> sourceId;
  final Value<String> appChannelId;
  final Value<String?> epgSourceId;
  final Value<String> epgChannelId;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const EpgChannelMappingsTableCompanion({
    this.id = const Value.absent(),
    this.sourceId = const Value.absent(),
    this.appChannelId = const Value.absent(),
    this.epgSourceId = const Value.absent(),
    this.epgChannelId = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EpgChannelMappingsTableCompanion.insert({
    required String id,
    required String sourceId,
    required String appChannelId,
    this.epgSourceId = const Value.absent(),
    required String epgChannelId,
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        sourceId = Value(sourceId),
        appChannelId = Value(appChannelId),
        epgChannelId = Value(epgChannelId);
  static Insertable<EpgChannelMappingsTableData> custom({
    Expression<String>? id,
    Expression<String>? sourceId,
    Expression<String>? appChannelId,
    Expression<String>? epgSourceId,
    Expression<String>? epgChannelId,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sourceId != null) 'source_id': sourceId,
      if (appChannelId != null) 'app_channel_id': appChannelId,
      if (epgSourceId != null) 'epg_source_id': epgSourceId,
      if (epgChannelId != null) 'epg_channel_id': epgChannelId,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EpgChannelMappingsTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? sourceId,
      Value<String>? appChannelId,
      Value<String?>? epgSourceId,
      Value<String>? epgChannelId,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return EpgChannelMappingsTableCompanion(
      id: id ?? this.id,
      sourceId: sourceId ?? this.sourceId,
      appChannelId: appChannelId ?? this.appChannelId,
      epgSourceId: epgSourceId ?? this.epgSourceId,
      epgChannelId: epgChannelId ?? this.epgChannelId,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (sourceId.present) {
      map['source_id'] = Variable<String>(sourceId.value);
    }
    if (appChannelId.present) {
      map['app_channel_id'] = Variable<String>(appChannelId.value);
    }
    if (epgSourceId.present) {
      map['epg_source_id'] = Variable<String>(epgSourceId.value);
    }
    if (epgChannelId.present) {
      map['epg_channel_id'] = Variable<String>(epgChannelId.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EpgChannelMappingsTableCompanion(')
          ..write('id: $id, ')
          ..write('sourceId: $sourceId, ')
          ..write('appChannelId: $appChannelId, ')
          ..write('epgSourceId: $epgSourceId, ')
          ..write('epgChannelId: $epgChannelId, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $FavoritesTableTable extends FavoritesTable
    with TableInfo<$FavoritesTableTable, FavoritesTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FavoritesTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _referenceIdMeta =
      const VerificationMeta('referenceId');
  @override
  late final GeneratedColumn<String> referenceId = GeneratedColumn<String>(
      'reference_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _displayNameMeta =
      const VerificationMeta('displayName');
  @override
  late final GeneratedColumn<String> displayName = GeneratedColumn<String>(
      'display_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _metadataMeta =
      const VerificationMeta('metadata');
  @override
  late final GeneratedColumn<String> metadata = GeneratedColumn<String>(
      'metadata', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _addedAtMeta =
      const VerificationMeta('addedAt');
  @override
  late final GeneratedColumn<DateTime> addedAt = GeneratedColumn<DateTime>(
      'added_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns =>
      [id, type, referenceId, displayName, metadata, addedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'favorites_table';
  @override
  VerificationContext validateIntegrity(Insertable<FavoritesTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    if (data.containsKey('reference_id')) {
      context.handle(
          _referenceIdMeta,
          referenceId.isAcceptableOrUnknown(
              data['reference_id']!, _referenceIdMeta));
    } else if (isInserting) {
      context.missing(_referenceIdMeta);
    }
    if (data.containsKey('display_name')) {
      context.handle(
          _displayNameMeta,
          displayName.isAcceptableOrUnknown(
              data['display_name']!, _displayNameMeta));
    } else if (isInserting) {
      context.missing(_displayNameMeta);
    }
    if (data.containsKey('metadata')) {
      context.handle(_metadataMeta,
          metadata.isAcceptableOrUnknown(data['metadata']!, _metadataMeta));
    }
    if (data.containsKey('added_at')) {
      context.handle(_addedAtMeta,
          addedAt.isAcceptableOrUnknown(data['added_at']!, _addedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FavoritesTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FavoritesTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      referenceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reference_id'])!,
      displayName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}display_name'])!,
      metadata: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}metadata']),
      addedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}added_at'])!,
    );
  }

  @override
  $FavoritesTableTable createAlias(String alias) {
    return $FavoritesTableTable(attachedDatabase, alias);
  }
}

class FavoritesTableData extends DataClass
    implements Insertable<FavoritesTableData> {
  final String id;
  final String type;
  final String referenceId;
  final String displayName;
  final String? metadata;
  final DateTime addedAt;
  const FavoritesTableData(
      {required this.id,
      required this.type,
      required this.referenceId,
      required this.displayName,
      this.metadata,
      required this.addedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['type'] = Variable<String>(type);
    map['reference_id'] = Variable<String>(referenceId);
    map['display_name'] = Variable<String>(displayName);
    if (!nullToAbsent || metadata != null) {
      map['metadata'] = Variable<String>(metadata);
    }
    map['added_at'] = Variable<DateTime>(addedAt);
    return map;
  }

  FavoritesTableCompanion toCompanion(bool nullToAbsent) {
    return FavoritesTableCompanion(
      id: Value(id),
      type: Value(type),
      referenceId: Value(referenceId),
      displayName: Value(displayName),
      metadata: metadata == null && nullToAbsent
          ? const Value.absent()
          : Value(metadata),
      addedAt: Value(addedAt),
    );
  }

  factory FavoritesTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FavoritesTableData(
      id: serializer.fromJson<String>(json['id']),
      type: serializer.fromJson<String>(json['type']),
      referenceId: serializer.fromJson<String>(json['referenceId']),
      displayName: serializer.fromJson<String>(json['displayName']),
      metadata: serializer.fromJson<String?>(json['metadata']),
      addedAt: serializer.fromJson<DateTime>(json['addedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'type': serializer.toJson<String>(type),
      'referenceId': serializer.toJson<String>(referenceId),
      'displayName': serializer.toJson<String>(displayName),
      'metadata': serializer.toJson<String?>(metadata),
      'addedAt': serializer.toJson<DateTime>(addedAt),
    };
  }

  FavoritesTableData copyWith(
          {String? id,
          String? type,
          String? referenceId,
          String? displayName,
          Value<String?> metadata = const Value.absent(),
          DateTime? addedAt}) =>
      FavoritesTableData(
        id: id ?? this.id,
        type: type ?? this.type,
        referenceId: referenceId ?? this.referenceId,
        displayName: displayName ?? this.displayName,
        metadata: metadata.present ? metadata.value : this.metadata,
        addedAt: addedAt ?? this.addedAt,
      );
  FavoritesTableData copyWithCompanion(FavoritesTableCompanion data) {
    return FavoritesTableData(
      id: data.id.present ? data.id.value : this.id,
      type: data.type.present ? data.type.value : this.type,
      referenceId:
          data.referenceId.present ? data.referenceId.value : this.referenceId,
      displayName:
          data.displayName.present ? data.displayName.value : this.displayName,
      metadata: data.metadata.present ? data.metadata.value : this.metadata,
      addedAt: data.addedAt.present ? data.addedAt.value : this.addedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FavoritesTableData(')
          ..write('id: $id, ')
          ..write('type: $type, ')
          ..write('referenceId: $referenceId, ')
          ..write('displayName: $displayName, ')
          ..write('metadata: $metadata, ')
          ..write('addedAt: $addedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, type, referenceId, displayName, metadata, addedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FavoritesTableData &&
          other.id == this.id &&
          other.type == this.type &&
          other.referenceId == this.referenceId &&
          other.displayName == this.displayName &&
          other.metadata == this.metadata &&
          other.addedAt == this.addedAt);
}

class FavoritesTableCompanion extends UpdateCompanion<FavoritesTableData> {
  final Value<String> id;
  final Value<String> type;
  final Value<String> referenceId;
  final Value<String> displayName;
  final Value<String?> metadata;
  final Value<DateTime> addedAt;
  final Value<int> rowid;
  const FavoritesTableCompanion({
    this.id = const Value.absent(),
    this.type = const Value.absent(),
    this.referenceId = const Value.absent(),
    this.displayName = const Value.absent(),
    this.metadata = const Value.absent(),
    this.addedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  FavoritesTableCompanion.insert({
    required String id,
    required String type,
    required String referenceId,
    required String displayName,
    this.metadata = const Value.absent(),
    this.addedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        type = Value(type),
        referenceId = Value(referenceId),
        displayName = Value(displayName);
  static Insertable<FavoritesTableData> custom({
    Expression<String>? id,
    Expression<String>? type,
    Expression<String>? referenceId,
    Expression<String>? displayName,
    Expression<String>? metadata,
    Expression<DateTime>? addedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (type != null) 'type': type,
      if (referenceId != null) 'reference_id': referenceId,
      if (displayName != null) 'display_name': displayName,
      if (metadata != null) 'metadata': metadata,
      if (addedAt != null) 'added_at': addedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  FavoritesTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? type,
      Value<String>? referenceId,
      Value<String>? displayName,
      Value<String?>? metadata,
      Value<DateTime>? addedAt,
      Value<int>? rowid}) {
    return FavoritesTableCompanion(
      id: id ?? this.id,
      type: type ?? this.type,
      referenceId: referenceId ?? this.referenceId,
      displayName: displayName ?? this.displayName,
      metadata: metadata ?? this.metadata,
      addedAt: addedAt ?? this.addedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (referenceId.present) {
      map['reference_id'] = Variable<String>(referenceId.value);
    }
    if (displayName.present) {
      map['display_name'] = Variable<String>(displayName.value);
    }
    if (metadata.present) {
      map['metadata'] = Variable<String>(metadata.value);
    }
    if (addedAt.present) {
      map['added_at'] = Variable<DateTime>(addedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FavoritesTableCompanion(')
          ..write('id: $id, ')
          ..write('type: $type, ')
          ..write('referenceId: $referenceId, ')
          ..write('displayName: $displayName, ')
          ..write('metadata: $metadata, ')
          ..write('addedAt: $addedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $WatchHistoryTableTable extends WatchHistoryTable
    with TableInfo<$WatchHistoryTableTable, WatchHistoryTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WatchHistoryTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _channelIdMeta =
      const VerificationMeta('channelId');
  @override
  late final GeneratedColumn<String> channelId = GeneratedColumn<String>(
      'channel_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _channelNameMeta =
      const VerificationMeta('channelName');
  @override
  late final GeneratedColumn<String> channelName = GeneratedColumn<String>(
      'channel_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _streamUrlMeta =
      const VerificationMeta('streamUrl');
  @override
  late final GeneratedColumn<String> streamUrl = GeneratedColumn<String>(
      'stream_url', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _durationSecondsMeta =
      const VerificationMeta('durationSeconds');
  @override
  late final GeneratedColumn<int> durationSeconds = GeneratedColumn<int>(
      'duration_seconds', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultValue: const Constant(0));
  static const VerificationMeta _watchedAtMeta =
      const VerificationMeta('watchedAt');
  @override
  late final GeneratedColumn<DateTime> watchedAt = GeneratedColumn<DateTime>(
      'watched_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns =>
      [id, channelId, channelName, streamUrl, durationSeconds, watchedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'watch_history_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<WatchHistoryTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('channel_id')) {
      context.handle(_channelIdMeta,
          channelId.isAcceptableOrUnknown(data['channel_id']!, _channelIdMeta));
    } else if (isInserting) {
      context.missing(_channelIdMeta);
    }
    if (data.containsKey('channel_name')) {
      context.handle(
          _channelNameMeta,
          channelName.isAcceptableOrUnknown(
              data['channel_name']!, _channelNameMeta));
    } else if (isInserting) {
      context.missing(_channelNameMeta);
    }
    if (data.containsKey('stream_url')) {
      context.handle(_streamUrlMeta,
          streamUrl.isAcceptableOrUnknown(data['stream_url']!, _streamUrlMeta));
    } else if (isInserting) {
      context.missing(_streamUrlMeta);
    }
    if (data.containsKey('duration_seconds')) {
      context.handle(
          _durationSecondsMeta,
          durationSeconds.isAcceptableOrUnknown(
              data['duration_seconds']!, _durationSecondsMeta));
    }
    if (data.containsKey('watched_at')) {
      context.handle(_watchedAtMeta,
          watchedAt.isAcceptableOrUnknown(data['watched_at']!, _watchedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WatchHistoryTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WatchHistoryTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      channelId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}channel_id'])!,
      channelName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}channel_name'])!,
      streamUrl: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}stream_url'])!,
      durationSeconds: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}duration_seconds'])!,
      watchedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}watched_at'])!,
    );
  }

  @override
  $WatchHistoryTableTable createAlias(String alias) {
    return $WatchHistoryTableTable(attachedDatabase, alias);
  }
}

class WatchHistoryTableData extends DataClass
    implements Insertable<WatchHistoryTableData> {
  final String id;
  final String channelId;
  final String channelName;
  final String streamUrl;
  final int durationSeconds;
  final DateTime watchedAt;
  const WatchHistoryTableData(
      {required this.id,
      required this.channelId,
      required this.channelName,
      required this.streamUrl,
      required this.durationSeconds,
      required this.watchedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['channel_id'] = Variable<String>(channelId);
    map['channel_name'] = Variable<String>(channelName);
    map['stream_url'] = Variable<String>(streamUrl);
    map['duration_seconds'] = Variable<int>(durationSeconds);
    map['watched_at'] = Variable<DateTime>(watchedAt);
    return map;
  }

  WatchHistoryTableCompanion toCompanion(bool nullToAbsent) {
    return WatchHistoryTableCompanion(
      id: Value(id),
      channelId: Value(channelId),
      channelName: Value(channelName),
      streamUrl: Value(streamUrl),
      durationSeconds: Value(durationSeconds),
      watchedAt: Value(watchedAt),
    );
  }

  factory WatchHistoryTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WatchHistoryTableData(
      id: serializer.fromJson<String>(json['id']),
      channelId: serializer.fromJson<String>(json['channelId']),
      channelName: serializer.fromJson<String>(json['channelName']),
      streamUrl: serializer.fromJson<String>(json['streamUrl']),
      durationSeconds: serializer.fromJson<int>(json['durationSeconds']),
      watchedAt: serializer.fromJson<DateTime>(json['watchedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'channelId': serializer.toJson<String>(channelId),
      'channelName': serializer.toJson<String>(channelName),
      'streamUrl': serializer.toJson<String>(streamUrl),
      'durationSeconds': serializer.toJson<int>(durationSeconds),
      'watchedAt': serializer.toJson<DateTime>(watchedAt),
    };
  }

  WatchHistoryTableData copyWith(
          {String? id,
          String? channelId,
          String? channelName,
          String? streamUrl,
          int? durationSeconds,
          DateTime? watchedAt}) =>
      WatchHistoryTableData(
        id: id ?? this.id,
        channelId: channelId ?? this.channelId,
        channelName: channelName ?? this.channelName,
        streamUrl: streamUrl ?? this.streamUrl,
        durationSeconds: durationSeconds ?? this.durationSeconds,
        watchedAt: watchedAt ?? this.watchedAt,
      );
  WatchHistoryTableData copyWithCompanion(WatchHistoryTableCompanion data) {
    return WatchHistoryTableData(
      id: data.id.present ? data.id.value : this.id,
      channelId: data.channelId.present ? data.channelId.value : this.channelId,
      channelName:
          data.channelName.present ? data.channelName.value : this.channelName,
      streamUrl: data.streamUrl.present ? data.streamUrl.value : this.streamUrl,
      durationSeconds: data.durationSeconds.present
          ? data.durationSeconds.value
          : this.durationSeconds,
      watchedAt: data.watchedAt.present ? data.watchedAt.value : this.watchedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WatchHistoryTableData(')
          ..write('id: $id, ')
          ..write('channelId: $channelId, ')
          ..write('channelName: $channelName, ')
          ..write('streamUrl: $streamUrl, ')
          ..write('durationSeconds: $durationSeconds, ')
          ..write('watchedAt: $watchedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, channelId, channelName, streamUrl, durationSeconds, watchedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WatchHistoryTableData &&
          other.id == this.id &&
          other.channelId == this.channelId &&
          other.channelName == this.channelName &&
          other.streamUrl == this.streamUrl &&
          other.durationSeconds == this.durationSeconds &&
          other.watchedAt == this.watchedAt);
}

class WatchHistoryTableCompanion
    extends UpdateCompanion<WatchHistoryTableData> {
  final Value<String> id;
  final Value<String> channelId;
  final Value<String> channelName;
  final Value<String> streamUrl;
  final Value<int> durationSeconds;
  final Value<DateTime> watchedAt;
  final Value<int> rowid;
  const WatchHistoryTableCompanion({
    this.id = const Value.absent(),
    this.channelId = const Value.absent(),
    this.channelName = const Value.absent(),
    this.streamUrl = const Value.absent(),
    this.durationSeconds = const Value.absent(),
    this.watchedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  WatchHistoryTableCompanion.insert({
    required String id,
    required String channelId,
    required String channelName,
    required String streamUrl,
    this.durationSeconds = const Value.absent(),
    this.watchedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        channelId = Value(channelId),
        channelName = Value(channelName),
        streamUrl = Value(streamUrl);
  static Insertable<WatchHistoryTableData> custom({
    Expression<String>? id,
    Expression<String>? channelId,
    Expression<String>? channelName,
    Expression<String>? streamUrl,
    Expression<int>? durationSeconds,
    Expression<DateTime>? watchedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (channelId != null) 'channel_id': channelId,
      if (channelName != null) 'channel_name': channelName,
      if (streamUrl != null) 'stream_url': streamUrl,
      if (durationSeconds != null) 'duration_seconds': durationSeconds,
      if (watchedAt != null) 'watched_at': watchedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  WatchHistoryTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? channelId,
      Value<String>? channelName,
      Value<String>? streamUrl,
      Value<int>? durationSeconds,
      Value<DateTime>? watchedAt,
      Value<int>? rowid}) {
    return WatchHistoryTableCompanion(
      id: id ?? this.id,
      channelId: channelId ?? this.channelId,
      channelName: channelName ?? this.channelName,
      streamUrl: streamUrl ?? this.streamUrl,
      durationSeconds: durationSeconds ?? this.durationSeconds,
      watchedAt: watchedAt ?? this.watchedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (channelId.present) {
      map['channel_id'] = Variable<String>(channelId.value);
    }
    if (channelName.present) {
      map['channel_name'] = Variable<String>(channelName.value);
    }
    if (streamUrl.present) {
      map['stream_url'] = Variable<String>(streamUrl.value);
    }
    if (durationSeconds.present) {
      map['duration_seconds'] = Variable<int>(durationSeconds.value);
    }
    if (watchedAt.present) {
      map['watched_at'] = Variable<DateTime>(watchedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WatchHistoryTableCompanion(')
          ..write('id: $id, ')
          ..write('channelId: $channelId, ')
          ..write('channelName: $channelName, ')
          ..write('streamUrl: $streamUrl, ')
          ..write('durationSeconds: $durationSeconds, ')
          ..write('watchedAt: $watchedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $RemindersTableTable extends RemindersTable
    with TableInfo<$RemindersTableTable, RemindersTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RemindersTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _typeMeta = const VerificationMeta('type');
  @override
  late final GeneratedColumn<String> type = GeneratedColumn<String>(
      'type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _referenceIdMeta =
      const VerificationMeta('referenceId');
  @override
  late final GeneratedColumn<String> referenceId = GeneratedColumn<String>(
      'reference_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _subtitleMeta =
      const VerificationMeta('subtitle');
  @override
  late final GeneratedColumn<String> subtitle = GeneratedColumn<String>(
      'subtitle', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _reminderTimeMeta =
      const VerificationMeta('reminderTime');
  @override
  late final GeneratedColumn<DateTime> reminderTime = GeneratedColumn<DateTime>(
      'reminder_time', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _isFiredMeta =
      const VerificationMeta('isFired');
  @override
  late final GeneratedColumn<bool> isFired = GeneratedColumn<bool>(
      'is_fired', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_fired" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        type,
        referenceId,
        title,
        subtitle,
        reminderTime,
        isFired,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'reminders_table';
  @override
  VerificationContext validateIntegrity(Insertable<RemindersTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('type')) {
      context.handle(
          _typeMeta, type.isAcceptableOrUnknown(data['type']!, _typeMeta));
    } else if (isInserting) {
      context.missing(_typeMeta);
    }
    if (data.containsKey('reference_id')) {
      context.handle(
          _referenceIdMeta,
          referenceId.isAcceptableOrUnknown(
              data['reference_id']!, _referenceIdMeta));
    } else if (isInserting) {
      context.missing(_referenceIdMeta);
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('subtitle')) {
      context.handle(_subtitleMeta,
          subtitle.isAcceptableOrUnknown(data['subtitle']!, _subtitleMeta));
    }
    if (data.containsKey('reminder_time')) {
      context.handle(
          _reminderTimeMeta,
          reminderTime.isAcceptableOrUnknown(
              data['reminder_time']!, _reminderTimeMeta));
    } else if (isInserting) {
      context.missing(_reminderTimeMeta);
    }
    if (data.containsKey('is_fired')) {
      context.handle(_isFiredMeta,
          isFired.isAcceptableOrUnknown(data['is_fired']!, _isFiredMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RemindersTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RemindersTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      type: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}type'])!,
      referenceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}reference_id'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      subtitle: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}subtitle']),
      reminderTime: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}reminder_time'])!,
      isFired: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_fired'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $RemindersTableTable createAlias(String alias) {
    return $RemindersTableTable(attachedDatabase, alias);
  }
}

class RemindersTableData extends DataClass
    implements Insertable<RemindersTableData> {
  final String id;
  final String type;
  final String referenceId;
  final String title;
  final String? subtitle;
  final DateTime reminderTime;
  final bool isFired;
  final DateTime createdAt;
  const RemindersTableData(
      {required this.id,
      required this.type,
      required this.referenceId,
      required this.title,
      this.subtitle,
      required this.reminderTime,
      required this.isFired,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['type'] = Variable<String>(type);
    map['reference_id'] = Variable<String>(referenceId);
    map['title'] = Variable<String>(title);
    if (!nullToAbsent || subtitle != null) {
      map['subtitle'] = Variable<String>(subtitle);
    }
    map['reminder_time'] = Variable<DateTime>(reminderTime);
    map['is_fired'] = Variable<bool>(isFired);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  RemindersTableCompanion toCompanion(bool nullToAbsent) {
    return RemindersTableCompanion(
      id: Value(id),
      type: Value(type),
      referenceId: Value(referenceId),
      title: Value(title),
      subtitle: subtitle == null && nullToAbsent
          ? const Value.absent()
          : Value(subtitle),
      reminderTime: Value(reminderTime),
      isFired: Value(isFired),
      createdAt: Value(createdAt),
    );
  }

  factory RemindersTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RemindersTableData(
      id: serializer.fromJson<String>(json['id']),
      type: serializer.fromJson<String>(json['type']),
      referenceId: serializer.fromJson<String>(json['referenceId']),
      title: serializer.fromJson<String>(json['title']),
      subtitle: serializer.fromJson<String?>(json['subtitle']),
      reminderTime: serializer.fromJson<DateTime>(json['reminderTime']),
      isFired: serializer.fromJson<bool>(json['isFired']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'type': serializer.toJson<String>(type),
      'referenceId': serializer.toJson<String>(referenceId),
      'title': serializer.toJson<String>(title),
      'subtitle': serializer.toJson<String?>(subtitle),
      'reminderTime': serializer.toJson<DateTime>(reminderTime),
      'isFired': serializer.toJson<bool>(isFired),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  RemindersTableData copyWith(
          {String? id,
          String? type,
          String? referenceId,
          String? title,
          Value<String?> subtitle = const Value.absent(),
          DateTime? reminderTime,
          bool? isFired,
          DateTime? createdAt}) =>
      RemindersTableData(
        id: id ?? this.id,
        type: type ?? this.type,
        referenceId: referenceId ?? this.referenceId,
        title: title ?? this.title,
        subtitle: subtitle.present ? subtitle.value : this.subtitle,
        reminderTime: reminderTime ?? this.reminderTime,
        isFired: isFired ?? this.isFired,
        createdAt: createdAt ?? this.createdAt,
      );
  RemindersTableData copyWithCompanion(RemindersTableCompanion data) {
    return RemindersTableData(
      id: data.id.present ? data.id.value : this.id,
      type: data.type.present ? data.type.value : this.type,
      referenceId:
          data.referenceId.present ? data.referenceId.value : this.referenceId,
      title: data.title.present ? data.title.value : this.title,
      subtitle: data.subtitle.present ? data.subtitle.value : this.subtitle,
      reminderTime: data.reminderTime.present
          ? data.reminderTime.value
          : this.reminderTime,
      isFired: data.isFired.present ? data.isFired.value : this.isFired,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RemindersTableData(')
          ..write('id: $id, ')
          ..write('type: $type, ')
          ..write('referenceId: $referenceId, ')
          ..write('title: $title, ')
          ..write('subtitle: $subtitle, ')
          ..write('reminderTime: $reminderTime, ')
          ..write('isFired: $isFired, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, type, referenceId, title, subtitle, reminderTime, isFired, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RemindersTableData &&
          other.id == this.id &&
          other.type == this.type &&
          other.referenceId == this.referenceId &&
          other.title == this.title &&
          other.subtitle == this.subtitle &&
          other.reminderTime == this.reminderTime &&
          other.isFired == this.isFired &&
          other.createdAt == this.createdAt);
}

class RemindersTableCompanion extends UpdateCompanion<RemindersTableData> {
  final Value<String> id;
  final Value<String> type;
  final Value<String> referenceId;
  final Value<String> title;
  final Value<String?> subtitle;
  final Value<DateTime> reminderTime;
  final Value<bool> isFired;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const RemindersTableCompanion({
    this.id = const Value.absent(),
    this.type = const Value.absent(),
    this.referenceId = const Value.absent(),
    this.title = const Value.absent(),
    this.subtitle = const Value.absent(),
    this.reminderTime = const Value.absent(),
    this.isFired = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  RemindersTableCompanion.insert({
    required String id,
    required String type,
    required String referenceId,
    required String title,
    this.subtitle = const Value.absent(),
    required DateTime reminderTime,
    this.isFired = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        type = Value(type),
        referenceId = Value(referenceId),
        title = Value(title),
        reminderTime = Value(reminderTime);
  static Insertable<RemindersTableData> custom({
    Expression<String>? id,
    Expression<String>? type,
    Expression<String>? referenceId,
    Expression<String>? title,
    Expression<String>? subtitle,
    Expression<DateTime>? reminderTime,
    Expression<bool>? isFired,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (type != null) 'type': type,
      if (referenceId != null) 'reference_id': referenceId,
      if (title != null) 'title': title,
      if (subtitle != null) 'subtitle': subtitle,
      if (reminderTime != null) 'reminder_time': reminderTime,
      if (isFired != null) 'is_fired': isFired,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  RemindersTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? type,
      Value<String>? referenceId,
      Value<String>? title,
      Value<String?>? subtitle,
      Value<DateTime>? reminderTime,
      Value<bool>? isFired,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return RemindersTableCompanion(
      id: id ?? this.id,
      type: type ?? this.type,
      referenceId: referenceId ?? this.referenceId,
      title: title ?? this.title,
      subtitle: subtitle ?? this.subtitle,
      reminderTime: reminderTime ?? this.reminderTime,
      isFired: isFired ?? this.isFired,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (type.present) {
      map['type'] = Variable<String>(type.value);
    }
    if (referenceId.present) {
      map['reference_id'] = Variable<String>(referenceId.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (subtitle.present) {
      map['subtitle'] = Variable<String>(subtitle.value);
    }
    if (reminderTime.present) {
      map['reminder_time'] = Variable<DateTime>(reminderTime.value);
    }
    if (isFired.present) {
      map['is_fired'] = Variable<bool>(isFired.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RemindersTableCompanion(')
          ..write('id: $id, ')
          ..write('type: $type, ')
          ..write('referenceId: $referenceId, ')
          ..write('title: $title, ')
          ..write('subtitle: $subtitle, ')
          ..write('reminderTime: $reminderTime, ')
          ..write('isFired: $isFired, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SportsEventsTableTable extends SportsEventsTable
    with TableInfo<$SportsEventsTableTable, SportsEventsTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SportsEventsTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _sportMeta = const VerificationMeta('sport');
  @override
  late final GeneratedColumn<String> sport = GeneratedColumn<String>(
      'sport', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _homeTeamIdMeta =
      const VerificationMeta('homeTeamId');
  @override
  late final GeneratedColumn<String> homeTeamId = GeneratedColumn<String>(
      'home_team_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _homeTeamNameMeta =
      const VerificationMeta('homeTeamName');
  @override
  late final GeneratedColumn<String> homeTeamName = GeneratedColumn<String>(
      'home_team_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _awayTeamIdMeta =
      const VerificationMeta('awayTeamId');
  @override
  late final GeneratedColumn<String> awayTeamId = GeneratedColumn<String>(
      'away_team_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _awayTeamNameMeta =
      const VerificationMeta('awayTeamName');
  @override
  late final GeneratedColumn<String> awayTeamName = GeneratedColumn<String>(
      'away_team_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _competitionIdMeta =
      const VerificationMeta('competitionId');
  @override
  late final GeneratedColumn<String> competitionId = GeneratedColumn<String>(
      'competition_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _competitionNameMeta =
      const VerificationMeta('competitionName');
  @override
  late final GeneratedColumn<String> competitionName = GeneratedColumn<String>(
      'competition_name', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
      'status', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _homeScoreMeta =
      const VerificationMeta('homeScore');
  @override
  late final GeneratedColumn<String> homeScore = GeneratedColumn<String>(
      'home_score', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _awayScoreMeta =
      const VerificationMeta('awayScore');
  @override
  late final GeneratedColumn<String> awayScore = GeneratedColumn<String>(
      'away_score', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _startTimeMeta =
      const VerificationMeta('startTime');
  @override
  late final GeneratedColumn<DateTime> startTime = GeneratedColumn<DateTime>(
      'start_time', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _venueMeta = const VerificationMeta('venue');
  @override
  late final GeneratedColumn<String> venue = GeneratedColumn<String>(
      'venue', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _metadataMeta =
      const VerificationMeta('metadata');
  @override
  late final GeneratedColumn<String> metadata = GeneratedColumn<String>(
      'metadata', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _sourceIdMeta =
      const VerificationMeta('sourceId');
  @override
  late final GeneratedColumn<String> sourceId = GeneratedColumn<String>(
      'source_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _cachedAtMeta =
      const VerificationMeta('cachedAt');
  @override
  late final GeneratedColumn<DateTime> cachedAt = GeneratedColumn<DateTime>(
      'cached_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        sport,
        homeTeamId,
        homeTeamName,
        awayTeamId,
        awayTeamName,
        competitionId,
        competitionName,
        status,
        homeScore,
        awayScore,
        startTime,
        venue,
        metadata,
        sourceId,
        cachedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sports_events_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<SportsEventsTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('sport')) {
      context.handle(
          _sportMeta, sport.isAcceptableOrUnknown(data['sport']!, _sportMeta));
    } else if (isInserting) {
      context.missing(_sportMeta);
    }
    if (data.containsKey('home_team_id')) {
      context.handle(
          _homeTeamIdMeta,
          homeTeamId.isAcceptableOrUnknown(
              data['home_team_id']!, _homeTeamIdMeta));
    }
    if (data.containsKey('home_team_name')) {
      context.handle(
          _homeTeamNameMeta,
          homeTeamName.isAcceptableOrUnknown(
              data['home_team_name']!, _homeTeamNameMeta));
    } else if (isInserting) {
      context.missing(_homeTeamNameMeta);
    }
    if (data.containsKey('away_team_id')) {
      context.handle(
          _awayTeamIdMeta,
          awayTeamId.isAcceptableOrUnknown(
              data['away_team_id']!, _awayTeamIdMeta));
    }
    if (data.containsKey('away_team_name')) {
      context.handle(
          _awayTeamNameMeta,
          awayTeamName.isAcceptableOrUnknown(
              data['away_team_name']!, _awayTeamNameMeta));
    } else if (isInserting) {
      context.missing(_awayTeamNameMeta);
    }
    if (data.containsKey('competition_id')) {
      context.handle(
          _competitionIdMeta,
          competitionId.isAcceptableOrUnknown(
              data['competition_id']!, _competitionIdMeta));
    }
    if (data.containsKey('competition_name')) {
      context.handle(
          _competitionNameMeta,
          competitionName.isAcceptableOrUnknown(
              data['competition_name']!, _competitionNameMeta));
    } else if (isInserting) {
      context.missing(_competitionNameMeta);
    }
    if (data.containsKey('status')) {
      context.handle(_statusMeta,
          status.isAcceptableOrUnknown(data['status']!, _statusMeta));
    } else if (isInserting) {
      context.missing(_statusMeta);
    }
    if (data.containsKey('home_score')) {
      context.handle(_homeScoreMeta,
          homeScore.isAcceptableOrUnknown(data['home_score']!, _homeScoreMeta));
    }
    if (data.containsKey('away_score')) {
      context.handle(_awayScoreMeta,
          awayScore.isAcceptableOrUnknown(data['away_score']!, _awayScoreMeta));
    }
    if (data.containsKey('start_time')) {
      context.handle(_startTimeMeta,
          startTime.isAcceptableOrUnknown(data['start_time']!, _startTimeMeta));
    } else if (isInserting) {
      context.missing(_startTimeMeta);
    }
    if (data.containsKey('venue')) {
      context.handle(
          _venueMeta, venue.isAcceptableOrUnknown(data['venue']!, _venueMeta));
    }
    if (data.containsKey('metadata')) {
      context.handle(_metadataMeta,
          metadata.isAcceptableOrUnknown(data['metadata']!, _metadataMeta));
    }
    if (data.containsKey('source_id')) {
      context.handle(_sourceIdMeta,
          sourceId.isAcceptableOrUnknown(data['source_id']!, _sourceIdMeta));
    } else if (isInserting) {
      context.missing(_sourceIdMeta);
    }
    if (data.containsKey('cached_at')) {
      context.handle(_cachedAtMeta,
          cachedAt.isAcceptableOrUnknown(data['cached_at']!, _cachedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SportsEventsTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SportsEventsTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      sport: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sport'])!,
      homeTeamId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}home_team_id']),
      homeTeamName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}home_team_name'])!,
      awayTeamId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}away_team_id']),
      awayTeamName: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}away_team_name'])!,
      competitionId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competition_id']),
      competitionName: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}competition_name'])!,
      status: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}status'])!,
      homeScore: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}home_score']),
      awayScore: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}away_score']),
      startTime: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}start_time'])!,
      venue: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}venue']),
      metadata: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}metadata']),
      sourceId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}source_id'])!,
      cachedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}cached_at'])!,
    );
  }

  @override
  $SportsEventsTableTable createAlias(String alias) {
    return $SportsEventsTableTable(attachedDatabase, alias);
  }
}

class SportsEventsTableData extends DataClass
    implements Insertable<SportsEventsTableData> {
  final String id;
  final String sport;
  final String? homeTeamId;
  final String homeTeamName;
  final String? awayTeamId;
  final String awayTeamName;
  final String? competitionId;
  final String competitionName;
  final String status;
  final String? homeScore;
  final String? awayScore;
  final DateTime startTime;
  final String? venue;
  final String? metadata;
  final String sourceId;
  final DateTime cachedAt;
  const SportsEventsTableData(
      {required this.id,
      required this.sport,
      this.homeTeamId,
      required this.homeTeamName,
      this.awayTeamId,
      required this.awayTeamName,
      this.competitionId,
      required this.competitionName,
      required this.status,
      this.homeScore,
      this.awayScore,
      required this.startTime,
      this.venue,
      this.metadata,
      required this.sourceId,
      required this.cachedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['sport'] = Variable<String>(sport);
    if (!nullToAbsent || homeTeamId != null) {
      map['home_team_id'] = Variable<String>(homeTeamId);
    }
    map['home_team_name'] = Variable<String>(homeTeamName);
    if (!nullToAbsent || awayTeamId != null) {
      map['away_team_id'] = Variable<String>(awayTeamId);
    }
    map['away_team_name'] = Variable<String>(awayTeamName);
    if (!nullToAbsent || competitionId != null) {
      map['competition_id'] = Variable<String>(competitionId);
    }
    map['competition_name'] = Variable<String>(competitionName);
    map['status'] = Variable<String>(status);
    if (!nullToAbsent || homeScore != null) {
      map['home_score'] = Variable<String>(homeScore);
    }
    if (!nullToAbsent || awayScore != null) {
      map['away_score'] = Variable<String>(awayScore);
    }
    map['start_time'] = Variable<DateTime>(startTime);
    if (!nullToAbsent || venue != null) {
      map['venue'] = Variable<String>(venue);
    }
    if (!nullToAbsent || metadata != null) {
      map['metadata'] = Variable<String>(metadata);
    }
    map['source_id'] = Variable<String>(sourceId);
    map['cached_at'] = Variable<DateTime>(cachedAt);
    return map;
  }

  SportsEventsTableCompanion toCompanion(bool nullToAbsent) {
    return SportsEventsTableCompanion(
      id: Value(id),
      sport: Value(sport),
      homeTeamId: homeTeamId == null && nullToAbsent
          ? const Value.absent()
          : Value(homeTeamId),
      homeTeamName: Value(homeTeamName),
      awayTeamId: awayTeamId == null && nullToAbsent
          ? const Value.absent()
          : Value(awayTeamId),
      awayTeamName: Value(awayTeamName),
      competitionId: competitionId == null && nullToAbsent
          ? const Value.absent()
          : Value(competitionId),
      competitionName: Value(competitionName),
      status: Value(status),
      homeScore: homeScore == null && nullToAbsent
          ? const Value.absent()
          : Value(homeScore),
      awayScore: awayScore == null && nullToAbsent
          ? const Value.absent()
          : Value(awayScore),
      startTime: Value(startTime),
      venue:
          venue == null && nullToAbsent ? const Value.absent() : Value(venue),
      metadata: metadata == null && nullToAbsent
          ? const Value.absent()
          : Value(metadata),
      sourceId: Value(sourceId),
      cachedAt: Value(cachedAt),
    );
  }

  factory SportsEventsTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SportsEventsTableData(
      id: serializer.fromJson<String>(json['id']),
      sport: serializer.fromJson<String>(json['sport']),
      homeTeamId: serializer.fromJson<String?>(json['homeTeamId']),
      homeTeamName: serializer.fromJson<String>(json['homeTeamName']),
      awayTeamId: serializer.fromJson<String?>(json['awayTeamId']),
      awayTeamName: serializer.fromJson<String>(json['awayTeamName']),
      competitionId: serializer.fromJson<String?>(json['competitionId']),
      competitionName: serializer.fromJson<String>(json['competitionName']),
      status: serializer.fromJson<String>(json['status']),
      homeScore: serializer.fromJson<String?>(json['homeScore']),
      awayScore: serializer.fromJson<String?>(json['awayScore']),
      startTime: serializer.fromJson<DateTime>(json['startTime']),
      venue: serializer.fromJson<String?>(json['venue']),
      metadata: serializer.fromJson<String?>(json['metadata']),
      sourceId: serializer.fromJson<String>(json['sourceId']),
      cachedAt: serializer.fromJson<DateTime>(json['cachedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'sport': serializer.toJson<String>(sport),
      'homeTeamId': serializer.toJson<String?>(homeTeamId),
      'homeTeamName': serializer.toJson<String>(homeTeamName),
      'awayTeamId': serializer.toJson<String?>(awayTeamId),
      'awayTeamName': serializer.toJson<String>(awayTeamName),
      'competitionId': serializer.toJson<String?>(competitionId),
      'competitionName': serializer.toJson<String>(competitionName),
      'status': serializer.toJson<String>(status),
      'homeScore': serializer.toJson<String?>(homeScore),
      'awayScore': serializer.toJson<String?>(awayScore),
      'startTime': serializer.toJson<DateTime>(startTime),
      'venue': serializer.toJson<String?>(venue),
      'metadata': serializer.toJson<String?>(metadata),
      'sourceId': serializer.toJson<String>(sourceId),
      'cachedAt': serializer.toJson<DateTime>(cachedAt),
    };
  }

  SportsEventsTableData copyWith(
          {String? id,
          String? sport,
          Value<String?> homeTeamId = const Value.absent(),
          String? homeTeamName,
          Value<String?> awayTeamId = const Value.absent(),
          String? awayTeamName,
          Value<String?> competitionId = const Value.absent(),
          String? competitionName,
          String? status,
          Value<String?> homeScore = const Value.absent(),
          Value<String?> awayScore = const Value.absent(),
          DateTime? startTime,
          Value<String?> venue = const Value.absent(),
          Value<String?> metadata = const Value.absent(),
          String? sourceId,
          DateTime? cachedAt}) =>
      SportsEventsTableData(
        id: id ?? this.id,
        sport: sport ?? this.sport,
        homeTeamId: homeTeamId.present ? homeTeamId.value : this.homeTeamId,
        homeTeamName: homeTeamName ?? this.homeTeamName,
        awayTeamId: awayTeamId.present ? awayTeamId.value : this.awayTeamId,
        awayTeamName: awayTeamName ?? this.awayTeamName,
        competitionId:
            competitionId.present ? competitionId.value : this.competitionId,
        competitionName: competitionName ?? this.competitionName,
        status: status ?? this.status,
        homeScore: homeScore.present ? homeScore.value : this.homeScore,
        awayScore: awayScore.present ? awayScore.value : this.awayScore,
        startTime: startTime ?? this.startTime,
        venue: venue.present ? venue.value : this.venue,
        metadata: metadata.present ? metadata.value : this.metadata,
        sourceId: sourceId ?? this.sourceId,
        cachedAt: cachedAt ?? this.cachedAt,
      );
  SportsEventsTableData copyWithCompanion(SportsEventsTableCompanion data) {
    return SportsEventsTableData(
      id: data.id.present ? data.id.value : this.id,
      sport: data.sport.present ? data.sport.value : this.sport,
      homeTeamId:
          data.homeTeamId.present ? data.homeTeamId.value : this.homeTeamId,
      homeTeamName: data.homeTeamName.present
          ? data.homeTeamName.value
          : this.homeTeamName,
      awayTeamId:
          data.awayTeamId.present ? data.awayTeamId.value : this.awayTeamId,
      awayTeamName: data.awayTeamName.present
          ? data.awayTeamName.value
          : this.awayTeamName,
      competitionId: data.competitionId.present
          ? data.competitionId.value
          : this.competitionId,
      competitionName: data.competitionName.present
          ? data.competitionName.value
          : this.competitionName,
      status: data.status.present ? data.status.value : this.status,
      homeScore: data.homeScore.present ? data.homeScore.value : this.homeScore,
      awayScore: data.awayScore.present ? data.awayScore.value : this.awayScore,
      startTime: data.startTime.present ? data.startTime.value : this.startTime,
      venue: data.venue.present ? data.venue.value : this.venue,
      metadata: data.metadata.present ? data.metadata.value : this.metadata,
      sourceId: data.sourceId.present ? data.sourceId.value : this.sourceId,
      cachedAt: data.cachedAt.present ? data.cachedAt.value : this.cachedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SportsEventsTableData(')
          ..write('id: $id, ')
          ..write('sport: $sport, ')
          ..write('homeTeamId: $homeTeamId, ')
          ..write('homeTeamName: $homeTeamName, ')
          ..write('awayTeamId: $awayTeamId, ')
          ..write('awayTeamName: $awayTeamName, ')
          ..write('competitionId: $competitionId, ')
          ..write('competitionName: $competitionName, ')
          ..write('status: $status, ')
          ..write('homeScore: $homeScore, ')
          ..write('awayScore: $awayScore, ')
          ..write('startTime: $startTime, ')
          ..write('venue: $venue, ')
          ..write('metadata: $metadata, ')
          ..write('sourceId: $sourceId, ')
          ..write('cachedAt: $cachedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      sport,
      homeTeamId,
      homeTeamName,
      awayTeamId,
      awayTeamName,
      competitionId,
      competitionName,
      status,
      homeScore,
      awayScore,
      startTime,
      venue,
      metadata,
      sourceId,
      cachedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SportsEventsTableData &&
          other.id == this.id &&
          other.sport == this.sport &&
          other.homeTeamId == this.homeTeamId &&
          other.homeTeamName == this.homeTeamName &&
          other.awayTeamId == this.awayTeamId &&
          other.awayTeamName == this.awayTeamName &&
          other.competitionId == this.competitionId &&
          other.competitionName == this.competitionName &&
          other.status == this.status &&
          other.homeScore == this.homeScore &&
          other.awayScore == this.awayScore &&
          other.startTime == this.startTime &&
          other.venue == this.venue &&
          other.metadata == this.metadata &&
          other.sourceId == this.sourceId &&
          other.cachedAt == this.cachedAt);
}

class SportsEventsTableCompanion
    extends UpdateCompanion<SportsEventsTableData> {
  final Value<String> id;
  final Value<String> sport;
  final Value<String?> homeTeamId;
  final Value<String> homeTeamName;
  final Value<String?> awayTeamId;
  final Value<String> awayTeamName;
  final Value<String?> competitionId;
  final Value<String> competitionName;
  final Value<String> status;
  final Value<String?> homeScore;
  final Value<String?> awayScore;
  final Value<DateTime> startTime;
  final Value<String?> venue;
  final Value<String?> metadata;
  final Value<String> sourceId;
  final Value<DateTime> cachedAt;
  final Value<int> rowid;
  const SportsEventsTableCompanion({
    this.id = const Value.absent(),
    this.sport = const Value.absent(),
    this.homeTeamId = const Value.absent(),
    this.homeTeamName = const Value.absent(),
    this.awayTeamId = const Value.absent(),
    this.awayTeamName = const Value.absent(),
    this.competitionId = const Value.absent(),
    this.competitionName = const Value.absent(),
    this.status = const Value.absent(),
    this.homeScore = const Value.absent(),
    this.awayScore = const Value.absent(),
    this.startTime = const Value.absent(),
    this.venue = const Value.absent(),
    this.metadata = const Value.absent(),
    this.sourceId = const Value.absent(),
    this.cachedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SportsEventsTableCompanion.insert({
    required String id,
    required String sport,
    this.homeTeamId = const Value.absent(),
    required String homeTeamName,
    this.awayTeamId = const Value.absent(),
    required String awayTeamName,
    this.competitionId = const Value.absent(),
    required String competitionName,
    required String status,
    this.homeScore = const Value.absent(),
    this.awayScore = const Value.absent(),
    required DateTime startTime,
    this.venue = const Value.absent(),
    this.metadata = const Value.absent(),
    required String sourceId,
    this.cachedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        sport = Value(sport),
        homeTeamName = Value(homeTeamName),
        awayTeamName = Value(awayTeamName),
        competitionName = Value(competitionName),
        status = Value(status),
        startTime = Value(startTime),
        sourceId = Value(sourceId);
  static Insertable<SportsEventsTableData> custom({
    Expression<String>? id,
    Expression<String>? sport,
    Expression<String>? homeTeamId,
    Expression<String>? homeTeamName,
    Expression<String>? awayTeamId,
    Expression<String>? awayTeamName,
    Expression<String>? competitionId,
    Expression<String>? competitionName,
    Expression<String>? status,
    Expression<String>? homeScore,
    Expression<String>? awayScore,
    Expression<DateTime>? startTime,
    Expression<String>? venue,
    Expression<String>? metadata,
    Expression<String>? sourceId,
    Expression<DateTime>? cachedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sport != null) 'sport': sport,
      if (homeTeamId != null) 'home_team_id': homeTeamId,
      if (homeTeamName != null) 'home_team_name': homeTeamName,
      if (awayTeamId != null) 'away_team_id': awayTeamId,
      if (awayTeamName != null) 'away_team_name': awayTeamName,
      if (competitionId != null) 'competition_id': competitionId,
      if (competitionName != null) 'competition_name': competitionName,
      if (status != null) 'status': status,
      if (homeScore != null) 'home_score': homeScore,
      if (awayScore != null) 'away_score': awayScore,
      if (startTime != null) 'start_time': startTime,
      if (venue != null) 'venue': venue,
      if (metadata != null) 'metadata': metadata,
      if (sourceId != null) 'source_id': sourceId,
      if (cachedAt != null) 'cached_at': cachedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SportsEventsTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? sport,
      Value<String?>? homeTeamId,
      Value<String>? homeTeamName,
      Value<String?>? awayTeamId,
      Value<String>? awayTeamName,
      Value<String?>? competitionId,
      Value<String>? competitionName,
      Value<String>? status,
      Value<String?>? homeScore,
      Value<String?>? awayScore,
      Value<DateTime>? startTime,
      Value<String?>? venue,
      Value<String?>? metadata,
      Value<String>? sourceId,
      Value<DateTime>? cachedAt,
      Value<int>? rowid}) {
    return SportsEventsTableCompanion(
      id: id ?? this.id,
      sport: sport ?? this.sport,
      homeTeamId: homeTeamId ?? this.homeTeamId,
      homeTeamName: homeTeamName ?? this.homeTeamName,
      awayTeamId: awayTeamId ?? this.awayTeamId,
      awayTeamName: awayTeamName ?? this.awayTeamName,
      competitionId: competitionId ?? this.competitionId,
      competitionName: competitionName ?? this.competitionName,
      status: status ?? this.status,
      homeScore: homeScore ?? this.homeScore,
      awayScore: awayScore ?? this.awayScore,
      startTime: startTime ?? this.startTime,
      venue: venue ?? this.venue,
      metadata: metadata ?? this.metadata,
      sourceId: sourceId ?? this.sourceId,
      cachedAt: cachedAt ?? this.cachedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (sport.present) {
      map['sport'] = Variable<String>(sport.value);
    }
    if (homeTeamId.present) {
      map['home_team_id'] = Variable<String>(homeTeamId.value);
    }
    if (homeTeamName.present) {
      map['home_team_name'] = Variable<String>(homeTeamName.value);
    }
    if (awayTeamId.present) {
      map['away_team_id'] = Variable<String>(awayTeamId.value);
    }
    if (awayTeamName.present) {
      map['away_team_name'] = Variable<String>(awayTeamName.value);
    }
    if (competitionId.present) {
      map['competition_id'] = Variable<String>(competitionId.value);
    }
    if (competitionName.present) {
      map['competition_name'] = Variable<String>(competitionName.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (homeScore.present) {
      map['home_score'] = Variable<String>(homeScore.value);
    }
    if (awayScore.present) {
      map['away_score'] = Variable<String>(awayScore.value);
    }
    if (startTime.present) {
      map['start_time'] = Variable<DateTime>(startTime.value);
    }
    if (venue.present) {
      map['venue'] = Variable<String>(venue.value);
    }
    if (metadata.present) {
      map['metadata'] = Variable<String>(metadata.value);
    }
    if (sourceId.present) {
      map['source_id'] = Variable<String>(sourceId.value);
    }
    if (cachedAt.present) {
      map['cached_at'] = Variable<DateTime>(cachedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SportsEventsTableCompanion(')
          ..write('id: $id, ')
          ..write('sport: $sport, ')
          ..write('homeTeamId: $homeTeamId, ')
          ..write('homeTeamName: $homeTeamName, ')
          ..write('awayTeamId: $awayTeamId, ')
          ..write('awayTeamName: $awayTeamName, ')
          ..write('competitionId: $competitionId, ')
          ..write('competitionName: $competitionName, ')
          ..write('status: $status, ')
          ..write('homeScore: $homeScore, ')
          ..write('awayScore: $awayScore, ')
          ..write('startTime: $startTime, ')
          ..write('venue: $venue, ')
          ..write('metadata: $metadata, ')
          ..write('sourceId: $sourceId, ')
          ..write('cachedAt: $cachedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ResumePointsTableTable extends ResumePointsTable
    with TableInfo<$ResumePointsTableTable, ResumePointsTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ResumePointsTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _contentTypeMeta =
      const VerificationMeta('contentType');
  @override
  late final GeneratedColumn<String> contentType = GeneratedColumn<String>(
      'content_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _titleMeta = const VerificationMeta('title');
  @override
  late final GeneratedColumn<String> title = GeneratedColumn<String>(
      'title', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _streamUrlMeta =
      const VerificationMeta('streamUrl');
  @override
  late final GeneratedColumn<String> streamUrl = GeneratedColumn<String>(
      'stream_url', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _positionSecondsMeta =
      const VerificationMeta('positionSeconds');
  @override
  late final GeneratedColumn<int> positionSeconds = GeneratedColumn<int>(
      'position_seconds', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _durationSecondsMeta =
      const VerificationMeta('durationSeconds');
  @override
  late final GeneratedColumn<int> durationSeconds = GeneratedColumn<int>(
      'duration_seconds', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        contentType,
        title,
        streamUrl,
        positionSeconds,
        durationSeconds,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'resume_points_table';
  @override
  VerificationContext validateIntegrity(
      Insertable<ResumePointsTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('content_type')) {
      context.handle(
          _contentTypeMeta,
          contentType.isAcceptableOrUnknown(
              data['content_type']!, _contentTypeMeta));
    } else if (isInserting) {
      context.missing(_contentTypeMeta);
    }
    if (data.containsKey('title')) {
      context.handle(
          _titleMeta, title.isAcceptableOrUnknown(data['title']!, _titleMeta));
    } else if (isInserting) {
      context.missing(_titleMeta);
    }
    if (data.containsKey('stream_url')) {
      context.handle(_streamUrlMeta,
          streamUrl.isAcceptableOrUnknown(data['stream_url']!, _streamUrlMeta));
    } else if (isInserting) {
      context.missing(_streamUrlMeta);
    }
    if (data.containsKey('position_seconds')) {
      context.handle(
          _positionSecondsMeta,
          positionSeconds.isAcceptableOrUnknown(
              data['position_seconds']!, _positionSecondsMeta));
    } else if (isInserting) {
      context.missing(_positionSecondsMeta);
    }
    if (data.containsKey('duration_seconds')) {
      context.handle(
          _durationSecondsMeta,
          durationSeconds.isAcceptableOrUnknown(
              data['duration_seconds']!, _durationSecondsMeta));
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ResumePointsTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ResumePointsTableData(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      contentType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}content_type'])!,
      title: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}title'])!,
      streamUrl: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}stream_url'])!,
      positionSeconds: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}position_seconds'])!,
      durationSeconds: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}duration_seconds']),
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $ResumePointsTableTable createAlias(String alias) {
    return $ResumePointsTableTable(attachedDatabase, alias);
  }
}

class ResumePointsTableData extends DataClass
    implements Insertable<ResumePointsTableData> {
  final String id;
  final String contentType;
  final String title;
  final String streamUrl;
  final int positionSeconds;
  final int? durationSeconds;
  final DateTime updatedAt;
  const ResumePointsTableData(
      {required this.id,
      required this.contentType,
      required this.title,
      required this.streamUrl,
      required this.positionSeconds,
      this.durationSeconds,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['content_type'] = Variable<String>(contentType);
    map['title'] = Variable<String>(title);
    map['stream_url'] = Variable<String>(streamUrl);
    map['position_seconds'] = Variable<int>(positionSeconds);
    if (!nullToAbsent || durationSeconds != null) {
      map['duration_seconds'] = Variable<int>(durationSeconds);
    }
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  ResumePointsTableCompanion toCompanion(bool nullToAbsent) {
    return ResumePointsTableCompanion(
      id: Value(id),
      contentType: Value(contentType),
      title: Value(title),
      streamUrl: Value(streamUrl),
      positionSeconds: Value(positionSeconds),
      durationSeconds: durationSeconds == null && nullToAbsent
          ? const Value.absent()
          : Value(durationSeconds),
      updatedAt: Value(updatedAt),
    );
  }

  factory ResumePointsTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ResumePointsTableData(
      id: serializer.fromJson<String>(json['id']),
      contentType: serializer.fromJson<String>(json['contentType']),
      title: serializer.fromJson<String>(json['title']),
      streamUrl: serializer.fromJson<String>(json['streamUrl']),
      positionSeconds: serializer.fromJson<int>(json['positionSeconds']),
      durationSeconds: serializer.fromJson<int?>(json['durationSeconds']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'contentType': serializer.toJson<String>(contentType),
      'title': serializer.toJson<String>(title),
      'streamUrl': serializer.toJson<String>(streamUrl),
      'positionSeconds': serializer.toJson<int>(positionSeconds),
      'durationSeconds': serializer.toJson<int?>(durationSeconds),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  ResumePointsTableData copyWith(
          {String? id,
          String? contentType,
          String? title,
          String? streamUrl,
          int? positionSeconds,
          Value<int?> durationSeconds = const Value.absent(),
          DateTime? updatedAt}) =>
      ResumePointsTableData(
        id: id ?? this.id,
        contentType: contentType ?? this.contentType,
        title: title ?? this.title,
        streamUrl: streamUrl ?? this.streamUrl,
        positionSeconds: positionSeconds ?? this.positionSeconds,
        durationSeconds: durationSeconds.present
            ? durationSeconds.value
            : this.durationSeconds,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  ResumePointsTableData copyWithCompanion(ResumePointsTableCompanion data) {
    return ResumePointsTableData(
      id: data.id.present ? data.id.value : this.id,
      contentType:
          data.contentType.present ? data.contentType.value : this.contentType,
      title: data.title.present ? data.title.value : this.title,
      streamUrl: data.streamUrl.present ? data.streamUrl.value : this.streamUrl,
      positionSeconds: data.positionSeconds.present
          ? data.positionSeconds.value
          : this.positionSeconds,
      durationSeconds: data.durationSeconds.present
          ? data.durationSeconds.value
          : this.durationSeconds,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ResumePointsTableData(')
          ..write('id: $id, ')
          ..write('contentType: $contentType, ')
          ..write('title: $title, ')
          ..write('streamUrl: $streamUrl, ')
          ..write('positionSeconds: $positionSeconds, ')
          ..write('durationSeconds: $durationSeconds, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, contentType, title, streamUrl,
      positionSeconds, durationSeconds, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ResumePointsTableData &&
          other.id == this.id &&
          other.contentType == this.contentType &&
          other.title == this.title &&
          other.streamUrl == this.streamUrl &&
          other.positionSeconds == this.positionSeconds &&
          other.durationSeconds == this.durationSeconds &&
          other.updatedAt == this.updatedAt);
}

class ResumePointsTableCompanion
    extends UpdateCompanion<ResumePointsTableData> {
  final Value<String> id;
  final Value<String> contentType;
  final Value<String> title;
  final Value<String> streamUrl;
  final Value<int> positionSeconds;
  final Value<int?> durationSeconds;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const ResumePointsTableCompanion({
    this.id = const Value.absent(),
    this.contentType = const Value.absent(),
    this.title = const Value.absent(),
    this.streamUrl = const Value.absent(),
    this.positionSeconds = const Value.absent(),
    this.durationSeconds = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  ResumePointsTableCompanion.insert({
    required String id,
    required String contentType,
    required String title,
    required String streamUrl,
    required int positionSeconds,
    this.durationSeconds = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        contentType = Value(contentType),
        title = Value(title),
        streamUrl = Value(streamUrl),
        positionSeconds = Value(positionSeconds);
  static Insertable<ResumePointsTableData> custom({
    Expression<String>? id,
    Expression<String>? contentType,
    Expression<String>? title,
    Expression<String>? streamUrl,
    Expression<int>? positionSeconds,
    Expression<int>? durationSeconds,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (contentType != null) 'content_type': contentType,
      if (title != null) 'title': title,
      if (streamUrl != null) 'stream_url': streamUrl,
      if (positionSeconds != null) 'position_seconds': positionSeconds,
      if (durationSeconds != null) 'duration_seconds': durationSeconds,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  ResumePointsTableCompanion copyWith(
      {Value<String>? id,
      Value<String>? contentType,
      Value<String>? title,
      Value<String>? streamUrl,
      Value<int>? positionSeconds,
      Value<int?>? durationSeconds,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return ResumePointsTableCompanion(
      id: id ?? this.id,
      contentType: contentType ?? this.contentType,
      title: title ?? this.title,
      streamUrl: streamUrl ?? this.streamUrl,
      positionSeconds: positionSeconds ?? this.positionSeconds,
      durationSeconds: durationSeconds ?? this.durationSeconds,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (contentType.present) {
      map['content_type'] = Variable<String>(contentType.value);
    }
    if (title.present) {
      map['title'] = Variable<String>(title.value);
    }
    if (streamUrl.present) {
      map['stream_url'] = Variable<String>(streamUrl.value);
    }
    if (positionSeconds.present) {
      map['position_seconds'] = Variable<int>(positionSeconds.value);
    }
    if (durationSeconds.present) {
      map['duration_seconds'] = Variable<int>(durationSeconds.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ResumePointsTableCompanion(')
          ..write('id: $id, ')
          ..write('contentType: $contentType, ')
          ..write('title: $title, ')
          ..write('streamUrl: $streamUrl, ')
          ..write('positionSeconds: $positionSeconds, ')
          ..write('durationSeconds: $durationSeconds, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SettingsTableTable extends SettingsTable
    with TableInfo<$SettingsTableTable, SettingsTableData> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SettingsTableTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _keyMeta = const VerificationMeta('key');
  @override
  late final GeneratedColumn<String> key = GeneratedColumn<String>(
      'key', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _valueMeta = const VerificationMeta('value');
  @override
  late final GeneratedColumn<String> value = GeneratedColumn<String>(
      'value', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime,
      requiredDuringInsert: false,
      defaultValue: currentDateAndTime);
  @override
  List<GeneratedColumn> get $columns => [key, value, updatedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'settings_table';
  @override
  VerificationContext validateIntegrity(Insertable<SettingsTableData> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('key')) {
      context.handle(
          _keyMeta, key.isAcceptableOrUnknown(data['key']!, _keyMeta));
    } else if (isInserting) {
      context.missing(_keyMeta);
    }
    if (data.containsKey('value')) {
      context.handle(
          _valueMeta, value.isAcceptableOrUnknown(data['value']!, _valueMeta));
    } else if (isInserting) {
      context.missing(_valueMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {key};
  @override
  SettingsTableData map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SettingsTableData(
      key: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}key'])!,
      value: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}value'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $SettingsTableTable createAlias(String alias) {
    return $SettingsTableTable(attachedDatabase, alias);
  }
}

class SettingsTableData extends DataClass
    implements Insertable<SettingsTableData> {
  final String key;
  final String value;
  final DateTime updatedAt;
  const SettingsTableData(
      {required this.key, required this.value, required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['key'] = Variable<String>(key);
    map['value'] = Variable<String>(value);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  SettingsTableCompanion toCompanion(bool nullToAbsent) {
    return SettingsTableCompanion(
      key: Value(key),
      value: Value(value),
      updatedAt: Value(updatedAt),
    );
  }

  factory SettingsTableData.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SettingsTableData(
      key: serializer.fromJson<String>(json['key']),
      value: serializer.fromJson<String>(json['value']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'key': serializer.toJson<String>(key),
      'value': serializer.toJson<String>(value),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  SettingsTableData copyWith(
          {String? key, String? value, DateTime? updatedAt}) =>
      SettingsTableData(
        key: key ?? this.key,
        value: value ?? this.value,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  SettingsTableData copyWithCompanion(SettingsTableCompanion data) {
    return SettingsTableData(
      key: data.key.present ? data.key.value : this.key,
      value: data.value.present ? data.value.value : this.value,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SettingsTableData(')
          ..write('key: $key, ')
          ..write('value: $value, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(key, value, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SettingsTableData &&
          other.key == this.key &&
          other.value == this.value &&
          other.updatedAt == this.updatedAt);
}

class SettingsTableCompanion extends UpdateCompanion<SettingsTableData> {
  final Value<String> key;
  final Value<String> value;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const SettingsTableCompanion({
    this.key = const Value.absent(),
    this.value = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SettingsTableCompanion.insert({
    required String key,
    required String value,
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  })  : key = Value(key),
        value = Value(value);
  static Insertable<SettingsTableData> custom({
    Expression<String>? key,
    Expression<String>? value,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (key != null) 'key': key,
      if (value != null) 'value': value,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SettingsTableCompanion copyWith(
      {Value<String>? key,
      Value<String>? value,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return SettingsTableCompanion(
      key: key ?? this.key,
      value: value ?? this.value,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (key.present) {
      map['key'] = Variable<String>(key.value);
    }
    if (value.present) {
      map['value'] = Variable<String>(value.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SettingsTableCompanion(')
          ..write('key: $key, ')
          ..write('value: $value, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $ChannelsTableTable channelsTable = $ChannelsTableTable(this);
  late final $PlaylistSourcesTableTable playlistSourcesTable =
      $PlaylistSourcesTableTable(this);
  late final $EpgProgrammesTableTable epgProgrammesTable =
      $EpgProgrammesTableTable(this);
  late final $EpgSourcesTableTable epgSourcesTable =
      $EpgSourcesTableTable(this);
  late final $EpgChannelsTableTable epgChannelsTable =
      $EpgChannelsTableTable(this);
  late final $EpgChannelMappingsTableTable epgChannelMappingsTable =
      $EpgChannelMappingsTableTable(this);
  late final $FavoritesTableTable favoritesTable = $FavoritesTableTable(this);
  late final $WatchHistoryTableTable watchHistoryTable =
      $WatchHistoryTableTable(this);
  late final $RemindersTableTable remindersTable = $RemindersTableTable(this);
  late final $SportsEventsTableTable sportsEventsTable =
      $SportsEventsTableTable(this);
  late final $ResumePointsTableTable resumePointsTable =
      $ResumePointsTableTable(this);
  late final $SettingsTableTable settingsTable = $SettingsTableTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        channelsTable,
        playlistSourcesTable,
        epgProgrammesTable,
        epgSourcesTable,
        epgChannelsTable,
        epgChannelMappingsTable,
        favoritesTable,
        watchHistoryTable,
        remindersTable,
        sportsEventsTable,
        resumePointsTable,
        settingsTable
      ];
}

typedef $$ChannelsTableTableCreateCompanionBuilder = ChannelsTableCompanion
    Function({
  required String id,
  required String name,
  Value<String?> logoUrl,
  Value<String?> groupTitle,
  Value<String?> tvgId,
  Value<String?> tvgName,
  Value<String?> country,
  Value<String?> language,
  Value<String?> categories,
  required String streamUrl,
  required String sourceId,
  Value<bool> isFavorite,
  Value<bool> isHidden,
  Value<int?> userOrder,
  Value<String> rightsStatus,
  Value<DateTime?> lastWatched,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$ChannelsTableTableUpdateCompanionBuilder = ChannelsTableCompanion
    Function({
  Value<String> id,
  Value<String> name,
  Value<String?> logoUrl,
  Value<String?> groupTitle,
  Value<String?> tvgId,
  Value<String?> tvgName,
  Value<String?> country,
  Value<String?> language,
  Value<String?> categories,
  Value<String> streamUrl,
  Value<String> sourceId,
  Value<bool> isFavorite,
  Value<bool> isHidden,
  Value<int?> userOrder,
  Value<String> rightsStatus,
  Value<DateTime?> lastWatched,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$ChannelsTableTableFilterComposer
    extends Composer<_$AppDatabase, $ChannelsTableTable> {
  $$ChannelsTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get logoUrl => $composableBuilder(
      column: $table.logoUrl, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get groupTitle => $composableBuilder(
      column: $table.groupTitle, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tvgId => $composableBuilder(
      column: $table.tvgId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get tvgName => $composableBuilder(
      column: $table.tvgName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get country => $composableBuilder(
      column: $table.country, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get language => $composableBuilder(
      column: $table.language, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get categories => $composableBuilder(
      column: $table.categories, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get streamUrl => $composableBuilder(
      column: $table.streamUrl, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isFavorite => $composableBuilder(
      column: $table.isFavorite, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isHidden => $composableBuilder(
      column: $table.isHidden, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get userOrder => $composableBuilder(
      column: $table.userOrder, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get rightsStatus => $composableBuilder(
      column: $table.rightsStatus, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get lastWatched => $composableBuilder(
      column: $table.lastWatched, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$ChannelsTableTableOrderingComposer
    extends Composer<_$AppDatabase, $ChannelsTableTable> {
  $$ChannelsTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get logoUrl => $composableBuilder(
      column: $table.logoUrl, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get groupTitle => $composableBuilder(
      column: $table.groupTitle, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tvgId => $composableBuilder(
      column: $table.tvgId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get tvgName => $composableBuilder(
      column: $table.tvgName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get country => $composableBuilder(
      column: $table.country, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get language => $composableBuilder(
      column: $table.language, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get categories => $composableBuilder(
      column: $table.categories, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get streamUrl => $composableBuilder(
      column: $table.streamUrl, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isFavorite => $composableBuilder(
      column: $table.isFavorite, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isHidden => $composableBuilder(
      column: $table.isHidden, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get userOrder => $composableBuilder(
      column: $table.userOrder, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get rightsStatus => $composableBuilder(
      column: $table.rightsStatus,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get lastWatched => $composableBuilder(
      column: $table.lastWatched, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$ChannelsTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $ChannelsTableTable> {
  $$ChannelsTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get logoUrl =>
      $composableBuilder(column: $table.logoUrl, builder: (column) => column);

  GeneratedColumn<String> get groupTitle => $composableBuilder(
      column: $table.groupTitle, builder: (column) => column);

  GeneratedColumn<String> get tvgId =>
      $composableBuilder(column: $table.tvgId, builder: (column) => column);

  GeneratedColumn<String> get tvgName =>
      $composableBuilder(column: $table.tvgName, builder: (column) => column);

  GeneratedColumn<String> get country =>
      $composableBuilder(column: $table.country, builder: (column) => column);

  GeneratedColumn<String> get language =>
      $composableBuilder(column: $table.language, builder: (column) => column);

  GeneratedColumn<String> get categories => $composableBuilder(
      column: $table.categories, builder: (column) => column);

  GeneratedColumn<String> get streamUrl =>
      $composableBuilder(column: $table.streamUrl, builder: (column) => column);

  GeneratedColumn<String> get sourceId =>
      $composableBuilder(column: $table.sourceId, builder: (column) => column);

  GeneratedColumn<bool> get isFavorite => $composableBuilder(
      column: $table.isFavorite, builder: (column) => column);

  GeneratedColumn<bool> get isHidden =>
      $composableBuilder(column: $table.isHidden, builder: (column) => column);

  GeneratedColumn<int> get userOrder =>
      $composableBuilder(column: $table.userOrder, builder: (column) => column);

  GeneratedColumn<String> get rightsStatus => $composableBuilder(
      column: $table.rightsStatus, builder: (column) => column);

  GeneratedColumn<DateTime> get lastWatched => $composableBuilder(
      column: $table.lastWatched, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$ChannelsTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ChannelsTableTable,
    ChannelsTableData,
    $$ChannelsTableTableFilterComposer,
    $$ChannelsTableTableOrderingComposer,
    $$ChannelsTableTableAnnotationComposer,
    $$ChannelsTableTableCreateCompanionBuilder,
    $$ChannelsTableTableUpdateCompanionBuilder,
    (
      ChannelsTableData,
      BaseReferences<_$AppDatabase, $ChannelsTableTable, ChannelsTableData>
    ),
    ChannelsTableData,
    PrefetchHooks Function()> {
  $$ChannelsTableTableTableManager(_$AppDatabase db, $ChannelsTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ChannelsTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ChannelsTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ChannelsTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String?> logoUrl = const Value.absent(),
            Value<String?> groupTitle = const Value.absent(),
            Value<String?> tvgId = const Value.absent(),
            Value<String?> tvgName = const Value.absent(),
            Value<String?> country = const Value.absent(),
            Value<String?> language = const Value.absent(),
            Value<String?> categories = const Value.absent(),
            Value<String> streamUrl = const Value.absent(),
            Value<String> sourceId = const Value.absent(),
            Value<bool> isFavorite = const Value.absent(),
            Value<bool> isHidden = const Value.absent(),
            Value<int?> userOrder = const Value.absent(),
            Value<String> rightsStatus = const Value.absent(),
            Value<DateTime?> lastWatched = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ChannelsTableCompanion(
            id: id,
            name: name,
            logoUrl: logoUrl,
            groupTitle: groupTitle,
            tvgId: tvgId,
            tvgName: tvgName,
            country: country,
            language: language,
            categories: categories,
            streamUrl: streamUrl,
            sourceId: sourceId,
            isFavorite: isFavorite,
            isHidden: isHidden,
            userOrder: userOrder,
            rightsStatus: rightsStatus,
            lastWatched: lastWatched,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String name,
            Value<String?> logoUrl = const Value.absent(),
            Value<String?> groupTitle = const Value.absent(),
            Value<String?> tvgId = const Value.absent(),
            Value<String?> tvgName = const Value.absent(),
            Value<String?> country = const Value.absent(),
            Value<String?> language = const Value.absent(),
            Value<String?> categories = const Value.absent(),
            required String streamUrl,
            required String sourceId,
            Value<bool> isFavorite = const Value.absent(),
            Value<bool> isHidden = const Value.absent(),
            Value<int?> userOrder = const Value.absent(),
            Value<String> rightsStatus = const Value.absent(),
            Value<DateTime?> lastWatched = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ChannelsTableCompanion.insert(
            id: id,
            name: name,
            logoUrl: logoUrl,
            groupTitle: groupTitle,
            tvgId: tvgId,
            tvgName: tvgName,
            country: country,
            language: language,
            categories: categories,
            streamUrl: streamUrl,
            sourceId: sourceId,
            isFavorite: isFavorite,
            isHidden: isHidden,
            userOrder: userOrder,
            rightsStatus: rightsStatus,
            lastWatched: lastWatched,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ChannelsTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ChannelsTableTable,
    ChannelsTableData,
    $$ChannelsTableTableFilterComposer,
    $$ChannelsTableTableOrderingComposer,
    $$ChannelsTableTableAnnotationComposer,
    $$ChannelsTableTableCreateCompanionBuilder,
    $$ChannelsTableTableUpdateCompanionBuilder,
    (
      ChannelsTableData,
      BaseReferences<_$AppDatabase, $ChannelsTableTable, ChannelsTableData>
    ),
    ChannelsTableData,
    PrefetchHooks Function()>;
typedef $$PlaylistSourcesTableTableCreateCompanionBuilder
    = PlaylistSourcesTableCompanion Function({
  required String id,
  required String name,
  required String type,
  Value<String?> url,
  Value<String?> filePath,
  Value<String?> username,
  Value<int> channelCount,
  Value<String> status,
  Value<String?> lastError,
  Value<DateTime?> lastRefresh,
  Value<DateTime?> lastSuccess,
  Value<String?> etag,
  Value<int> priority,
  Value<bool> isEnabled,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$PlaylistSourcesTableTableUpdateCompanionBuilder
    = PlaylistSourcesTableCompanion Function({
  Value<String> id,
  Value<String> name,
  Value<String> type,
  Value<String?> url,
  Value<String?> filePath,
  Value<String?> username,
  Value<int> channelCount,
  Value<String> status,
  Value<String?> lastError,
  Value<DateTime?> lastRefresh,
  Value<DateTime?> lastSuccess,
  Value<String?> etag,
  Value<int> priority,
  Value<bool> isEnabled,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$PlaylistSourcesTableTableFilterComposer
    extends Composer<_$AppDatabase, $PlaylistSourcesTableTable> {
  $$PlaylistSourcesTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get url => $composableBuilder(
      column: $table.url, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get filePath => $composableBuilder(
      column: $table.filePath, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get username => $composableBuilder(
      column: $table.username, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get channelCount => $composableBuilder(
      column: $table.channelCount, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get lastError => $composableBuilder(
      column: $table.lastError, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get lastRefresh => $composableBuilder(
      column: $table.lastRefresh, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get lastSuccess => $composableBuilder(
      column: $table.lastSuccess, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get etag => $composableBuilder(
      column: $table.etag, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get priority => $composableBuilder(
      column: $table.priority, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isEnabled => $composableBuilder(
      column: $table.isEnabled, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$PlaylistSourcesTableTableOrderingComposer
    extends Composer<_$AppDatabase, $PlaylistSourcesTableTable> {
  $$PlaylistSourcesTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get url => $composableBuilder(
      column: $table.url, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get filePath => $composableBuilder(
      column: $table.filePath, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get username => $composableBuilder(
      column: $table.username, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get channelCount => $composableBuilder(
      column: $table.channelCount,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get lastError => $composableBuilder(
      column: $table.lastError, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get lastRefresh => $composableBuilder(
      column: $table.lastRefresh, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get lastSuccess => $composableBuilder(
      column: $table.lastSuccess, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get etag => $composableBuilder(
      column: $table.etag, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get priority => $composableBuilder(
      column: $table.priority, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isEnabled => $composableBuilder(
      column: $table.isEnabled, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$PlaylistSourcesTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $PlaylistSourcesTableTable> {
  $$PlaylistSourcesTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<String> get url =>
      $composableBuilder(column: $table.url, builder: (column) => column);

  GeneratedColumn<String> get filePath =>
      $composableBuilder(column: $table.filePath, builder: (column) => column);

  GeneratedColumn<String> get username =>
      $composableBuilder(column: $table.username, builder: (column) => column);

  GeneratedColumn<int> get channelCount => $composableBuilder(
      column: $table.channelCount, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get lastError =>
      $composableBuilder(column: $table.lastError, builder: (column) => column);

  GeneratedColumn<DateTime> get lastRefresh => $composableBuilder(
      column: $table.lastRefresh, builder: (column) => column);

  GeneratedColumn<DateTime> get lastSuccess => $composableBuilder(
      column: $table.lastSuccess, builder: (column) => column);

  GeneratedColumn<String> get etag =>
      $composableBuilder(column: $table.etag, builder: (column) => column);

  GeneratedColumn<int> get priority =>
      $composableBuilder(column: $table.priority, builder: (column) => column);

  GeneratedColumn<bool> get isEnabled =>
      $composableBuilder(column: $table.isEnabled, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$PlaylistSourcesTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PlaylistSourcesTableTable,
    PlaylistSourcesTableData,
    $$PlaylistSourcesTableTableFilterComposer,
    $$PlaylistSourcesTableTableOrderingComposer,
    $$PlaylistSourcesTableTableAnnotationComposer,
    $$PlaylistSourcesTableTableCreateCompanionBuilder,
    $$PlaylistSourcesTableTableUpdateCompanionBuilder,
    (
      PlaylistSourcesTableData,
      BaseReferences<_$AppDatabase, $PlaylistSourcesTableTable,
          PlaylistSourcesTableData>
    ),
    PlaylistSourcesTableData,
    PrefetchHooks Function()> {
  $$PlaylistSourcesTableTableTableManager(
      _$AppDatabase db, $PlaylistSourcesTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$PlaylistSourcesTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$PlaylistSourcesTableTableOrderingComposer(
                  $db: db, $table: table),
          createComputedFieldComposer: () =>
              $$PlaylistSourcesTableTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<String?> url = const Value.absent(),
            Value<String?> filePath = const Value.absent(),
            Value<String?> username = const Value.absent(),
            Value<int> channelCount = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> lastError = const Value.absent(),
            Value<DateTime?> lastRefresh = const Value.absent(),
            Value<DateTime?> lastSuccess = const Value.absent(),
            Value<String?> etag = const Value.absent(),
            Value<int> priority = const Value.absent(),
            Value<bool> isEnabled = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PlaylistSourcesTableCompanion(
            id: id,
            name: name,
            type: type,
            url: url,
            filePath: filePath,
            username: username,
            channelCount: channelCount,
            status: status,
            lastError: lastError,
            lastRefresh: lastRefresh,
            lastSuccess: lastSuccess,
            etag: etag,
            priority: priority,
            isEnabled: isEnabled,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String name,
            required String type,
            Value<String?> url = const Value.absent(),
            Value<String?> filePath = const Value.absent(),
            Value<String?> username = const Value.absent(),
            Value<int> channelCount = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> lastError = const Value.absent(),
            Value<DateTime?> lastRefresh = const Value.absent(),
            Value<DateTime?> lastSuccess = const Value.absent(),
            Value<String?> etag = const Value.absent(),
            Value<int> priority = const Value.absent(),
            Value<bool> isEnabled = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PlaylistSourcesTableCompanion.insert(
            id: id,
            name: name,
            type: type,
            url: url,
            filePath: filePath,
            username: username,
            channelCount: channelCount,
            status: status,
            lastError: lastError,
            lastRefresh: lastRefresh,
            lastSuccess: lastSuccess,
            etag: etag,
            priority: priority,
            isEnabled: isEnabled,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$PlaylistSourcesTableTableProcessedTableManager
    = ProcessedTableManager<
        _$AppDatabase,
        $PlaylistSourcesTableTable,
        PlaylistSourcesTableData,
        $$PlaylistSourcesTableTableFilterComposer,
        $$PlaylistSourcesTableTableOrderingComposer,
        $$PlaylistSourcesTableTableAnnotationComposer,
        $$PlaylistSourcesTableTableCreateCompanionBuilder,
        $$PlaylistSourcesTableTableUpdateCompanionBuilder,
        (
          PlaylistSourcesTableData,
          BaseReferences<_$AppDatabase, $PlaylistSourcesTableTable,
              PlaylistSourcesTableData>
        ),
        PlaylistSourcesTableData,
        PrefetchHooks Function()>;
typedef $$EpgProgrammesTableTableCreateCompanionBuilder
    = EpgProgrammesTableCompanion Function({
  required String id,
  required String channelId,
  required String title,
  Value<String?> description,
  Value<String?> category,
  Value<String?> language,
  required DateTime startTime,
  required DateTime endTime,
  required String sourceId,
  Value<int> rowid,
});
typedef $$EpgProgrammesTableTableUpdateCompanionBuilder
    = EpgProgrammesTableCompanion Function({
  Value<String> id,
  Value<String> channelId,
  Value<String> title,
  Value<String?> description,
  Value<String?> category,
  Value<String?> language,
  Value<DateTime> startTime,
  Value<DateTime> endTime,
  Value<String> sourceId,
  Value<int> rowid,
});

class $$EpgProgrammesTableTableFilterComposer
    extends Composer<_$AppDatabase, $EpgProgrammesTableTable> {
  $$EpgProgrammesTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get channelId => $composableBuilder(
      column: $table.channelId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get language => $composableBuilder(
      column: $table.language, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get startTime => $composableBuilder(
      column: $table.startTime, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get endTime => $composableBuilder(
      column: $table.endTime, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnFilters(column));
}

class $$EpgProgrammesTableTableOrderingComposer
    extends Composer<_$AppDatabase, $EpgProgrammesTableTable> {
  $$EpgProgrammesTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get channelId => $composableBuilder(
      column: $table.channelId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get category => $composableBuilder(
      column: $table.category, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get language => $composableBuilder(
      column: $table.language, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get startTime => $composableBuilder(
      column: $table.startTime, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get endTime => $composableBuilder(
      column: $table.endTime, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnOrderings(column));
}

class $$EpgProgrammesTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $EpgProgrammesTableTable> {
  $$EpgProgrammesTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get channelId =>
      $composableBuilder(column: $table.channelId, builder: (column) => column);

  GeneratedColumn<String> get title =>
      $composableBuilder(column: $table.title, builder: (column) => column);

  GeneratedColumn<String> get description => $composableBuilder(
      column: $table.description, builder: (column) => column);

  GeneratedColumn<String> get category =>
      $composableBuilder(column: $table.category, builder: (column) => column);

  GeneratedColumn<String> get language =>
      $composableBuilder(column: $table.language, builder: (column) => column);

  GeneratedColumn<DateTime> get startTime =>
      $composableBuilder(column: $table.startTime, builder: (column) => column);

  GeneratedColumn<DateTime> get endTime =>
      $composableBuilder(column: $table.endTime, builder: (column) => column);

  GeneratedColumn<String> get sourceId =>
      $composableBuilder(column: $table.sourceId, builder: (column) => column);
}

class $$EpgProgrammesTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EpgProgrammesTableTable,
    EpgProgrammesTableData,
    $$EpgProgrammesTableTableFilterComposer,
    $$EpgProgrammesTableTableOrderingComposer,
    $$EpgProgrammesTableTableAnnotationComposer,
    $$EpgProgrammesTableTableCreateCompanionBuilder,
    $$EpgProgrammesTableTableUpdateCompanionBuilder,
    (
      EpgProgrammesTableData,
      BaseReferences<_$AppDatabase, $EpgProgrammesTableTable,
          EpgProgrammesTableData>
    ),
    EpgProgrammesTableData,
    PrefetchHooks Function()> {
  $$EpgProgrammesTableTableTableManager(
      _$AppDatabase db, $EpgProgrammesTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EpgProgrammesTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EpgProgrammesTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EpgProgrammesTableTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> channelId = const Value.absent(),
            Value<String> title = const Value.absent(),
            Value<String?> description = const Value.absent(),
            Value<String?> category = const Value.absent(),
            Value<String?> language = const Value.absent(),
            Value<DateTime> startTime = const Value.absent(),
            Value<DateTime> endTime = const Value.absent(),
            Value<String> sourceId = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgProgrammesTableCompanion(
            id: id,
            channelId: channelId,
            title: title,
            description: description,
            category: category,
            language: language,
            startTime: startTime,
            endTime: endTime,
            sourceId: sourceId,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String channelId,
            required String title,
            Value<String?> description = const Value.absent(),
            Value<String?> category = const Value.absent(),
            Value<String?> language = const Value.absent(),
            required DateTime startTime,
            required DateTime endTime,
            required String sourceId,
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgProgrammesTableCompanion.insert(
            id: id,
            channelId: channelId,
            title: title,
            description: description,
            category: category,
            language: language,
            startTime: startTime,
            endTime: endTime,
            sourceId: sourceId,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EpgProgrammesTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EpgProgrammesTableTable,
    EpgProgrammesTableData,
    $$EpgProgrammesTableTableFilterComposer,
    $$EpgProgrammesTableTableOrderingComposer,
    $$EpgProgrammesTableTableAnnotationComposer,
    $$EpgProgrammesTableTableCreateCompanionBuilder,
    $$EpgProgrammesTableTableUpdateCompanionBuilder,
    (
      EpgProgrammesTableData,
      BaseReferences<_$AppDatabase, $EpgProgrammesTableTable,
          EpgProgrammesTableData>
    ),
    EpgProgrammesTableData,
    PrefetchHooks Function()>;
typedef $$EpgSourcesTableTableCreateCompanionBuilder = EpgSourcesTableCompanion
    Function({
  required String id,
  required String name,
  required String url,
  Value<String?> channelCount,
  Value<String> status,
  Value<DateTime?> lastRefresh,
  Value<bool> isEnabled,
  Value<int> rowid,
});
typedef $$EpgSourcesTableTableUpdateCompanionBuilder = EpgSourcesTableCompanion
    Function({
  Value<String> id,
  Value<String> name,
  Value<String> url,
  Value<String?> channelCount,
  Value<String> status,
  Value<DateTime?> lastRefresh,
  Value<bool> isEnabled,
  Value<int> rowid,
});

class $$EpgSourcesTableTableFilterComposer
    extends Composer<_$AppDatabase, $EpgSourcesTableTable> {
  $$EpgSourcesTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get url => $composableBuilder(
      column: $table.url, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get channelCount => $composableBuilder(
      column: $table.channelCount, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get lastRefresh => $composableBuilder(
      column: $table.lastRefresh, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isEnabled => $composableBuilder(
      column: $table.isEnabled, builder: (column) => ColumnFilters(column));
}

class $$EpgSourcesTableTableOrderingComposer
    extends Composer<_$AppDatabase, $EpgSourcesTableTable> {
  $$EpgSourcesTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get name => $composableBuilder(
      column: $table.name, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get url => $composableBuilder(
      column: $table.url, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get channelCount => $composableBuilder(
      column: $table.channelCount,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get lastRefresh => $composableBuilder(
      column: $table.lastRefresh, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isEnabled => $composableBuilder(
      column: $table.isEnabled, builder: (column) => ColumnOrderings(column));
}

class $$EpgSourcesTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $EpgSourcesTableTable> {
  $$EpgSourcesTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get name =>
      $composableBuilder(column: $table.name, builder: (column) => column);

  GeneratedColumn<String> get url =>
      $composableBuilder(column: $table.url, builder: (column) => column);

  GeneratedColumn<String> get channelCount => $composableBuilder(
      column: $table.channelCount, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<DateTime> get lastRefresh => $composableBuilder(
      column: $table.lastRefresh, builder: (column) => column);

  GeneratedColumn<bool> get isEnabled =>
      $composableBuilder(column: $table.isEnabled, builder: (column) => column);
}

class $$EpgSourcesTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EpgSourcesTableTable,
    EpgSourcesTableData,
    $$EpgSourcesTableTableFilterComposer,
    $$EpgSourcesTableTableOrderingComposer,
    $$EpgSourcesTableTableAnnotationComposer,
    $$EpgSourcesTableTableCreateCompanionBuilder,
    $$EpgSourcesTableTableUpdateCompanionBuilder,
    (
      EpgSourcesTableData,
      BaseReferences<_$AppDatabase, $EpgSourcesTableTable, EpgSourcesTableData>
    ),
    EpgSourcesTableData,
    PrefetchHooks Function()> {
  $$EpgSourcesTableTableTableManager(
      _$AppDatabase db, $EpgSourcesTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EpgSourcesTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EpgSourcesTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EpgSourcesTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> name = const Value.absent(),
            Value<String> url = const Value.absent(),
            Value<String?> channelCount = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<DateTime?> lastRefresh = const Value.absent(),
            Value<bool> isEnabled = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgSourcesTableCompanion(
            id: id,
            name: name,
            url: url,
            channelCount: channelCount,
            status: status,
            lastRefresh: lastRefresh,
            isEnabled: isEnabled,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String name,
            required String url,
            Value<String?> channelCount = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<DateTime?> lastRefresh = const Value.absent(),
            Value<bool> isEnabled = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgSourcesTableCompanion.insert(
            id: id,
            name: name,
            url: url,
            channelCount: channelCount,
            status: status,
            lastRefresh: lastRefresh,
            isEnabled: isEnabled,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EpgSourcesTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EpgSourcesTableTable,
    EpgSourcesTableData,
    $$EpgSourcesTableTableFilterComposer,
    $$EpgSourcesTableTableOrderingComposer,
    $$EpgSourcesTableTableAnnotationComposer,
    $$EpgSourcesTableTableCreateCompanionBuilder,
    $$EpgSourcesTableTableUpdateCompanionBuilder,
    (
      EpgSourcesTableData,
      BaseReferences<_$AppDatabase, $EpgSourcesTableTable, EpgSourcesTableData>
    ),
    EpgSourcesTableData,
    PrefetchHooks Function()>;
typedef $$EpgChannelsTableTableCreateCompanionBuilder
    = EpgChannelsTableCompanion Function({
  required String id,
  required String epgSourceId,
  required String xmltvChannelId,
  required String displayName,
  required String normalizedName,
  Value<int> rowid,
});
typedef $$EpgChannelsTableTableUpdateCompanionBuilder
    = EpgChannelsTableCompanion Function({
  Value<String> id,
  Value<String> epgSourceId,
  Value<String> xmltvChannelId,
  Value<String> displayName,
  Value<String> normalizedName,
  Value<int> rowid,
});

class $$EpgChannelsTableTableFilterComposer
    extends Composer<_$AppDatabase, $EpgChannelsTableTable> {
  $$EpgChannelsTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get epgSourceId => $composableBuilder(
      column: $table.epgSourceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get xmltvChannelId => $composableBuilder(
      column: $table.xmltvChannelId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get normalizedName => $composableBuilder(
      column: $table.normalizedName,
      builder: (column) => ColumnFilters(column));
}

class $$EpgChannelsTableTableOrderingComposer
    extends Composer<_$AppDatabase, $EpgChannelsTableTable> {
  $$EpgChannelsTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get epgSourceId => $composableBuilder(
      column: $table.epgSourceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get xmltvChannelId => $composableBuilder(
      column: $table.xmltvChannelId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get normalizedName => $composableBuilder(
      column: $table.normalizedName,
      builder: (column) => ColumnOrderings(column));
}

class $$EpgChannelsTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $EpgChannelsTableTable> {
  $$EpgChannelsTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get epgSourceId => $composableBuilder(
      column: $table.epgSourceId, builder: (column) => column);

  GeneratedColumn<String> get xmltvChannelId => $composableBuilder(
      column: $table.xmltvChannelId, builder: (column) => column);

  GeneratedColumn<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => column);

  GeneratedColumn<String> get normalizedName => $composableBuilder(
      column: $table.normalizedName, builder: (column) => column);
}

class $$EpgChannelsTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EpgChannelsTableTable,
    EpgChannelsTableData,
    $$EpgChannelsTableTableFilterComposer,
    $$EpgChannelsTableTableOrderingComposer,
    $$EpgChannelsTableTableAnnotationComposer,
    $$EpgChannelsTableTableCreateCompanionBuilder,
    $$EpgChannelsTableTableUpdateCompanionBuilder,
    (
      EpgChannelsTableData,
      BaseReferences<_$AppDatabase, $EpgChannelsTableTable,
          EpgChannelsTableData>
    ),
    EpgChannelsTableData,
    PrefetchHooks Function()> {
  $$EpgChannelsTableTableTableManager(
      _$AppDatabase db, $EpgChannelsTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EpgChannelsTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EpgChannelsTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EpgChannelsTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> epgSourceId = const Value.absent(),
            Value<String> xmltvChannelId = const Value.absent(),
            Value<String> displayName = const Value.absent(),
            Value<String> normalizedName = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgChannelsTableCompanion(
            id: id,
            epgSourceId: epgSourceId,
            xmltvChannelId: xmltvChannelId,
            displayName: displayName,
            normalizedName: normalizedName,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String epgSourceId,
            required String xmltvChannelId,
            required String displayName,
            required String normalizedName,
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgChannelsTableCompanion.insert(
            id: id,
            epgSourceId: epgSourceId,
            xmltvChannelId: xmltvChannelId,
            displayName: displayName,
            normalizedName: normalizedName,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EpgChannelsTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EpgChannelsTableTable,
    EpgChannelsTableData,
    $$EpgChannelsTableTableFilterComposer,
    $$EpgChannelsTableTableOrderingComposer,
    $$EpgChannelsTableTableAnnotationComposer,
    $$EpgChannelsTableTableCreateCompanionBuilder,
    $$EpgChannelsTableTableUpdateCompanionBuilder,
    (
      EpgChannelsTableData,
      BaseReferences<_$AppDatabase, $EpgChannelsTableTable,
          EpgChannelsTableData>
    ),
    EpgChannelsTableData,
    PrefetchHooks Function()>;
typedef $$EpgChannelMappingsTableTableCreateCompanionBuilder
    = EpgChannelMappingsTableCompanion Function({
  required String id,
  required String sourceId,
  required String appChannelId,
  Value<String?> epgSourceId,
  required String epgChannelId,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$EpgChannelMappingsTableTableUpdateCompanionBuilder
    = EpgChannelMappingsTableCompanion Function({
  Value<String> id,
  Value<String> sourceId,
  Value<String> appChannelId,
  Value<String?> epgSourceId,
  Value<String> epgChannelId,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$EpgChannelMappingsTableTableFilterComposer
    extends Composer<_$AppDatabase, $EpgChannelMappingsTableTable> {
  $$EpgChannelMappingsTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get appChannelId => $composableBuilder(
      column: $table.appChannelId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get epgSourceId => $composableBuilder(
      column: $table.epgSourceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get epgChannelId => $composableBuilder(
      column: $table.epgChannelId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$EpgChannelMappingsTableTableOrderingComposer
    extends Composer<_$AppDatabase, $EpgChannelMappingsTableTable> {
  $$EpgChannelMappingsTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get appChannelId => $composableBuilder(
      column: $table.appChannelId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get epgSourceId => $composableBuilder(
      column: $table.epgSourceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get epgChannelId => $composableBuilder(
      column: $table.epgChannelId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$EpgChannelMappingsTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $EpgChannelMappingsTableTable> {
  $$EpgChannelMappingsTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get sourceId =>
      $composableBuilder(column: $table.sourceId, builder: (column) => column);

  GeneratedColumn<String> get appChannelId => $composableBuilder(
      column: $table.appChannelId, builder: (column) => column);

  GeneratedColumn<String> get epgSourceId => $composableBuilder(
      column: $table.epgSourceId, builder: (column) => column);

  GeneratedColumn<String> get epgChannelId => $composableBuilder(
      column: $table.epgChannelId, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$EpgChannelMappingsTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EpgChannelMappingsTableTable,
    EpgChannelMappingsTableData,
    $$EpgChannelMappingsTableTableFilterComposer,
    $$EpgChannelMappingsTableTableOrderingComposer,
    $$EpgChannelMappingsTableTableAnnotationComposer,
    $$EpgChannelMappingsTableTableCreateCompanionBuilder,
    $$EpgChannelMappingsTableTableUpdateCompanionBuilder,
    (
      EpgChannelMappingsTableData,
      BaseReferences<_$AppDatabase, $EpgChannelMappingsTableTable,
          EpgChannelMappingsTableData>
    ),
    EpgChannelMappingsTableData,
    PrefetchHooks Function()> {
  $$EpgChannelMappingsTableTableTableManager(
      _$AppDatabase db, $EpgChannelMappingsTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EpgChannelMappingsTableTableFilterComposer(
                  $db: db, $table: table),
          createOrderingComposer: () =>
              $$EpgChannelMappingsTableTableOrderingComposer(
                  $db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EpgChannelMappingsTableTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> sourceId = const Value.absent(),
            Value<String> appChannelId = const Value.absent(),
            Value<String?> epgSourceId = const Value.absent(),
            Value<String> epgChannelId = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgChannelMappingsTableCompanion(
            id: id,
            sourceId: sourceId,
            appChannelId: appChannelId,
            epgSourceId: epgSourceId,
            epgChannelId: epgChannelId,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String sourceId,
            required String appChannelId,
            Value<String?> epgSourceId = const Value.absent(),
            required String epgChannelId,
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EpgChannelMappingsTableCompanion.insert(
            id: id,
            sourceId: sourceId,
            appChannelId: appChannelId,
            epgSourceId: epgSourceId,
            epgChannelId: epgChannelId,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$EpgChannelMappingsTableTableProcessedTableManager
    = ProcessedTableManager<
        _$AppDatabase,
        $EpgChannelMappingsTableTable,
        EpgChannelMappingsTableData,
        $$EpgChannelMappingsTableTableFilterComposer,
        $$EpgChannelMappingsTableTableOrderingComposer,
        $$EpgChannelMappingsTableTableAnnotationComposer,
        $$EpgChannelMappingsTableTableCreateCompanionBuilder,
        $$EpgChannelMappingsTableTableUpdateCompanionBuilder,
        (
          EpgChannelMappingsTableData,
          BaseReferences<_$AppDatabase, $EpgChannelMappingsTableTable,
              EpgChannelMappingsTableData>
        ),
        EpgChannelMappingsTableData,
        PrefetchHooks Function()>;
typedef $$FavoritesTableTableCreateCompanionBuilder = FavoritesTableCompanion
    Function({
  required String id,
  required String type,
  required String referenceId,
  required String displayName,
  Value<String?> metadata,
  Value<DateTime> addedAt,
  Value<int> rowid,
});
typedef $$FavoritesTableTableUpdateCompanionBuilder = FavoritesTableCompanion
    Function({
  Value<String> id,
  Value<String> type,
  Value<String> referenceId,
  Value<String> displayName,
  Value<String?> metadata,
  Value<DateTime> addedAt,
  Value<int> rowid,
});

class $$FavoritesTableTableFilterComposer
    extends Composer<_$AppDatabase, $FavoritesTableTable> {
  $$FavoritesTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get referenceId => $composableBuilder(
      column: $table.referenceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get metadata => $composableBuilder(
      column: $table.metadata, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get addedAt => $composableBuilder(
      column: $table.addedAt, builder: (column) => ColumnFilters(column));
}

class $$FavoritesTableTableOrderingComposer
    extends Composer<_$AppDatabase, $FavoritesTableTable> {
  $$FavoritesTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get referenceId => $composableBuilder(
      column: $table.referenceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get metadata => $composableBuilder(
      column: $table.metadata, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get addedAt => $composableBuilder(
      column: $table.addedAt, builder: (column) => ColumnOrderings(column));
}

class $$FavoritesTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $FavoritesTableTable> {
  $$FavoritesTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<String> get referenceId => $composableBuilder(
      column: $table.referenceId, builder: (column) => column);

  GeneratedColumn<String> get displayName => $composableBuilder(
      column: $table.displayName, builder: (column) => column);

  GeneratedColumn<String> get metadata =>
      $composableBuilder(column: $table.metadata, builder: (column) => column);

  GeneratedColumn<DateTime> get addedAt =>
      $composableBuilder(column: $table.addedAt, builder: (column) => column);
}

class $$FavoritesTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FavoritesTableTable,
    FavoritesTableData,
    $$FavoritesTableTableFilterComposer,
    $$FavoritesTableTableOrderingComposer,
    $$FavoritesTableTableAnnotationComposer,
    $$FavoritesTableTableCreateCompanionBuilder,
    $$FavoritesTableTableUpdateCompanionBuilder,
    (
      FavoritesTableData,
      BaseReferences<_$AppDatabase, $FavoritesTableTable, FavoritesTableData>
    ),
    FavoritesTableData,
    PrefetchHooks Function()> {
  $$FavoritesTableTableTableManager(
      _$AppDatabase db, $FavoritesTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$FavoritesTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$FavoritesTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$FavoritesTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<String> referenceId = const Value.absent(),
            Value<String> displayName = const Value.absent(),
            Value<String?> metadata = const Value.absent(),
            Value<DateTime> addedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FavoritesTableCompanion(
            id: id,
            type: type,
            referenceId: referenceId,
            displayName: displayName,
            metadata: metadata,
            addedAt: addedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String type,
            required String referenceId,
            required String displayName,
            Value<String?> metadata = const Value.absent(),
            Value<DateTime> addedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FavoritesTableCompanion.insert(
            id: id,
            type: type,
            referenceId: referenceId,
            displayName: displayName,
            metadata: metadata,
            addedAt: addedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$FavoritesTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $FavoritesTableTable,
    FavoritesTableData,
    $$FavoritesTableTableFilterComposer,
    $$FavoritesTableTableOrderingComposer,
    $$FavoritesTableTableAnnotationComposer,
    $$FavoritesTableTableCreateCompanionBuilder,
    $$FavoritesTableTableUpdateCompanionBuilder,
    (
      FavoritesTableData,
      BaseReferences<_$AppDatabase, $FavoritesTableTable, FavoritesTableData>
    ),
    FavoritesTableData,
    PrefetchHooks Function()>;
typedef $$WatchHistoryTableTableCreateCompanionBuilder
    = WatchHistoryTableCompanion Function({
  required String id,
  required String channelId,
  required String channelName,
  required String streamUrl,
  Value<int> durationSeconds,
  Value<DateTime> watchedAt,
  Value<int> rowid,
});
typedef $$WatchHistoryTableTableUpdateCompanionBuilder
    = WatchHistoryTableCompanion Function({
  Value<String> id,
  Value<String> channelId,
  Value<String> channelName,
  Value<String> streamUrl,
  Value<int> durationSeconds,
  Value<DateTime> watchedAt,
  Value<int> rowid,
});

class $$WatchHistoryTableTableFilterComposer
    extends Composer<_$AppDatabase, $WatchHistoryTableTable> {
  $$WatchHistoryTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get channelId => $composableBuilder(
      column: $table.channelId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get channelName => $composableBuilder(
      column: $table.channelName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get streamUrl => $composableBuilder(
      column: $table.streamUrl, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get durationSeconds => $composableBuilder(
      column: $table.durationSeconds,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get watchedAt => $composableBuilder(
      column: $table.watchedAt, builder: (column) => ColumnFilters(column));
}

class $$WatchHistoryTableTableOrderingComposer
    extends Composer<_$AppDatabase, $WatchHistoryTableTable> {
  $$WatchHistoryTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get channelId => $composableBuilder(
      column: $table.channelId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get channelName => $composableBuilder(
      column: $table.channelName, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get streamUrl => $composableBuilder(
      column: $table.streamUrl, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get durationSeconds => $composableBuilder(
      column: $table.durationSeconds,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get watchedAt => $composableBuilder(
      column: $table.watchedAt, builder: (column) => ColumnOrderings(column));
}

class $$WatchHistoryTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $WatchHistoryTableTable> {
  $$WatchHistoryTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get channelId =>
      $composableBuilder(column: $table.channelId, builder: (column) => column);

  GeneratedColumn<String> get channelName => $composableBuilder(
      column: $table.channelName, builder: (column) => column);

  GeneratedColumn<String> get streamUrl =>
      $composableBuilder(column: $table.streamUrl, builder: (column) => column);

  GeneratedColumn<int> get durationSeconds => $composableBuilder(
      column: $table.durationSeconds, builder: (column) => column);

  GeneratedColumn<DateTime> get watchedAt =>
      $composableBuilder(column: $table.watchedAt, builder: (column) => column);
}

class $$WatchHistoryTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $WatchHistoryTableTable,
    WatchHistoryTableData,
    $$WatchHistoryTableTableFilterComposer,
    $$WatchHistoryTableTableOrderingComposer,
    $$WatchHistoryTableTableAnnotationComposer,
    $$WatchHistoryTableTableCreateCompanionBuilder,
    $$WatchHistoryTableTableUpdateCompanionBuilder,
    (
      WatchHistoryTableData,
      BaseReferences<_$AppDatabase, $WatchHistoryTableTable,
          WatchHistoryTableData>
    ),
    WatchHistoryTableData,
    PrefetchHooks Function()> {
  $$WatchHistoryTableTableTableManager(
      _$AppDatabase db, $WatchHistoryTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$WatchHistoryTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$WatchHistoryTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$WatchHistoryTableTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> channelId = const Value.absent(),
            Value<String> channelName = const Value.absent(),
            Value<String> streamUrl = const Value.absent(),
            Value<int> durationSeconds = const Value.absent(),
            Value<DateTime> watchedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              WatchHistoryTableCompanion(
            id: id,
            channelId: channelId,
            channelName: channelName,
            streamUrl: streamUrl,
            durationSeconds: durationSeconds,
            watchedAt: watchedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String channelId,
            required String channelName,
            required String streamUrl,
            Value<int> durationSeconds = const Value.absent(),
            Value<DateTime> watchedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              WatchHistoryTableCompanion.insert(
            id: id,
            channelId: channelId,
            channelName: channelName,
            streamUrl: streamUrl,
            durationSeconds: durationSeconds,
            watchedAt: watchedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$WatchHistoryTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $WatchHistoryTableTable,
    WatchHistoryTableData,
    $$WatchHistoryTableTableFilterComposer,
    $$WatchHistoryTableTableOrderingComposer,
    $$WatchHistoryTableTableAnnotationComposer,
    $$WatchHistoryTableTableCreateCompanionBuilder,
    $$WatchHistoryTableTableUpdateCompanionBuilder,
    (
      WatchHistoryTableData,
      BaseReferences<_$AppDatabase, $WatchHistoryTableTable,
          WatchHistoryTableData>
    ),
    WatchHistoryTableData,
    PrefetchHooks Function()>;
typedef $$RemindersTableTableCreateCompanionBuilder = RemindersTableCompanion
    Function({
  required String id,
  required String type,
  required String referenceId,
  required String title,
  Value<String?> subtitle,
  required DateTime reminderTime,
  Value<bool> isFired,
  Value<DateTime> createdAt,
  Value<int> rowid,
});
typedef $$RemindersTableTableUpdateCompanionBuilder = RemindersTableCompanion
    Function({
  Value<String> id,
  Value<String> type,
  Value<String> referenceId,
  Value<String> title,
  Value<String?> subtitle,
  Value<DateTime> reminderTime,
  Value<bool> isFired,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$RemindersTableTableFilterComposer
    extends Composer<_$AppDatabase, $RemindersTableTable> {
  $$RemindersTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get referenceId => $composableBuilder(
      column: $table.referenceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get subtitle => $composableBuilder(
      column: $table.subtitle, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get reminderTime => $composableBuilder(
      column: $table.reminderTime, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isFired => $composableBuilder(
      column: $table.isFired, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$RemindersTableTableOrderingComposer
    extends Composer<_$AppDatabase, $RemindersTableTable> {
  $$RemindersTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get type => $composableBuilder(
      column: $table.type, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get referenceId => $composableBuilder(
      column: $table.referenceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get subtitle => $composableBuilder(
      column: $table.subtitle, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get reminderTime => $composableBuilder(
      column: $table.reminderTime,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isFired => $composableBuilder(
      column: $table.isFired, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$RemindersTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $RemindersTableTable> {
  $$RemindersTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get type =>
      $composableBuilder(column: $table.type, builder: (column) => column);

  GeneratedColumn<String> get referenceId => $composableBuilder(
      column: $table.referenceId, builder: (column) => column);

  GeneratedColumn<String> get title =>
      $composableBuilder(column: $table.title, builder: (column) => column);

  GeneratedColumn<String> get subtitle =>
      $composableBuilder(column: $table.subtitle, builder: (column) => column);

  GeneratedColumn<DateTime> get reminderTime => $composableBuilder(
      column: $table.reminderTime, builder: (column) => column);

  GeneratedColumn<bool> get isFired =>
      $composableBuilder(column: $table.isFired, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$RemindersTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $RemindersTableTable,
    RemindersTableData,
    $$RemindersTableTableFilterComposer,
    $$RemindersTableTableOrderingComposer,
    $$RemindersTableTableAnnotationComposer,
    $$RemindersTableTableCreateCompanionBuilder,
    $$RemindersTableTableUpdateCompanionBuilder,
    (
      RemindersTableData,
      BaseReferences<_$AppDatabase, $RemindersTableTable, RemindersTableData>
    ),
    RemindersTableData,
    PrefetchHooks Function()> {
  $$RemindersTableTableTableManager(
      _$AppDatabase db, $RemindersTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$RemindersTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$RemindersTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$RemindersTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> type = const Value.absent(),
            Value<String> referenceId = const Value.absent(),
            Value<String> title = const Value.absent(),
            Value<String?> subtitle = const Value.absent(),
            Value<DateTime> reminderTime = const Value.absent(),
            Value<bool> isFired = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              RemindersTableCompanion(
            id: id,
            type: type,
            referenceId: referenceId,
            title: title,
            subtitle: subtitle,
            reminderTime: reminderTime,
            isFired: isFired,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String type,
            required String referenceId,
            required String title,
            Value<String?> subtitle = const Value.absent(),
            required DateTime reminderTime,
            Value<bool> isFired = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              RemindersTableCompanion.insert(
            id: id,
            type: type,
            referenceId: referenceId,
            title: title,
            subtitle: subtitle,
            reminderTime: reminderTime,
            isFired: isFired,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$RemindersTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $RemindersTableTable,
    RemindersTableData,
    $$RemindersTableTableFilterComposer,
    $$RemindersTableTableOrderingComposer,
    $$RemindersTableTableAnnotationComposer,
    $$RemindersTableTableCreateCompanionBuilder,
    $$RemindersTableTableUpdateCompanionBuilder,
    (
      RemindersTableData,
      BaseReferences<_$AppDatabase, $RemindersTableTable, RemindersTableData>
    ),
    RemindersTableData,
    PrefetchHooks Function()>;
typedef $$SportsEventsTableTableCreateCompanionBuilder
    = SportsEventsTableCompanion Function({
  required String id,
  required String sport,
  Value<String?> homeTeamId,
  required String homeTeamName,
  Value<String?> awayTeamId,
  required String awayTeamName,
  Value<String?> competitionId,
  required String competitionName,
  required String status,
  Value<String?> homeScore,
  Value<String?> awayScore,
  required DateTime startTime,
  Value<String?> venue,
  Value<String?> metadata,
  required String sourceId,
  Value<DateTime> cachedAt,
  Value<int> rowid,
});
typedef $$SportsEventsTableTableUpdateCompanionBuilder
    = SportsEventsTableCompanion Function({
  Value<String> id,
  Value<String> sport,
  Value<String?> homeTeamId,
  Value<String> homeTeamName,
  Value<String?> awayTeamId,
  Value<String> awayTeamName,
  Value<String?> competitionId,
  Value<String> competitionName,
  Value<String> status,
  Value<String?> homeScore,
  Value<String?> awayScore,
  Value<DateTime> startTime,
  Value<String?> venue,
  Value<String?> metadata,
  Value<String> sourceId,
  Value<DateTime> cachedAt,
  Value<int> rowid,
});

class $$SportsEventsTableTableFilterComposer
    extends Composer<_$AppDatabase, $SportsEventsTableTable> {
  $$SportsEventsTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sport => $composableBuilder(
      column: $table.sport, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get homeTeamId => $composableBuilder(
      column: $table.homeTeamId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get homeTeamName => $composableBuilder(
      column: $table.homeTeamName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get awayTeamId => $composableBuilder(
      column: $table.awayTeamId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get awayTeamName => $composableBuilder(
      column: $table.awayTeamName, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get competitionId => $composableBuilder(
      column: $table.competitionId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get competitionName => $composableBuilder(
      column: $table.competitionName,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get homeScore => $composableBuilder(
      column: $table.homeScore, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get awayScore => $composableBuilder(
      column: $table.awayScore, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get startTime => $composableBuilder(
      column: $table.startTime, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get venue => $composableBuilder(
      column: $table.venue, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get metadata => $composableBuilder(
      column: $table.metadata, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get cachedAt => $composableBuilder(
      column: $table.cachedAt, builder: (column) => ColumnFilters(column));
}

class $$SportsEventsTableTableOrderingComposer
    extends Composer<_$AppDatabase, $SportsEventsTableTable> {
  $$SportsEventsTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sport => $composableBuilder(
      column: $table.sport, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get homeTeamId => $composableBuilder(
      column: $table.homeTeamId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get homeTeamName => $composableBuilder(
      column: $table.homeTeamName,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get awayTeamId => $composableBuilder(
      column: $table.awayTeamId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get awayTeamName => $composableBuilder(
      column: $table.awayTeamName,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get competitionId => $composableBuilder(
      column: $table.competitionId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get competitionName => $composableBuilder(
      column: $table.competitionName,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get status => $composableBuilder(
      column: $table.status, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get homeScore => $composableBuilder(
      column: $table.homeScore, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get awayScore => $composableBuilder(
      column: $table.awayScore, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get startTime => $composableBuilder(
      column: $table.startTime, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get venue => $composableBuilder(
      column: $table.venue, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get metadata => $composableBuilder(
      column: $table.metadata, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get sourceId => $composableBuilder(
      column: $table.sourceId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get cachedAt => $composableBuilder(
      column: $table.cachedAt, builder: (column) => ColumnOrderings(column));
}

class $$SportsEventsTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $SportsEventsTableTable> {
  $$SportsEventsTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get sport =>
      $composableBuilder(column: $table.sport, builder: (column) => column);

  GeneratedColumn<String> get homeTeamId => $composableBuilder(
      column: $table.homeTeamId, builder: (column) => column);

  GeneratedColumn<String> get homeTeamName => $composableBuilder(
      column: $table.homeTeamName, builder: (column) => column);

  GeneratedColumn<String> get awayTeamId => $composableBuilder(
      column: $table.awayTeamId, builder: (column) => column);

  GeneratedColumn<String> get awayTeamName => $composableBuilder(
      column: $table.awayTeamName, builder: (column) => column);

  GeneratedColumn<String> get competitionId => $composableBuilder(
      column: $table.competitionId, builder: (column) => column);

  GeneratedColumn<String> get competitionName => $composableBuilder(
      column: $table.competitionName, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get homeScore =>
      $composableBuilder(column: $table.homeScore, builder: (column) => column);

  GeneratedColumn<String> get awayScore =>
      $composableBuilder(column: $table.awayScore, builder: (column) => column);

  GeneratedColumn<DateTime> get startTime =>
      $composableBuilder(column: $table.startTime, builder: (column) => column);

  GeneratedColumn<String> get venue =>
      $composableBuilder(column: $table.venue, builder: (column) => column);

  GeneratedColumn<String> get metadata =>
      $composableBuilder(column: $table.metadata, builder: (column) => column);

  GeneratedColumn<String> get sourceId =>
      $composableBuilder(column: $table.sourceId, builder: (column) => column);

  GeneratedColumn<DateTime> get cachedAt =>
      $composableBuilder(column: $table.cachedAt, builder: (column) => column);
}

class $$SportsEventsTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SportsEventsTableTable,
    SportsEventsTableData,
    $$SportsEventsTableTableFilterComposer,
    $$SportsEventsTableTableOrderingComposer,
    $$SportsEventsTableTableAnnotationComposer,
    $$SportsEventsTableTableCreateCompanionBuilder,
    $$SportsEventsTableTableUpdateCompanionBuilder,
    (
      SportsEventsTableData,
      BaseReferences<_$AppDatabase, $SportsEventsTableTable,
          SportsEventsTableData>
    ),
    SportsEventsTableData,
    PrefetchHooks Function()> {
  $$SportsEventsTableTableTableManager(
      _$AppDatabase db, $SportsEventsTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SportsEventsTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SportsEventsTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SportsEventsTableTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> sport = const Value.absent(),
            Value<String?> homeTeamId = const Value.absent(),
            Value<String> homeTeamName = const Value.absent(),
            Value<String?> awayTeamId = const Value.absent(),
            Value<String> awayTeamName = const Value.absent(),
            Value<String?> competitionId = const Value.absent(),
            Value<String> competitionName = const Value.absent(),
            Value<String> status = const Value.absent(),
            Value<String?> homeScore = const Value.absent(),
            Value<String?> awayScore = const Value.absent(),
            Value<DateTime> startTime = const Value.absent(),
            Value<String?> venue = const Value.absent(),
            Value<String?> metadata = const Value.absent(),
            Value<String> sourceId = const Value.absent(),
            Value<DateTime> cachedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SportsEventsTableCompanion(
            id: id,
            sport: sport,
            homeTeamId: homeTeamId,
            homeTeamName: homeTeamName,
            awayTeamId: awayTeamId,
            awayTeamName: awayTeamName,
            competitionId: competitionId,
            competitionName: competitionName,
            status: status,
            homeScore: homeScore,
            awayScore: awayScore,
            startTime: startTime,
            venue: venue,
            metadata: metadata,
            sourceId: sourceId,
            cachedAt: cachedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String sport,
            Value<String?> homeTeamId = const Value.absent(),
            required String homeTeamName,
            Value<String?> awayTeamId = const Value.absent(),
            required String awayTeamName,
            Value<String?> competitionId = const Value.absent(),
            required String competitionName,
            required String status,
            Value<String?> homeScore = const Value.absent(),
            Value<String?> awayScore = const Value.absent(),
            required DateTime startTime,
            Value<String?> venue = const Value.absent(),
            Value<String?> metadata = const Value.absent(),
            required String sourceId,
            Value<DateTime> cachedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SportsEventsTableCompanion.insert(
            id: id,
            sport: sport,
            homeTeamId: homeTeamId,
            homeTeamName: homeTeamName,
            awayTeamId: awayTeamId,
            awayTeamName: awayTeamName,
            competitionId: competitionId,
            competitionName: competitionName,
            status: status,
            homeScore: homeScore,
            awayScore: awayScore,
            startTime: startTime,
            venue: venue,
            metadata: metadata,
            sourceId: sourceId,
            cachedAt: cachedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SportsEventsTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SportsEventsTableTable,
    SportsEventsTableData,
    $$SportsEventsTableTableFilterComposer,
    $$SportsEventsTableTableOrderingComposer,
    $$SportsEventsTableTableAnnotationComposer,
    $$SportsEventsTableTableCreateCompanionBuilder,
    $$SportsEventsTableTableUpdateCompanionBuilder,
    (
      SportsEventsTableData,
      BaseReferences<_$AppDatabase, $SportsEventsTableTable,
          SportsEventsTableData>
    ),
    SportsEventsTableData,
    PrefetchHooks Function()>;
typedef $$ResumePointsTableTableCreateCompanionBuilder
    = ResumePointsTableCompanion Function({
  required String id,
  required String contentType,
  required String title,
  required String streamUrl,
  required int positionSeconds,
  Value<int?> durationSeconds,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$ResumePointsTableTableUpdateCompanionBuilder
    = ResumePointsTableCompanion Function({
  Value<String> id,
  Value<String> contentType,
  Value<String> title,
  Value<String> streamUrl,
  Value<int> positionSeconds,
  Value<int?> durationSeconds,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$ResumePointsTableTableFilterComposer
    extends Composer<_$AppDatabase, $ResumePointsTableTable> {
  $$ResumePointsTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get contentType => $composableBuilder(
      column: $table.contentType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get streamUrl => $composableBuilder(
      column: $table.streamUrl, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get positionSeconds => $composableBuilder(
      column: $table.positionSeconds,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get durationSeconds => $composableBuilder(
      column: $table.durationSeconds,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$ResumePointsTableTableOrderingComposer
    extends Composer<_$AppDatabase, $ResumePointsTableTable> {
  $$ResumePointsTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get contentType => $composableBuilder(
      column: $table.contentType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get title => $composableBuilder(
      column: $table.title, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get streamUrl => $composableBuilder(
      column: $table.streamUrl, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get positionSeconds => $composableBuilder(
      column: $table.positionSeconds,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get durationSeconds => $composableBuilder(
      column: $table.durationSeconds,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$ResumePointsTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $ResumePointsTableTable> {
  $$ResumePointsTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get contentType => $composableBuilder(
      column: $table.contentType, builder: (column) => column);

  GeneratedColumn<String> get title =>
      $composableBuilder(column: $table.title, builder: (column) => column);

  GeneratedColumn<String> get streamUrl =>
      $composableBuilder(column: $table.streamUrl, builder: (column) => column);

  GeneratedColumn<int> get positionSeconds => $composableBuilder(
      column: $table.positionSeconds, builder: (column) => column);

  GeneratedColumn<int> get durationSeconds => $composableBuilder(
      column: $table.durationSeconds, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$ResumePointsTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ResumePointsTableTable,
    ResumePointsTableData,
    $$ResumePointsTableTableFilterComposer,
    $$ResumePointsTableTableOrderingComposer,
    $$ResumePointsTableTableAnnotationComposer,
    $$ResumePointsTableTableCreateCompanionBuilder,
    $$ResumePointsTableTableUpdateCompanionBuilder,
    (
      ResumePointsTableData,
      BaseReferences<_$AppDatabase, $ResumePointsTableTable,
          ResumePointsTableData>
    ),
    ResumePointsTableData,
    PrefetchHooks Function()> {
  $$ResumePointsTableTableTableManager(
      _$AppDatabase db, $ResumePointsTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ResumePointsTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ResumePointsTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ResumePointsTableTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> contentType = const Value.absent(),
            Value<String> title = const Value.absent(),
            Value<String> streamUrl = const Value.absent(),
            Value<int> positionSeconds = const Value.absent(),
            Value<int?> durationSeconds = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ResumePointsTableCompanion(
            id: id,
            contentType: contentType,
            title: title,
            streamUrl: streamUrl,
            positionSeconds: positionSeconds,
            durationSeconds: durationSeconds,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String contentType,
            required String title,
            required String streamUrl,
            required int positionSeconds,
            Value<int?> durationSeconds = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              ResumePointsTableCompanion.insert(
            id: id,
            contentType: contentType,
            title: title,
            streamUrl: streamUrl,
            positionSeconds: positionSeconds,
            durationSeconds: durationSeconds,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ResumePointsTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ResumePointsTableTable,
    ResumePointsTableData,
    $$ResumePointsTableTableFilterComposer,
    $$ResumePointsTableTableOrderingComposer,
    $$ResumePointsTableTableAnnotationComposer,
    $$ResumePointsTableTableCreateCompanionBuilder,
    $$ResumePointsTableTableUpdateCompanionBuilder,
    (
      ResumePointsTableData,
      BaseReferences<_$AppDatabase, $ResumePointsTableTable,
          ResumePointsTableData>
    ),
    ResumePointsTableData,
    PrefetchHooks Function()>;
typedef $$SettingsTableTableCreateCompanionBuilder = SettingsTableCompanion
    Function({
  required String key,
  required String value,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});
typedef $$SettingsTableTableUpdateCompanionBuilder = SettingsTableCompanion
    Function({
  Value<String> key,
  Value<String> value,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$SettingsTableTableFilterComposer
    extends Composer<_$AppDatabase, $SettingsTableTable> {
  $$SettingsTableTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$SettingsTableTableOrderingComposer
    extends Composer<_$AppDatabase, $SettingsTableTable> {
  $$SettingsTableTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$SettingsTableTableAnnotationComposer
    extends Composer<_$AppDatabase, $SettingsTableTable> {
  $$SettingsTableTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get key =>
      $composableBuilder(column: $table.key, builder: (column) => column);

  GeneratedColumn<String> get value =>
      $composableBuilder(column: $table.value, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$SettingsTableTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SettingsTableTable,
    SettingsTableData,
    $$SettingsTableTableFilterComposer,
    $$SettingsTableTableOrderingComposer,
    $$SettingsTableTableAnnotationComposer,
    $$SettingsTableTableCreateCompanionBuilder,
    $$SettingsTableTableUpdateCompanionBuilder,
    (
      SettingsTableData,
      BaseReferences<_$AppDatabase, $SettingsTableTable, SettingsTableData>
    ),
    SettingsTableData,
    PrefetchHooks Function()> {
  $$SettingsTableTableTableManager(_$AppDatabase db, $SettingsTableTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SettingsTableTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SettingsTableTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SettingsTableTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> key = const Value.absent(),
            Value<String> value = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SettingsTableCompanion(
            key: key,
            value: value,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String key,
            required String value,
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SettingsTableCompanion.insert(
            key: key,
            value: value,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SettingsTableTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SettingsTableTable,
    SettingsTableData,
    $$SettingsTableTableFilterComposer,
    $$SettingsTableTableOrderingComposer,
    $$SettingsTableTableAnnotationComposer,
    $$SettingsTableTableCreateCompanionBuilder,
    $$SettingsTableTableUpdateCompanionBuilder,
    (
      SettingsTableData,
      BaseReferences<_$AppDatabase, $SettingsTableTable, SettingsTableData>
    ),
    SettingsTableData,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$ChannelsTableTableTableManager get channelsTable =>
      $$ChannelsTableTableTableManager(_db, _db.channelsTable);
  $$PlaylistSourcesTableTableTableManager get playlistSourcesTable =>
      $$PlaylistSourcesTableTableTableManager(_db, _db.playlistSourcesTable);
  $$EpgProgrammesTableTableTableManager get epgProgrammesTable =>
      $$EpgProgrammesTableTableTableManager(_db, _db.epgProgrammesTable);
  $$EpgSourcesTableTableTableManager get epgSourcesTable =>
      $$EpgSourcesTableTableTableManager(_db, _db.epgSourcesTable);
  $$EpgChannelsTableTableTableManager get epgChannelsTable =>
      $$EpgChannelsTableTableTableManager(_db, _db.epgChannelsTable);
  $$EpgChannelMappingsTableTableTableManager get epgChannelMappingsTable =>
      $$EpgChannelMappingsTableTableTableManager(
          _db, _db.epgChannelMappingsTable);
  $$FavoritesTableTableTableManager get favoritesTable =>
      $$FavoritesTableTableTableManager(_db, _db.favoritesTable);
  $$WatchHistoryTableTableTableManager get watchHistoryTable =>
      $$WatchHistoryTableTableTableManager(_db, _db.watchHistoryTable);
  $$RemindersTableTableTableManager get remindersTable =>
      $$RemindersTableTableTableManager(_db, _db.remindersTable);
  $$SportsEventsTableTableTableManager get sportsEventsTable =>
      $$SportsEventsTableTableTableManager(_db, _db.sportsEventsTable);
  $$ResumePointsTableTableTableManager get resumePointsTable =>
      $$ResumePointsTableTableTableManager(_db, _db.resumePointsTable);
  $$SettingsTableTableTableManager get settingsTable =>
      $$SettingsTableTableTableManager(_db, _db.settingsTable);
}

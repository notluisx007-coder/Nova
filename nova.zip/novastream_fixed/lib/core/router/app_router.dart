import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../features/epg/presentation/epg_screen.dart';
import '../../features/favorites/presentation/favorites_screen.dart';
import '../../features/home/presentation/home_screen.dart';
import '../../features/live_tv/presentation/channel_detail_screen.dart';
import '../../features/live_tv/presentation/live_tv_screen.dart';
import '../../features/onboarding/presentation/onboarding_screen.dart';
import '../../features/onboarding/presentation/splash_screen.dart';
import '../../features/player/presentation/player_screen.dart';
import '../../features/search/presentation/search_screen.dart';
import '../../features/settings/presentation/settings_screen.dart';
import '../../features/sources/presentation/add_source_screen.dart';
import '../../features/sources/presentation/sources_screen.dart';
import '../../features/sports/presentation/competition_detail_screen.dart';
import '../../features/sports/presentation/match_detail_screen.dart';
import '../../features/sports/presentation/sports_category_screen.dart';
import '../../features/sports/presentation/sports_screen.dart';
import '../../features/sports/presentation/team_detail_screen.dart';
import '../../shared/widgets/main_scaffold.dart';

part 'app_router.g.dart';

class AppRoutes {
  static const splash = '/splash';
  static const onboarding = '/onboarding';
  static const home = '/';
  static const liveTV = '/live-tv';
  static const channelDetail = '/live-tv/channel/:id';
  static const sports = '/sports';
  static const sportsCategory = '/sports/category/:sport';
  static const matchDetail = '/sports/match/:id';
  static const teamDetail = '/sports/team/:id';
  static const competitionDetail = '/sports/competition/:id';
  static const epg = '/epg';
  static const favorites = '/favorites';
  static const search = '/search';
  static const sources = '/sources';
  static const addSource = '/sources/add';
  static const player = '/player';
  static const settings = '/settings';
}

@riverpod
GoRouter appRouter(AppRouterRef ref) {
  return GoRouter(
    initialLocation: AppRoutes.splash,
    routes: [
      GoRoute(
        path: AppRoutes.splash,
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: AppRoutes.onboarding,
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: AppRoutes.player,
        builder: (context, state) {
          final extra = state.extra;
          return PlayerScreen(
            args: PlayerArgs.fromExtra(
              extra is Map<String, dynamic> ? extra : const {},
            ),
          );
        },
      ),
      ShellRoute(
        builder: (context, state, child) => MainScaffold(child: child),
        routes: [
          GoRoute(
            path: AppRoutes.home,
            builder: (context, state) => const HomeScreen(),
          ),
          GoRoute(
            path: AppRoutes.liveTV,
            builder: (context, state) => const LiveTvScreen(),
            routes: [
              GoRoute(
                path: 'channel/:id',
                builder: (context, state) => ChannelDetailScreen(
                  channelId: state.pathParameters['id'] ?? '',
                ),
              ),
            ],
          ),
          GoRoute(
            path: AppRoutes.sports,
            builder: (context, state) => const SportsScreen(),
            routes: [
              GoRoute(
                path: 'category/:sport',
                builder: (context, state) => SportsCategoryScreen(
                  sport: state.pathParameters['sport'] ?? '',
                ),
              ),
              GoRoute(
                path: 'match/:id',
                builder: (context, state) => MatchDetailScreen(
                  matchId: state.pathParameters['id'] ?? '',
                ),
              ),
              GoRoute(
                path: 'team/:id',
                builder: (context, state) => TeamDetailScreen(
                  teamId: state.pathParameters['id'] ?? '',
                ),
              ),
              GoRoute(
                path: 'competition/:id',
                builder: (context, state) => CompetitionDetailScreen(
                  competitionId: state.pathParameters['id'] ?? '',
                ),
              ),
            ],
          ),
          GoRoute(
            path: AppRoutes.epg,
            builder: (context, state) => const EpgScreen(),
          ),
          GoRoute(
            path: AppRoutes.favorites,
            builder: (context, state) => const FavoritesScreen(),
          ),
          GoRoute(
            path: AppRoutes.search,
            builder: (context, state) => const SearchScreen(),
          ),
          GoRoute(
            path: AppRoutes.sources,
            builder: (context, state) => const SourcesScreen(),
            routes: [
              GoRoute(
                path: 'add',
                builder: (context, state) => const AddSourceScreen(),
              ),
            ],
          ),
          GoRoute(
            path: AppRoutes.settings,
            builder: (context, state) => const SettingsScreen(),
          ),
        ],
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      backgroundColor: const Color(0xFF050A14),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, color: Color(0xFF00D4FF), size: 48),
            const SizedBox(height: 16),
            Text('Page not found',
                style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => context.go(AppRoutes.home),
              child: const Text('Go Home'),
            ),
          ],
        ),
      ),
    ),
  );
}

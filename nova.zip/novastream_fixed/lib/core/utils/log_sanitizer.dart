/// Redacts secrets and private material from anything that could reach logs,
/// crash reports or exported diagnostics.
///
/// Redacted categories:
///   * passwords/tokens/keys in `key=value` shapes
///   * URLs carrying userinfo (`user:pass@host`)
///   * URLs containing password/token/query credentials (Xtream style)
///   * long hex/base64 blobs that look like API keys
library;

class LogSanitizer {
  LogSanitizer._();

  static final _sensitiveKeys = RegExp(
    r'(password|passwd|pwd|token|api[_-]?key|apikey|secret|authorization|auth|credentials|session)',
    caseSensitive: false,
  );

  static final _keyValue = RegExp(
    r"""(['"]?)(password|passwd|pwd|token|api[_-]?key|apikey|secret|authorization|auth)\1?(\s*[:=]\s*)([^\s,;&'"]+)""",
    caseSensitive: false,
  );

  /// The first word after `Authorization:` is redacted by [_keyValue], but
  /// the actual credential follows it (`Bearer <jwt>`, `Basic <base64>`) —
  /// this catches that token too.
  static final _bearerSchemeToken = RegExp(
    r'\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{8,}',
    caseSensitive: false,
  );

  static final _userInfoInUrl = RegExp(
    r'(https?|rtmp|rtmps|rtsp)://[^\s/@:]+:[^\s/@]+@',
    caseSensitive: false,
  );

  static final _xtreamCredQuery = RegExp(
    r'([?&])(username|password)=[^&\s]+',
    caseSensitive: false,
  );

  static final _authHeaderCredential = RegExp(
    r'(authorization|auth)(\s*[:=]\s*)(\S+)(\s+\S+)?',
    caseSensitive: false,
  );

  static final _hexKeyBlob = RegExp(r'\b[0-9a-fA-F]{32,}\b');

  static final _base64Blob = RegExp(r'\b[A-Za-z0-9+/=]{40,}\b');

  /// Returns [input] with every recognised secret replaced by `[REDACTED]`.
  static String sanitize(String input) {
    var out = input;

    // Redact the ENTIRE credential of an Authorization/auth header first —
    // the value may be "Bearer <token>" / "Basic <b64>" with a space inside,
    // which the single-token keyValue rule cannot cover.
    out = out.replaceAllMapped(_authHeaderCredential, (m) {
      return '${m.group(1)}${m.group(2)}[REDACTED]';
    });

    out = out.replaceAllMapped(_keyValue, (m) {
      final prefix = m.group(1) ?? '';
      final key = m.group(2)!;
      final sep = m.group(3)!;
      return '$prefix$key$sep[REDACTED]';
    });

    out = out.replaceAllMapped(_bearerSchemeToken, (m) {
      return '${m.group(1)} [REDACTED]';
    });

    out = out.replaceAllMapped(_userInfoInUrl, (m) {
      final scheme = m.group(1)!;
      return '$scheme://[REDACTED]@';
    });

    out = out.replaceAllMapped(_xtreamCredQuery, (m) {
      return '${m.group(1)}${m.group(2)}=[REDACTED]';
    });

    out = out.replaceAllMapped(_hexKeyBlob, (_) => '[REDACTED]');
    out = out.replaceAllMapped(_base64Blob, (_) => '[REDACTED]');

    return out;
  }

  /// True when [input] contains anything the sanitizer would redact.
  static bool containsSensitive(String input) =>
      sanitize(input) != input || _sensitiveKeys.hasMatch(input);

  /// Builds a safe, human-readable stream description for logs/UI:
  /// scheme + host only, never the path, query or credentials.
  static String describeStreamUrl(String url) {
    try {
      final uri = Uri.parse(url);
      final host = uri.host.isEmpty ? '<no-host>' : uri.host;
      return '${uri.scheme}://$host';
    } catch (_) {
      return '<invalid-url>';
    }
  }
}

Future<void> configureDependencies() async {
  // Initialization logic handled by Riverpod providers
  // Database, repositories, and services are lazily initialized
}

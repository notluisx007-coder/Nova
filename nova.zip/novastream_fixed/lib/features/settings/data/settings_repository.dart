import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:shared_preferences/shared_preferences.dart';

part 'settings_repository.g.dart';

class SettingsKeys {
  static const themeMode = 'theme_mode';
  static const hasCompletedOnboarding = 'has_completed_onboarding';
  static const wifiOnlyRefresh = 'wifi_only_refresh';
  static const autoRefreshEnabled = 'auto_refresh_enabled';
  static const refreshIntervalHours = 'refresh_interval_hours';
  static const dataSaverMode = 'data_saver_mode';
  // NOTE: there is deliberately NO provider API key stored in the app.
  // Provider keys live only on the NovaStream backend (see backend/README).
  static const sportsBackendUrl = 'sports_backend_url';
  static const defaultPlayerQuality = 'default_player_quality';
  static const enableSubtitles = 'enable_subtitles';
  static const bufferDurationSeconds = 'buffer_duration_seconds';
  static const notificationsEnabled = 'notifications_enabled';
  static const matchReminderMinutes = 'match_reminder_minutes';
  static const privacyAnalyticsEnabled = 'privacy_analytics_enabled';
}

@riverpod
Future<SharedPreferences> sharedPreferences(SharedPreferencesRef ref) async {
  return SharedPreferences.getInstance();
}

@riverpod
class SettingsRepository extends _$SettingsRepository {
  @override
  Future<Map<String, dynamic>> build() async {
    final prefs = await ref.watch(sharedPreferencesProvider.future);
    return _loadAll(prefs);
  }

  Map<String, dynamic> _loadAll(SharedPreferences prefs) {
    return {
      SettingsKeys.themeMode: prefs.getString(SettingsKeys.themeMode) ?? 'dark',
      SettingsKeys.hasCompletedOnboarding:
          prefs.getBool(SettingsKeys.hasCompletedOnboarding) ?? false,
      SettingsKeys.wifiOnlyRefresh:
          prefs.getBool(SettingsKeys.wifiOnlyRefresh) ?? false,
      SettingsKeys.autoRefreshEnabled:
          prefs.getBool(SettingsKeys.autoRefreshEnabled) ?? true,
      SettingsKeys.refreshIntervalHours:
          prefs.getInt(SettingsKeys.refreshIntervalHours) ?? 6,
      SettingsKeys.dataSaverMode:
          prefs.getBool(SettingsKeys.dataSaverMode) ?? false,
      SettingsKeys.defaultPlayerQuality:
          prefs.getString(SettingsKeys.defaultPlayerQuality) ?? 'auto',
      SettingsKeys.enableSubtitles:
          prefs.getBool(SettingsKeys.enableSubtitles) ?? true,
      SettingsKeys.bufferDurationSeconds:
          prefs.getInt(SettingsKeys.bufferDurationSeconds) ?? 15,
      SettingsKeys.notificationsEnabled:
          prefs.getBool(SettingsKeys.notificationsEnabled) ?? true,
      SettingsKeys.matchReminderMinutes:
          prefs.getInt(SettingsKeys.matchReminderMinutes) ?? 15,
      SettingsKeys.privacyAnalyticsEnabled:
          prefs.getBool(SettingsKeys.privacyAnalyticsEnabled) ?? false,
    };
  }

  Future<void> set(String key, dynamic value) async {
    final prefs = await ref.read(sharedPreferencesProvider.future);
    if (value is String) await prefs.setString(key, value);
    if (value is bool) await prefs.setBool(key, value);
    if (value is int) await prefs.setInt(key, value);
    if (value is double) await prefs.setDouble(key, value);
    ref.invalidateSelf();
  }
}

// Theme mode provider
@riverpod
ThemeMode themeMode(ThemeModeRef ref) {
  final settings = ref.watch(settingsRepositoryProvider);
  final mode =
      settings.valueOrNull?[SettingsKeys.themeMode] as String? ?? 'dark';
  return switch (mode) {
    'light' => ThemeMode.light,
    'system' => ThemeMode.system,
    _ => ThemeMode.dark,
  };
}

// Onboarding state
@riverpod
bool hasCompletedOnboarding(HasCompletedOnboardingRef ref) {
  final settings = ref.watch(settingsRepositoryProvider);
  return settings.valueOrNull?[SettingsKeys.hasCompletedOnboarding] as bool? ??
      false;
}

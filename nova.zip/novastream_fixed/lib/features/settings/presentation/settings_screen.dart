import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../../core/database/app_database.dart';
import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../sports/data/sports_repository.dart';
import '../data/settings_repository.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsRepositoryProvider);

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceBackground,
        surfaceTintColor: Colors.transparent,
        title: const Text(
          'Settings',
          style: TextStyle(
              color: AppTheme.textPrimary,
              fontWeight: FontWeight.w700,
              fontFamily: 'Inter'),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0.5),
          child: Container(height: 0.5, color: AppTheme.surfaceBorder),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ---- Live TV ----
          const _SectionHeader(title: 'Live TV'),
          _SettingsTile(
            icon: Icons.playlist_play_rounded,
            title: 'Sources & Playlists',
            subtitle: 'Manage M3U providers',
            onTap: () => context.go(AppRoutes.sources),
          ),
          _SettingsTile(
            icon: Icons.calendar_today_rounded,
            title: 'TV Guide (EPG)',
            subtitle: 'Configure Electronic Programme Guide',
            onTap: () => context.go(AppRoutes.epg),
          ),
          const SizedBox(height: 20),

          // ---- Sports ----
          const _SectionHeader(title: 'Sports'),
          const _SportStatusTile(),
          const _BackendUrlTile(),
          const SizedBox(height: 20),

          // ---- Player ----
          const _SectionHeader(title: 'Player'),
          settings.when(
            data: (s) => Column(
              children: [
                _SwitchTile(
                  icon: Icons.closed_caption_rounded,
                  title: 'Enable Subtitles',
                  value: s[SettingsKeys.enableSubtitles] as bool? ?? true,
                  onChanged: (v) => ref
                      .read(settingsRepositoryProvider.notifier)
                      .set(SettingsKeys.enableSubtitles, v),
                ),
                _SwitchTile(
                  icon: Icons.data_saver_on_rounded,
                  title: 'Data Saver Mode',
                  subtitle: 'Reduce background data usage',
                  value: s[SettingsKeys.dataSaverMode] as bool? ?? false,
                  onChanged: (v) => ref
                      .read(settingsRepositoryProvider.notifier)
                      .set(SettingsKeys.dataSaverMode, v),
                ),
              ],
            ),
            loading: () => const SizedBox(),
            error: (_, __) => const SizedBox(),
          ),
          const SizedBox(height: 20),

          // ---- Notifications ----
          const _SectionHeader(title: 'Notifications'),
          settings.when(
            data: (s) => _SwitchTile(
              icon: Icons.notifications_rounded,
              title: 'Match Reminders',
              value: s[SettingsKeys.notificationsEnabled] as bool? ?? true,
              onChanged: (v) => ref
                  .read(settingsRepositoryProvider.notifier)
                  .set(SettingsKeys.notificationsEnabled, v),
            ),
            loading: () => const SizedBox(),
            error: (_, __) => const SizedBox(),
          ),
          const SizedBox(height: 20),

          // ---- Privacy & Storage ----
          const _SectionHeader(title: 'Privacy & Storage'),
          _SettingsTile(
            icon: Icons.delete_outline_rounded,
            title: 'Clear Watch History',
            subtitle: 'Remove recently watched channels',
            onTap: () => _clearHistory(context, ref),
          ),
          _SettingsTile(
            icon: Icons.storage_rounded,
            title: 'Clear Sports Cache',
            subtitle: 'Remove cached sports event data',
            onTap: () => _clearSportsCache(context, ref),
          ),
          const SizedBox(height: 20),

          // ---- Appearance ----
          const _SectionHeader(title: 'Appearance'),
          settings.when(
            data: (s) => _DropdownTile<String>(
              icon: Icons.dark_mode_rounded,
              title: 'Theme',
              value: s[SettingsKeys.themeMode] as String? ?? 'dark',
              items: const [
                DropdownMenuItem(value: 'dark', child: Text('Dark')),
                DropdownMenuItem(value: 'light', child: Text('Light')),
                DropdownMenuItem(value: 'system', child: Text('System')),
              ],
              onChanged: (v) {
                if (v != null) {
                  ref
                      .read(settingsRepositoryProvider.notifier)
                      .set(SettingsKeys.themeMode, v);
                }
              },
            ),
            loading: () => const SizedBox(),
            error: (_, __) => const SizedBox(),
          ),
          const SizedBox(height: 20),

          // ---- About ----
          const _SectionHeader(title: 'About'),
          const _AppVersionTile(),
          const SizedBox(height: 40),
        ],
      ),
    );
  }

  void _clearHistory(BuildContext context, WidgetRef ref) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surfaceCard,
        title: const Text('Clear Watch History',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text('This will remove your recently watched channels.',
            style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await ref.read(appDatabaseProvider).clearWatchHistory();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Watch history cleared')));
              }
            },
            child: const Text('Clear',
                style: TextStyle(color: AppTheme.statusError)),
          ),
        ],
      ),
    );
  }

  void _clearSportsCache(BuildContext context, WidgetRef ref) {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppTheme.surfaceCard,
        title: const Text('Clear Sports Cache',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text(
            'Cached sports event data will be removed. Live data will re-appear after the next refresh.',
            style: TextStyle(color: AppTheme.textSecondary)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await ref.read(appDatabaseProvider).clearStaleSportsEvents();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Sports cache cleared')));
              }
            },
            child: const Text('Clear',
                style: TextStyle(color: AppTheme.statusError)),
          ),
        ],
      ),
    );
  }
}

class _SportStatusTile extends ConsumerWidget {
  const _SportStatusTile();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = ref.watch(sportsBackendStatusProvider);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.surfaceBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.sports_soccer_rounded,
                  color: AppTheme.accentViolet, size: 20),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Sports API Status',
                  style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Inter'),
                ),
              ),
              status.when(
                data: (s) => Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: s.isReachable
                        ? AppTheme.statusLive
                        : AppTheme.statusError,
                  ),
                ),
                loading: () => const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2)),
                error: (_, __) => const Icon(Icons.error_outline,
                    size: 16, color: AppTheme.statusError),
              ),
            ],
          ),
          const SizedBox(height: 8),
          status.when(
            data: (s) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  s.isReachable
                      ? 'Backend reachable${s.backendVersion != null ? " — v${s.backendVersion}" : ""}'
                      : (s.message ?? 'Backend unreachable'),
                  style: TextStyle(
                      color: s.isReachable
                          ? AppTheme.textSecondary
                          : AppTheme.statusError,
                      fontSize: 12),
                ),
                if (s.sportsAvailable != null) ...[
                  const SizedBox(height: 4),
                  Text(
                    'Sports: ${s.sportsAvailable!.join(", ")}',
                    style: const TextStyle(
                        color: AppTheme.textSecondary, fontSize: 11),
                  ),
                ],
              ],
            ),
            loading: () => const Text('Checking backend…',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
            error: (e, _) => Text('Error: $e',
                style:
                    const TextStyle(color: AppTheme.statusError, fontSize: 12)),
          ),
          const SizedBox(height: 8),
          const Text(
            'The sports API key is managed securely on the NovaStream backend. '
            'It is never stored in the app.',
            style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 11,
                fontStyle: FontStyle.italic),
          ),
        ],
      ),
    );
  }
}

/// Editable HTTPS backend URL. Provider API keys never belong in the app —
/// only the backend base URL is configured here.
class _BackendUrlTile extends ConsumerStatefulWidget {
  const _BackendUrlTile();

  @override
  ConsumerState<_BackendUrlTile> createState() => _BackendUrlTileState();
}

class _BackendUrlTileState extends ConsumerState<_BackendUrlTile> {
  @override
  Widget build(BuildContext context) {
    final urlAsync = ref.watch(sportsBackendUrlProvider);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surfaceCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.surfaceBorder),
      ),
      child: Row(
        children: [
          const Icon(Icons.dns_rounded, color: AppTheme.primaryCyan, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Sports Backend URL',
                    style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter')),
                Text(
                  urlAsync.asData?.value ?? 'Not configured (HTTPS required)',
                  style: const TextStyle(
                      color: AppTheme.textSecondary, fontSize: 12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: () => _editUrl(context, ref),
            child: const Text('Edit'),
          ),
        ],
      ),
    );
  }

  Future<void> _editUrl(BuildContext context, WidgetRef ref) async {
    final controller = TextEditingController(
        text: ref.read(sportsBackendUrlProvider).valueOrNull ?? '');
    final saved = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surfaceCard,
        title: const Text('Sports backend URL',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(
              controller: controller,
              keyboardType: TextInputType.url,
              autocorrect: false,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 13),
              decoration: const InputDecoration(
                hintText: 'https://my-backend.example.com/sports/v1',
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Must be HTTPS. The backend holds the sports provider key; the '
              'app never stores provider credentials.',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 11),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (saved != true) return;
    final prefs = await ref.read(sharedPreferencesProvider.future);
    final url = controller.text.trim();
    if (url.isEmpty) {
      await prefs.remove(SettingsKeys.sportsBackendUrl);
    } else {
      final uri = Uri.tryParse(url);
      if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text(
                  'Invalid URL — must be a valid https:// address. Not saved.')));
        }
        return;
      }
      await prefs.setString(SettingsKeys.sportsBackendUrl, url);
    }
    ref.invalidate(sportsBackendUrlProvider);
    ref.invalidate(sportsBackendStatusProvider);
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Sports backend URL updated')));
    }
  }
}

class _AppVersionTile extends StatelessWidget {
  const _AppVersionTile();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<PackageInfo>(
      future: PackageInfo.fromPlatform(),
      builder: (_, snap) {
        final version = snap.data?.version ?? '—';
        final build = snap.data?.buildNumber ?? '—';
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.surfaceCard,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppTheme.surfaceBorder),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  'assets/images/app_icon.png',
                  width: 36,
                  height: 36,
                  errorBuilder: (_, __, ___) => const Icon(Icons.tv_rounded,
                      color: AppTheme.primaryCyan, size: 36),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'NovaStream',
                      style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter'),
                    ),
                    Text(
                      'Version $version ($build)',
                      style: const TextStyle(
                          color: AppTheme.textSecondary, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ---- Reusable setting tiles ----

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Text(
        title,
        style: const TextStyle(
          color: AppTheme.primaryCyan,
          fontSize: 12,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.0,
          fontFamily: 'Inter',
        ),
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback? onTap;
  const _SettingsTile(
      {required this.icon, required this.title, this.subtitle, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: title,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.surfaceCard,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: AppTheme.surfaceBorder),
          ),
          child: Row(
            children: [
              Icon(icon, color: AppTheme.primaryCyan, size: 20),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontWeight: FontWeight.w500,
                            fontFamily: 'Inter')),
                    if (subtitle != null)
                      Text(subtitle!,
                          style: const TextStyle(
                              color: AppTheme.textSecondary, fontSize: 12)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded,
                  color: AppTheme.textSecondary, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

class _SwitchTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchTile(
      {required this.icon,
      required this.title,
      this.subtitle,
      required this.value,
      required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.surfaceCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.surfaceBorder),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppTheme.primaryCyan, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter')),
                if (subtitle != null)
                  Text(subtitle!,
                      style: const TextStyle(
                          color: AppTheme.textSecondary, fontSize: 12)),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: AppTheme.primaryCyan,
          ),
        ],
      ),
    );
  }
}

class _DropdownTile<T> extends StatelessWidget {
  final IconData icon;
  final String title;
  final T value;
  final List<DropdownMenuItem<T>> items;
  final ValueChanged<T?> onChanged;
  const _DropdownTile(
      {required this.icon,
      required this.title,
      required this.value,
      required this.items,
      required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppTheme.surfaceCard,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.surfaceBorder),
      ),
      child: Row(
        children: [
          Icon(icon, color: AppTheme.primaryCyan, size: 20),
          const SizedBox(width: 12),
          Expanded(
              child: Text(title,
                  style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Inter'))),
          DropdownButtonHideUnderline(
            child: DropdownButton<T>(
              value: value,
              items: items,
              onChanged: onChanged,
              dropdownColor: AppTheme.surfaceCard,
              style: const TextStyle(
                  color: AppTheme.textPrimary, fontFamily: 'Inter'),
            ),
          ),
        ],
      ),
    );
  }
}

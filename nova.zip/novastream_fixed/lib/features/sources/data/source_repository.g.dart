// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'source_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$sourcesHash() => r'535bb7b199de2aea49a5af36c5bfec3e168643eb';

/// See also [sources].
@ProviderFor(sources)
final sourcesProvider =
    AutoDisposeStreamProvider<List<PlaylistSource>>.internal(
  sources,
  name: r'sourcesProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$sourcesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef SourcesRef = AutoDisposeStreamProviderRef<List<PlaylistSource>>;
String _$sourceRepositoryHash() => r'132f4fe4dafbdebd8c716ff3c3ce536c8f5cb8e5';

/// See also [SourceRepository].
@ProviderFor(SourceRepository)
final sourceRepositoryProvider =
    AutoDisposeAsyncNotifierProvider<SourceRepository, void>.internal(
  SourceRepository.new,
  name: r'sourceRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sourceRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SourceRepository = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package

import 'dart:async';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:drift/drift.dart' hide isNull;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:uuid/uuid.dart';

import '../../../core/database/app_database.dart';
import '../../../shared/models/channel.dart';
import '../../live_tv/data/channel_repository.dart';
import 'm3u_parser.dart';

part 'source_repository.g.dart';

@riverpod
Stream<List<PlaylistSource>> sources(SourcesRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db.watchSources().map((rows) => rows.map(_sourceFromRow).toList());
}

/// Tracks which source IDs are currently being refreshed to prevent
/// concurrent refresh races on the same source. Guarded writes happen under
/// a single-threaded event loop, and the lock is ALWAYS released in the
/// `finally` block of [refreshSource] (success, error, cancellation).
final _refreshingSourceIds = <String>{};

/// Progress of an in-flight refresh keyed by source id (0.0 - 1.0).
final sourceRefreshProgressProvider =
    StateProvider<Map<String, double>>((ref) => {});

@riverpod
class SourceRepository extends _$SourceRepository {
  static const _uuid = Uuid();
  late final Dio _dio;

  @override
  Future<void> build() async {
    _dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 60),
      sendTimeout: const Duration(seconds: 15),
    ));
  }

  /// Whether a refresh for [sourceId] is currently running.
  bool isRefreshing(String sourceId) => _refreshingSourceIds.contains(sourceId);

  /// Add a new M3U URL source. The full playlist is downloaded, parsed and
  /// validated BEFORE any record is written; on any failure only a single
  /// error-status row remains (no partial channel import).
  Future<SourceAddResult> addM3uUrl({
    required String name,
    required String url,
  }) async {
    final uri = _validateSourceUrl(url);
    if (uri == null) {
      return SourceAddResult.error('Invalid URL. Must be http:// or https://');
    }

    final id = _uuid.v4();
    final db = ref.read(appDatabaseProvider);

    await db.upsertSource(PlaylistSourcesTableCompanion(
      id: Value(id),
      name: Value(name),
      type: const Value('m3u_url'),
      url: Value(url),
      status: const Value('connecting'),
    ));

    try {
      // 1. Download fully.
      final content = await _fetchUrl(url);
      // 2. Parse and validate fully — nothing is persisted yet.
      final result = await M3UParser.parse(content);
      if (result.validCount == 0) {
        final reason = result.errors.isNotEmpty
            ? result.errors.first
            : 'No valid channels found';
        await _markSourceError(db, id, name, 'm3u_url', url, reason);
        return SourceAddResult.error(reason);
      }

      // 3. Transactionally import the validated channel set.
      final importResult = await ref
          .read(channelRepositoryProvider.notifier)
          .importFromM3UContent(content, id);

      await db.upsertSource(PlaylistSourcesTableCompanion(
        id: Value(id),
        name: Value(name),
        type: const Value('m3u_url'),
        url: Value(url),
        channelCount: Value(importResult.total),
        status: const Value('active'),
        lastRefresh: Value(DateTime.now()),
        lastSuccess: Value(DateTime.now()),
        lastError: const Value(null),
      ));

      return SourceAddResult.success(id, importResult.total);
    } catch (e) {
      await _markSourceError(db, id, name, 'm3u_url', url, _summarise(e));
      return SourceAddResult.error(_summarise(e));
    }
  }

  /// Add a local M3U file source. Same validate-before-write behaviour.
  Future<SourceAddResult> addM3uFile({
    required String name,
    required String filePath,
  }) async {
    final id = _uuid.v4();
    final db = ref.read(appDatabaseProvider);

    try {
      final file = File(filePath);
      if (!file.existsSync()) {
        return SourceAddResult.error('File not found: $filePath');
      }

      final content = await file.readAsString();
      final result = await M3UParser.parse(content);

      if (result.validCount == 0) {
        final reason = result.errors.isNotEmpty
            ? result.errors.first
            : 'No valid channels found in file';
        return SourceAddResult.error(reason);
      }

      await db.upsertSource(PlaylistSourcesTableCompanion(
        id: Value(id),
        name: Value(name),
        type: const Value('m3u_file'),
        filePath: Value(filePath),
        status: const Value('active'),
        lastRefresh: Value(DateTime.now()),
        lastSuccess: Value(DateTime.now()),
      ));

      final importResult = await ref
          .read(channelRepositoryProvider.notifier)
          .importFromM3UContent(content, id);

      await db.upsertSource(PlaylistSourcesTableCompanion(
        id: Value(id),
        name: Value(name),
        type: const Value('m3u_file'),
        filePath: Value(filePath),
        channelCount: Value(importResult.total),
        status: const Value('active'),
        lastRefresh: Value(DateTime.now()),
        lastSuccess: Value(DateTime.now()),
      ));

      return SourceAddResult.success(id, importResult.total);
    } catch (e) {
      return SourceAddResult.error(_summarise(e));
    }
  }

  /// Refresh an existing source:
  ///
  /// * Only one refresh per source id can run at a time; the guard is
  ///   released in every path (success / error / cancellation) via finally.
  /// * The new playlist is downloaded AND parsed AND validated before any
  ///   database mutation. If the download fails, the parse fails, or the
  ///   validated result is empty for a source that previously had channels,
  ///   the previous good data is kept untouched and the failure is recorded.
  /// * The channel set is replaced inside one transaction (see
  ///   [ChannelRepository.importFromM3UContent]) which preserves favorites,
  ///   hidden state, custom ordering and watch timestamps, and removes
  ///   channels that no longer exist in the new playlist.
  Future<SourceRefreshResult> refreshSource(String sourceId) async {
    // Acquire the per-source lock synchronously, BEFORE any await: the
    // single-threaded event loop guarantees that a second overlapping call
    // observes the lock and bails out (a TOCTOU gap existed when the lock
    // was taken after awaiting the source lookup).
    if (_refreshingSourceIds.contains(sourceId)) {
      return SourceRefreshResult.error('Refresh already in progress');
    }
    _refreshingSourceIds.add(sourceId);

    try {
      final db = ref.read(appDatabaseProvider);
      final source = await db.getSource(sourceId);
      if (source == null) {
        return SourceRefreshResult.error('Source not found');
      }

      if (source.type != 'm3u_url' || source.url == null) {
        if (source.type == 'm3u_file' && source.filePath != null) {
          return await _refreshFileSource(db, source);
        }
        return SourceRefreshResult.error(
            'Cannot refresh this source type (${source.type})');
      }

      _setProgress(sourceId, 0.0);

      await db.upsertSource(PlaylistSourcesTableCompanion(
        id: Value(sourceId),
        name: Value(source.name),
        type: Value(source.type),
        url: Value(source.url),
        status: const Value('refreshing'),
        // Preserve last-success fields during refresh
        lastSuccess: Value(source.lastSuccess),
      ));

      // 1. Download.
      _setProgress(sourceId, 0.1);
      final content = await _fetchUrl(source.url!);
      _setProgress(sourceId, 0.5);

      // 2. Parse + validate BEFORE touching existing rows.
      final result = await M3UParser.parse(content);
      final previousChannels = await (db.select(db.channelsTable)
            ..where((t) => t.sourceId.equals(sourceId)))
          .get();
      final suspiciousReason = _playlistSuspicion(result,
          previousCount: previousChannels.length);
      if (suspiciousReason != null) {
        await _markRefreshError(db, source, suspiciousReason);
        return SourceRefreshResult.error(suspiciousReason);
      }
      _setProgress(sourceId, 0.7);

      // 3. Transactional replace (inserts + updates + removals).
      final importResult = await ref
          .read(channelRepositoryProvider.notifier)
          .importFromM3UContent(content, sourceId);
      _setProgress(sourceId, 1.0);

      await db.upsertSource(PlaylistSourcesTableCompanion(
        id: Value(sourceId),
        name: Value(source.name),
        type: Value(source.type),
        url: Value(source.url),
        channelCount: Value(importResult.total),
        status: const Value('active'),
        lastRefresh: Value(DateTime.now()),
        lastSuccess: Value(DateTime.now()),
        lastError: const Value(null),
      ));

      return SourceRefreshResult.success(
        importResult.total,
        removed: importResult.removed,
        added: importResult.inserted,
        updated: importResult.updated,
      );
    } catch (e) {
      final db = ref.read(appDatabaseProvider);
      final source = await db.getSource(sourceId);
      if (source != null) {
        await _markRefreshError(db, source, _summarise(e));
      }
      return SourceRefreshResult.error(_summarise(e));
    } finally {
      // The lock is released on success, error, cancellation AND exception.
      _refreshingSourceIds.remove(sourceId);
      _clearProgress(sourceId);
    }
  }

  Future<SourceRefreshResult> _refreshFileSource(
      AppDatabase db, PlaylistSourcesTableData source) async {
    // The per-source lock is already held by [refreshSource] — do not
    // re-acquire or release it here.
    _setProgress(source.id, 0.2);
    try {
      final file = File(source.filePath!);
      if (!file.existsSync()) {
        await _markRefreshError(db, source, 'Playlist file no longer exists');
        return SourceRefreshResult.error('Playlist file no longer exists');
      }
      final content = await file.readAsString();
      _setProgress(source.id, 0.6);
      final result = await M3UParser.parse(content);
      final previousChannels = await (db.select(db.channelsTable)
            ..where((t) => t.sourceId.equals(source.id)))
          .get();
      final suspiciousReason = _playlistSuspicion(result,
          previousCount: previousChannels.length);
      if (suspiciousReason != null) {
        await _markRefreshError(db, source, suspiciousReason);
        return SourceRefreshResult.error(suspiciousReason);
      }
      final importResult = await ref
          .read(channelRepositoryProvider.notifier)
          .importFromM3UContent(content, source.id);
      _setProgress(source.id, 1.0);
      await db.upsertSource(PlaylistSourcesTableCompanion(
        id: Value(source.id),
        name: Value(source.name),
        type: Value(source.type),
        filePath: Value(source.filePath),
        channelCount: Value(importResult.total),
        status: const Value('active'),
        lastRefresh: Value(DateTime.now()),
        lastSuccess: Value(DateTime.now()),
        lastError: const Value(null),
      ));
      return SourceRefreshResult.success(
        importResult.total,
        removed: importResult.removed,
        added: importResult.inserted,
        updated: importResult.updated,
      );
    } catch (e) {
      await _markRefreshError(db, source, _summarise(e));
      return SourceRefreshResult.error(_summarise(e));
    } finally {
      // Progress is cleared here; the per-source LOCK is owned by
      // [refreshSource] and released by its finally in every path.
      _clearProgress(source.id);
    }
  }

  void _setProgress(String sourceId, double value) {
    ref.read(sourceRefreshProgressProvider.notifier).state = {
      ...ref.read(sourceRefreshProgressProvider.notifier).state,
      sourceId: value,
    };
  }

  void _clearProgress(String sourceId) {
    final current = Map<String, double>.from(
        ref.read(sourceRefreshProgressProvider.notifier).state);
    current.remove(sourceId);
    ref.read(sourceRefreshProgressProvider.notifier).state = current;
  }

  /// FIX: Delete source AND every dependent record in a single transaction.
  Future<void> deleteSource(String sourceId) async {
    final db = ref.read(appDatabaseProvider);
    await db.deleteSourceWithChannels(sourceId);
  }

  Future<void> toggleSource(String sourceId, bool enabled) async {
    final db = ref.read(appDatabaseProvider);
    final source = await db.getSource(sourceId);
    if (source == null) return;
    await db.upsertSource(PlaylistSourcesTableCompanion(
      id: Value(sourceId),
      name: Value(source.name),
      type: Value(source.type),
      isEnabled: Value(enabled),
    ));
  }

  Future<String> _fetchUrl(String url) async {
    try {
      final response = await _dio.get<String>(
        url,
        options: Options(
          responseType: ResponseType.plain,
          headers: {'User-Agent': 'NovaStream/1.0'},
          followRedirects: true,
          maxRedirects: 3,
        ),
      );
      final data = response.data;
      if (data == null || data.isEmpty) {
        throw const FormatException('Empty response from playlist URL');
      }
      return data;
    } on DioException catch (e) {
      // Translate network errors to a readable string; do not expose raw URL
      throw Exception(_dioErrorMessage(e));
    }
  }

  Uri? _validateSourceUrl(String url) {
    try {
      final uri = Uri.parse(url);
      if (uri.scheme != 'http' && uri.scheme != 'https') return null;
      if (uri.host.isEmpty) return null;
      return uri;
    } catch (_) {
      return null;
    }
  }

  Future<void> _markSourceError(
    AppDatabase db,
    String id,
    String name,
    String type,
    String? url,
    String error,
  ) async {
    await db.upsertSource(PlaylistSourcesTableCompanion(
      id: Value(id),
      name: Value(name),
      type: Value(type),
      url: Value(url),
      status: const Value('error'),
      lastError: Value(error),
      lastRefresh: Value(DateTime.now()),
    ));
  }

  /// Records a refresh failure while keeping the previous lastSuccess time
  /// visible so the UI can show "last good data at …".
  Future<void> _markRefreshError(
      AppDatabase db, PlaylistSourcesTableData source, String error) async {
    await db.upsertSource(PlaylistSourcesTableCompanion(
      id: Value(source.id),
      name: Value(source.name),
      type: Value(source.type),
      url: Value(source.url),
      filePath: Value(source.filePath),
      status: const Value('error'),
      lastError: Value(error),
      lastRefresh: Value(DateTime.now()),
      lastSuccess: Value(source.lastSuccess),
    ));
  }

  String _summarise(Object e) {
    if (e is DioException) return _dioErrorMessage(e);
    // Avoid printing full stack traces as user-visible messages
    return e.toString().split('\n').first;
  }

  String _dioErrorMessage(DioException e) => switch (e.type) {
        DioExceptionType.connectionTimeout => 'Connection timed out',
        DioExceptionType.receiveTimeout => 'Request timed out',
        DioExceptionType.connectionError => 'No network connection',
        DioExceptionType.badResponse =>
          'Server error (${e.response?.statusCode ?? "unknown"})',
        _ => e.message ?? 'Unknown network error',
      };
}

/// Rejects clearly incomplete imports before they can replace known-good
/// channel data. A provider may legitimately remove channels, so the ratio
/// check is deliberately conservative and reports the reason to the user.
String? _playlistSuspicion(M3UParseResult result,
    {required int previousCount}) {
  if (result.validCount == 0) {
    return result.errors.isNotEmpty
        ? result.errors.first
        : 'Playlist contains no valid channels — keeping previous data';
  }
  final totalRecords = result.validCount + result.invalidCount;
  if (totalRecords >= 10 && result.invalidCount / totalRecords > 0.20) {
    return 'Playlist has too many malformed entries '
        '(${result.invalidCount}/$totalRecords) — keeping previous data';
  }
  if (previousCount >= 10 && result.validCount < previousCount * 0.5) {
    return 'Playlist unexpectedly contains less than half the previous '
        'channel count — possible truncation; keeping previous data';
  }
  return null;
}

class SourceAddResult {
  final bool success;
  final String? sourceId;
  final int? channelCount;
  final String? errorMessage;

  SourceAddResult.success(this.sourceId, this.channelCount)
      : success = true,
        errorMessage = null;

  SourceAddResult.error(this.errorMessage)
      : success = false,
        sourceId = null,
        channelCount = null;
}

class SourceRefreshResult {
  final bool success;
  final int? channelCount;
  final int? added;
  final int? updated;
  final int? removed;
  final String? errorMessage;

  SourceRefreshResult.success(this.channelCount,
      {this.added, this.updated, this.removed})
      : success = true,
        errorMessage = null;

  SourceRefreshResult.error(this.errorMessage)
      : success = false,
        channelCount = null,
        added = null,
        updated = null,
        removed = null;
}

PlaylistSource _sourceFromRow(PlaylistSourcesTableData row) {
  return PlaylistSource(
    id: row.id,
    name: row.name,
    type: _parseSourceType(row.type),
    url: row.url,
    filePath: row.filePath,
    username: row.username,
    channelCount: row.channelCount,
    status: _parseStatus(row.status),
    lastError: row.lastError,
    lastRefresh: row.lastRefresh,
    lastSuccess: row.lastSuccess,
    etag: row.etag,
    priority: row.priority,
    isEnabled: row.isEnabled,
  );
}

PlaylistSourceType _parseSourceType(String type) => switch (type) {
      'm3u_url' => PlaylistSourceType.m3uUrl,
      'm3u_file' => PlaylistSourceType.m3uFile,
      'xtream' => PlaylistSourceType.xtream,
      'iptv_org' => PlaylistSourceType.iptvOrg,
      _ => PlaylistSourceType.m3uUrl,
    };

SourceStatus _parseStatus(String status) => switch (status) {
      'active' => SourceStatus.active,
      'connecting' => SourceStatus.connecting,
      'error' => SourceStatus.error,
      'disabled' => SourceStatus.disabled,
      'refreshing' => SourceStatus.refreshing,
      _ => SourceStatus.unconfigured,
    };

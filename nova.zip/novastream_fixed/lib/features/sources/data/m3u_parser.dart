import 'dart:async';
import 'dart:isolate';

import '../../../shared/models/channel.dart';

class M3UParseResult {
  final List<M3UEntry> entries;
  final int totalLines;
  final int validCount;
  final int invalidCount;
  final int duplicateCount;
  final List<String> errors;

  const M3UParseResult({
    required this.entries,
    required this.totalLines,
    required this.validCount,
    required this.invalidCount,
    required this.duplicateCount,
    required this.errors,
  });
}

class M3UEntry {
  final String? tvgId;
  final String? tvgName;
  final String? tvgLogo;
  final String? groupTitle;
  final String? tvgLanguage;
  final String? channelNumber;
  final String displayName;
  final String streamUrl;
  final Map<String, String> extraAttributes;

  const M3UEntry({
    this.tvgId,
    this.tvgName,
    this.tvgLogo,
    this.groupTitle,
    this.tvgLanguage,
    this.channelNumber,
    required this.displayName,
    required this.streamUrl,
    this.extraAttributes = const {},
  });
}

class M3UParseError {
  final int line;
  final String message;
  M3UParseError(this.line, this.message);
}

class M3UParser {
  static final _extinfPattern = RegExp(r'^#EXTINF:(-?\d+)\s*(.*),(.*)$');
  static final _attributePattern = RegExp(r'([\w-]+)="([^"]*)"|([\w-]+)=(\S+)');
  static final _safeUrlSchemes = {'http', 'https', 'rtmp', 'rtmps', 'rtsp'};

  /// Parse M3U content, returns result with entries and diagnostics.
  /// Runs in isolate for large files.
  static Future<M3UParseResult> parse(
    String content, {
    void Function(double progress)? onProgress,
  }) async {
    if (content.length > 5 * 1024 * 1024) {
      // Large file: run in isolate
      return _parseInIsolate(content, onProgress);
    }
    return _parseSync(content, onProgress);
  }

  static Future<M3UParseResult> _parseInIsolate(
    String content,
    void Function(double)? onProgress,
  ) async {
    final receivePort = ReceivePort();
    await Isolate.spawn(
      _isolateWorker,
      [receivePort.sendPort, content],
    );

    final completer = Completer<M3UParseResult>();
    receivePort.listen((message) {
      if (message is M3UParseResult) {
        completer.complete(message);
        receivePort.close();
      }
    });
    return completer.future;
  }

  static void _isolateWorker(List<dynamic> args) {
    final sendPort = args[0] as SendPort;
    final content = args[1] as String;
    final result = _parseSync(content, null);
    sendPort.send(result);
  }

  static M3UParseResult _parseSync(
    String content,
    void Function(double)? onProgress,
  ) {
    final lines = content.split(RegExp(r'\r?\n'));
    final entries = <M3UEntry>[];
    final errors = <String>[];
    final seenUrls = <String>{};
    int invalidCount = 0;
    int duplicateCount = 0;

    if (lines.isEmpty || !lines.first.trim().startsWith('#EXTM3U')) {
      return M3UParseResult(
        entries: [],
        totalLines: lines.length,
        validCount: 0,
        invalidCount: 1,
        duplicateCount: 0,
        errors: ['Not a valid M3U file (missing #EXTM3U header)'],
      );
    }

    String? pendingExtinf;
    int lineNum = 0;

    for (final rawLine in lines) {
      lineNum++;
      final line = rawLine.trim();
      if (line.isEmpty) continue;
      if (line.startsWith('#EXTM3U')) continue;
      if (line.startsWith('#EXTINF:')) {
        pendingExtinf = line;
        continue;
      }
      if (line.startsWith('#')) continue; // Other comments

      // This should be a URL
      if (pendingExtinf == null) {
        // URL without EXTINF — still try to use it
        if (_isValidStreamUrl(line)) {
          if (seenUrls.contains(line)) {
            duplicateCount++;
            continue;
          }
          seenUrls.add(line);
          final entry = M3UEntry(
            displayName: 'Channel ${entries.length + 1}',
            streamUrl: line,
          );
          entries.add(entry);
        } else {
          invalidCount++;
          if (errors.length < 20) {
            errors.add('Line $lineNum: Invalid URL scheme: $line');
          }
        }
        continue;
      }

      // Parse EXTINF
      final entry = _parseExtinf(pendingExtinf, line, lineNum, errors);
      pendingExtinf = null;

      if (entry == null) {
        invalidCount++;
        continue;
      }

      if (!_isValidStreamUrl(entry.streamUrl)) {
        invalidCount++;
        if (errors.length < 20) {
          errors.add('Line $lineNum: Unsafe URL scheme: ${entry.streamUrl}');
        }
        continue;
      }

      if (seenUrls.contains(entry.streamUrl)) {
        duplicateCount++;
        continue;
      }
      seenUrls.add(entry.streamUrl);
      entries.add(entry);

      if (onProgress != null && lineNum % 500 == 0) {
        onProgress(lineNum / lines.length);
      }
    }

    // A playlist ending immediately after EXTINF is almost certainly
    // truncated: the metadata record has no corresponding stream URL.
    if (pendingExtinf != null) {
      invalidCount++;
      if (errors.length < 20) {
        errors.add('Playlist ended before an EXTINF stream URL was received');
      }
    }

    return M3UParseResult(
      entries: entries,
      totalLines: lines.length,
      validCount: entries.length,
      invalidCount: invalidCount,
      duplicateCount: duplicateCount,
      errors: errors,
    );
  }

  static M3UEntry? _parseExtinf(
    String extinf,
    String url,
    int lineNum,
    List<String> errors,
  ) {
    final match = _extinfPattern.firstMatch(extinf);
    if (match == null) {
      if (errors.length < 20) {
        errors.add('Line $lineNum: Malformed EXTINF: $extinf');
      }
      return null;
    }

    final attributesStr = match.group(2) ?? '';
    final displayName = match.group(3)?.trim() ?? 'Unknown';
    final attrs = _parseAttributes(attributesStr);

    return M3UEntry(
      tvgId: attrs['tvg-id'],
      tvgName: attrs['tvg-name'],
      tvgLogo: _sanitizeLogoUrl(attrs['tvg-logo']),
      groupTitle: attrs['group-title'],
      tvgLanguage: attrs['tvg-language'],
      channelNumber: attrs['tvg-chno'] ?? attrs['channel-number'],
      displayName: displayName.isNotEmpty
          ? displayName
          : (attrs['tvg-name'] ?? 'Unknown'),
      streamUrl: url.trim(),
      extraAttributes: attrs,
    );
  }

  static Map<String, String> _parseAttributes(String input) {
    final result = <String, String>{};
    for (final match in _attributePattern.allMatches(input)) {
      final key = (match.group(1) ?? match.group(3) ?? '').toLowerCase().trim();
      final value = match.group(2) ?? match.group(4) ?? '';
      if (key.isNotEmpty) {
        result[key] = value;
      }
    }
    return result;
  }

  static bool _isValidStreamUrl(String url) {
    try {
      final uri = Uri.parse(url);
      return _safeUrlSchemes.contains(uri.scheme.toLowerCase());
    } catch (_) {
      return false;
    }
  }

  static String? _sanitizeLogoUrl(String? url) {
    if (url == null || url.isEmpty) return null;
    try {
      final uri = Uri.parse(url);
      if (uri.scheme == 'http' || uri.scheme == 'https') return url;
      return null;
    } catch (_) {
      return null;
    }
  }

  /// Convert parsed M3U entries to IptvChannel domain models
  static List<IptvChannel> toChannels(
    List<M3UEntry> entries,
    String sourceId,
  ) {
    return entries.asMap().entries.map((e) {
      final idx = e.key;
      final entry = e.value;
      final id = _generateChannelId(entry, sourceId, idx);
      return IptvChannel(
        id: id,
        name: entry.displayName,
        logoUrl: entry.tvgLogo,
        groupTitle: entry.groupTitle,
        tvgId: entry.tvgId,
        tvgName: entry.tvgName,
        language: entry.tvgLanguage,
        categories: entry.groupTitle != null ? [entry.groupTitle!] : [],
        streamUrl: entry.streamUrl,
        sourceId: sourceId,
      );
    }).toList();
  }

  static String _generateChannelId(M3UEntry entry, String sourceId, int idx) {
    if (entry.tvgId != null && entry.tvgId!.isNotEmpty) {
      return '${sourceId}_${entry.tvgId}';
    }
    // Fallback: hash of name + url
    final combined = '${entry.displayName}_${entry.streamUrl}';
    return '${sourceId}_${combined.hashCode.abs()}';
  }
}

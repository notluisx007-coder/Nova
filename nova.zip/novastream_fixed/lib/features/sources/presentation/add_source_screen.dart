import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../data/source_repository.dart';

enum _SourceType { url, file }

class AddSourceScreen extends ConsumerStatefulWidget {
  const AddSourceScreen({super.key});

  @override
  ConsumerState<AddSourceScreen> createState() => _AddSourceScreenState();
}

class _AddSourceScreenState extends ConsumerState<AddSourceScreen> {
  _SourceType _type = _SourceType.url;
  final _nameController = TextEditingController();
  final _urlController = TextEditingController();
  String? _selectedFilePath;
  String? _selectedFileName;
  bool _isLoading = false;
  bool _httpConfirmed = false;
  String? _errorMessage;
  String? _successMessage;
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _nameController.dispose();
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['m3u', 'm3u8'],
    );
    if (result != null && result.files.single.path != null) {
      setState(() {
        _selectedFilePath = result.files.single.path;
        _selectedFileName = result.files.single.name;
        if (_nameController.text.isEmpty) {
          _nameController.text =
              result.files.single.name.replaceAll(RegExp(r'\.(m3u8?)$'), '');
        }
      });
    }
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_type == _SourceType.file && _selectedFilePath == null) {
      setState(() => _errorMessage = 'Please select an M3U file');
      return;
    }
    // Explicit user confirmation required before an unencrypted HTTP
    // playlist is stored/used (narrowly scoped compatibility path).
    final isHttp = _type == _SourceType.url &&
        _urlController.text.trim().toLowerCase().startsWith('http://');
    if (isHttp && !_httpConfirmed) {
      setState(() => _errorMessage = 'Tick the confirmation below to allow an '
          'unencrypted HTTP source.');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _successMessage = null;
    });

    try {
      final repo = ref.read(sourceRepositoryProvider.notifier);
      SourceAddResult result;

      if (_type == _SourceType.url) {
        result = await repo.addM3uUrl(
          name: _nameController.text.trim(),
          url: _urlController.text.trim(),
        );
      } else {
        result = await repo.addM3uFile(
          name: _nameController.text.trim(),
          filePath: _selectedFilePath!,
        );
      }

      if (!mounted) return;

      if (result.success) {
        setState(() {
          _successMessage =
              'Source added: ${result.channelCount} channels imported';
          _isLoading = false;
        });
        await Future<void>.delayed(const Duration(seconds: 2));
        if (mounted) Navigator.of(context).pop();
      } else {
        setState(() {
          _errorMessage = result.errorMessage ?? 'Failed to add source';
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = e.toString();
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        title: const Text('Add Playlist Source'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0.5),
          child: Container(height: 0.5, color: AppTheme.surfaceBorder),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Info banner
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.primaryCyan.withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                      color: AppTheme.primaryCyan.withValues(alpha: 0.2)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline_rounded,
                        color: AppTheme.primaryCyan, size: 18),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Only add playlists from sources you are authorized to use. NovaStream does not provide or endorse any IPTV service.',
                        style: TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 12,
                            fontFamily: 'Inter',
                            height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Type selector
              const Text('Source Type',
                  style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Inter')),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: _TypeButton(
                      icon: Icons.link_rounded,
                      label: 'Remote URL',
                      selected: _type == _SourceType.url,
                      onTap: () => setState(() => _type = _SourceType.url),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _TypeButton(
                      icon: Icons.upload_file_rounded,
                      label: 'Local File',
                      selected: _type == _SourceType.file,
                      onTap: () => setState(() => _type = _SourceType.file),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              // Source name
              const Text('Source Name',
                  style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Inter')),
              const SizedBox(height: 8),
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  hintText: 'e.g. My IPTV Provider',
                  prefixIcon: Icon(Icons.label_outline_rounded),
                ),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Enter a name' : null,
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 16),
              // URL or file picker
              if (_type == _SourceType.url) ...[
                const Text('Playlist URL',
                    style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter')),
                const SizedBox(height: 8),
                TextFormField(
                  controller: _urlController,
                  decoration: const InputDecoration(
                    hintText: 'https://example.com/playlist.m3u',
                    prefixIcon: Icon(Icons.link_rounded),
                  ),
                  keyboardType: TextInputType.url,
                  autocorrect: false,
                  onChanged: (_) => setState(() {}),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Enter a URL';
                    final uri = Uri.tryParse(v.trim());
                    if (uri == null ||
                        (uri.scheme != 'http' && uri.scheme != 'https')) {
                      return 'Enter a valid http:// or https:// URL';
                    }
                    return null;
                  },
                ),
              ] else ...[
                const Text('M3U File',
                    style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter')),
                const SizedBox(height: 8),
                GestureDetector(
                  onTap: _pickFile,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceElevated,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppTheme.surfaceBorder),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.upload_file_rounded,
                            color: AppTheme.primaryCyan),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _selectedFileName ??
                                'Tap to select .m3u or .m3u8 file',
                            style: TextStyle(
                              color: _selectedFileName != null
                                  ? AppTheme.textPrimary
                                  : AppTheme.textSecondary,
                              fontFamily: 'Inter',
                              fontSize: 13,
                            ),
                          ),
                        ),
                        if (_selectedFileName != null)
                          const Icon(Icons.check_circle_rounded,
                              color: AppTheme.statusSuccess, size: 18),
                      ],
                    ),
                  ),
                ),
              ],
              const SizedBox(height: 20),
              // Explicit confirmation for unencrypted HTTP sources.
              if (_type == _SourceType.url &&
                  _urlController.text
                      .trim()
                      .toLowerCase()
                      .startsWith('http://')) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.statusWarning.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        color: AppTheme.statusWarning.withValues(alpha: 0.4)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.warning_amber_rounded,
                              color: AppTheme.statusWarning, size: 18),
                          SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'This playlist URL uses HTTP — traffic is NOT encrypted.',
                              style: TextStyle(
                                  color: AppTheme.statusWarning,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Inter'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        dense: true,
                        controlAffinity: ListTileControlAffinity.leading,
                        activeColor: AppTheme.statusWarning,
                        title: const Text(
                          'I understand and want to allow this insecure HTTP source',
                          style: TextStyle(
                              color: AppTheme.textSecondary,
                              fontSize: 12,
                              fontFamily: 'Inter'),
                        ),
                        value: _httpConfirmed,
                        onChanged: (v) =>
                            setState(() => _httpConfirmed = v ?? false),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
              // Error / success messages
              if (_errorMessage != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.statusError.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        color: AppTheme.statusError.withValues(alpha: 0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline_rounded,
                          color: AppTheme.statusError, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                          child: Text(_errorMessage!,
                              style: const TextStyle(
                                  color: AppTheme.statusError,
                                  fontSize: 13,
                                  fontFamily: 'Inter'))),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
              if (_successMessage != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppTheme.statusSuccess.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        color: AppTheme.statusSuccess.withValues(alpha: 0.3)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.check_circle_rounded,
                          color: AppTheme.statusSuccess, size: 18),
                      const SizedBox(width: 8),
                      Expanded(
                          child: Text(_successMessage!,
                              style: const TextStyle(
                                  color: AppTheme.statusSuccess,
                                  fontSize: 13,
                                  fontFamily: 'Inter'))),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
              ],
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _submit,
                  child: _isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: AppTheme.textOnPrimary))
                      : const Text('Add Source'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TypeButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _TypeButton(
      {required this.icon,
      required this.label,
      required this.selected,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected
              ? AppTheme.primaryCyan.withValues(alpha: 0.1)
              : AppTheme.surfaceCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
              color: selected ? AppTheme.primaryCyan : AppTheme.surfaceBorder),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                color: selected ? AppTheme.primaryCyan : AppTheme.textSecondary,
                size: 18),
            const SizedBox(width: 8),
            Text(label,
                style: TextStyle(
                    color: selected
                        ? AppTheme.primaryCyan
                        : AppTheme.textSecondary,
                    fontSize: 13,
                    fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                    fontFamily: 'Inter')),
          ],
        ),
      ),
    );
  }
}

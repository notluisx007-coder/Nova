import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/models/channel.dart';
import '../../../shared/widgets/empty_state_widget.dart';
import '../data/source_repository.dart';

class SourcesScreen extends ConsumerWidget {
  const SourcesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sources = ref.watch(sourcesProvider);

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        title: const Text('Playlist Sources'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0.5),
          child: Container(height: 0.5, color: AppTheme.surfaceBorder),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push(AppRoutes.addSource),
        backgroundColor: AppTheme.primaryCyan,
        foregroundColor: AppTheme.textOnPrimary,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Add Source',
            style: TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600)),
      ),
      body: sources.when(
        data: (list) {
          if (list.isEmpty) {
            return EmptyStateWidget(
              icon: Icons.playlist_add_rounded,
              title: 'No Sources',
              message:
                  'Add an M3U playlist URL or import a local file to start watching live TV.',
              actionLabel: 'Add Source',
              onAction: () => context.push(AppRoutes.addSource),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
            itemCount: list.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (ctx, i) => _SourceCard(source: list[i]),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateWidget(message: e.toString()),
      ),
    );
  }
}

class _SourceCard extends ConsumerWidget {
  final PlaylistSource source;
  const _SourceCard({required this.source});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isRefreshing = source.status == SourceStatus.refreshing;

    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surfaceCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _statusColor(source.status).withValues(alpha: 0.3),
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                _StatusDot(status: source.status),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(source.name,
                          style: const TextStyle(
                              color: AppTheme.textPrimary,
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Inter')),
                      const SizedBox(height: 2),
                      Text(
                        source.url ?? source.filePath ?? 'Local file',
                        style: const TextStyle(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                            fontFamily: 'Inter'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: source.isEnabled,
                  onChanged: (v) => ref
                      .read(sourceRepositoryProvider.notifier)
                      .toggleSource(source.id, v),
                ),
              ],
            ),
          ),
          // Stats row
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: const BoxDecoration(
              color: AppTheme.surfaceElevated,
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(12)),
            ),
            child: Row(
              children: [
                _StatChip(Icons.tv_rounded, '${source.channelCount} ch'),
                const SizedBox(width: 10),
                _StatChip(
                  Icons.access_time_rounded,
                  source.lastSuccess != null
                      ? DateFormat('dd MMM HH:mm').format(source.lastSuccess!)
                      : 'Never',
                ),
                const Spacer(),
                // Refresh
                isRefreshing
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: AppTheme.primaryCyan))
                    : IconButton(
                        icon: const Icon(Icons.refresh_rounded,
                            size: 18, color: AppTheme.textSecondary),
                        onPressed: () => ref
                            .read(sourceRepositoryProvider.notifier)
                            .refreshSource(source.id),
                        visualDensity: VisualDensity.compact,
                      ),
                IconButton(
                  icon: const Icon(Icons.delete_outline_rounded,
                      size: 18, color: AppTheme.textSecondary),
                  onPressed: () => _confirmDelete(context, ref),
                  visualDensity: VisualDensity.compact,
                ),
              ],
            ),
          ),
          if (source.lastError != null)
            Container(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  const Icon(Icons.error_outline_rounded,
                      size: 14, color: AppTheme.statusError),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(source.lastError!,
                        style: const TextStyle(
                            color: AppTheme.statusError,
                            fontSize: 11,
                            fontFamily: 'Inter'),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Remove Source'),
        content:
            Text('Remove "${source.name}"? Its channels will also be removed.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              ref
                  .read(sourceRepositoryProvider.notifier)
                  .deleteSource(source.id);
            },
            child: const Text('Remove',
                style: TextStyle(color: AppTheme.statusError)),
          ),
        ],
      ),
    );
  }

  Color _statusColor(SourceStatus status) => switch (status) {
        SourceStatus.active => AppTheme.statusSuccess,
        SourceStatus.error => AppTheme.statusError,
        SourceStatus.connecting ||
        SourceStatus.refreshing =>
          AppTheme.statusWarning,
        SourceStatus.disabled => AppTheme.textDisabled,
        SourceStatus.unconfigured => AppTheme.textDisabled,
      };
}

class _StatusDot extends StatelessWidget {
  final SourceStatus status;
  const _StatusDot({required this.status});

  @override
  Widget build(BuildContext context) {
    final color = switch (status) {
      SourceStatus.active => AppTheme.statusSuccess,
      SourceStatus.error => AppTheme.statusError,
      SourceStatus.connecting ||
      SourceStatus.refreshing =>
        AppTheme.statusWarning,
      _ => AppTheme.textDisabled,
    };
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
    );
  }
}

class _StatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  const _StatChip(this.icon, this.label);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: AppTheme.textSecondary),
        const SizedBox(width: 4),
        Text(label,
            style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 11,
                fontFamily: 'Inter')),
      ],
    );
  }
}

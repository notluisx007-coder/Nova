import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/database/app_database.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/channel_card.dart';
import '../../../shared/widgets/empty_state_widget.dart';
import '../../live_tv/data/channel_repository.dart';

/// Live view of the favourites table filtered by type ('team' / 'programme').
final favoritesByTypeProvider = StreamProvider.autoDispose
    .family<List<FavoritesTableData>, String>((ref, type) {
  final db = ref.watch(appDatabaseProvider);
  return db.watchFavoritesByType(type);
});

class FavoritesScreen extends ConsumerStatefulWidget {
  const FavoritesScreen({super.key});

  @override
  ConsumerState<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends ConsumerState<FavoritesScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        title: const Text('Favourites'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Channels'),
            Tab(text: 'Teams'),
            Tab(text: 'Shows'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _FavoriteChannels(),
          _FavoriteTeams(),
          _FavoriteShows(),
        ],
      ),
    );
  }
}

class _FavoriteChannels extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorites = ref.watch(favoriteChannelsProvider);

    return favorites.when(
      data: (channels) {
        if (channels.isEmpty) {
          return const EmptyStateWidget(
            icon: Icons.favorite_border_rounded,
            title: 'No Favourite Channels',
            message: 'Tap the heart icon on any channel to add it here.',
          );
        }
        return ListView.separated(
          itemCount: channels.length,
          separatorBuilder: (_, __) => const Divider(
              height: 0.5, indent: 76, color: AppTheme.surfaceBorder),
          itemBuilder: (ctx, i) => ChannelListTile(
            channel: channels[i],
            onFavoriteToggle: () {
              ref
                  .read(channelRepositoryProvider.notifier)
                  .toggleFavorite(channels[i].id, false);
            },
          ),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorStateWidget(message: e.toString()),
    );
  }
}

class _FavoriteTeams extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorites = ref.watch(favoritesByTypeProvider('team'));
    return favorites.when(
      data: (rows) {
        if (rows.isEmpty) {
          return const EmptyStateWidget(
            icon: Icons.groups_rounded,
            title: 'No Favourite Teams',
            message:
                'Open a team in the Sports Hub and tap the star to add it here.',
            iconColor: AppTheme.accentViolet,
          );
        }
        return ListView.separated(
          itemCount: rows.length,
          separatorBuilder: (_, __) => const Divider(
              height: 0.5, indent: 16, color: AppTheme.surfaceBorder),
          itemBuilder: (ctx, i) {
            final row = rows[i];
            return ListTile(
              leading: const Icon(Icons.groups_rounded,
                  color: AppTheme.accentViolet),
              title: Text(row.displayName,
                  style: const TextStyle(
                      color: AppTheme.textPrimary, fontSize: 14)),
              subtitle: const Text('Team',
                  style:
                      TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
              trailing: IconButton(
                icon: const Icon(Icons.star_rounded,
                    color: AppTheme.primaryCyan, size: 20),
                tooltip: 'Remove favourite',
                onPressed: () => ref
                    .read(appDatabaseProvider)
                    .removeFavorite('team', row.referenceId),
              ),
              onTap: () => context.go('/sports/team/${row.referenceId}'),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorStateWidget(message: e.toString()),
    );
  }
}

class _FavoriteShows extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final favorites = ref.watch(favoritesByTypeProvider('programme'));
    return favorites.when(
      data: (rows) {
        if (rows.isEmpty) {
          return const EmptyStateWidget(
            icon: Icons.bookmark_border_rounded,
            title: 'No Saved Shows',
            message: 'Saved programmes from the TV Guide appear here.',
            iconColor: AppTheme.primaryBlue,
          );
        }
        return ListView.separated(
          itemCount: rows.length,
          separatorBuilder: (_, __) => const Divider(
              height: 0.5, indent: 16, color: AppTheme.surfaceBorder),
          itemBuilder: (ctx, i) {
            final row = rows[i];
            return ListTile(
              leading: const Icon(Icons.bookmark_rounded,
                  color: AppTheme.primaryBlue),
              title: Text(row.displayName,
                  style: const TextStyle(
                      color: AppTheme.textPrimary, fontSize: 14)),
              subtitle: const Text('Programme',
                  style:
                      TextStyle(color: AppTheme.textSecondary, fontSize: 11)),
              trailing: IconButton(
                icon: const Icon(Icons.bookmark_rounded,
                    color: AppTheme.primaryCyan, size: 20),
                tooltip: 'Remove bookmark',
                onPressed: () => ref
                    .read(appDatabaseProvider)
                    .removeFavorite('programme', row.referenceId),
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorStateWidget(message: e.toString()),
    );
  }
}

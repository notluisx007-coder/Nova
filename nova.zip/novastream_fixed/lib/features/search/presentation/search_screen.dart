import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/channel_card.dart';
import '../../../shared/widgets/empty_state_widget.dart';
import '../../live_tv/data/channel_repository.dart';

final _searchQueryProvider = StateProvider<String>((ref) => '');

class SearchScreen extends ConsumerStatefulWidget {
  const SearchScreen({super.key});

  @override
  ConsumerState<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends ConsumerState<SearchScreen> {
  final _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      FocusScope.of(context).requestFocus(FocusNode());
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = ref.watch(_searchQueryProvider);

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        titleSpacing: 0,
        title: Padding(
          padding: const EdgeInsets.only(right: 16),
          child: TextField(
            controller: _controller,
            autofocus: true,
            style: const TextStyle(
                color: AppTheme.textPrimary, fontFamily: 'Inter'),
            decoration: InputDecoration(
              hintText: 'Search channels, sports, movies...',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: BorderSide.none,
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide:
                    const BorderSide(color: AppTheme.primaryCyan, width: 1.5),
              ),
              filled: true,
              fillColor: AppTheme.surfaceElevated,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              suffixIcon: query.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear_rounded, size: 18),
                      onPressed: () {
                        _controller.clear();
                        ref.read(_searchQueryProvider.notifier).state = '';
                      },
                    )
                  : null,
            ),
            onChanged: (q) => ref.read(_searchQueryProvider.notifier).state = q,
          ),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0.5),
          child: Container(height: 0.5, color: AppTheme.surfaceBorder),
        ),
      ),
      body: query.isEmpty ? _EmptySearch() : _SearchResults(query: query),
    );
  }
}

class _EmptySearch extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const EmptyStateWidget(
      icon: Icons.search_rounded,
      title: 'Search NovaStream',
      message: 'Find channels, teams, competitions, movies and shows.',
    );
  }
}

class _SearchResults extends ConsumerWidget {
  final String query;
  const _SearchResults({required this.query});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final allChannels = ref.watch(allChannelsProvider);

    return allChannels.when(
      data: (channels) {
        final filtered = channels
            .where((c) =>
                c.name.toLowerCase().contains(query.toLowerCase()) ||
                (c.groupTitle?.toLowerCase().contains(query.toLowerCase()) ??
                    false))
            .toList();

        if (filtered.isEmpty) {
          return EmptyStateWidget(
            icon: Icons.search_off_rounded,
            title: 'No Results',
            message: 'No channels found for "$query".',
          );
        }

        return ListView(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Text(
                '${filtered.length} channel${filtered.length == 1 ? '' : 's'} found',
                style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    fontFamily: 'Inter'),
              ),
            ),
            ...filtered.map((ch) => ChannelListTile(channel: ch)),
          ],
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => ErrorStateWidget(message: e.toString()),
    );
  }
}

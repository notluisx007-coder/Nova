import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:drift/drift.dart' hide isNull, Column;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

import '../../../core/database/app_database.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/models/channel.dart';
import '../../live_tv/data/channel_repository.dart';

// ---------------------------------------------------------------------------
// Arguments passed into the player.
// ---------------------------------------------------------------------------

/// Lightweight reference to a channel used for previous/next navigation.
/// The ordered list preserves the currently active source/category/filter
/// order of the screen that opened the player.
class PlayerChannelRef {
  final String id;
  final String name;
  final String url;

  const PlayerChannelRef({
    required this.id,
    required this.name,
    required this.url,
  });

  factory PlayerChannelRef.fromChannel(IptvChannel c) => PlayerChannelRef(
        id: c.id,
        name: c.name,
        url: c.streamUrl,
      );

  factory PlayerChannelRef.fromMap(Map<dynamic, dynamic> m) => PlayerChannelRef(
        id: m['id'] as String? ?? '',
        name: m['name'] as String? ?? '',
        url: m['url'] as String? ?? '',
      );

  Map<String, dynamic> toMap() => {'id': id, 'name': name, 'url': url};
}

/// Everything the player needs. Built by the router from `extra`.
class PlayerArgs {
  final String streamUrl;
  final String title;
  final String? channelId;
  final List<PlayerChannelRef> playlist;
  final int initialIndex;
  final bool isVod;
  final String? subtitleUrl; // external WebVTT only

  const PlayerArgs({
    required this.streamUrl,
    required this.title,
    this.channelId,
    this.playlist = const [],
    this.initialIndex = 0,
    this.isVod = false,
    this.subtitleUrl,
  });

  static PlayerArgs fromExtra(Map<String, dynamic> extra) {
    final rawList = extra['playlist'] as List?;
    final playlist = rawList
            ?.map((e) => e is Map ? PlayerChannelRef.fromMap(e) : null)
            .whereType<PlayerChannelRef>()
            .toList() ??
        const [];
    return PlayerArgs(
      streamUrl: extra['url'] as String? ?? '',
      title: extra['title'] as String? ?? '',
      channelId: extra['channelId'] as String?,
      playlist: playlist,
      initialIndex: extra['initialIndex'] as int? ?? 0,
      isVod: extra['isVod'] as bool? ?? false,
      subtitleUrl: extra['subtitleUrl'] as String?,
    );
  }
}

/// Aspect-ratio display modes supported by the player surface.
enum AspectMode { fit, fill, original }

extension AspectModeX on AspectMode {
  String get label => switch (this) {
        AspectMode.fit => 'Fit (letterbox)',
        AspectMode.fill => 'Fill (crop)',
        AspectMode.original => 'Original (stretch)',
      };
  IconData get icon => switch (this) {
        AspectMode.fit => Icons.fit_screen_rounded,
        AspectMode.fill => Icons.crop_rounded,
        AspectMode.original => Icons.aspect_ratio_rounded,
      };
}

/// The platform channel used for Android Picture-in-Picture.
const _pipChannel = MethodChannel('com.novastream.app/platform');

class PlayerScreen extends ConsumerStatefulWidget {
  final PlayerArgs args;

  const PlayerScreen({super.key, required this.args});

  @override
  ConsumerState<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends ConsumerState<PlayerScreen>
    with WidgetsBindingObserver {
  VideoPlayerController? _controller;
  int _currentIndex = 0;
  AspectMode _aspectMode = AspectMode.fit;

  bool _showControls = true;
  bool _isBuffering = false;
  bool _hasError = false;
  String? _errorMessage;
  bool _isInitialized = false;
  bool _isDisposed = false;
  bool _isInPip = false;
  bool _autoRetryScheduled = false;

  int _retriesUsed = 0;
  static const _maxRetries = 3;

  Timer? _hideTimer;
  Timer? _positionSaveTimer;
  Timer? _pipPollTimer;

  /// Whether the currently loaded stream is seekable (VOD). Live streams
  /// report a zero/unknown duration from ExoPlayer and are never resumable.
  bool get _currentIsVod =>
      widget.args.isVod ||
      (_controller != null && _controller!.value.duration.inMilliseconds > 0);

  String get _currentTitle => _currentIndex < widget.args.playlist.length
      ? widget.args.playlist[_currentIndex].name
      : widget.args.title;

  String get _resumePointId =>
      widget.args.channelId ?? 'url_${widget.args.streamUrl.hashCode.abs()}';

  bool get _supportsPip =>
      Platform.isAndroid; // PiP requires API 26+; native side reports support.

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _currentIndex = widget.args.initialIndex.clamp(
        0, widget.args.playlist.isEmpty ? 0 : widget.args.playlist.length - 1);
    _enterFullscreenPlaybackUi();
    WakelockPlus.enable();
    _scheduleHideControls();
    _initPlayer();
    _listenPipState();
    _notifyPipAutoEnter(true);
  }

  // ---------------------------------------------------------------------------
  // Player lifecycle
  // ---------------------------------------------------------------------------

  Future<void> _initPlayer() async {
    if (widget.args.streamUrl.isEmpty) {
      if (mounted) {
        setState(() {
          _hasError = true;
          _errorMessage = 'No stream URL provided';
        });
      }
      return;
    }

    try {
      final uri = Uri.parse(widget.args.streamUrl);
      final controller = VideoPlayerController.networkUrl(
        uri,
        closedCaptionFile: widget.args.subtitleUrl != null
            ? _loadCaptionFile(widget.args.subtitleUrl!)
            : null,
      );
      _controller = controller;

      await controller.initialize();
      if (_isDisposed) {
        await controller.dispose();
        return;
      }

      controller.addListener(_onControllerUpdate);
      await controller.play();

      if (mounted) {
        setState(() => _isInitialized = true);
      }

      // VOD resume: only for seekable content; live TV is never resumable.
      if (_currentIsVod && !_isInPip) {
        await _maybeOfferResume();
      } else if (!_currentIsVod) {
        _startPositionSaving(); // live: watch history only (void)
      }
      if (_currentIsVod) {
        _startPositionSaving();
      }

      // Record watch event
      final activeId = _activeChannelId;
      if (activeId != null) {
        unawaited(ref
            .read(channelRepositoryProvider.notifier)
            .markWatched(activeId, _currentTitle, widget.args.streamUrl));
      }
    } catch (e) {
      if (mounted && !_isDisposed) {
        setState(() {
          _hasError = true;
          _errorMessage = _classifyError(e.toString());
        });
        _scheduleAutoRetry();
      }
    }
  }

  String? get _activeChannelId {
    if (widget.args.channelId != null) return widget.args.channelId;
    if (_currentIndex < widget.args.playlist.length) {
      return widget.args.playlist[_currentIndex].id;
    }
    return null;
  }

  /// External subtitles: WebVTT via URL. video_player 2.14 no longer ships
  /// [NetworkClosedCaptionFile], so the download and cue parsing are done
  /// here (real parsing — malformed cues are skipped, never invented).
  Future<ClosedCaptionFile> _loadCaptionFile(String url) =>
      NetworkWebVttCaptionFile.load(url);

  Future<void> _maybeOfferResume() async {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) return;
    final duration = controller.value.duration;
    if (duration.inMilliseconds <= 0) return;

    final db = ref.read(appDatabaseProvider);
    final saved = await db.getResumePoint(_resumePointId);
    if (saved == null) return;

    final savedPos = Duration(seconds: saved.positionSeconds);
    const threshold = Duration(seconds: 30);
    final nearEnd = duration - savedPos < threshold;
    if (savedPos <= threshold || nearEnd) {
      if (nearEnd) {
        // Content was effectively finished — clear the stale point.
        await db.deleteResumePoint(_resumePointId);
      }
      return;
    }

    await controller.pause();
    if (!mounted) return;
    final choice = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surfaceCard,
        title: const Text('Resume playback',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: Text(
          'You stopped at ${_fmtDuration(savedPos)} of ${_fmtDuration(duration)}.',
          style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, 'startover'),
            child: const Text('Start over'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, 'resume'),
            child: const Text('Resume'),
          ),
        ],
      ),
    );
    if (!mounted || _isDisposed) return;
    if (choice == 'resume') {
      await controller.seekTo(savedPos);
    } else {
      await controller.seekTo(Duration.zero);
      await ref.read(appDatabaseProvider).deleteResumePoint(_resumePointId);
    }
    await controller.play();
  }

  /// Periodically stores the VOD playback position so it survives restarts.
  void _startPositionSaving() {
    _positionSaveTimer?.cancel();
    _positionSaveTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final controller = _controller;
      if (controller == null || _isDisposed) return;
      final value = controller.value;
      if (!value.isInitialized) return;
      if (!value.isPlaying) return;

      if (value.duration.inMilliseconds <= 0) {
        // Live stream — never store a resume point.
        return;
      }
      final pos = value.position;
      final remaining = value.duration - pos;
      if (remaining < const Duration(seconds: 30)) {
        // Watched to (almost) the end — drop any saved point.
        await ref.read(appDatabaseProvider).deleteResumePoint(_resumePointId);
        return;
      }
      await ref.read(appDatabaseProvider).upsertResumePoint(
            ResumePointsTableCompanion(
              id: Value(_resumePointId),
              contentType: const Value('vod'),
              title: Value(_currentTitle),
              streamUrl: Value(widget.args.streamUrl),
              positionSeconds: Value(pos.inSeconds),
              durationSeconds: Value(value.duration.inSeconds),
              updatedAt: Value(DateTime.now()),
            ),
          );
    });
  }

  // ---------------------------------------------------------------------------
  // Playback state listener, errors, bounded retry
  // ---------------------------------------------------------------------------

  void _onControllerUpdate() {
    if (_controller == null || !mounted || _isDisposed) return;
    final v = _controller!.value;
    final isBuffering = v.isBuffering;

    if (v.hasError && !_hasError) {
      setState(() {
        _hasError = true;
        _errorMessage =
            _classifyError(v.errorDescription ?? 'Unknown playback error');
      });
      _scheduleAutoRetry();
    } else if (!v.hasError && _hasError) {
      setState(() {
        _hasError = false;
        _errorMessage = null;
      });
    }
    if (isBuffering != _isBuffering) {
      setState(() => _isBuffering = isBuffering);
    }
    // Completed VOD: clear the resume point.
    if (v.isInitialized &&
        v.duration.inMilliseconds > 0 &&
        !v.isPlaying &&
        v.position >= v.duration &&
        v.duration - v.position < const Duration(seconds: 1)) {
      ref.read(appDatabaseProvider).deleteResumePoint(_resumePointId);
    }
  }

  String _classifyError(String error) {
    final e = error.toLowerCase();
    if (e.contains('network') ||
        e.contains('connection') ||
        e.contains('socket')) {
      return 'Network error — check your connection';
    }
    if (e.contains('403') || e.contains('401') || e.contains('unauthorized')) {
      return 'Access denied — stream may require authentication';
    }
    if (e.contains('404') || e.contains('not found')) {
      return 'Stream not found — URL may be incorrect or unavailable';
    }
    if (e.contains('codec') || e.contains('format')) {
      return 'Unsupported format on this device';
    }
    if (e.contains('timeout')) {
      return 'Connection timed out — stream may be offline';
    }
    return 'Playback failed. Check your subscription and network.';
  }

  bool _isTransientError(String? message) =>
      message != null &&
      (message.contains('Network') ||
          message.contains('timed out') ||
          message.contains('offline'));

  void _scheduleAutoRetry() {
    if (_autoRetryScheduled || _isDisposed) return;
    if (!_isTransientError(_errorMessage)) return;
    if (_retriesUsed >= _maxRetries) return;
    _autoRetryScheduled = true;
    final delay = Duration(seconds: 2 * (_retriesUsed + 1));
    Future.delayed(delay, () {
      _autoRetryScheduled = false;
      if (mounted && _hasError && !_isDisposed) {
        _retriesUsed++;
        _retry(showMessage: true);
      }
    });
  }

  Future<void> _retry({bool showMessage = false}) async {
    setState(() {
      _hasError = false;
      _errorMessage = null;
      _isInitialized = false;
    });
    _controller?.removeListener(_onControllerUpdate);
    final old = _controller;
    _controller = null;
    await old?.dispose();
    await _initPlayer();
    if (showMessage && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Reconnecting… (attempt $_retriesUsed/$_maxRetries)'),
      ));
    }
  }

  // ---------------------------------------------------------------------------
  // Picture-in-Picture
  // ---------------------------------------------------------------------------

  Future<void> _listenPipState() async {
    if (!_supportsPip) return;
    _pipChannel.setMethodCallHandler((call) async {
      if (call.method == 'onPipChanged') {
        final inPip = call.arguments == true;
        _isInPip = inPip;
        if (mounted) {
          setState(() {
            // Controls are meaningless inside the PiP window.
            if (inPip) _showControls = false;
          });
        }
        // Closing the PiP window finishes the activity — pop the player.
        if (!inPip &&
            call.arguments is Map &&
            (call.arguments as Map)['closed'] == true) {
          if (mounted && !_isDisposed) Navigator.of(context).pop();
        }
      }
      return null;
    });
    _pipPollTimer = Timer.periodic(const Duration(seconds: 2), (_) async {
      if (_isDisposed) return;
      try {
        final inPip = await _pipChannel.invokeMethod<bool>('isInPiP') ?? false;
        if (inPip != _isInPip && mounted) {
          setState(() => _isInPip = inPip);
        }
      } on PlatformException {
        // Method channel not available (non-Android platform) — ignore.
      } on MissingPluginException {
        // Not implemented on this build — PiP stays unavailable.
      }
    });
  }

  Future<bool> _enterPip() async {
    if (!_supportsPip) return false;
    if (_controller == null || !_controller!.value.isInitialized) return false;
    try {
      final supported =
          await _pipChannel.invokeMethod('isPipSupported') as bool?;
      if (supported != true) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content:
                  Text('Picture-in-Picture is not supported on this device')));
        }
        return false;
      }
      final ok = await _pipChannel.invokeMethod('enterPiP') as bool?;
      return ok == true;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  Future<void> _notifyPipAutoEnter(bool enabled) async {
    if (!_supportsPip) return;
    try {
      await _pipChannel.invokeMethod('setPipAutoEnter', {'enabled': enabled});
    } on PlatformException {
      // Ignore — manual PiP still works.
    } on MissingPluginException {
      // Ignore.
    }
  }

  // ---------------------------------------------------------------------------
  // Controls
  // ---------------------------------------------------------------------------

  void _enterFullscreenPlaybackUi() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  void _exitLandscape() {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  }

  void _scheduleHideControls() {
    _hideTimer?.cancel();
    _hideTimer = Timer(const Duration(seconds: 4), () {
      if (mounted && _showControls && (_controller?.value.isPlaying ?? false)) {
        setState(() => _showControls = false);
      }
    });
  }

  void _toggleControls() {
    if (_isInPip) return;
    setState(() => _showControls = !_showControls);
    if (_showControls) _scheduleHideControls();
  }

  void _togglePlay() {
    if (_controller == null) return;
    if (_controller!.value.isPlaying) {
      _controller!.pause();
      // Keep controls visible while paused
      _hideTimer?.cancel();
    } else {
      _controller!.play();
      _scheduleHideControls();
    }
    setState(() {});
  }

  void _toggleMute() {
    if (_controller == null) return;
    final newVol = _controller!.value.volume == 0 ? 1.0 : 0.0;
    _controller!.setVolume(newVol);
    setState(() {});
  }

  Future<void> _cycleAspectMode() async {
    if (_controller == null) {
      _showNotAvailable('Aspect ratio', 'Video is not initialised yet.');
      return;
    }
    final next =
        AspectMode.values[(_aspectMode.index + 1) % AspectMode.values.length];
    setState(() => _aspectMode = next);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Aspect ratio: ${next.label}'),
            duration: const Duration(milliseconds: 900)),
      );
    }
  }

  Future<bool> _switchChannel(int newIndex) async {
    if (newIndex < 0 || newIndex >= widget.args.playlist.length) return false;
    if (newIndex == _currentIndex && _controller != null) return false;
    // Prevent duplicate sessions: dispose the old controller first.
    setState(() {
      _currentIndex = newIndex;
      _isInitialized = false;
      _isBuffering = false;
      _hasError = false;
      _errorMessage = null;
      _retriesUsed = 0;
    });
    _controller?.removeListener(_onControllerUpdate);
    final old = _controller;
    _controller = null;
    await old?.dispose();
    await _initPlayer();
    return true;
  }

  void _goBack() {
    _exitLandscape();
    if (mounted) Navigator.of(context).pop();
  }

  // ---------------------------------------------------------------------------
  // Capability dialogs (honest "not available" states)
  // ---------------------------------------------------------------------------

  void _showNotAvailable(String capability, String reason) {
    if (!mounted) return;
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surfaceCard,
        title: Text('$capability not available',
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 17)),
        content: Text(
          reason,
          style: const TextStyle(
              color: AppTheme.textSecondary, fontSize: 13, height: 1.4),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showAudioTracks() {
    // video_player does not expose audio-track enumeration/selection on any
    // platform (ExoPlayer track selection is not surfaced by the plugin).
    _showNotAvailable(
      'Audio track selection',
      'The media player plugin used by NovaStream does not expose the audio '
          'tracks of this stream. Multi-audio selection is not available for '
          'this stream/device.',
    );
  }

  void _showSubtitleTracks() {
    if (widget.args.subtitleUrl == null) {
      _showNotAvailable(
        'Subtitles',
        'No subtitles are available for this stream. The player only exposes '
            'embedded caption tracks when the underlying plugin reports them; '
            'this stream/device does not.',
      );
      return;
    }
    // External WebVTT captions were loaded with the controller — allow
    // toggling them via the controller's caption state.
    final controller = _controller;
    if (controller == null) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('External subtitles are enabled for this stream')));
  }

  void _showQualityOptions() {
    // video_player does not expose HLS/DASH variant lists, so presenting a
    // quality menu would be invented data. Adaptive playback continues at
    // the best quality the network supports.
    _showNotAvailable(
      'Quality selection',
      'The media player plugin does not report the available quality '
          'variants of this stream, so manual quality selection is not offered. '
          'Playback is adaptive and uses the best variant your connection '
          'supports.',
    );
  }

  void _showDiagnostics() {
    final v = _controller?.value;
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Playback diagnostics',
                  style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 16,
                      fontWeight: FontWeight.w600)),
              const SizedBox(height: 12),
              _diagRow(
                  'Stream type',
                  v == null
                      ? '—'
                      : (_currentIsVod ? 'VOD (seekable)' : 'Live')),
              _diagRow(
                  'State',
                  _hasError
                      ? 'Error'
                      : !_isInitialized
                          ? 'Connecting'
                          : v!.isPlaying
                              ? 'Playing'
                              : 'Paused'),
              _diagRow('Buffering',
                  v == null ? '—' : (v.isBuffering ? 'Yes' : 'No')),
              if (v != null && v.size.width > 0)
                _diagRow('Resolution',
                    '${v.size.width.toInt()} × ${v.size.height.toInt()}'),
              if (v != null && v.duration.inMilliseconds > 0) ...[
                _diagRow('Position', _fmtDuration(v.position)),
                _diagRow('Duration', _fmtDuration(v.duration)),
              ],
              _diagRow('Reconnect attempts', '$_retriesUsed / $_maxRetries'),
              _diagRow(
                  'Picture-in-Picture',
                  _isInPip
                      ? 'Active'
                      : (_supportsPip ? 'Available' : 'Unavailable')),
              _diagRow(
                  'Source',
                  widget.args.streamUrl.startsWith('https')
                      ? 'HTTPS (encrypted)'
                      : widget.args.streamUrl.startsWith('http')
                          ? 'HTTP (not encrypted)'
                          : 'Other'),
              if (_errorMessage != null) _diagRow('Last error', _errorMessage!),
              const SizedBox(height: 10),
              const Text(
                'Stream addresses and credentials are never shown here.',
                style: TextStyle(
                    color: AppTheme.textDisabled,
                    fontSize: 11,
                    fontStyle: FontStyle.italic),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _diagRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 140,
            child: Text(label,
                style: const TextStyle(
                    color: AppTheme.textSecondary, fontSize: 12)),
          ),
          Expanded(
            child: Text(value,
                style:
                    const TextStyle(color: AppTheme.textPrimary, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Lifecycle
  // ---------------------------------------------------------------------------

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused && !_isInPip) {
      _controller?.pause();
    }
  }

  @override
  void dispose() {
    _isDisposed = true;
    _hideTimer?.cancel();
    _positionSaveTimer?.cancel();
    _pipPollTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    _pipChannel.setMethodCallHandler(null);
    _notifyPipAutoEnter(false);
    _controller?.removeListener(_onControllerUpdate);
    _controller?.dispose();
    WakelockPlus.disable();
    _exitLandscape();
    super.dispose();
  }

  String _fmtDuration(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return h > 0
        ? '$h:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}'
        : '$m:${s.toString().padLeft(2, '0')}';
  }

  // ---------------------------------------------------------------------------
  // Build
  // ---------------------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _toggleControls,
        child: Stack(
          children: [
            // Video surface
            if (_isInitialized && _controller != null)
              _buildVideoSurface()
            else if (_hasError)
              _ErrorView(
                message: _errorMessage ?? 'Playback failed',
                onRetry: () => _retry(),
                onBack: _goBack,
                retriesUsed: _retriesUsed,
                maxRetries: _maxRetries,
              )
            else
              const Center(
                child: CircularProgressIndicator(color: AppTheme.primaryCyan),
              ),

            // Buffering overlay (shown above video, hidden during error)
            if (_isBuffering && !_hasError)
              const Center(
                child: CircularProgressIndicator(color: AppTheme.primaryCyan),
              ),

            // Controls overlay (fades in/out)
            AnimatedOpacity(
              opacity: _showControls && !_isInPip ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 300),
              child: IgnorePointer(
                ignoring: !_showControls || _isInPip,
                child: _ControlsOverlay(
                  title: _currentTitle,
                  controller: _controller,
                  isInitialized: _isInitialized,
                  isLive: !_currentIsVod,
                  aspectMode: _aspectMode,
                  playlistSize: widget.args.playlist.length,
                  currentIndex: _currentIndex,
                  onPlayToggle: _togglePlay,
                  onMuteToggle: _toggleMute,
                  onAspectCycle: _cycleAspectMode,
                  onPrev: _currentIndex > 0
                      ? () => _switchChannel(_currentIndex - 1)
                      : null,
                  onNext: _currentIndex < widget.args.playlist.length - 1
                      ? () => _switchChannel(_currentIndex + 1)
                      : null,
                  onPip: _supportsPip ? () => _enterPip() : null,
                  onAudioTracks: _showAudioTracks,
                  onSubtitles: _showSubtitleTracks,
                  onQuality: _showQualityOptions,
                  onDiagnostics: _showDiagnostics,
                  onBack: _goBack,
                  onSeek: (pos) async {
                    await _controller?.seekTo(pos);
                    setState(() {});
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildVideoSurface() {
    final controller = _controller!;
    final videoAspect = controller.value.aspectRatio > 0
        ? controller.value.aspectRatio
        : 16 / 9;

    return Center(
      child: switch (_aspectMode) {
        // Fit: letterbox the video inside the available space.
        AspectMode.fit => AspectRatio(
            aspectRatio: videoAspect,
            child: VideoPlayer(controller),
          ),
        // Fill: cover the whole surface, cropping the overflow.
        AspectMode.fill => LayoutBuilder(builder: (context, constraints) {
            return SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: constraints.maxWidth,
                  height: constraints.maxWidth / videoAspect,
                  child: VideoPlayer(controller),
                ),
              ),
            );
          }),
        // Original: stretch to the surface, ignoring the video's ratio.
        AspectMode.original => SizedBox.expand(
            child: VideoPlayer(controller),
          ),
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Controls overlay
// ---------------------------------------------------------------------------
class _ControlsOverlay extends StatelessWidget {
  final String title;
  final VideoPlayerController? controller;
  final bool isInitialized;
  final bool isLive;
  final AspectMode aspectMode;
  final int playlistSize;
  final int currentIndex;
  final VoidCallback onPlayToggle;
  final VoidCallback onMuteToggle;
  final VoidCallback onAspectCycle;
  final VoidCallback? onPrev;
  final VoidCallback? onNext;
  final VoidCallback? onPip;
  final VoidCallback onAudioTracks;
  final VoidCallback onSubtitles;
  final VoidCallback onQuality;
  final VoidCallback onDiagnostics;
  final VoidCallback onBack;
  final ValueChanged<Duration> onSeek;

  const _ControlsOverlay({
    required this.title,
    required this.controller,
    required this.isInitialized,
    required this.isLive,
    required this.aspectMode,
    required this.playlistSize,
    required this.currentIndex,
    required this.onPlayToggle,
    required this.onMuteToggle,
    required this.onAspectCycle,
    this.onPrev,
    this.onNext,
    this.onPip,
    required this.onAudioTracks,
    required this.onSubtitles,
    required this.onQuality,
    required this.onDiagnostics,
    required this.onBack,
    required this.onSeek,
  });

  @override
  Widget build(BuildContext context) {
    final value = controller?.value;
    final canSeek = value != null && value.duration.inMilliseconds > 0;

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xCC000000), Colors.transparent, Color(0xCC000000)],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Column(
        children: [
          // Top bar
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 16, 0),
            child: Row(
              children: [
                IconButton(
                  icon:
                      const Icon(Icons.arrow_back_rounded, color: Colors.white),
                  onPressed: onBack,
                  tooltip: 'Back',
                ),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                if (isLive)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppTheme.statusLive,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Text(
                      'LIVE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1,
                      ),
                    ),
                  ),
                IconButton(
                  icon: const Icon(Icons.info_outline_rounded,
                      color: Colors.white),
                  onPressed: onDiagnostics,
                  tooltip: 'Playback diagnostics',
                ),
              ],
            ),
          ),

          const Spacer(),

          // Centre play/pause button
          if (isInitialized && controller != null)
            GestureDetector(
              onTap: onPlayToggle,
              child: Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withValues(alpha: 0.2),
                  border:
                      Border.all(color: Colors.white.withValues(alpha: 0.5)),
                ),
                child: Icon(
                  controller!.value.isPlaying
                      ? Icons.pause_rounded
                      : Icons.play_arrow_rounded,
                  color: Colors.white,
                  size: 36,
                ),
              ),
            ),

          const Spacer(),

          // Seek bar (VOD only — live streams are not seekable)
          if (isInitialized && canSeek) ...[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: [
                  Text(_fmt(value.position),
                      style:
                          const TextStyle(color: Colors.white70, fontSize: 11)),
                  Expanded(
                    child: Slider(
                      value: value.position.inMilliseconds
                          .clamp(0, value.duration.inMilliseconds)
                          .toDouble(),
                      max: value.duration.inMilliseconds.toDouble(),
                      activeColor: AppTheme.primaryCyan,
                      inactiveColor: Colors.white24,
                      onChanged: (ms) =>
                          onSeek(Duration(milliseconds: ms.round())),
                    ),
                  ),
                  Text(_fmt(value.duration),
                      style:
                          const TextStyle(color: Colors.white70, fontSize: 11)),
                ],
              ),
            ),
          ],

          // Bottom bar
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 0, 8, 16),
            child: Row(
              children: [
                // Mute / volume
                Semantics(
                  label: controller?.value.volume == 0 ? 'Unmute' : 'Mute',
                  button: true,
                  child: IconButton(
                    icon: Icon(
                      controller?.value.volume == 0
                          ? Icons.volume_off_rounded
                          : Icons.volume_up_rounded,
                      color: Colors.white,
                    ),
                    onPressed: onMuteToggle,
                    tooltip: controller?.value.volume == 0 ? 'Unmute' : 'Mute',
                  ),
                ),

                // Previous / next channel
                if (playlistSize > 1) ...[
                  IconButton(
                    icon: const Icon(Icons.skip_previous_rounded,
                        color: Colors.white),
                    onPressed: onPrev,
                    tooltip: 'Previous channel',
                  ),
                  IconButton(
                    icon: const Icon(Icons.skip_next_rounded,
                        color: Colors.white),
                    onPressed: onNext,
                    tooltip: 'Next channel',
                  ),
                ],

                const Spacer(),

                // Audio tracks
                IconButton(
                  icon:
                      const Icon(Icons.audiotrack_rounded, color: Colors.white),
                  onPressed: onAudioTracks,
                  tooltip: 'Audio tracks',
                ),
                // Subtitles
                IconButton(
                  icon: const Icon(Icons.closed_caption_rounded,
                      color: Colors.white),
                  onPressed: onSubtitles,
                  tooltip: 'Subtitles',
                ),
                // Quality
                IconButton(
                  icon: const Icon(Icons.high_quality_rounded,
                      color: Colors.white),
                  onPressed: onQuality,
                  tooltip: 'Quality',
                ),
                // PiP (Android only, shown when supported)
                if (onPip != null)
                  IconButton(
                    icon: const Icon(Icons.picture_in_picture_rounded,
                        color: Colors.white),
                    onPressed: onPip,
                    tooltip: 'Picture-in-Picture',
                  ),
                // Aspect ratio — real fit/fill/original cycle
                Semantics(
                  label: 'Aspect ratio: ${aspectMode.label}',
                  button: true,
                  child: IconButton(
                    icon: Icon(aspectMode.icon, color: Colors.white),
                    onPressed: onAspectCycle,
                    tooltip: 'Aspect ratio (${aspectMode.label})',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _fmt(Duration d) {
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return '${d.inHours}:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}';
  }
}

// ---------------------------------------------------------------------------
// Error view
// ---------------------------------------------------------------------------
class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  final VoidCallback onBack;
  final int retriesUsed;
  final int maxRetries;

  const _ErrorView({
    required this.message,
    required this.onRetry,
    required this.onBack,
    required this.retriesUsed,
    required this.maxRetries,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded,
                color: AppTheme.statusError, size: 48),
            const SizedBox(height: 16),
            const Text(
              'Playback Failed',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              message,
              style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 14,
                height: 1.5,
                fontFamily: 'Inter',
              ),
              textAlign: TextAlign.center,
            ),
            if (retriesUsed > 0) ...[
              const SizedBox(height: 6),
              Text(
                'Automatic reconnect attempts used: $retriesUsed / $maxRetries',
                style: const TextStyle(
                  color: AppTheme.textDisabled,
                  fontSize: 12,
                ),
              ),
            ],
            const SizedBox(height: 8),
            const Text(
              'Only streams you are authorised to access will play. '
              'Check your subscription and network.',
              style: TextStyle(
                color: AppTheme.textDisabled,
                fontSize: 12,
                height: 1.5,
                fontFamily: 'Inter',
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                OutlinedButton.icon(
                  onPressed: onBack,
                  icon: const Icon(Icons.arrow_back_rounded,
                      size: 16, color: Colors.white),
                  label: const Text('Go Back',
                      style: TextStyle(color: Colors.white)),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.white54),
                  ),
                ),
                const SizedBox(width: 12),
                ElevatedButton.icon(
                  onPressed: onRetry,
                  icon: const Icon(Icons.refresh_rounded, size: 16),
                  label: const Text('Retry'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Downloads and parses a WebVTT subtitle file from [url] for the player.
/// Cues are parsed for real: malformed records are skipped and counted, and
/// the file is never faked. Fetch failures surface to the player as errors.
class NetworkWebVttCaptionFile implements ClosedCaptionFile {
  NetworkWebVttCaptionFile._(List<Caption> parsed) : _captions = parsed;

  final List<Caption> _captions;

  @override
  List<Caption> get captions => _captions;

  static final _cueTimestamp = RegExp(
    r'(\d{1,2}):(\d{2}):(\d{2})\.(\d{3})',
  );
  static final _cueBlock = RegExp(
    r'((?:\d{1,2}:)?\d{2}:\d{2}\.\d{3})\s*-->\s*((?:\d{1,2}:)?\d{2}:\d{2}\.\d{3})',
  );

  static Future<ClosedCaptionFile> load(String url) async {
    final client = HttpClient();
    try {
      final request = await client.getUrl(Uri.parse(url));
      final response = await request.close();
      if (response.statusCode != HttpStatus.ok) {
        throw HttpException('Captions download failed '
            '(HTTP ${response.statusCode})');
      }
      final body = await response.transform(utf8.decoder).join();
      return NetworkWebVttCaptionFile._(_parse(body));
    } finally {
      client.close();
    }
  }

  static List<Caption> _parse(String body) {
    final cues = <Caption>[];
    var number = 0;
    for (final rawBlock in body.replaceAll('\r\n', '\n').split('\n\n')) {
      final lines = rawBlock
          .split('\n')
          .map((l) => l.trim())
          .where((l) => l.isNotEmpty)
          .toList();
      if (lines.isEmpty) continue;
      if (lines.first.toUpperCase().startsWith('WEBVTT')) continue;
      if (lines.first.toUpperCase().startsWith('NOTE')) continue;
      if (lines.first.toUpperCase().startsWith('STYLE') ||
          lines.first.toUpperCase().startsWith('REGION')) {
        continue;
      }

      final cueLineIndex = lines.indexWhere((l) => _cueBlock.hasMatch(l));
      if (cueLineIndex < 0) continue;
      final match = _cueBlock.firstMatch(lines[cueLineIndex])!;
      final begin = _parseTimestamp(match.group(1)!);
      final end = _parseTimestamp(match.group(2)!);
      if (begin == null || end == null || end <= begin) continue;

      final textLines = lines.skip(cueLineIndex + 1).toList();
      if (textLines.isEmpty) continue;
      final text = textLines
          .where((l) => !l.startsWith('<') && !l.contains('-->'))
          .join('\n')
          .trim();
      if (text.isEmpty) continue;

      number++;
      cues.add(Caption(number: number, start: begin, end: end, text: text));
    }
    return cues;
  }

  static Duration? _parseTimestamp(String s) {
    final m = _cueTimestamp.firstMatch(s);
    if (m == null) return null;
    final hours = int.parse(m.group(1)!);
    final minutes = int.parse(m.group(2)!);
    final seconds = int.parse(m.group(3)!);
    final millis = int.parse(m.group(4)!);
    return Duration(
        hours: hours, minutes: minutes, seconds: seconds, milliseconds: millis);
  }
}

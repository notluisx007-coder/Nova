import 'dart:async';

import 'package:dio/dio.dart';
import 'package:drift/drift.dart' hide isNull;
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../core/database/app_database.dart';
import '../../../features/settings/data/settings_repository.dart';
import '../../../shared/models/sports.dart';

part 'sports_repository.g.dart';

/// Backend base URL resolution order:
///   1. Runtime override stored by the user in Settings.
///   2. Compile-time `--dart-define=NOVASTREAM_SPORTS_BACKEND_URL=...`.
///   3. No default deployment is assumed — sports features honestly report
///      "backend not configured" until the user or build config provides one.
const _kCompileTimeBackendUrl = String.fromEnvironment(
  'NOVASTREAM_SPORTS_BACKEND_URL',
);

/// Setting key for the user-configurable backend base URL.
const kSportsBackendUrlSetting = 'sports_backend_url';

/// Returns the configured backend base URL, or null when none is set.
/// http:// URLs are rejected — the app only talks HTTPS to backends.
String? normalizeBackendUrl(String? raw) {
  if (raw == null) return null;
  final trimmed = raw.trim();
  if (trimmed.isEmpty) return null;
  final uri = Uri.tryParse(trimmed);
  if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
    return null; // https-only: never send data over cleartext to a backend
  }
  var path = uri.path;
  if (path.endsWith('/')) path = path.substring(0, path.length - 1);
  return '${uri.scheme}://${uri.host}$path';
}

/// Backend endpoint metadata returned with every fetch so the UI can show
/// stale/cached status honestly.
class SportsFetchMeta {
  final bool cached;
  final bool stale;
  final DateTime? fetchedAt;

  const SportsFetchMeta(
      {required this.cached, this.stale = false, this.fetchedAt});
}

class SportsClientException implements Exception {
  final String message;
  final int? statusCode;
  final String? code;

  const SportsClientException(this.message, {this.statusCode, this.code});

  @override
  String toString() => message;
}

@riverpod
Future<String?> sportsBackendUrl(SportsBackendUrlRef ref) async {
  final prefs = await ref.watch(sharedPreferencesProvider.future);
  final runtime = prefs.getString(kSportsBackendUrlSetting);
  return normalizeBackendUrl(runtime ?? _kCompileTimeBackendUrl);
}

/// TTL cache for backend responses (mirrors the backend's cache windows).
class _CacheEntry {
  final dynamic data;
  final SportsFetchMeta meta;
  final DateTime storedAt;
  final Duration ttl;
  _CacheEntry(this.data, this.meta, this.storedAt, this.ttl);

  bool get isFresh => DateTime.now().difference(storedAt) < ttl;
}

Dio _buildDio(String baseUrl) {
  return Dio(BaseOptions(
    baseUrl: baseUrl,
    connectTimeout: const Duration(seconds: 10),
    receiveTimeout: const Duration(seconds: 20),
    sendTimeout: const Duration(seconds: 10),
    headers: {
      'Accept': 'application/json',
      'User-Agent': 'NovaStream-Android/1.1',
    },
    validateStatus: (code) => code != null && code < 500,
  ));
}

// ---------------------------------------------------------------------------
// Backend status
// ---------------------------------------------------------------------------
@riverpod
Future<SportsBackendStatus> sportsBackendStatus(
    SportsBackendStatusRef ref) async {
  final baseUrl = await ref.watch(sportsBackendUrlProvider.future);
  if (baseUrl == null) {
    return SportsBackendStatus(
      isReachable: false,
      configured: false,
      message:
          'No sports backend configured. Set one in Settings to enable live scores. '
          'NovaStream does not ship a default deployment.',
      lastUpdated: DateTime.now(),
    );
  }
  try {
    final dio = _buildDio(baseUrl);
    final response = await dio.get<Map<String, dynamic>>('/sports/v1/status');
    final data = response.data ?? {};
    final provider = data['provider'] as Map<String, dynamic>?;
    final providerConfigured = provider?['configured'] == true;
    return SportsBackendStatus(
      isReachable: true,
      providerConfigured: providerConfigured,
      backendVersion: data['version'] as String?,
      sportsAvailable: data['sports'] != null
          ? List<String>.from(data['sports'] as List)
          : null,
      lastUpdated: DateTime.now(),
      message: data['message'] as String?,
    );
  } on DioException catch (e) {
    return SportsBackendStatus(
      isReachable: false,
      message: _dioErrorMessage(e),
      lastUpdated: DateTime.now(),
    );
  } catch (e) {
    return SportsBackendStatus(
      isReachable: false,
      message: 'Unexpected error: ${e.toString().split('\n').first}',
      lastUpdated: DateTime.now(),
    );
  }
}

// ---------------------------------------------------------------------------
// Live/upcoming/finished streams — from DB cache, refreshed via backend
// ---------------------------------------------------------------------------
@riverpod
Stream<List<SportsEvent>> liveEventsStream(LiveEventsStreamRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db.watchLiveEvents().map((rows) => rows.map(_eventFromRow).toList());
}

@riverpod
Stream<List<SportsEvent>> upcomingEventsStream(UpcomingEventsStreamRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db
      .watchUpcomingEvents()
      .map((rows) => rows.map(_eventFromRow).toList());
}

@riverpod
Stream<List<SportsEvent>> finishedEventsStream(FinishedEventsStreamRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db
      .watchFinishedEvents()
      .map((rows) => rows.map(_eventFromRow).toList());
}

// ---------------------------------------------------------------------------
// SportsRepository
// ---------------------------------------------------------------------------
@riverpod
class SportsRepository extends _$SportsRepository {
  final Map<String, _CacheEntry> _cache = {};

  @override
  Future<void> build() async {}

  bool get _hasBackend =>
      ref.read(sportsBackendUrlProvider).valueOrNull != null;

  Dio _requireDio() {
    final baseUrl = ref.read(sportsBackendUrlProvider).valueOrNull;
    if (baseUrl == null) {
      throw const SportsClientException(
          'No sports backend configured — set one in Settings');
    }
    return _buildDio(baseUrl);
  }

  /// One request against a backend endpoint with validation, error mapping
  /// and TTL caching. Returns the parsed `response` list.
  Future<List<Map<String, dynamic>>> _getEndpoint(
    String path, {
    Map<String, dynamic> query = const {},
    Duration ttl = const Duration(seconds: 60),
    bool forceRefresh = false,
  }) async {
    final dio = _requireDio();
    final cacheKey =
        '$path?${query.entries.map((e) => '${e.key}=${e.value}').join('&')}';

    if (!forceRefresh) {
      final entry = _cache[cacheKey];
      if (entry != null && entry.isFresh) {
        _lastMeta = entry.meta;
        return List<Map<String, dynamic>>.from(entry.data as List);
      }
    }

    try {
      final response =
          await dio.get<Map<String, dynamic>>(path, queryParameters: query);
      final status = response.statusCode ?? 0;
      if (status == 429) {
        throw const SportsClientException(
            'Rate limited by the backend — try again shortly',
            statusCode: 429);
      }
      if (status == 401) {
        throw const SportsClientException(
            'Backend rejected the request (unauthorized)',
            statusCode: 401);
      }
      if (status >= 400) {
        final err = response.data?['error'] as Map<String, dynamic>?;
        throw SportsClientException(
            err?['message'] as String? ?? 'Backend error ($status)',
            statusCode: status);
      }
      final data = response.data;
      final list = data?['response'];
      if (list is! List) {
        throw const SportsClientException('Malformed backend response');
      }
      final metaRaw = data?['meta'];
      _lastMeta = SportsFetchMeta(
        cached: metaRaw is Map ? metaRaw['cached'] == true : false,
        stale: metaRaw is Map ? metaRaw['stale'] == true : false,
        fetchedAt: metaRaw is Map && metaRaw['fetchedAt'] is String
            ? DateTime.tryParse(metaRaw['fetchedAt'] as String)
            : null,
      );
      final typed = list.whereType<Map<String, dynamic>>().toList();
      _cache[cacheKey] = _CacheEntry(typed, _lastMeta!, DateTime.now(), ttl);
      return typed;
    } on DioException catch (e) {
      // Serve stale cache entry if the backend fails, flagging staleness.
      final entry = _cache[cacheKey];
      if (entry != null) {
        _lastMeta = SportsFetchMeta(
            cached: true, stale: true, fetchedAt: entry.meta.fetchedAt);
        return List<Map<String, dynamic>>.from(entry.data as List);
      }
      throw SportsClientException(_dioErrorMessage(e),
          statusCode: e.response?.statusCode);
    } on FormatException {
      throw const SportsClientException('Malformed backend response');
    }
  }

  SportsFetchMeta? _lastMeta;

  SportsFetchMeta get lastFetchMeta =>
      _lastMeta ?? const SportsFetchMeta(cached: false);

  /// Fetch live events for a sport (or every sport) and store them in the DB.
  Future<SportsRefreshResult> refreshLiveEvents({String? sport}) async {
    if (!_hasBackend) {
      return SportsRefreshResult(
        successCount: 0,
        errors: ['No sports backend configured'],
        refreshedAt: DateTime.now(),
      );
    }
    final db = ref.read(appDatabaseProvider);
    int total = 0;
    final errors = <String>[];

    final sports = sport != null ? [sport] : _kSportEndpoints.keys.toList();

    for (final s in sports) {
      try {
        final items = await _getEndpoint(
          '/${_kSportEndpoints[s]}/live',
          ttl: const Duration(seconds: 30),
        );
        final events = _parseEvents(items, _sportTypeFromKey(s));
        for (final event in events) {
          await db.upsertSportsEvent(_eventToCompanion(event));
        }
        total += events.length;
      } catch (e) {
        errors.add('$s: ${_summariseError(e)}');
      }
    }

    await db.clearStaleSportsEvents();
    return SportsRefreshResult(
      successCount: total,
      errors: errors,
      refreshedAt: DateTime.now(),
    );
  }

  /// Fetch upcoming/fixed-date events for a sport.
  Future<List<SportsEvent>> fetchUpcomingEvents({
    required String sport,
    DateTime? date,
  }) async {
    if (!_hasBackend) return [];
    final path = _kSportEndpoints[sport];
    if (path == null) return [];

    final queryDate = date ?? DateTime.now();
    final dateStr =
        '${queryDate.year}-${queryDate.month.toString().padLeft(2, '0')}-${queryDate.day.toString().padLeft(2, '0')}';

    try {
      final items = await _getEndpoint(
        '/$path/fixtures',
        query: {'date': dateStr},
        ttl: const Duration(minutes: 5),
      );
      return _parseEvents(items, _sportTypeFromKey(sport));
    } on SportsClientException {
      return [];
    }
  }

  /// Fetch match detail by provider id.
  Future<MatchDetail?> fetchMatchDetail(String eventId, String sport) async {
    if (!_hasBackend) return null;
    final path = _kSportEndpoints[sport];
    if (path == null) return null;

    try {
      final items = await _getEndpoint(
        '/$path/fixtures',
        query: {'id': eventId},
        ttl: const Duration(seconds: 30),
      );
      final events = _parseEvents(items, _sportTypeFromKey(sport));
      if (events.isEmpty) return null;
      return MatchDetail(
        event: events.first,
        fetchedAt: DateTime.now(),
        sourceId: 'backend',
      );
    } on SportsClientException {
      return null;
    }
  }

  /// Fetch standings for a competition.
  Future<List<Map<String, dynamic>>> fetchStandings({
    required String sport,
    required String leagueId,
    required String season,
  }) async {
    if (!_hasBackend) return [];
    final path = _kSportEndpoints[sport];
    if (path == null) return [];
    try {
      return await _getEndpoint(
        '/$path/standings',
        query: {'league': leagueId, 'season': season},
        ttl: const Duration(minutes: 10),
      );
    } on SportsClientException {
      return [];
    }
  }

  /// Search teams.
  Future<List<SportsTeam>> searchTeams(String query, {String? sport}) async {
    if (!_hasBackend) return [];
    final sports =
        sport != null ? [sport] : _kSportEndpoints.keys.take(3).toList();
    final results = <SportsTeam>[];

    for (final s in sports) {
      final path = _kSportEndpoints[s];
      if (path == null) continue;
      try {
        final items = await _getEndpoint(
          '/$path/teams',
          query: {'search': query},
          ttl: const Duration(minutes: 10),
        );
        results.addAll(_parseTeams(items, _sportTypeFromKey(s)));
      } on SportsClientException {
        continue;
      }
    }
    return results;
  }

  // ---------------------------------------------------------------------------
  // Response parsing (validated + normalized)
  // ---------------------------------------------------------------------------
  List<SportsEvent> _parseEvents(
      List<Map<String, dynamic>> items, SportType sport) {
    return items
        .map<SportsEvent?>((item) {
          try {
            final fixture = item['fixture'] as Map<String, dynamic>? ?? item;
            final teams = item['teams'] as Map<String, dynamic>?;
            final goals = item['goals'] as Map<String, dynamic>?;
            final league = item['league'] as Map<String, dynamic>? ?? {};
            final status = fixture['status'] as Map<String, dynamic>? ?? {};

            final homeTeam = teams?['home'] as Map<String, dynamic>? ?? {};
            final awayTeam = teams?['away'] as Map<String, dynamic>? ?? {};

            final startTimeRaw = fixture['date'] as String?;
            DateTime startTime;
            try {
              startTime = startTimeRaw != null
                  ? DateTime.parse(startTimeRaw)
                  : DateTime.now();
            } catch (_) {
              startTime = DateTime.now();
            }

            final id = (fixture['id'] ?? item['id'] ?? '').toString();
            if (id.isEmpty) return null;
            final homeName =
                homeTeam['name'] as String? ?? (item['home'] as String? ?? '');
            final awayName =
                awayTeam['name'] as String? ?? (item['away'] as String? ?? '');
            if (homeName.isEmpty || awayName.isEmpty) return null;

            return SportsEvent(
              id: id,
              sport: sport,
              homeTeamId: homeTeam['id']?.toString(),
              homeTeamName: homeName,
              homeTeamLogoUrl: homeTeam['logo'] as String?,
              awayTeamId: awayTeam['id']?.toString(),
              awayTeamName: awayName,
              awayTeamLogoUrl: awayTeam['logo'] as String?,
              competitionId:
                  (league['id'] ?? item['league_id'] ?? '').toString(),
              competitionName:
                  (league['name'] ?? item['competition'] ?? '') as String,
              status: _parseStatus(status['short'] as String? ??
                  status['long'] as String? ??
                  item['status'] as String? ??
                  ''),
              homeScore: (goals?['home'] ?? item['home_score'])?.toString(),
              awayScore: (goals?['away'] ?? item['away_score'])?.toString(),
              startTime: startTime,
              venue: (fixture['venue'] as Map<String, dynamic>?)?['name']
                      as String? ??
                  item['venue'] as String?,
              matchMinute: status['elapsed']?.toString(),
              sourceId: 'api-sports',
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<SportsEvent>()
        .toList();
  }

  List<SportsTeam> _parseTeams(
      List<Map<String, dynamic>> items, SportType sport) {
    return items
        .map<SportsTeam?>((item) {
          try {
            final team = (item['team'] != null)
                ? item['team'] as Map<String, dynamic>
                : item;
            final id = team['id']?.toString() ?? '';
            final name = team['name'] as String? ?? '';
            if (id.isEmpty || name.isEmpty) return null;
            return SportsTeam(
              id: id,
              name: name,
              shortName: team['code'] as String?,
              logoUrl: team['logo'] as String?,
              country: team['country'] is Map
                  ? (team['country'] as Map)['name'] as String?
                  : team['country'] as String?,
              sport: sport,
            );
          } catch (_) {
            return null;
          }
        })
        .whereType<SportsTeam>()
        .toList();
  }

  MatchStatus _parseStatus(String status) {
    final s = status.toUpperCase();
    if (s == 'NS' || s == 'TBD' || s == 'SCHEDULED' || s == 'NOT STARTED') {
      return MatchStatus.scheduled;
    }
    if (s == '1H' ||
        s == '2H' ||
        s == 'ET' ||
        s == 'P' ||
        s == 'LIVE' ||
        s == 'IN PROGRESS' ||
        s == 'IN_PROGRESS') {
      return MatchStatus.live;
    }
    if (s == 'HT' || s == 'HALF TIME') return MatchStatus.halfTime;
    if (s == 'FT' || s == 'AET' || s == 'PEN' || s == 'FINISHED' || s == 'F') {
      return MatchStatus.finished;
    }
    if (s == 'PST' || s == 'POSTPONED') return MatchStatus.postponed;
    if (s == 'CANC' || s == 'AWD' || s == 'WO' || s == 'CANCELLED') {
      return MatchStatus.cancelled;
    }
    if (s == 'SUSP' || s == 'INT' || s == 'ABD' || s == 'SUSPENDED') {
      return MatchStatus.suspended;
    }
    return MatchStatus.unknown;
  }

  SportType _sportTypeFromKey(String key) => switch (key) {
        'football' => SportType.football,
        'afl' => SportType.afl,
        'baseball' => SportType.baseball,
        'basketball' => SportType.basketball,
        'formula1' => SportType.formula1,
        'handball' => SportType.handball,
        'hockey' => SportType.hockey,
        'mma' => SportType.mma,
        'nba' => SportType.nba,
        'american_football' => SportType.americanFootball,
        'rugby' => SportType.rugby,
        'volleyball' => SportType.volleyball,
        _ => SportType.other,
      };
}

// ---------------------------------------------------------------------------
// Helper models
// ---------------------------------------------------------------------------
class SportsBackendStatus {
  final bool isReachable;
  final bool configured;
  final bool providerConfigured;
  final String? backendVersion;
  final List<String>? sportsAvailable;
  final DateTime lastUpdated;
  final String? message;

  SportsBackendStatus({
    required this.isReachable,
    this.configured = true,
    this.providerConfigured = true,
    this.backendVersion,
    this.sportsAvailable,
    required this.lastUpdated,
    this.message,
  });

  bool get showStaleHint => false;
}

class SportsRefreshResult {
  final int successCount;
  final List<String> errors;
  final DateTime refreshedAt;

  SportsRefreshResult({
    required this.successCount,
    required this.errors,
    required this.refreshedAt,
  });

  bool get hasErrors => errors.isNotEmpty;
}

// ---------------------------------------------------------------------------
// DB helpers
// ---------------------------------------------------------------------------
SportsEventsTableCompanion _eventToCompanion(SportsEvent e) {
  return SportsEventsTableCompanion(
    id: Value(e.id),
    sport: Value(e.sport.name),
    homeTeamId: Value(e.homeTeamId),
    homeTeamName: Value(e.homeTeamName),
    awayTeamId: Value(e.awayTeamId),
    awayTeamName: Value(e.awayTeamName),
    competitionId: Value(e.competitionId),
    competitionName: Value(e.competitionName),
    status: Value(e.status.name),
    homeScore: Value(e.homeScore),
    awayScore: Value(e.awayScore),
    startTime: Value(e.startTime),
    venue: Value(e.venue),
    sourceId: Value(e.sourceId ?? 'api-sports'),
  );
}

SportsEvent _eventFromRow(SportsEventsTableData row) {
  return SportsEvent(
    id: row.id,
    sport: SportType.values.firstWhere(
      (s) => s.name == row.sport,
      orElse: () => SportType.other,
    ),
    homeTeamId: row.homeTeamId,
    homeTeamName: row.homeTeamName,
    awayTeamId: row.awayTeamId,
    awayTeamName: row.awayTeamName,
    competitionId: row.competitionId,
    competitionName: row.competitionName,
    status: MatchStatus.values.firstWhere(
      (s) => s.name == row.status,
      orElse: () => MatchStatus.unknown,
    ),
    homeScore: row.homeScore,
    awayScore: row.awayScore,
    startTime: row.startTime,
    venue: row.venue,
    sourceId: row.sourceId,
    cachedAt: row.cachedAt,
  );
}

String _dioErrorMessage(DioException e) {
  return switch (e.type) {
    DioExceptionType.connectionTimeout => 'Connection timed out',
    DioExceptionType.receiveTimeout => 'Request timed out',
    DioExceptionType.connectionError => 'No network connection',
    DioExceptionType.badResponse =>
      'Server error (${e.response?.statusCode ?? "unknown"})',
    _ => e.message ?? 'Unknown network error',
  };
}

String _summariseError(Object e) {
  if (e is DioException) return _dioErrorMessage(e);
  if (e is SportsClientException) return e.message;
  return e.toString().split('\n').first;
}

const Map<String, String> _kSportEndpoints = {
  'football': 'football',
  'afl': 'afl',
  'baseball': 'baseball',
  'basketball': 'basketball',
  'formula1': 'formula1',
  'handball': 'handball',
  'hockey': 'hockey',
  'mma': 'mma',
  'nba': 'nba',
  'american_football': 'american-football',
  'rugby': 'rugby',
  'volleyball': 'volleyball',
};

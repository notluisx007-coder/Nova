// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sports_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$sportsBackendUrlHash() => r'bff62d17872051cf6cd06267b6b9e629d7c35445';

/// See also [sportsBackendUrl].
@ProviderFor(sportsBackendUrl)
final sportsBackendUrlProvider = AutoDisposeFutureProvider<String?>.internal(
  sportsBackendUrl,
  name: r'sportsBackendUrlProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sportsBackendUrlHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef SportsBackendUrlRef = AutoDisposeFutureProviderRef<String?>;
String _$sportsBackendStatusHash() =>
    r'ba514caff7459ba3d1a55517d603adc034b5ab05';

/// See also [sportsBackendStatus].
@ProviderFor(sportsBackendStatus)
final sportsBackendStatusProvider =
    AutoDisposeFutureProvider<SportsBackendStatus>.internal(
  sportsBackendStatus,
  name: r'sportsBackendStatusProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sportsBackendStatusHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef SportsBackendStatusRef
    = AutoDisposeFutureProviderRef<SportsBackendStatus>;
String _$liveEventsStreamHash() => r'e6e6940a668e2d13e9b61e0e88a3a70e209b1222';

/// See also [liveEventsStream].
@ProviderFor(liveEventsStream)
final liveEventsStreamProvider =
    AutoDisposeStreamProvider<List<SportsEvent>>.internal(
  liveEventsStream,
  name: r'liveEventsStreamProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$liveEventsStreamHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef LiveEventsStreamRef = AutoDisposeStreamProviderRef<List<SportsEvent>>;
String _$upcomingEventsStreamHash() =>
    r'59ec7241fab63c1e3a5581262771554f80a220f7';

/// See also [upcomingEventsStream].
@ProviderFor(upcomingEventsStream)
final upcomingEventsStreamProvider =
    AutoDisposeStreamProvider<List<SportsEvent>>.internal(
  upcomingEventsStream,
  name: r'upcomingEventsStreamProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$upcomingEventsStreamHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef UpcomingEventsStreamRef
    = AutoDisposeStreamProviderRef<List<SportsEvent>>;
String _$finishedEventsStreamHash() =>
    r'5ed23b392608a5814b168f4cc14fd861b44a0592';

/// See also [finishedEventsStream].
@ProviderFor(finishedEventsStream)
final finishedEventsStreamProvider =
    AutoDisposeStreamProvider<List<SportsEvent>>.internal(
  finishedEventsStream,
  name: r'finishedEventsStreamProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$finishedEventsStreamHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef FinishedEventsStreamRef
    = AutoDisposeStreamProviderRef<List<SportsEvent>>;
String _$sportsRepositoryHash() => r'e9feac27123db718e919ee49f8d4724a7d0599cc';

/// See also [SportsRepository].
@ProviderFor(SportsRepository)
final sportsRepositoryProvider =
    AutoDisposeAsyncNotifierProvider<SportsRepository, void>.internal(
  SportsRepository.new,
  name: r'sportsRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sportsRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SportsRepository = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package

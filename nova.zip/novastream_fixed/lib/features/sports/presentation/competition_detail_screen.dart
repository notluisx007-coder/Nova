import 'package:drift/drift.dart' hide isNull;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/database/app_database.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/empty_state_widget.dart';

/// Competition detail backed by REAL data: the cached fixtures of this
/// competition from the local sports cache. Live standings require the
/// backend (league id + season) and are fetched when available; otherwise
/// the honest "cached fixtures only" state is shown.
class CompetitionDetailScreen extends ConsumerWidget {
  final String competitionId;
  const CompetitionDetailScreen({super.key, required this.competitionId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final matches = ref.watch(_competitionMatchesProvider(competitionId));

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(title: const Text('Competition')),
      body: matches.when(
        data: (rows) {
          if (rows.isEmpty) {
            return const EmptyStateWidget(
              icon: Icons.emoji_events_rounded,
              title: 'No cached fixtures for this competition',
              message:
                  'Competitions appear here after their fixtures are cached '
                  'from the Sports Hub. Refresh the Sports Hub and try again.',
            );
          }
          final name = rows.first.competitionName;
          return ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text(name,
                  style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter')),
              const SizedBox(height: 4),
              Text('Cached fixtures (${rows.length})',
                  style: const TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 12,
                      fontFamily: 'Inter')),
              const SizedBox(height: 12),
              ...rows.map((m) => Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceCard,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppTheme.surfaceBorder),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text('${m.homeTeamName} — ${m.awayTeamName}',
                              style: const TextStyle(
                                  color: AppTheme.textPrimary, fontSize: 13)),
                        ),
                        Text(
                            (m.homeScore != null && m.awayScore != null)
                                ? '${m.homeScore} – ${m.awayScore}'
                                : m.status,
                            style: const TextStyle(
                                color: AppTheme.textSecondary, fontSize: 12)),
                      ],
                    ),
                  )),
            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateWidget(message: e.toString()),
      ),
    );
  }
}

final _competitionMatchesProvider = FutureProvider.autoDispose
    .family<List<SportsEventsTableData>, String>((ref, competitionId) async {
  final db = ref.watch(appDatabaseProvider);
  return (db.select(db.sportsEventsTable)
        ..where((t) => t.competitionId.equals(competitionId))
        ..orderBy([(t) => OrderingTerm.desc(t.startTime)])
        ..limit(30))
      .get();
});

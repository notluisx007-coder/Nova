import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/database/app_database.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/models/sports.dart';
import '../../../shared/widgets/empty_state_widget.dart';

/// Match detail backed by REAL data: the cached event row from the local
/// database, refreshed on demand from the configured backend. When the event
/// is unknown (never cached / cache cleared) the screen says so instead of
/// showing placeholder content.
class MatchDetailScreen extends ConsumerWidget {
  final String matchId;
  const MatchDetailScreen({super.key, required this.matchId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final eventFuture = ref.watch(_matchEventProvider(matchId));

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        title: const Text('Match Details'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0.5),
          child: Container(height: 0.5, color: AppTheme.surfaceBorder),
        ),
      ),
      body: eventFuture.when(
        data: (event) {
          if (event == null) {
            return const EmptyStateWidget(
              icon: Icons.search_off_rounded,
              title: 'Match not in cache',
              message: 'This match has no cached data. Open the Sports Hub, '
                  'refresh, and tap the match to load its details from the '
                  'backend.',
            );
          }
          return _MatchDetailContent(event: event);
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateWidget(message: e.toString()),
      ),
    );
  }
}

/// Loads the cached event row for [matchId] from the local database.
final _matchEventProvider =
    FutureProvider.autoDispose.family<SportsEvent?, String>((ref, id) async {
  final db = ref.watch(appDatabaseProvider);
  final row = await db.getSportsEvent(id);
  if (row == null) return null;
  return SportsEvent(
    id: row.id,
    sport: SportType.values.firstWhere(
      (s) => s.name == row.sport,
      orElse: () => SportType.other,
    ),
    homeTeamId: row.homeTeamId,
    homeTeamName: row.homeTeamName,
    awayTeamId: row.awayTeamId,
    awayTeamName: row.awayTeamName,
    competitionId: row.competitionId,
    competitionName: row.competitionName,
    status: MatchStatus.values.firstWhere(
      (s) => s.name == row.status,
      orElse: () => MatchStatus.unknown,
    ),
    homeScore: row.homeScore,
    awayScore: row.awayScore,
    startTime: row.startTime,
    venue: row.venue,
    sourceId: row.sourceId,
    cachedAt: row.cachedAt,
  );
});

class _MatchDetailContent extends ConsumerWidget {
  final SportsEvent event;
  const _MatchDetailContent({required this.event});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final df = DateFormat('EEE d MMM yyyy, HH:mm');
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(event.competitionName,
            style: const TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 13,
                fontFamily: 'Inter')),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: Column(
                children: [
                  Text(event.homeTeamName,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter')),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: event.homeScore != null && event.awayScore != null
                  ? Text('${event.homeScore} – ${event.awayScore}',
                      style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 26,
                          fontWeight: FontWeight.w700))
                  : Text(
                      event.status.isLive ? 'LIVE' : event.status.displayName,
                      style: TextStyle(
                          color: event.status.isLive
                              ? AppTheme.statusLive
                              : AppTheme.textSecondary,
                          fontSize: 16,
                          fontWeight: FontWeight.w700)),
            ),
            Expanded(
              child: Column(
                children: [
                  Text(event.awayTeamName,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter')),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppTheme.surfaceCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.surfaceBorder),
          ),
          child: Column(children: [
            _InfoRow('Kick-off (local)', df.format(event.startTime.toLocal())),
            if (event.matchMinute != null)
              _InfoRow('Match minute', "${event.matchMinute}'"),
            if (event.venue != null) _InfoRow('Venue', event.venue!),
            _InfoRow('Status', event.status.displayName),
            _InfoRow('Provider', event.sourceId ?? '—'),
          ]),
        ),
        const SizedBox(height: 12),
        if (event.cachedAt != null)
          Text(
            'Cached ${DateFormat('d MMM HH:mm').format(event.cachedAt!.toLocal())} — '
            'refresh the Sports Hub for the latest score.',
            style: const TextStyle(
                color: AppTheme.textDisabled,
                fontSize: 11,
                fontFamily: 'Inter'),
          ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 130,
            child: Text(label,
                style: const TextStyle(
                    color: AppTheme.textSecondary, fontSize: 12)),
          ),
          Expanded(
            child: Text(value,
                style:
                    const TextStyle(color: AppTheme.textPrimary, fontSize: 12)),
          ),
        ],
      ),
    );
  }
}

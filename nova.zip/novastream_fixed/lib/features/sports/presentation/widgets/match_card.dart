import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../shared/models/sports.dart';

class MatchCard extends StatelessWidget {
  final SportsEvent event;
  final VoidCallback? onTap;

  const MatchCard({super.key, required this.event, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.surfaceCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: event.status.isLive
                ? AppTheme.statusLive.withValues(alpha: 0.3)
                : AppTheme.surfaceBorder,
            width: event.status.isLive ? 1 : 0.5,
          ),
          boxShadow: event.status.isLive
              ? [
                  BoxShadow(
                      color: AppTheme.statusLive.withValues(alpha: 0.1),
                      blurRadius: 10)
                ]
              : null,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Competition + status row
            Row(
              children: [
                Text(
                  '${event.sport.icon}  ${event.competitionName}',
                  style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 11,
                    fontFamily: 'Inter',
                  ),
                ),
                const Spacer(),
                _StatusBadge(status: event.status, minute: event.matchMinute),
              ],
            ),
            const SizedBox(height: 10),
            // Teams row
            Row(
              children: [
                Expanded(
                  child: _TeamBlock(
                    name: event.homeTeamName,
                    logoUrl: event.homeTeamLogoUrl,
                    isHome: true,
                  ),
                ),
                _ScoreBlock(
                  homeScore: event.homeScore,
                  awayScore: event.awayScore,
                  status: event.status,
                  startTime: event.startTime,
                ),
                Expanded(
                  child: _TeamBlock(
                    name: event.awayTeamName,
                    logoUrl: event.awayTeamLogoUrl,
                    isHome: false,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final MatchStatus status;
  final String? minute;

  const _StatusBadge({required this.status, this.minute});

  @override
  Widget build(BuildContext context) {
    if (status.isLive) {
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
        decoration: BoxDecoration(
          color: AppTheme.statusLive.withValues(alpha: 0.15),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: AppTheme.statusLive.withValues(alpha: 0.4)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 5,
              height: 5,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.statusLive,
              ),
            ),
            const SizedBox(width: 4),
            Text(
              minute != null ? "$minute'" : 'LIVE',
              style: const TextStyle(
                color: AppTheme.statusLive,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter',
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppTheme.surfaceElevated,
        borderRadius: BorderRadius.circular(4),
      ),
      child: Text(
        status.displayName,
        style: const TextStyle(
          color: AppTheme.textSecondary,
          fontSize: 10,
          fontWeight: FontWeight.w500,
          fontFamily: 'Inter',
        ),
      ),
    );
  }
}

class _TeamBlock extends StatelessWidget {
  final String name;
  final String? logoUrl;
  final bool isHome;

  const _TeamBlock({required this.name, this.logoUrl, required this.isHome});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment:
          isHome ? CrossAxisAlignment.start : CrossAxisAlignment.end,
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppTheme.surfaceElevated,
            border: Border.all(color: AppTheme.surfaceBorder),
          ),
          alignment: isHome ? Alignment.centerLeft : Alignment.centerRight,
          child: const Center(
            child: Icon(Icons.shield_outlined,
                size: 18, color: AppTheme.textDisabled),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          name,
          style: const TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 12,
            fontWeight: FontWeight.w500,
            fontFamily: 'Inter',
          ),
          maxLines: 2,
          textAlign: isHome ? TextAlign.left : TextAlign.right,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }
}

class _ScoreBlock extends StatelessWidget {
  final String? homeScore;
  final String? awayScore;
  final MatchStatus status;
  final DateTime startTime;

  const _ScoreBlock({
    this.homeScore,
    this.awayScore,
    required this.status,
    required this.startTime,
  });

  @override
  Widget build(BuildContext context) {
    final hasScore = homeScore != null && awayScore != null;
    final timeStr = DateFormat('HH:mm').format(startTime.toLocal());

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(
        children: [
          if (hasScore)
            RichText(
              textAlign: TextAlign.center,
              text: TextSpan(
                children: [
                  TextSpan(
                    text: homeScore,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter',
                    ),
                  ),
                  const TextSpan(
                    text: ' — ',
                    style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 18,
                      fontFamily: 'Inter',
                    ),
                  ),
                  TextSpan(
                    text: awayScore,
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            )
          else
            Text(
              status == MatchStatus.scheduled ? timeStr : status.displayName,
              style: TextStyle(
                color: status.isLive
                    ? AppTheme.statusLive
                    : AppTheme.textSecondary,
                fontSize: 16,
                fontWeight: FontWeight.w600,
                fontFamily: 'Inter',
              ),
            ),
          const SizedBox(height: 2),
          if (!hasScore && status == MatchStatus.scheduled)
            Text(
              DateFormat('dd MMM').format(startTime.toLocal()),
              style: const TextStyle(
                color: AppTheme.textDisabled,
                fontSize: 10,
                fontFamily: 'Inter',
              ),
            ),
        ],
      ),
    );
  }
}

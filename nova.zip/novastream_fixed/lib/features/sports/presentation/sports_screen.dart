import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/models/sports.dart';
import '../data/sports_repository.dart';

class SportsScreen extends ConsumerStatefulWidget {
  const SportsScreen({super.key});

  @override
  ConsumerState<SportsScreen> createState() => _SportsScreenState();
}

class _SportsScreenState extends ConsumerState<SportsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isRefreshing = false;

  static const _tabs = ['Live', 'Upcoming', 'Results'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    setState(() => _isRefreshing = true);
    await ref.read(sportsRepositoryProvider.notifier).refreshLiveEvents();
    setState(() => _isRefreshing = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceBackground,
        surfaceTintColor: Colors.transparent,
        title: const Text(
          'Sports Hub',
          style: TextStyle(
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w700,
            fontFamily: 'Inter',
          ),
        ),
        actions: [
          IconButton(
            icon: _isRefreshing
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: AppTheme.primaryCyan))
                : const Icon(Icons.refresh_rounded,
                    color: AppTheme.textSecondary),
            onPressed: _isRefreshing ? null : _refresh,
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: _tabs.map((t) => Tab(text: t)).toList(),
          indicatorColor: AppTheme.primaryCyan,
          labelColor: AppTheme.primaryCyan,
          unselectedLabelColor: AppTheme.textSecondary,
          labelStyle: const TextStyle(
              fontWeight: FontWeight.w600, fontFamily: 'Inter', fontSize: 13),
        ),
      ),
      body: Column(
        children: [
          _buildSportSelector(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: const [
                _EventList(filter: 'live'),
                _EventList(filter: 'upcoming'),
                _EventList(filter: 'results'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSportSelector() {
    final sports = SportType.values.where((s) => s != SportType.other).toList();

    return Container(
      height: 80,
      color: AppTheme.surfaceBackground,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        itemCount: sports.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () => context.go('/sports'),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryCyan.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                        color: AppTheme.primaryCyan.withValues(alpha: 0.4)),
                  ),
                  child: const Text(
                    'All Sports',
                    style: TextStyle(
                        color: AppTheme.primaryCyan,
                        fontWeight: FontWeight.w600,
                        fontSize: 13),
                  ),
                ),
              ),
            );
          }
          final sport = sports[index - 1];
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: () => context.go('/sports/category/${sport.apiKey}'),
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceCard,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.surfaceBorder),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(sport.icon, style: const TextStyle(fontSize: 14)),
                    const SizedBox(width: 6),
                    Text(
                      sport.displayName,
                      style: const TextStyle(
                          color: AppTheme.textPrimary, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _EventList extends ConsumerWidget {
  final String filter;
  const _EventList({required this.filter});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (filter == 'live') {
      final events = ref.watch(liveEventsStreamProvider);
      return events.when(
        data: (list) =>
            _buildList(context, list, emptyMsg: 'No live events right now.'),
        loading: () => const Center(
            child: CircularProgressIndicator(color: AppTheme.primaryCyan)),
        error: (e, _) => _ErrorState(message: e.toString()),
      );
    } else if (filter == 'upcoming') {
      final events = ref.watch(upcomingEventsStreamProvider);
      return events.when(
        data: (list) =>
            _buildList(context, list, emptyMsg: 'No upcoming events found.'),
        loading: () => const Center(
            child: CircularProgressIndicator(color: AppTheme.primaryCyan)),
        error: (e, _) => _ErrorState(message: e.toString()),
      );
    } else {
      // Results — real finished events from the local cache.
      final events = ref.watch(finishedEventsStreamProvider);
      return events.when(
        data: (list) => _buildList(context, list,
            emptyMsg:
                'No results available yet. Finished matches appear here after a refresh.'),
        loading: () => const Center(
            child: CircularProgressIndicator(color: AppTheme.primaryCyan)),
        error: (e, _) => _ErrorState(message: e.toString()),
      );
    }
  }

  Widget _buildList(BuildContext context, List<SportsEvent> events,
      {required String emptyMsg}) {
    if (events.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🏆', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 12),
            Text(
              emptyMsg,
              style: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 14,
                  fontFamily: 'Inter'),
            ),
            const SizedBox(height: 8),
            const Text(
              'Pull to refresh or add a backend connection in Settings.',
              style: TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 12,
                  fontFamily: 'Inter'),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: events.length,
      itemBuilder: (context, index) {
        final event = events[index];
        return _EventCard(event: event);
      },
    );
  }
}

class _EventCard extends StatelessWidget {
  final SportsEvent event;
  const _EventCard({required this.event});

  @override
  Widget build(BuildContext context) {
    final isLive = event.status.isLive;
    return GestureDetector(
      onTap: () => context.go('/sports/match/${event.id}'),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.surfaceCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isLive
                ? AppTheme.statusLive.withValues(alpha: 0.3)
                : AppTheme.surfaceBorder,
          ),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Text(event.sport.icon, style: const TextStyle(fontSize: 14)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    event.competitionName,
                    style: const TextStyle(
                        color: AppTheme.textSecondary, fontSize: 11),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                _StatusBadge(status: event.status, minute: event.matchMinute),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: Text(
                    event.homeTeamName,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w600),
                    textAlign: TextAlign.start,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: event.homeScore != null && event.awayScore != null
                      ? Text(
                          '${event.homeScore} - ${event.awayScore}',
                          style: const TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        )
                      : Text(
                          _formatTime(event.startTime),
                          style: const TextStyle(
                              color: AppTheme.primaryCyan, fontSize: 13),
                        ),
                ),
                Expanded(
                  child: Text(
                    event.awayTeamName,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 14,
                        fontWeight: FontWeight.w600),
                    textAlign: TextAlign.end,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            if (event.venue != null) ...[
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.location_on_rounded,
                      size: 11, color: AppTheme.textSecondary),
                  const SizedBox(width: 3),
                  Text(
                    event.venue!,
                    style: const TextStyle(
                        color: AppTheme.textSecondary, fontSize: 11),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final local = dt.toLocal();
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }
}

class _StatusBadge extends StatelessWidget {
  final MatchStatus status;
  final String? minute;
  const _StatusBadge({required this.status, this.minute});

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;

    if (status.isLive) {
      color = AppTheme.statusLive;
      label = minute != null ? "LIVE $minute'" : 'LIVE';
    } else if (status == MatchStatus.finished) {
      color = AppTheme.textSecondary;
      label = 'FT';
    } else if (status == MatchStatus.postponed) {
      color = AppTheme.statusWarning;
      label = 'PST';
    } else {
      color = AppTheme.primaryCyan;
      label = status.displayName;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
            color: color,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 0.5),
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String message;
  const _ErrorState({required this.message});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded,
                color: AppTheme.textSecondary, size: 40),
            const SizedBox(height: 12),
            const Text(
              'Could not load sports data',
              style: TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 15,
                  fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Text(
              message,
              style:
                  const TextStyle(color: AppTheme.textSecondary, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}

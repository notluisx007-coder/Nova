import 'package:drift/drift.dart' hide isNull;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

import '../../../core/database/app_database.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/empty_state_widget.dart';

/// Team detail backed by REAL data: the team's recent fixtures from the
/// local sports cache, plus a favourite toggle persisted in the favourites
/// table. Teams the app has never cached show an honest "no data" state —
/// nothing is invented.
class TeamDetailScreen extends ConsumerWidget {
  final String teamId;
  const TeamDetailScreen({super.key, required this.teamId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final teamFuture = ref.watch(_teamFromCacheProvider(teamId));
    final isFav = ref.watch(_isTeamFavoriteProvider(teamId));

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        title: const Text('Team'),
        actions: [
          isFav.when(
            data: (fav) => IconButton(
              icon: Icon(
                fav ? Icons.star_rounded : Icons.star_border_rounded,
                color: fav ? AppTheme.primaryCyan : AppTheme.textSecondary,
              ),
              tooltip: fav ? 'Remove favourite' : 'Add favourite',
              onPressed: () => _toggleFavorite(ref, teamId, fav),
            ),
            loading: () => const SizedBox(width: 48),
            error: (_, __) => const SizedBox(width: 48),
          ),
        ],
      ),
      body: teamFuture.when(
        data: (team) {
          if (team == null) {
            return const EmptyStateWidget(
              icon: Icons.groups_rounded,
              title: 'No cached data for this team',
              message:
                  'Teams appear here after their fixtures are cached from the '
                  'Sports Hub. Refresh the Sports Hub and try again.',
            );
          }
          return _TeamContent(
              team: team,
              matches:
                  ref.watch(_teamMatchesProvider(teamId)).valueOrNull ?? []);
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => ErrorStateWidget(message: e.toString()),
      ),
    );
  }

  Future<void> _toggleFavorite(WidgetRef ref, String teamId, bool fav) async {
    final db = ref.read(appDatabaseProvider);
    if (fav) {
      await db.removeFavorite('team', teamId);
    } else {
      final team =
          await ref.read(_teamFromCacheProvider(teamId).future).then((t) => t);
      if (team == null) return;
      await db.addFavorite(FavoritesTableCompanion(
        id: Value(const Uuid().v4()),
        type: const Value('team'),
        referenceId: Value(teamId),
        displayName: Value(team.name),
        metadata: const Value(null),
      ));
    }
    ref.invalidate(_isTeamFavoriteProvider(teamId));
  }
}

final _teamFromCacheProvider = FutureProvider.autoDispose
    .family<_CachedTeam?, String>((ref, teamId) async {
  final db = ref.watch(appDatabaseProvider);
  // Find the team in any cached fixture (home or away).
  final rows = await (db.select(db.sportsEventsTable)
        ..where(
            (t) => t.homeTeamId.equals(teamId) | t.awayTeamId.equals(teamId))
        ..limit(1))
      .get();
  if (rows.isEmpty) return null;
  final row = rows.first;
  final isHome = row.homeTeamId == teamId;
  return _CachedTeam(
    id: teamId,
    name: isHome ? row.homeTeamName : row.awayTeamName,
    sport: row.sport,
  );
});

final _isTeamFavoriteProvider =
    FutureProvider.autoDispose.family<bool, String>((ref, teamId) async {
  final db = ref.watch(appDatabaseProvider);
  return db.isFavorite('team', teamId);
});

final _teamMatchesProvider = FutureProvider.autoDispose
    .family<List<SportsEventsTableData>, String>((ref, teamId) async {
  final db = ref.watch(appDatabaseProvider);
  return (db.select(db.sportsEventsTable)
        ..where(
            (t) => t.homeTeamId.equals(teamId) | t.awayTeamId.equals(teamId))
        ..orderBy([(t) => OrderingTerm.desc(t.startTime)])
        ..limit(10))
      .get();
});

class _CachedTeam {
  final String id;
  final String name;
  final String sport;
  const _CachedTeam(
      {required this.id, required this.name, required this.sport});
}

class _TeamContent extends StatelessWidget {
  final _CachedTeam team;
  final List<SportsEventsTableData> matches;
  const _TeamContent({required this.team, required this.matches});

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('d MMM, HH:mm');
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(team.name,
            style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 22,
                fontWeight: FontWeight.w700,
                fontFamily: 'Inter')),
        const SizedBox(height: 4),
        const Text('Recent fixtures (cached from the sports backend)',
            style: TextStyle(
                color: AppTheme.textSecondary,
                fontSize: 12,
                fontFamily: 'Inter')),
        const SizedBox(height: 16),
        if (matches.isEmpty)
          const Text('No cached fixtures yet.',
              style: TextStyle(color: AppTheme.textSecondary, fontSize: 13))
        else
          ...matches.map((m) {
            final isHome = m.homeTeamId == team.id;
            final opponent = isHome ? m.awayTeamName : m.homeTeamName;
            final score = (m.homeScore != null && m.awayScore != null)
                ? (isHome
                    ? '${m.homeScore} – ${m.awayScore}'
                    : '${m.awayScore} – ${m.homeScore}')
                : m.status;
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.surfaceCard,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.surfaceBorder),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text('${isHome ? "vs" : "@"} $opponent',
                        style: const TextStyle(
                            color: AppTheme.textPrimary, fontSize: 13)),
                  ),
                  Text(score,
                      style: const TextStyle(
                          color: AppTheme.textSecondary, fontSize: 12)),
                  const SizedBox(width: 10),
                  Text(df.format(m.startTime.toLocal()),
                      style: const TextStyle(
                          color: AppTheme.textDisabled, fontSize: 11)),
                ],
              ),
            );
          }),
      ],
    );
  }
}

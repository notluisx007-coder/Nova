import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/models/sports.dart';
import '../data/sports_repository.dart';

// Provider for sport-specific upcoming events
final sportUpcomingProvider = FutureProvider.family<List<SportsEvent>, String>(
  (ref, sport) async {
    final repo = ref.read(sportsRepositoryProvider.notifier);
    return repo.fetchUpcomingEvents(sport: sport);
  },
);

class SportsCategoryScreen extends ConsumerStatefulWidget {
  final String sport;
  const SportsCategoryScreen({super.key, required this.sport});

  @override
  ConsumerState<SportsCategoryScreen> createState() =>
      _SportsCategoryScreenState();
}

class _SportsCategoryScreenState extends ConsumerState<SportsCategoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  SportType get _sportType => SportType.values.firstWhere(
        (s) => s.apiKey == widget.sport,
        orElse: () => SportType.other,
      );

  @override
  Widget build(BuildContext context) {
    final sport = _sportType;

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceBackground,
        title: Row(
          children: [
            Text(sport.icon, style: const TextStyle(fontSize: 20)),
            const SizedBox(width: 8),
            Text(
              sport.displayName,
              style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w700,
                  fontFamily: 'Inter'),
            ),
          ],
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded,
              color: AppTheme.textSecondary),
          onPressed: () => context.go('/sports'),
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Live'),
            Tab(text: 'Upcoming'),
            Tab(text: 'Results')
          ],
          indicatorColor: AppTheme.primaryCyan,
          labelColor: AppTheme.primaryCyan,
          unselectedLabelColor: AppTheme.textSecondary,
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _SportEventsList(sport: widget.sport, filter: 'live'),
          _SportEventsList(sport: widget.sport, filter: 'upcoming'),
          _SportEventsList(sport: widget.sport, filter: 'results'),
        ],
      ),
    );
  }
}

class _SportEventsList extends ConsumerWidget {
  final String sport;
  final String filter;
  const _SportEventsList({required this.sport, required this.filter});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    if (filter == 'live') {
      final all = ref.watch(liveEventsStreamProvider);
      return all.when(
        data: (events) {
          final filtered =
              events.where((e) => e.sport.apiKey == sport).toList();
          return _buildList(context, filtered);
        },
        loading: () => const Center(
            child: CircularProgressIndicator(color: AppTheme.primaryCyan)),
        error: (e, _) => _errorWidget(e.toString()),
      );
    } else {
      final upcoming = ref.watch(sportUpcomingProvider(sport));
      return upcoming.when(
        data: (events) {
          final filtered = filter == 'results'
              ? events.where((e) => e.status == MatchStatus.finished).toList()
              : events.where((e) => e.status == MatchStatus.scheduled).toList();
          return _buildList(context, filtered);
        },
        loading: () => const Center(
            child: CircularProgressIndicator(color: AppTheme.primaryCyan)),
        error: (e, _) => _errorWidget(e.toString()),
      );
    }
  }

  Widget _buildList(BuildContext context, List<SportsEvent> events) {
    if (events.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.search_off_rounded,
                size: 40, color: AppTheme.textSecondary),
            const SizedBox(height: 12),
            Text(
              filter == 'live'
                  ? 'No live events at the moment.'
                  : filter == 'upcoming'
                      ? 'No upcoming fixtures found.'
                      : 'No results available.',
              style:
                  const TextStyle(color: AppTheme.textSecondary, fontSize: 14),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: events.length,
      itemBuilder: (context, index) {
        final event = events[index];
        return GestureDetector(
          onTap: () => context.go('/sports/match/${event.id}'),
          child: Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.surfaceCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.surfaceBorder),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    event.homeTeamName,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w600),
                    textAlign: TextAlign.end,
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: event.homeScore != null
                      ? Text(
                          '${event.homeScore} - ${event.awayScore}',
                          style: const TextStyle(
                              color: AppTheme.textPrimary,
                              fontSize: 16,
                              fontWeight: FontWeight.w700),
                        )
                      : Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              _formatDate(event.startTime),
                              style: const TextStyle(
                                  color: AppTheme.textSecondary, fontSize: 10),
                            ),
                            Text(
                              _formatTime(event.startTime),
                              style: const TextStyle(
                                  color: AppTheme.primaryCyan, fontSize: 13),
                            ),
                          ],
                        ),
                ),
                Expanded(
                  child: Text(
                    event.awayTeamName,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _errorWidget(String msg) {
    return Center(
      child: Text(msg,
          style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
    );
  }

  String _formatDate(DateTime dt) {
    final local = dt.toLocal();
    return '${local.day}/${local.month}';
  }

  String _formatTime(DateTime dt) {
    final local = dt.toLocal();
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }
}

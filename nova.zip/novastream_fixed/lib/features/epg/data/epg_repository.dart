import 'dart:async';

import 'package:dio/dio.dart';
import 'package:drift/drift.dart' hide isNull;
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:uuid/uuid.dart';

import '../../../core/database/app_database.dart';
import '../../../shared/models/channel.dart';
import 'xmltv_parser.dart';

part 'epg_repository.g.dart';

typedef ChannelDateParams = ({String channelId, DateTime date});

/// How an app channel was matched to a guide channel.
enum GuideMatchMode { manual, tvgId, nameFallback, none }

@riverpod
Stream<List<EpgSource>> epgSources(EpgSourcesRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db.select(db.epgSourcesTable).watch().map(
        (rows) => rows
            .map((r) => EpgSource(id: r.id, name: r.name, url: r.url))
            .toList(),
      );
}

@riverpod
Stream<List<EpgSourceFull>> epgSourcesFull(EpgSourcesFullRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db.select(db.epgSourcesTable).watch().map((rows) => rows
      .map((r) => EpgSourceFull(
            id: r.id,
            name: r.name,
            url: r.url,
            status: r.status,
            channelCount: r.channelCount,
            lastRefresh: r.lastRefresh,
            isEnabled: r.isEnabled,
          ))
      .toList());
}

@riverpod
Future<List<EpgProgramme>> channelProgrammes(
    ChannelProgrammesRef ref, ChannelDateParams params) async {
  final db = ref.watch(appDatabaseProvider);
  final start = DateTime(params.date.year, params.date.month, params.date.day);
  final end = start.add(const Duration(days: 1));
  final rows =
      await db.getProgrammesForGuideChannel(params.channelId, start, end);
  return rows.map(_programmeFromRow).toList();
}

@riverpod
Future<EpgProgramme?> currentProgramme(
    CurrentProgrammeRef ref, String guideChannelId) async {
  final db = ref.watch(appDatabaseProvider);
  final row = await db.getCurrentProgrammeForGuideChannel(guideChannelId);
  return row != null ? _programmeFromRow(row) : null;
}

/// EPG guide channels available for manual mapping, per guide source.
@riverpod
Future<List<XmltvChannelInfo>> epgChannelDirectory(
    EpgChannelDirectoryRef ref, String epgSourceId) async {
  final db = ref.watch(appDatabaseProvider);
  final rows = await db.getEpgChannels(epgSourceId);
  return rows
      .map((r) => XmltvChannelInfo(
            xmltvChannelId: r.xmltvChannelId,
            displayName: r.displayName,
            normalizedName: r.normalizedName,
          ))
      .toList();
}

/// Resolves the current guide match for [channel]: manual mapping first,
/// then tvg-id, then normalised-name fallback. Watched by the guide mapping
/// sheet so the match row updates as soon as a mapping changes.
@riverpod
Future<(String?, GuideMatchMode)> channelGuideMatch(
    ChannelGuideMatchRef ref, IptvChannel channel) async {
  final repo = ref.watch(epgRepositoryProvider.notifier);
  return repo.resolveGuideChannel(channel);
}

@riverpod
class EpgRepository extends _$EpgRepository {
  static const _uuid = Uuid();

  /// Guards against concurrent imports from the same URL.
  static final _importing = <String>{};

  @override
  Future<void> build() async {}

  bool isImporting(String sourceId) => _importing.contains(sourceId);

  Future<void> addEpgSource(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null ||
        (uri.scheme != 'http' && uri.scheme != 'https') ||
        uri.host.isEmpty) {
      throw const FormatException(
          'Invalid EPG URL — must be http:// or https://');
    }

    final db = ref.read(appDatabaseProvider);
    final id = _uuid.v4();
    final name = uri.host;

    await db.into(db.epgSourcesTable).insertOnConflictUpdate(
          EpgSourcesTableCompanion(
            id: Value(id),
            name: Value(name),
            url: Value(url),
            isEnabled: const Value(true),
            status: const Value('unconfigured'),
          ),
        );

    // Kick off import without blocking the caller.
    unawaited(_importFromUrl(id, url));
  }

  /// Re-downloads and re-imports a guide. Returns when the refresh attempt
  /// finishes; failures keep the last good guide data (see [_importFromUrl]).
  Future<GuideImportResult> refreshEpgSource(
      String sourceId, String url) async {
    if (_importing.contains(sourceId)) {
      return GuideImportResult.failure('EPG import already in progress');
    }
    return _importFromUrl(sourceId, url);
  }

  Future<void> removeEpgSource(String sourceId) async {
    final db = ref.read(appDatabaseProvider);
    await db.transaction(() async {
      await db.deleteProgrammesForEpgSource(sourceId);
      await db.deleteEpgChannelsForSource(sourceId);
      // Manual mappings that pointed at this guide become meaningless.
      await (db.delete(db.epgChannelMappingsTable)
            ..where((t) => t.epgSourceId.equals(sourceId)))
          .go();
      await (db.delete(db.epgSourcesTable)..where((t) => t.id.equals(sourceId)))
          .go();
    });
  }

  /// Download → parse → validate → transactional replace.
  ///
  /// The previous guide dataset is only replaced after the new document has
  /// been downloaded AND fully parsed AND validated, and the replacement
  /// happens in ONE transaction (programmes + channel directory). If the
  /// download or parse fails, the last good dataset is left untouched and
  /// the error is recorded on the source row.
  Future<GuideImportResult> _importFromUrl(String sourceId, String url) async {
    if (_importing.contains(sourceId)) {
      return GuideImportResult.failure('EPG import already in progress');
    }
    _importing.add(sourceId);

    final db = ref.read(appDatabaseProvider);
    final dio = Dio(BaseOptions(
      connectTimeout: const Duration(seconds: 20),
      receiveTimeout: const Duration(seconds: 120),
    ));

    try {
      await db.into(db.epgSourcesTable).insertOnConflictUpdate(
            EpgSourcesTableCompanion(
              id: Value(sourceId),
              name: Value(Uri.parse(url).host),
              url: Value(url),
              status: const Value('connecting'),
            ),
          );

      // 1. Download.
      final response = await dio.get<String>(
        url,
        options: Options(
          responseType: ResponseType.plain,
          headers: {'User-Agent': 'NovaStream/1.0'},
        ),
      );

      final content = response.data ?? '';
      if (content.isEmpty) {
        throw const FormatException('Empty EPG response');
      }

      // 2. Parse + validate fully (production parser; malformed individual
      //    records are skipped and counted, invalid documents throw).
      final parsed = XmltvParser.parse(content);
      if (!parsed.hasProgrammes) {
        throw const FormatException(
            'EPG contains no usable programmes — keeping previous guide');
      }

      // 3. Transactional replace of programmes + channel directory.
      int written = 0;
      await db.transaction(() async {
        await db.deleteProgrammesForEpgSource(sourceId);
        await db.deleteEpgChannelsForSource(sourceId);

        await db.batch((batch) {
          for (final ch in parsed.channels) {
            batch.insert(
              db.epgChannelsTable,
              EpgChannelsTableCompanion(
                id: Value('$sourceId::${ch.xmltvChannelId}'),
                epgSourceId: Value(sourceId),
                xmltvChannelId: Value(ch.xmltvChannelId),
                displayName: Value(ch.displayName),
                normalizedName: Value(ch.normalizedName),
              ),
              onConflict: DoUpdate((_) => EpgChannelsTableCompanion(
                    displayName: Value(ch.displayName),
                    normalizedName: Value(ch.normalizedName),
                  )),
            );
          }
          for (final p in parsed.programmes) {
            batch.insert(
              db.epgProgrammesTable,
              EpgProgrammesTableCompanion(
                id: Value('${sourceId}_${p.id}'),
                channelId: Value(p.channelId),
                title: Value(p.title),
                description: Value(p.description),
                category: Value(p.category),
                language: Value(p.language),
                startTime: Value(p.startTime),
                endTime: Value(p.endTime),
                sourceId: Value(sourceId),
              ),
              onConflict: DoUpdate((_) => const EpgProgrammesTableCompanion()),
            );
          }
        });
        written = parsed.programmes.length;
      });

      // 4. Prune programmes that have been over for two days (global).
      await db.clearOldProgrammes();

      await db.into(db.epgSourcesTable).insertOnConflictUpdate(
            EpgSourcesTableCompanion(
              id: Value(sourceId),
              name: Value(Uri.parse(url).host),
              url: Value(url),
              status: const Value('active'),
              channelCount: Value(parsed.channels.length.toString()),
              lastRefresh: Value(DateTime.now()),
            ),
          );

      return GuideImportResult(
        success: true,
        programmeCount: written,
        channelCount: parsed.channels.length,
        skippedRecords: parsed.skippedRecords,
      );
    } on DioException catch (e) {
      final msg = _dioError(e);
      await db.into(db.epgSourcesTable).insertOnConflictUpdate(
            EpgSourcesTableCompanion(
              id: Value(sourceId),
              name: Value(Uri.parse(url).host),
              url: Value(url),
              status: Value('error: $msg'),
            ),
          );
      return GuideImportResult.failure(msg);
    } catch (e) {
      final msg =
          e is FormatException ? e.message : e.toString().split('\n').first;
      await db.into(db.epgSourcesTable).insertOnConflictUpdate(
            EpgSourcesTableCompanion(
              id: Value(sourceId),
              name: Value(Uri.parse(url).host),
              url: Value(url),
              status: Value('error: $msg'),
            ),
          );
      return GuideImportResult.failure(msg);
    } finally {
      _importing.remove(sourceId);
    }
  }

  // ---------------------------------------------------------------------------
  // Guide-channel resolution: manual mapping → tvg-id → normalized name.
  // ---------------------------------------------------------------------------

  Future<(String?, GuideMatchMode)> resolveGuideChannel(
      IptvChannel channel) async {
    final db = ref.read(appDatabaseProvider);

    // 1. Manual mapping always wins.
    final manual = await db.getMappingForChannel(channel.sourceId, channel.id);
    if (manual != null) {
      // A manual mapping may target a specific guide source; otherwise any.
      if (manual.epgSourceId == null) {
        return (manual.epgChannelId, GuideMatchMode.manual);
      }
      final exists = await (db.select(db.epgChannelsTable)
            ..where((t) =>
                t.epgSourceId.equals(manual.epgSourceId!) &
                t.xmltvChannelId.equals(manual.epgChannelId)))
          .getSingleOrNull();
      if (exists != null) {
        return (manual.epgChannelId, GuideMatchMode.manual);
      }
      // The mapped guide channel vanished from the guide — fall through.
    }

    final epgSources = await db.select(db.epgSourcesTable).get();

    // 2. tvg-id exact match against guide channel ids.
    final tvgId = channel.tvgId?.trim();
    if (tvgId != null && tvgId.isNotEmpty) {
      for (final src in epgSources) {
        final byId = await (db.select(db.epgChannelsTable)
              ..where((t) =>
                  t.epgSourceId.equals(src.id) &
                  t.xmltvChannelId.equals(tvgId)))
            .getSingleOrNull();
        if (byId != null) return (tvgId, GuideMatchMode.tvgId);
      }
    }

    // 3. Normalized-name exact-match fallback. Never maps unrelated
    //    channels: the normalized names must be exactly equal.
    final normalized = XmltvParser.normalizeName(channel.name);
    if (normalized.isNotEmpty) {
      for (final src in epgSources) {
        final byName =
            await db.findEpgChannelByNormalizedName(normalized, src.id);
        if (byName != null) {
          return (byName.xmltvChannelId, GuideMatchMode.nameFallback);
        }
      }
    }

    return (null, GuideMatchMode.none);
  }

  // ---------------------------------------------------------------------------
  // Manual mapping management (persisted independently of refreshes).
  // ---------------------------------------------------------------------------

  Future<void> setManualMapping({
    required IptvChannel channel,
    required String epgChannelId,
    String? epgSourceId,
  }) {
    final db = ref.read(appDatabaseProvider);
    return db.setManualEpgMapping(
      sourceId: channel.sourceId,
      appChannelId: channel.id,
      epgChannelId: epgChannelId,
      epgSourceId: epgSourceId,
    );
  }

  Future<void> removeManualMapping(IptvChannel channel) {
    final db = ref.read(appDatabaseProvider);
    return db.removeManualEpgMapping(channel.sourceId, channel.id);
  }

  String _dioError(DioException e) => switch (e.type) {
        DioExceptionType.connectionTimeout => 'Connection timed out',
        DioExceptionType.receiveTimeout => 'Request timed out',
        DioExceptionType.connectionError => 'No network connection',
        DioExceptionType.badResponse =>
          'Server error (${e.response?.statusCode ?? "unknown"})',
        _ => e.message ?? 'Network error',
      };
}

class EpgSource {
  final String id;
  final String name;
  final String url;
  EpgSource({required this.id, required this.name, required this.url});
}

class EpgSourceFull {
  final String id;
  final String name;
  final String url;
  final String status;
  final String? channelCount;
  final DateTime? lastRefresh;
  final bool isEnabled;
  EpgSourceFull({
    required this.id,
    required this.name,
    required this.url,
    required this.status,
    this.channelCount,
    this.lastRefresh,
    required this.isEnabled,
  });
}

class GuideImportResult {
  final bool success;
  final int programmeCount;
  final int channelCount;
  final int skippedRecords;
  final String? errorMessage;

  const GuideImportResult({
    required this.success,
    this.programmeCount = 0,
    this.channelCount = 0,
    this.skippedRecords = 0,
    this.errorMessage,
  });

  factory GuideImportResult.failure(String message) => GuideImportResult(
        success: false,
        errorMessage: message,
      );
}

EpgProgramme _programmeFromRow(EpgProgrammesTableData row) {
  return EpgProgramme(
    id: row.id,
    channelId: row.channelId,
    title: row.title,
    description: row.description,
    category: row.category,
    language: row.language,
    startTime: row.startTime,
    endTime: row.endTime,
    sourceId: row.sourceId,
  );
}

// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'epg_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$epgSourcesHash() => r'fc4dde1150bcfe93670d75ba067149a910c70d10';

/// See also [epgSources].
@ProviderFor(epgSources)
final epgSourcesProvider = AutoDisposeStreamProvider<List<EpgSource>>.internal(
  epgSources,
  name: r'epgSourcesProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$epgSourcesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef EpgSourcesRef = AutoDisposeStreamProviderRef<List<EpgSource>>;
String _$epgSourcesFullHash() => r'2c35eaf01b0f356dc3f0304d3810e0799f7a83c2';

/// See also [epgSourcesFull].
@ProviderFor(epgSourcesFull)
final epgSourcesFullProvider =
    AutoDisposeStreamProvider<List<EpgSourceFull>>.internal(
  epgSourcesFull,
  name: r'epgSourcesFullProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$epgSourcesFullHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef EpgSourcesFullRef = AutoDisposeStreamProviderRef<List<EpgSourceFull>>;
String _$channelProgrammesHash() => r'0879d99feb7a8e778d9cd91fc19f0d61cb96711a';

/// Copied from Dart SDK
class _SystemHash {
  _SystemHash._();

  static int combine(int hash, int value) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + value);
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x0007ffff & hash) << 10));
    return hash ^ (hash >> 6);
  }

  static int finish(int hash) {
    // ignore: parameter_assignments
    hash = 0x1fffffff & (hash + ((0x03ffffff & hash) << 3));
    // ignore: parameter_assignments
    hash = hash ^ (hash >> 11);
    return 0x1fffffff & (hash + ((0x00003fff & hash) << 15));
  }
}

/// See also [channelProgrammes].
@ProviderFor(channelProgrammes)
const channelProgrammesProvider = ChannelProgrammesFamily();

/// See also [channelProgrammes].
class ChannelProgrammesFamily extends Family<AsyncValue<List<EpgProgramme>>> {
  /// See also [channelProgrammes].
  const ChannelProgrammesFamily();

  /// See also [channelProgrammes].
  ChannelProgrammesProvider call(
    ({String channelId, DateTime date}) params,
  ) {
    return ChannelProgrammesProvider(
      params,
    );
  }

  @override
  ChannelProgrammesProvider getProviderOverride(
    covariant ChannelProgrammesProvider provider,
  ) {
    return call(
      provider.params,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'channelProgrammesProvider';
}

/// See also [channelProgrammes].
class ChannelProgrammesProvider
    extends AutoDisposeFutureProvider<List<EpgProgramme>> {
  /// See also [channelProgrammes].
  ChannelProgrammesProvider(
    ({String channelId, DateTime date}) params,
  ) : this._internal(
          (ref) => channelProgrammes(
            ref as ChannelProgrammesRef,
            params,
          ),
          from: channelProgrammesProvider,
          name: r'channelProgrammesProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$channelProgrammesHash,
          dependencies: ChannelProgrammesFamily._dependencies,
          allTransitiveDependencies:
              ChannelProgrammesFamily._allTransitiveDependencies,
          params: params,
        );

  ChannelProgrammesProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.params,
  }) : super.internal();

  final ({String channelId, DateTime date}) params;

  @override
  Override overrideWith(
    FutureOr<List<EpgProgramme>> Function(ChannelProgrammesRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ChannelProgrammesProvider._internal(
        (ref) => create(ref as ChannelProgrammesRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        params: params,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<List<EpgProgramme>> createElement() {
    return _ChannelProgrammesProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ChannelProgrammesProvider && other.params == params;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, params.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ChannelProgrammesRef on AutoDisposeFutureProviderRef<List<EpgProgramme>> {
  /// The parameter `params` of this provider.
  ({String channelId, DateTime date}) get params;
}

class _ChannelProgrammesProviderElement
    extends AutoDisposeFutureProviderElement<List<EpgProgramme>>
    with ChannelProgrammesRef {
  _ChannelProgrammesProviderElement(super.provider);

  @override
  ({String channelId, DateTime date}) get params =>
      (origin as ChannelProgrammesProvider).params;
}

String _$currentProgrammeHash() => r'3dd3552a06c45204f4a77777481d5b0df2944343';

/// See also [currentProgramme].
@ProviderFor(currentProgramme)
const currentProgrammeProvider = CurrentProgrammeFamily();

/// See also [currentProgramme].
class CurrentProgrammeFamily extends Family<AsyncValue<EpgProgramme?>> {
  /// See also [currentProgramme].
  const CurrentProgrammeFamily();

  /// See also [currentProgramme].
  CurrentProgrammeProvider call(
    String guideChannelId,
  ) {
    return CurrentProgrammeProvider(
      guideChannelId,
    );
  }

  @override
  CurrentProgrammeProvider getProviderOverride(
    covariant CurrentProgrammeProvider provider,
  ) {
    return call(
      provider.guideChannelId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'currentProgrammeProvider';
}

/// See also [currentProgramme].
class CurrentProgrammeProvider
    extends AutoDisposeFutureProvider<EpgProgramme?> {
  /// See also [currentProgramme].
  CurrentProgrammeProvider(
    String guideChannelId,
  ) : this._internal(
          (ref) => currentProgramme(
            ref as CurrentProgrammeRef,
            guideChannelId,
          ),
          from: currentProgrammeProvider,
          name: r'currentProgrammeProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$currentProgrammeHash,
          dependencies: CurrentProgrammeFamily._dependencies,
          allTransitiveDependencies:
              CurrentProgrammeFamily._allTransitiveDependencies,
          guideChannelId: guideChannelId,
        );

  CurrentProgrammeProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.guideChannelId,
  }) : super.internal();

  final String guideChannelId;

  @override
  Override overrideWith(
    FutureOr<EpgProgramme?> Function(CurrentProgrammeRef provider) create,
  ) {
    return ProviderOverride(
      origin: this,
      override: CurrentProgrammeProvider._internal(
        (ref) => create(ref as CurrentProgrammeRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        guideChannelId: guideChannelId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<EpgProgramme?> createElement() {
    return _CurrentProgrammeProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is CurrentProgrammeProvider &&
        other.guideChannelId == guideChannelId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, guideChannelId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin CurrentProgrammeRef on AutoDisposeFutureProviderRef<EpgProgramme?> {
  /// The parameter `guideChannelId` of this provider.
  String get guideChannelId;
}

class _CurrentProgrammeProviderElement
    extends AutoDisposeFutureProviderElement<EpgProgramme?>
    with CurrentProgrammeRef {
  _CurrentProgrammeProviderElement(super.provider);

  @override
  String get guideChannelId =>
      (origin as CurrentProgrammeProvider).guideChannelId;
}

String _$epgChannelDirectoryHash() =>
    r'9c7222ba3589d3ee14affb6c0f94a057dadc9eb9';

/// EPG guide channels available for manual mapping, per guide source.
///
/// Copied from [epgChannelDirectory].
@ProviderFor(epgChannelDirectory)
const epgChannelDirectoryProvider = EpgChannelDirectoryFamily();

/// EPG guide channels available for manual mapping, per guide source.
///
/// Copied from [epgChannelDirectory].
class EpgChannelDirectoryFamily
    extends Family<AsyncValue<List<XmltvChannelInfo>>> {
  /// EPG guide channels available for manual mapping, per guide source.
  ///
  /// Copied from [epgChannelDirectory].
  const EpgChannelDirectoryFamily();

  /// EPG guide channels available for manual mapping, per guide source.
  ///
  /// Copied from [epgChannelDirectory].
  EpgChannelDirectoryProvider call(
    String epgSourceId,
  ) {
    return EpgChannelDirectoryProvider(
      epgSourceId,
    );
  }

  @override
  EpgChannelDirectoryProvider getProviderOverride(
    covariant EpgChannelDirectoryProvider provider,
  ) {
    return call(
      provider.epgSourceId,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'epgChannelDirectoryProvider';
}

/// EPG guide channels available for manual mapping, per guide source.
///
/// Copied from [epgChannelDirectory].
class EpgChannelDirectoryProvider
    extends AutoDisposeFutureProvider<List<XmltvChannelInfo>> {
  /// EPG guide channels available for manual mapping, per guide source.
  ///
  /// Copied from [epgChannelDirectory].
  EpgChannelDirectoryProvider(
    String epgSourceId,
  ) : this._internal(
          (ref) => epgChannelDirectory(
            ref as EpgChannelDirectoryRef,
            epgSourceId,
          ),
          from: epgChannelDirectoryProvider,
          name: r'epgChannelDirectoryProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$epgChannelDirectoryHash,
          dependencies: EpgChannelDirectoryFamily._dependencies,
          allTransitiveDependencies:
              EpgChannelDirectoryFamily._allTransitiveDependencies,
          epgSourceId: epgSourceId,
        );

  EpgChannelDirectoryProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.epgSourceId,
  }) : super.internal();

  final String epgSourceId;

  @override
  Override overrideWith(
    FutureOr<List<XmltvChannelInfo>> Function(EpgChannelDirectoryRef provider)
        create,
  ) {
    return ProviderOverride(
      origin: this,
      override: EpgChannelDirectoryProvider._internal(
        (ref) => create(ref as EpgChannelDirectoryRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        epgSourceId: epgSourceId,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<List<XmltvChannelInfo>> createElement() {
    return _EpgChannelDirectoryProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is EpgChannelDirectoryProvider &&
        other.epgSourceId == epgSourceId;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, epgSourceId.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin EpgChannelDirectoryRef
    on AutoDisposeFutureProviderRef<List<XmltvChannelInfo>> {
  /// The parameter `epgSourceId` of this provider.
  String get epgSourceId;
}

class _EpgChannelDirectoryProviderElement
    extends AutoDisposeFutureProviderElement<List<XmltvChannelInfo>>
    with EpgChannelDirectoryRef {
  _EpgChannelDirectoryProviderElement(super.provider);

  @override
  String get epgSourceId => (origin as EpgChannelDirectoryProvider).epgSourceId;
}

String _$channelGuideMatchHash() => r'2e4016557a422cffbba0837fd73953456856cef4';

/// Resolves the current guide match for [channel]: manual mapping first,
/// then tvg-id, then normalised-name fallback. Watched by the guide mapping
/// sheet so the match row updates as soon as a mapping changes.
///
/// Copied from [channelGuideMatch].
@ProviderFor(channelGuideMatch)
const channelGuideMatchProvider = ChannelGuideMatchFamily();

/// Resolves the current guide match for [channel]: manual mapping first,
/// then tvg-id, then normalised-name fallback. Watched by the guide mapping
/// sheet so the match row updates as soon as a mapping changes.
///
/// Copied from [channelGuideMatch].
class ChannelGuideMatchFamily
    extends Family<AsyncValue<(String?, GuideMatchMode)>> {
  /// Resolves the current guide match for [channel]: manual mapping first,
  /// then tvg-id, then normalised-name fallback. Watched by the guide mapping
  /// sheet so the match row updates as soon as a mapping changes.
  ///
  /// Copied from [channelGuideMatch].
  const ChannelGuideMatchFamily();

  /// Resolves the current guide match for [channel]: manual mapping first,
  /// then tvg-id, then normalised-name fallback. Watched by the guide mapping
  /// sheet so the match row updates as soon as a mapping changes.
  ///
  /// Copied from [channelGuideMatch].
  ChannelGuideMatchProvider call(
    IptvChannel channel,
  ) {
    return ChannelGuideMatchProvider(
      channel,
    );
  }

  @override
  ChannelGuideMatchProvider getProviderOverride(
    covariant ChannelGuideMatchProvider provider,
  ) {
    return call(
      provider.channel,
    );
  }

  static const Iterable<ProviderOrFamily>? _dependencies = null;

  @override
  Iterable<ProviderOrFamily>? get dependencies => _dependencies;

  static const Iterable<ProviderOrFamily>? _allTransitiveDependencies = null;

  @override
  Iterable<ProviderOrFamily>? get allTransitiveDependencies =>
      _allTransitiveDependencies;

  @override
  String? get name => r'channelGuideMatchProvider';
}

/// Resolves the current guide match for [channel]: manual mapping first,
/// then tvg-id, then normalised-name fallback. Watched by the guide mapping
/// sheet so the match row updates as soon as a mapping changes.
///
/// Copied from [channelGuideMatch].
class ChannelGuideMatchProvider
    extends AutoDisposeFutureProvider<(String?, GuideMatchMode)> {
  /// Resolves the current guide match for [channel]: manual mapping first,
  /// then tvg-id, then normalised-name fallback. Watched by the guide mapping
  /// sheet so the match row updates as soon as a mapping changes.
  ///
  /// Copied from [channelGuideMatch].
  ChannelGuideMatchProvider(
    IptvChannel channel,
  ) : this._internal(
          (ref) => channelGuideMatch(
            ref as ChannelGuideMatchRef,
            channel,
          ),
          from: channelGuideMatchProvider,
          name: r'channelGuideMatchProvider',
          debugGetCreateSourceHash:
              const bool.fromEnvironment('dart.vm.product')
                  ? null
                  : _$channelGuideMatchHash,
          dependencies: ChannelGuideMatchFamily._dependencies,
          allTransitiveDependencies:
              ChannelGuideMatchFamily._allTransitiveDependencies,
          channel: channel,
        );

  ChannelGuideMatchProvider._internal(
    super._createNotifier, {
    required super.name,
    required super.dependencies,
    required super.allTransitiveDependencies,
    required super.debugGetCreateSourceHash,
    required super.from,
    required this.channel,
  }) : super.internal();

  final IptvChannel channel;

  @override
  Override overrideWith(
    FutureOr<(String?, GuideMatchMode)> Function(ChannelGuideMatchRef provider)
        create,
  ) {
    return ProviderOverride(
      origin: this,
      override: ChannelGuideMatchProvider._internal(
        (ref) => create(ref as ChannelGuideMatchRef),
        from: from,
        name: null,
        dependencies: null,
        allTransitiveDependencies: null,
        debugGetCreateSourceHash: null,
        channel: channel,
      ),
    );
  }

  @override
  AutoDisposeFutureProviderElement<(String?, GuideMatchMode)> createElement() {
    return _ChannelGuideMatchProviderElement(this);
  }

  @override
  bool operator ==(Object other) {
    return other is ChannelGuideMatchProvider && other.channel == channel;
  }

  @override
  int get hashCode {
    var hash = _SystemHash.combine(0, runtimeType.hashCode);
    hash = _SystemHash.combine(hash, channel.hashCode);

    return _SystemHash.finish(hash);
  }
}

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
mixin ChannelGuideMatchRef
    on AutoDisposeFutureProviderRef<(String?, GuideMatchMode)> {
  /// The parameter `channel` of this provider.
  IptvChannel get channel;
}

class _ChannelGuideMatchProviderElement
    extends AutoDisposeFutureProviderElement<(String?, GuideMatchMode)>
    with ChannelGuideMatchRef {
  _ChannelGuideMatchProviderElement(super.provider);

  @override
  IptvChannel get channel => (origin as ChannelGuideMatchProvider).channel;
}

String _$epgRepositoryHash() => r'e84cbed14873659c7dafb355ccd3a1b8c10af194';

/// See also [EpgRepository].
@ProviderFor(EpgRepository)
final epgRepositoryProvider =
    AutoDisposeAsyncNotifierProvider<EpgRepository, void>.internal(
  EpgRepository.new,
  name: r'epgRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$epgRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EpgRepository = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package

import 'package:xml/xml.dart';

import '../../../shared/models/channel.dart';

/// A `<channel>` entry declared by an XMLTV guide.
class XmltvChannelInfo {
  final String xmltvChannelId;
  final String displayName;
  final String normalizedName;

  const XmltvChannelInfo({
    required this.xmltvChannelId,
    required this.displayName,
    required this.normalizedName,
  });
}

/// Result of parsing a complete XMLTV document.
class XmltvParseResult {
  /// Programmes that passed validation, start times in UTC.
  final List<EpgProgramme> programmes;

  /// Channel directory declared by the guide.
  final List<XmltvChannelInfo> channels;

  /// Number of individual `<programme>` records skipped because they were
  /// malformed or missing required fields. Valid records are still usable.
  final int skippedRecords;

  /// Human-readable reasons for the first few skipped records.
  final List<String> errors;

  const XmltvParseResult({
    required this.programmes,
    required this.channels,
    required this.skippedRecords,
    required this.errors,
  });

  bool get hasProgrammes => programmes.isNotEmpty;
}

/// Production XMLTV parser used by [EpgRepository]. Public so that tests
/// exercise exactly the code that runs in the app — tests must not copy this
/// logic.
class XmltvParser {
  /// XMLTV accepts `YYYYMMDDHHMMSS [+|-]HHMM` (the seconds and the offset are
  /// both optional per the DTD used in the wild).
  static final RegExp _timePattern =
      RegExp(r'^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-]\d{4})?$');

  /// Parses [content] into a validated result.
  ///
  /// * A document that is not well-formed XML throws [FormatException] —
  ///   callers must keep the previous guide data in that case.
  /// * Individually malformed `<programme>` records are skipped and counted,
  ///   so one bad entry does not discard the whole guide.
  static XmltvParseResult parse(String content) {
    XmlDocument document;
    try {
      document = XmlDocument.parse(content);
    } on XmlException catch (e) {
      throw FormatException('XMLTV parse error: ${e.message}');
    } catch (e) {
      throw FormatException('XMLTV parse error: $e');
    }

    final channels = <XmltvChannelInfo>[];
    final channelIds = <String>{};
    for (final node in document.findAllElements('channel')) {
      final id = node.getAttribute('id') ?? '';
      if (id.isEmpty || channelIds.contains(id)) continue;
      final name =
          node.findElements('display-name').firstOrNull?.innerText.trim() ?? id;
      channelIds.add(id);
      channels.add(XmltvChannelInfo(
        xmltvChannelId: id,
        displayName: name,
        normalizedName: normalizeName(name),
      ));
    }

    final programmes = <EpgProgramme>[];
    final errors = <String>[];
    int skipped = 0;
    final seenProgrammeKeys = <String>{};

    for (final prog in document.findAllElements('programme')) {
      try {
        final channelId = prog.getAttribute('channel') ?? '';
        final startAttr = prog.getAttribute('start') ?? '';
        final stopAttr = prog.getAttribute('stop') ?? '';
        final title =
            prog.findElements('title').firstOrNull?.innerText.trim() ?? '';

        if (channelId.isEmpty) {
          skipped++;
          _addError(errors, 'programme record without channel attribute');
          continue;
        }
        if (startAttr.isEmpty) {
          skipped++;
          _addError(errors, 'programme without start time');
          continue;
        }
        if (title.isEmpty) {
          skipped++;
          _addError(errors, 'programme without title');
          continue;
        }

        final startTime = parseXmltvTime(startAttr);
        if (startTime == null) {
          skipped++;
          _addError(errors, 'unparseable start time "$startAttr"');
          continue;
        }

        var endTime = stopAttr.isNotEmpty ? parseXmltvTime(stopAttr) : null;
        endTime ??= startTime.add(const Duration(hours: 1));
        if (!endTime.isAfter(startTime)) {
          endTime = startTime.add(const Duration(hours: 1));
        }

        // Skip exact duplicate programme slots.
        final key = '${channelId}_$startAttr';
        if (!seenProgrammeKeys.add(key)) {
          skipped++;
          _addError(errors, 'duplicate programme slot $key');
          continue;
        }

        final description = prog.findElements('desc').firstOrNull?.innerText;
        final category = prog.findElements('category').firstOrNull?.innerText;
        final language =
            prog.findElements('title').firstOrNull?.getAttribute('lang');

        programmes.add(EpgProgramme(
          id: key,
          channelId: channelId,
          title: title,
          description: (description != null && description.trim().isNotEmpty)
              ? description.trim()
              : null,
          category: (category != null && category.trim().isNotEmpty)
              ? category.trim()
              : null,
          language: language,
          startTime: startTime,
          endTime: endTime,
          // sourceId is filled in by the repository, which owns the guide.
          sourceId: '',
        ));
      } catch (_) {
        skipped++;
        _addError(errors, 'malformed programme record');
      }
    }

    return XmltvParseResult(
      programmes: programmes,
      channels: channels,
      skippedRecords: skipped,
      errors: errors,
    );
  }

  static void _addError(List<String> errors, String message) {
    if (errors.length < 20) {
      errors.add(message);
    }
  }

  /// Parses an XMLTV timestamp such as `20240101120000 +0000`,
  /// `20240101120000`, or `20240601140000 +0200` into a UTC [DateTime].
  /// Returns null when the value cannot be parsed.
  static DateTime? parseXmltvTime(String xmltvTime) {
    final clean = xmltvTime.trim();
    final match = _timePattern.firstMatch(clean);
    if (match == null) return null;

    final year = int.parse(match.group(1)!);
    final month = int.parse(match.group(2)!);
    final day = int.parse(match.group(3)!);
    final hour = int.parse(match.group(4)!);
    final minute = int.parse(match.group(5)!);
    final second = int.tryParse(match.group(6) ?? '') ?? 0;
    final tzPart = match.group(7);

    Duration offset = Duration.zero;
    if (tzPart != null) {
      final sign = tzPart.startsWith('-') ? -1 : 1;
      final digits = tzPart.substring(1);
      final tzHours = int.tryParse(digits.substring(0, 2)) ?? 0;
      final tzMins = int.tryParse(digits.substring(2, 4)) ?? 0;
      offset = Duration(hours: tzHours, minutes: tzMins) * sign;
    }

    try {
      return DateTime.utc(year, month, day, hour, minute, second)
          .subtract(offset);
    } catch (_) {
      return null;
    }
  }

  /// Normalizes a channel name for fallback matching: lowercase, strip all
  /// non-alphanumeric characters and collapse whitespace so `BBC One HD`,
  /// `bbc-one` and `BBCONE` match each other, while unrelated channels
  /// (different base names) still do not.
  static String normalizeName(String name) {
    final lower = name.toLowerCase().trim();
    final stripped = lower.replaceAll(
        RegExp(
            r'[^a-z0-9\u0400-\u04ff\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]'),
        '');
    return stripped.isEmpty ? lower : stripped;
  }
}

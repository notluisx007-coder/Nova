import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/models/channel.dart';
import '../data/epg_repository.dart';
import '../data/xmltv_parser.dart';

/// Bottom sheet that lets the user manually map (or unmap) an app channel to
/// a guide channel. Shows every imported EPG source and its channel
/// directory with search; manual mappings persist across playlist and guide
/// refreshes because they live in their own table.
Future<void> showGuideMappingSheet(
    BuildContext context, WidgetRef ref, IptvChannel channel) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: AppTheme.surfaceElevated,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
    ),
    builder: (ctx) => _GuideMappingSheet(channel: channel),
  );
}

class _GuideMappingSheet extends ConsumerStatefulWidget {
  final IptvChannel channel;
  const _GuideMappingSheet({required this.channel});

  @override
  ConsumerState<_GuideMappingSheet> createState() => _GuideMappingSheetState();
}

class _GuideMappingSheetState extends ConsumerState<_GuideMappingSheet> {
  String? _selectedSourceId;
  String _search = '';
  bool _loaded = true;

  @override
  Widget build(BuildContext context) {
    final sourcesAsync = ref.watch(epgSourcesProvider);
    final (currentGuideChannelId, currentMode) =
        ref.watch(channelGuideMatchProvider(widget.channel)).valueOrNull ??
            (null, GuideMatchMode.none);

    return SafeArea(
      child: Padding(
        padding:
            EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SizedBox(
          height: MediaQuery.of(context).size.height * 0.72,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 4),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Map to guide channel',
                        style: TextStyle(
                            color: AppTheme.textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter')),
                    const SizedBox(height: 4),
                    Text(
                      'Channel: ${widget.channel.name}',
                      style: const TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                          fontFamily: 'Inter'),
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(
                          currentMode == GuideMatchMode.none
                              ? Icons.link_off_rounded
                              : Icons.link_rounded,
                          size: 14,
                          color: currentMode == GuideMatchMode.none
                              ? AppTheme.statusWarning
                              : AppTheme.primaryCyan,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          switch (currentMode) {
                            GuideMatchMode.manual =>
                              'Manually mapped to "${currentGuideChannelId ?? ''}"',
                            GuideMatchMode.tvgId =>
                              'Matched by tvg-id "${currentGuideChannelId ?? ''}"',
                            GuideMatchMode.nameFallback =>
                              'Matched by name (auto)',
                            GuideMatchMode.none =>
                              'No guide data linked to this channel',
                          },
                          style: TextStyle(
                            color: currentMode == GuideMatchMode.none
                                ? AppTheme.statusWarning
                                : AppTheme.textSecondary,
                            fontSize: 12,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const Divider(color: AppTheme.surfaceBorder, height: 12),

              // Guide source selector
              sourcesAsync.when(
                data: (sources) {
                  if (sources.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(20),
                      child: Text(
                          'No EPG sources imported yet. Add one from the + button.',
                          style: TextStyle(
                              color: AppTheme.textSecondary, fontSize: 13)),
                    );
                  }
                  _selectedSourceId ??= sources.first.id;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        value: _selectedSourceId,
                        isExpanded: true,
                        dropdownColor: AppTheme.surfaceCard,
                        items: sources
                            .map((s) => DropdownMenuItem(
                                  value: s.id,
                                  child: Text(s.name,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                          color: AppTheme.textPrimary,
                                          fontSize: 13)),
                                ))
                            .toList(),
                        onChanged: (v) => setState(() => _selectedSourceId = v),
                      ),
                    ),
                  );
                },
                loading: () => const SizedBox(height: 40),
                error: (_, __) => const SizedBox(height: 40),
              ),

              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 4),
                child: TextField(
                  style: const TextStyle(
                      color: AppTheme.textPrimary, fontSize: 13),
                  decoration: const InputDecoration(
                    hintText: 'Search guide channels…',
                    prefixIcon: Icon(Icons.search_rounded, size: 18),
                    isDense: true,
                  ),
                  onChanged: (v) => setState(() => _search = v),
                ),
              ),

              Expanded(
                child: _selectedSourceId == null
                    ? const SizedBox()
                    : _buildDirectory(currentGuideChannelId, currentMode),
              ),

              // Unmap action
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                child: Row(
                  children: [
                    if (currentMode == GuideMatchMode.manual)
                      TextButton.icon(
                        icon: const Icon(Icons.link_off_rounded,
                            size: 16, color: AppTheme.statusError),
                        label: const Text('Remove manual mapping',
                            style: TextStyle(color: AppTheme.statusError)),
                        onPressed: _loaded ? _unmap : null,
                      ),
                    const Spacer(),
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Done'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDirectory(
      String? currentGuideChannelId, GuideMatchMode currentMode) {
    final directoryAsync =
        ref.watch(epgChannelDirectoryProvider(_selectedSourceId!));
    return directoryAsync.when(
      data: (channels) {
        final q = _search.trim().toLowerCase();
        final filtered = q.isEmpty
            ? channels
            : channels
                .where((c) =>
                    c.displayName.toLowerCase().contains(q) ||
                    c.xmltvChannelId.toLowerCase().contains(q))
                .toList();
        if (filtered.isEmpty) {
          return const Padding(
            padding: EdgeInsets.all(20),
            child: Text('No matching guide channels.',
                style: TextStyle(color: AppTheme.textSecondary, fontSize: 13)),
          );
        }
        return ListView.builder(
          itemCount: filtered.length,
          itemBuilder: (ctx, i) {
            final ch = filtered[i];
            final isCurrent = currentGuideChannelId == ch.xmltvChannelId &&
                currentMode != GuideMatchMode.none;
            return ListTile(
              dense: true,
              leading: Icon(
                isCurrent
                    ? Icons.radio_button_checked_rounded
                    : Icons.radio_button_off_rounded,
                size: 18,
                color: isCurrent ? AppTheme.primaryCyan : AppTheme.textDisabled,
              ),
              title: Text(ch.displayName,
                  style: const TextStyle(
                      color: AppTheme.textPrimary, fontSize: 13),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              subtitle: Text(ch.xmltvChannelId,
                  style: const TextStyle(
                      color: AppTheme.textDisabled, fontSize: 11),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              onTap: () => _map(ch),
            );
          },
        );
      },
      loading: () =>
          const Center(child: CircularProgressIndicator(strokeWidth: 2)),
      error: (e, _) => Padding(
        padding: const EdgeInsets.all(20),
        child: Text('Could not load guide channels: $e',
            style: const TextStyle(color: AppTheme.statusError, fontSize: 12)),
      ),
    );
  }

  Future<void> _map(XmltvChannelInfo target) async {
    setState(() => _loaded = false);
    final repo = ref.read(epgRepositoryProvider.notifier);
    await repo.setManualMapping(
      channel: widget.channel,
      epgChannelId: target.xmltvChannelId,
      epgSourceId: _selectedSourceId,
    );
    // Immediately switch programme lookups to the newly mapped guide channel.
    setState(() => _loaded = true);
    ref.invalidate(channelProgrammesProvider);
    ref.invalidate(currentProgrammeProvider);
    ref.invalidate(channelGuideMatchProvider(widget.channel));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:
            Text('Mapped "${widget.channel.name}" to "${target.displayName}"'),
      ));
    }
  }

  Future<void> _unmap() async {
    setState(() => _loaded = false);
    final repo = ref.read(epgRepositoryProvider.notifier);
    await repo.removeManualMapping(widget.channel);
    setState(() => _loaded = true);
    ref.invalidate(channelProgrammesProvider);
    ref.invalidate(currentProgrammeProvider);
    ref.invalidate(channelGuideMatchProvider(widget.channel));
  }
}

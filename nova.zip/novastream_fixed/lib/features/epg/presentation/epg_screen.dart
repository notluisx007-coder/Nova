import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';

import '../../../core/theme/app_theme.dart';
import '../../../shared/models/channel.dart';
import '../../../shared/widgets/empty_state_widget.dart';
import '../../live_tv/data/channel_repository.dart';
import '../data/epg_repository.dart';
import 'guide_mapping_sheet.dart';

final _epgDateProvider = StateProvider<DateTime>((ref) => DateTime.now());

/// Resolves the current guide-match mode for an app channel (manual mapping,
/// tvg-id match, normalized-name fallback, or none).
final channelGuideMatchProvider = FutureProvider.autoDispose
    .family<GuideMatchMode, IptvChannel>((ref, channel) async {
  final repo = ref.watch(epgRepositoryProvider.notifier);
  final (_, mode) = await repo.resolveGuideChannel(channel);
  return mode;
});

class EpgScreen extends ConsumerWidget {
  const EpgScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final channels = ref.watch(allChannelsProvider);
    final epgSources = ref.watch(epgSourcesProvider);
    final selectedDate = ref.watch(_epgDateProvider);

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        title: const Text('TV Guide'),
        actions: [
          IconButton(
            icon:
                const Icon(Icons.today_rounded, color: AppTheme.textSecondary),
            onPressed: () =>
                ref.read(_epgDateProvider.notifier).state = DateTime.now(),
          ),
          IconButton(
            icon: const Icon(Icons.add_circle_outline_rounded,
                color: AppTheme.textSecondary),
            onPressed: () => _showAddEpgSheet(context, ref),
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0.5),
          child: Container(height: 0.5, color: AppTheme.surfaceBorder),
        ),
      ),
      body: Column(
        children: [
          _DateNav(selectedDate: selectedDate),
          Expanded(
            child: channels.when(
              data: (channelList) {
                if (channelList.isEmpty) {
                  return const EmptyStateWidget(
                    icon: Icons.calendar_view_week_rounded,
                    title: 'No Channels',
                    message: 'Import a playlist to see the TV Guide.',
                  );
                }

                final hasEpg = epgSources.valueOrNull?.isNotEmpty == true;

                return ListView.builder(
                  itemCount: channelList.length,
                  itemBuilder: (ctx, i) {
                    final ch = channelList[i];
                    return _EpgChannelRow(
                      channel: ch,
                      date: selectedDate,
                      hasEpgSource: hasEpg,
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => ErrorStateWidget(message: e.toString()),
            ),
          ),
        ],
      ),
    );
  }

  void _showAddEpgSheet(BuildContext context, WidgetRef ref) {
    final controller = TextEditingController();
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(
            20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Add EPG Source (XMLTV)',
                style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Inter')),
            const SizedBox(height: 4),
            const Text('Import an XMLTV-format guide URL',
                style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 12,
                    fontFamily: 'Inter')),
            const SizedBox(height: 14),
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                hintText: 'https://example.com/guide.xml',
                prefixIcon: Icon(Icons.link_rounded),
              ),
              keyboardType: TextInputType.url,
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  final url = controller.text.trim();
                  if (url.isNotEmpty) {
                    ref.read(epgRepositoryProvider.notifier).addEpgSource(url);
                    Navigator.pop(ctx);
                  }
                },
                child: const Text('Add EPG Source'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DateNav extends ConsumerWidget {
  final DateTime selectedDate;
  const _DateNav({required this.selectedDate});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final days =
        List.generate(7, (i) => DateTime.now().add(Duration(days: i - 1)));

    return Container(
      height: 56,
      color: AppTheme.surfaceCard,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        itemCount: days.length,
        itemBuilder: (ctx, i) {
          final d = days[i];
          final isToday = i == 1;
          final isSelected = _isSameDay(d, selectedDate);

          return GestureDetector(
            onTap: () => ref.read(_epgDateProvider.notifier).state = d,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(right: 6),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              decoration: BoxDecoration(
                color: isSelected
                    ? AppTheme.primaryCyan.withValues(alpha: 0.15)
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                    color: isSelected
                        ? AppTheme.primaryCyan
                        : AppTheme.surfaceBorder),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    isToday ? 'Today' : DateFormat('EEE').format(d),
                    style: TextStyle(
                      color: isSelected
                          ? AppTheme.primaryCyan
                          : AppTheme.textSecondary,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      fontFamily: 'Inter',
                    ),
                  ),
                  Text(
                    DateFormat('d').format(d),
                    style: TextStyle(
                      color: isSelected
                          ? AppTheme.primaryCyan
                          : AppTheme.textPrimary,
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      fontFamily: 'Inter',
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;
}

class _EpgChannelRow extends ConsumerWidget {
  final IptvChannel channel;
  final DateTime date;
  final bool hasEpgSource;

  const _EpgChannelRow({
    required this.channel,
    required this.date,
    required this.hasEpgSource,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final programmesAsync = ref.watch(channelProgrammesProvider(
      (channelId: channel.tvgId ?? channel.id, date: date),
    ));
    final matchInfo = ref.watch(channelGuideMatchProvider(channel));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Channel header
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 4),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppTheme.surfaceCard,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppTheme.surfaceBorder, width: 0.5),
                ),
                child: channel.logoUrl != null
                    ? Image.network(channel.logoUrl!,
                        fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => const Icon(
                            Icons.tv_rounded,
                            size: 18,
                            color: AppTheme.textDisabled))
                    : const Icon(Icons.tv_rounded,
                        size: 18, color: AppTheme.textDisabled),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(channel.name,
                    style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
              ),
              // Guide-match status + manual mapping entry point.
              matchInfo.when(
                data: (mode) => GestureDetector(
                  onTap: () => showGuideMappingSheet(context, ref, channel),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: mode == GuideMatchMode.none
                          ? AppTheme.statusWarning.withValues(alpha: 0.12)
                          : AppTheme.primaryCyan.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: mode == GuideMatchMode.none
                            ? AppTheme.statusWarning.withValues(alpha: 0.4)
                            : AppTheme.primaryCyan.withValues(alpha: 0.4),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          mode == GuideMatchMode.none
                              ? Icons.link_off_rounded
                              : Icons.link_rounded,
                          size: 12,
                          color: mode == GuideMatchMode.none
                              ? AppTheme.statusWarning
                              : AppTheme.primaryCyan,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          switch (mode) {
                            GuideMatchMode.manual => 'Mapped',
                            GuideMatchMode.tvgId => 'tvg-id',
                            GuideMatchMode.nameFallback => 'Auto',
                            GuideMatchMode.none => 'No guide',
                          },
                          style: TextStyle(
                            color: mode == GuideMatchMode.none
                                ? AppTheme.statusWarning
                                : AppTheme.primaryCyan,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Inter',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                loading: () => const SizedBox(width: 12),
                error: (_, __) => const SizedBox(width: 12),
              ),
            ],
          ),
        ),
        // Programmes scroll
        SizedBox(
          height: 60,
          child: programmesAsync.when(
            data: (programmes) {
              if (programmes.isEmpty) {
                return Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 58, vertical: 8),
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceCard,
                      borderRadius: BorderRadius.circular(6),
                      border:
                          Border.all(color: AppTheme.surfaceBorder, width: 0.5),
                    ),
                    child: Text(
                      hasEpgSource
                          ? 'No guide data for this channel'
                          : 'Add an EPG source to see guide',
                      style: const TextStyle(
                          color: AppTheme.textDisabled,
                          fontSize: 11,
                          fontFamily: 'Inter'),
                    ),
                  ),
                );
              }
              return ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.fromLTRB(58, 4, 12, 4),
                itemCount: programmes.length,
                itemBuilder: (ctx, i) =>
                    _ProgrammeChip(programme: programmes[i]),
              );
            },
            loading: () => Padding(
              padding: const EdgeInsets.fromLTRB(58, 8, 12, 8),
              child: Container(
                width: 160,
                decoration: BoxDecoration(
                    color: AppTheme.surfaceCard,
                    borderRadius: BorderRadius.circular(6)),
              ),
            ),
            error: (_, __) => const SizedBox(),
          ),
        ),
        const Divider(height: 0.5, color: AppTheme.surfaceBorder),
      ],
    );
  }
}

class _ProgrammeChip extends StatelessWidget {
  final EpgProgramme programme;
  const _ProgrammeChip({required this.programme});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final isNow =
        now.isAfter(programme.startTime) && now.isBefore(programme.endTime);
    final timeStr = DateFormat('HH:mm').format(programme.startTime.toLocal());

    return GestureDetector(
      onTap: () => _showDetail(context),
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: isNow
              ? AppTheme.primaryCyan.withValues(alpha: 0.1)
              : AppTheme.surfaceCard,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: isNow
                ? AppTheme.primaryCyan.withValues(alpha: 0.4)
                : AppTheme.surfaceBorder,
            width: isNow ? 1 : 0.5,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isNow) ...[
                  Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                          shape: BoxShape.circle, color: AppTheme.statusLive)),
                  const SizedBox(width: 4),
                ],
                Text(timeStr,
                    style: TextStyle(
                        color: isNow
                            ? AppTheme.primaryCyan
                            : AppTheme.textSecondary,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                        fontFamily: 'Inter')),
              ],
            ),
            const SizedBox(height: 2),
            SizedBox(
              width: 140,
              child: Text(programme.title,
                  style: TextStyle(
                      color:
                          isNow ? AppTheme.textPrimary : AppTheme.textSecondary,
                      fontSize: 11,
                      fontWeight: isNow ? FontWeight.w600 : FontWeight.w400,
                      fontFamily: 'Inter'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ),
          ],
        ),
      ),
    );
  }

  void _showDetail(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: AppTheme.surfaceElevated,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(programme.title,
                style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    fontFamily: 'Inter')),
            const SizedBox(height: 6),
            Text(
              '${DateFormat('HH:mm').format(programme.startTime.toLocal())} — ${DateFormat('HH:mm').format(programme.endTime.toLocal())}',
              style: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 13,
                  fontFamily: 'Inter'),
            ),
            if (programme.description != null) ...[
              const SizedBox(height: 12),
              Text(programme.description!,
                  style: const TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 13,
                      height: 1.5,
                      fontFamily: 'Inter')),
            ],
          ],
        ),
      ),
    );
  }
}

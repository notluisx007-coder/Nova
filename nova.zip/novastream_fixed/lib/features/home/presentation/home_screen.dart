import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/models/channel.dart';
import '../../../shared/models/sports.dart';
import '../../../shared/widgets/channel_card.dart';
import '../../../shared/widgets/section_header.dart';
import '../../live_tv/data/channel_repository.dart';
import '../../sources/data/source_repository.dart';
import '../../sports/data/sports_repository.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final sources = ref.watch(sourcesProvider);
    final recentChannels = ref.watch(recentChannelsProvider);
    final hasSources = sources.valueOrNull?.isNotEmpty == true;

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      body: CustomScrollView(
        slivers: [
          _buildAppBar(context),
          if (!hasSources)
            _buildSetupBanner(context)
          else ...[
            if (recentChannels.valueOrNull?.isNotEmpty == true)
              _buildRecentlyWatched(context, ref, recentChannels),
            _buildFeaturedHero(context, ref),
            _buildQuickCategories(context),
            _buildLiveNow(context, ref),
            _buildLiveSportsSection(context, ref),
            _buildUpcomingSports(context, ref),
          ],
          const SliverToBoxAdapter(child: SizedBox(height: 24)),
        ],
      ),
    );
  }

  SliverAppBar _buildAppBar(BuildContext context) {
    return SliverAppBar(
      pinned: true,
      backgroundColor: AppTheme.surfaceBackground,
      surfaceTintColor: Colors.transparent,
      title: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              'assets/images/app_icon.png',
              width: 32,
              height: 32,
              errorBuilder: (_, __, ___) => Container(
                width: 32,
                height: 32,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppTheme.primaryGradient,
                ),
                child: const Icon(Icons.play_arrow_rounded,
                    size: 20, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(width: 8),
          ShaderMask(
            shaderCallback: (bounds) =>
                AppTheme.primaryGradient.createShader(bounds),
            child: const Text(
              'NOVASTREAM',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                letterSpacing: 1.5,
                fontFamily: 'Inter',
              ),
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.search_rounded),
          color: AppTheme.textSecondary,
          onPressed: () => context.go(AppRoutes.search),
        ),
        IconButton(
          icon: const Icon(Icons.settings_rounded),
          color: AppTheme.textSecondary,
          onPressed: () => context.go(AppRoutes.settings),
        ),
      ],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(0.5),
        child: Container(height: 0.5, color: AppTheme.surfaceBorder),
      ),
    );
  }

  SliverToBoxAdapter _buildSetupBanner(BuildContext context) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const SizedBox(height: 32),
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: AppTheme.surfaceCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppTheme.surfaceBorder),
              ),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.asset(
                      'assets/images/app_icon.png',
                      width: 80,
                      height: 80,
                      errorBuilder: (_, __, ___) => Container(
                        width: 72,
                        height: 72,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppTheme.primaryCyan.withValues(alpha: 0.1),
                        ),
                        child: const Icon(Icons.tv_rounded,
                            size: 36, color: AppTheme.primaryCyan),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Welcome to NovaStream',
                    style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                      fontFamily: 'Inter',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Add an IPTV source to start browsing live channels, or explore the Sports Hub.',
                    style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 14,
                        height: 1.5,
                        fontFamily: 'Inter'),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  _SetupOption(
                    icon: Icons.playlist_add_rounded,
                    title: 'Import M3U Playlist',
                    subtitle: 'Add a URL or local file',
                    onTap: () => context.go(AppRoutes.sources),
                  ),
                  const SizedBox(height: 10),
                  _SetupOption(
                    icon: Icons.sports_soccer_rounded,
                    title: 'Explore Sports Hub',
                    subtitle: 'Live scores, fixtures & teams',
                    onTap: () => context.go(AppRoutes.sports),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  SliverToBoxAdapter _buildRecentlyWatched(BuildContext context, WidgetRef ref,
      AsyncValue<List<IptvChannel>> channels) {
    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
            child: SectionHeader(
                title: 'Continue Watching',
                onSeeAll: () => context.go(AppRoutes.liveTV)),
          ),
          SizedBox(
            height: 90,
            child: channels.when(
              data: (list) => ListView.builder(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: list.length,
                itemBuilder: (ctx, i) => Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: ChannelMiniCard(channel: list[i]),
                ),
              ),
              loading: () => const _HorizontalShimmer(height: 90),
              error: (e, _) => const SizedBox(),
            ),
          ),
        ],
      ),
    );
  }

  SliverToBoxAdapter _buildFeaturedHero(BuildContext context, WidgetRef ref) {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          height: 180,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: const LinearGradient(
              colors: [Color(0xFF0D1526), Color(0xFF1A2847)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(color: AppTheme.surfaceBorder),
          ),
          child: Stack(
            children: [
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                    gradient: LinearGradient(
                      colors: [
                        AppTheme.primaryCyan.withValues(alpha: 0.05),
                        AppTheme.accentViolet.withValues(alpha: 0.05),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppTheme.primaryCyan.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(
                            color: AppTheme.primaryCyan.withValues(alpha: 0.3)),
                      ),
                      child: const Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.fiber_manual_record,
                              size: 8, color: AppTheme.statusLive),
                          SizedBox(width: 4),
                          Text(
                            'LIVE',
                            style: TextStyle(
                              color: AppTheme.statusLive,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Inter',
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Live TV & Sports',
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Inter',
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      'Stream your channels. Follow the action.',
                      style: TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 13,
                          fontFamily: 'Inter'),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        ElevatedButton.icon(
                          onPressed: () => context.go(AppRoutes.liveTV),
                          icon: const Icon(Icons.tv_rounded, size: 16),
                          label: const Text('Live TV'),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            textStyle: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        OutlinedButton.icon(
                          onPressed: () => context.go(AppRoutes.sports),
                          icon:
                              const Icon(Icons.sports_soccer_rounded, size: 16),
                          label: const Text('Sports'),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            textStyle: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Inter'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  SliverToBoxAdapter _buildQuickCategories(BuildContext context) {
    final categories = [
      ('Live TV', Icons.tv_rounded, AppRoutes.liveTV, AppTheme.primaryCyan),
      (
        'Sports',
        Icons.sports_soccer_rounded,
        AppRoutes.sports,
        AppTheme.accentViolet
      ),
      (
        'TV Guide',
        Icons.calendar_view_week_rounded,
        AppRoutes.epg,
        AppTheme.accentPurple
      ),
      (
        'Favourites',
        Icons.favorite_rounded,
        AppRoutes.favorites,
        const Color(0xFFE91E8C)
      ),
      ('Search', Icons.search_rounded, AppRoutes.search, AppTheme.primaryBlue),
      (
        'Sources',
        Icons.playlist_add_check_rounded,
        AppRoutes.sources,
        AppTheme.statusWarning
      ),
    ];

    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 3,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.5,
          children: categories
              .map((c) => _QuickCategoryCard(
                    label: c.$1,
                    icon: c.$2,
                    route: c.$3,
                    color: c.$4,
                  ))
              .toList(),
        ),
      ),
    );
  }

  SliverToBoxAdapter _buildLiveNow(BuildContext context, WidgetRef ref) {
    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
            child: SectionHeader(
                title: 'Live Channels',
                onSeeAll: () => context.go(AppRoutes.liveTV)),
          ),
          Consumer(builder: (context, ref, _) {
            final channels = ref.watch(allChannelsProvider);
            return channels.when(
              data: (list) {
                if (list.isEmpty) {
                  return Padding(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceCard,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppTheme.surfaceBorder),
                      ),
                      child: const Row(
                        children: [
                          Icon(Icons.info_outline_rounded,
                              color: AppTheme.textSecondary, size: 20),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'No channels yet. Add a playlist source in Sources.',
                              style: TextStyle(
                                  color: AppTheme.textSecondary,
                                  fontSize: 13,
                                  fontFamily: 'Inter'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }
                return SizedBox(
                  height: 110,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: list.take(20).length,
                    itemBuilder: (ctx, i) => Padding(
                      padding: const EdgeInsets.only(right: 12),
                      child: ChannelMiniCard(channel: list[i]),
                    ),
                  ),
                );
              },
              loading: () => const _HorizontalShimmer(height: 110),
              error: (e, _) => const SizedBox(),
            );
          }),
        ],
      ),
    );
  }

  SliverToBoxAdapter _buildLiveSportsSection(
      BuildContext context, WidgetRef ref) {
    final liveEvents = ref.watch(liveEventsStreamProvider);
    return SliverToBoxAdapter(
      child: liveEvents.when(
        data: (events) {
          if (events.isEmpty) return const SizedBox();
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
                child: SectionHeader(
                    title: 'Live Sports',
                    onSeeAll: () => context.go(AppRoutes.sports)),
              ),
              SizedBox(
                height: 100,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: events.take(10).length,
                  itemBuilder: (ctx, i) {
                    final e = events[i];
                    return Padding(
                      padding: const EdgeInsets.only(right: 12),
                      child: GestureDetector(
                        onTap: () => context.go('/sports/match/${e.id}'),
                        child: Container(
                          width: 180,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppTheme.surfaceCard,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color:
                                    AppTheme.statusLive.withValues(alpha: 0.3)),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 5, vertical: 2),
                                    decoration: BoxDecoration(
                                      color: AppTheme.statusLive
                                          .withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.circular(3),
                                    ),
                                    child: const Text(
                                      'LIVE',
                                      style: TextStyle(
                                        color: AppTheme.statusLive,
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700,
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Expanded(
                                    child: Text(
                                      e.competitionName,
                                      style: const TextStyle(
                                          color: AppTheme.textSecondary,
                                          fontSize: 10),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              Text(
                                '${e.homeTeamName} vs ${e.awayTeamName}',
                                style: const TextStyle(
                                    color: AppTheme.textPrimary,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              if (e.homeScore != null && e.awayScore != null)
                                Text(
                                  '${e.homeScore} - ${e.awayScore}',
                                  style: const TextStyle(
                                    color: AppTheme.primaryCyan,
                                    fontSize: 14,
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
        loading: () => const SizedBox(),
        error: (_, __) => const SizedBox(),
      ),
    );
  }

  SliverToBoxAdapter _buildUpcomingSports(BuildContext context, WidgetRef ref) {
    final upcomingEvents = ref.watch(upcomingEventsStreamProvider);
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionHeader(
                title: 'Sports Hub',
                onSeeAll: () => context.go(AppRoutes.sports)),
            const SizedBox(height: 12),
            upcomingEvents.when(
              data: (events) {
                if (events.isEmpty) {
                  return GestureDetector(
                    onTap: () => context.go(AppRoutes.sports),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.surfaceCard,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppTheme.surfaceBorder),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 48,
                            height: 48,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color:
                                  AppTheme.accentViolet.withValues(alpha: 0.15),
                            ),
                            child: const Icon(Icons.sports_soccer_rounded,
                                color: AppTheme.accentViolet, size: 24),
                          ),
                          const SizedBox(width: 14),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Sports Hub',
                                  style: TextStyle(
                                      color: AppTheme.textPrimary,
                                      fontSize: 15,
                                      fontWeight: FontWeight.w600,
                                      fontFamily: 'Inter'),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  'Browse live scores, fixtures, teams and standings',
                                  style: TextStyle(
                                      color: AppTheme.textSecondary,
                                      fontSize: 12,
                                      fontFamily: 'Inter'),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right_rounded,
                              color: AppTheme.textSecondary),
                        ],
                      ),
                    ),
                  );
                }
                return Column(
                  children: events.take(3).map((e) {
                    return GestureDetector(
                      onTap: () => context.go('/sports/match/${e.id}'),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceCard,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: AppTheme.surfaceBorder),
                        ),
                        child: Row(
                          children: [
                            Text(e.sport.icon,
                                style: const TextStyle(fontSize: 20)),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    '${e.homeTeamName} vs ${e.awayTeamName}',
                                    style: const TextStyle(
                                        color: AppTheme.textPrimary,
                                        fontSize: 13,
                                        fontWeight: FontWeight.w500),
                                  ),
                                  Text(
                                    e.competitionName,
                                    style: const TextStyle(
                                        color: AppTheme.textSecondary,
                                        fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              _formatTime(e.startTime),
                              style: const TextStyle(
                                  color: AppTheme.primaryCyan, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                );
              },
              loading: () => const SizedBox(
                  height: 80,
                  child:
                      Center(child: CircularProgressIndicator(strokeWidth: 2))),
              error: (_, __) => const SizedBox(),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime dt) {
    final local = dt.toLocal();
    return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }
}

class _QuickCategoryCard extends StatelessWidget {
  final String label;
  final IconData icon;
  final String route;
  final Color color;
  const _QuickCategoryCard(
      {required this.label,
      required this.icon,
      required this.route,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.go(route),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.surfaceCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.2)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 24),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  fontFamily: 'Inter'),
            ),
          ],
        ),
      ),
    );
  }
}

class _SetupOption extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _SetupOption(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.surfaceElevated,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.surfaceBorder),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppTheme.primaryCyan, size: 22),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Inter')),
                  Text(subtitle,
                      style: const TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 12,
                          fontFamily: 'Inter')),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded,
                color: AppTheme.textSecondary, size: 20),
          ],
        ),
      ),
    );
  }
}

class _HorizontalShimmer extends StatelessWidget {
  final double height;
  const _HorizontalShimmer({required this.height});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: height,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: 5,
        itemBuilder: (_, __) => Padding(
          padding: const EdgeInsets.only(right: 12),
          child: Container(
            width: 80,
            decoration: BoxDecoration(
              color: AppTheme.surfaceCard,
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
      ),
    );
  }
}

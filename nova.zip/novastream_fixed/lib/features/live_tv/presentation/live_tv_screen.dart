import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/widgets/channel_card.dart';
import '../../../shared/widgets/empty_state_widget.dart';
import '../../player/presentation/player_screen.dart';
import '../../sources/data/source_repository.dart';
import '../data/channel_repository.dart';

final _searchQueryProvider = StateProvider<String>((ref) => '');
final _selectedGroupProvider = StateProvider<String?>((ref) => null);

class LiveTvScreen extends ConsumerStatefulWidget {
  const LiveTvScreen({super.key});

  @override
  ConsumerState<LiveTvScreen> createState() => _LiveTvScreenState();
}

class _LiveTvScreenState extends ConsumerState<LiveTvScreen> {
  final _searchController = TextEditingController();
  bool _showSearch = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final allChannels = ref.watch(allChannelsProvider);
    final groups = ref.watch(channelGroupsProvider);
    final selectedGroup = ref.watch(_selectedGroupProvider);
    final searchQuery = ref.watch(_searchQueryProvider);
    final sources = ref.watch(sourcesProvider);
    final hasSources = sources.valueOrNull?.isNotEmpty == true;

    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      appBar: AppBar(
        title: _showSearch
            ? TextField(
                controller: _searchController,
                autofocus: true,
                style: const TextStyle(
                    color: AppTheme.textPrimary, fontFamily: 'Inter'),
                decoration: const InputDecoration(
                  hintText: 'Search channels...',
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
                onChanged: (q) =>
                    ref.read(_searchQueryProvider.notifier).state = q,
              )
            : const Text('Live TV'),
        actions: [
          IconButton(
            icon:
                Icon(_showSearch ? Icons.close_rounded : Icons.search_rounded),
            color: AppTheme.textSecondary,
            onPressed: () {
              setState(() => _showSearch = !_showSearch);
              if (!_showSearch) {
                _searchController.clear();
                ref.read(_searchQueryProvider.notifier).state = '';
              }
            },
          ),
          if (!_showSearch)
            IconButton(
              icon: const Icon(Icons.playlist_add_rounded),
              color: AppTheme.textSecondary,
              onPressed: () => context.go(AppRoutes.sources),
            ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(0.5),
          child: Container(height: 0.5, color: AppTheme.surfaceBorder),
        ),
      ),
      body: Column(
        children: [
          // Group filter chips
          groups.when(
            data: (groupList) => groupList.isEmpty
                ? const SizedBox()
                : _GroupFilter(groups: groupList),
            loading: () => const SizedBox(height: 40),
            error: (_, __) => const SizedBox(),
          ),
          // Channel list
          Expanded(
            child: allChannels.when(
              data: (channels) {
                if (!hasSources || channels.isEmpty) {
                  return EmptyStateWidget(
                    icon: Icons.tv_rounded,
                    title: 'No Channels',
                    message: 'Import a playlist to browse live TV channels.',
                    actionLabel: 'Add Source',
                    onAction: () => context.go(AppRoutes.sources),
                  );
                }

                // Filter by search
                var filtered = channels;
                if (searchQuery.isNotEmpty) {
                  filtered = channels
                      .where((c) =>
                          c.name
                              .toLowerCase()
                              .contains(searchQuery.toLowerCase()) ||
                          (c.groupTitle
                                  ?.toLowerCase()
                                  .contains(searchQuery.toLowerCase()) ??
                              false))
                      .toList();
                }

                // Filter by group
                if (selectedGroup != null) {
                  filtered = filtered
                      .where((c) => c.groupTitle == selectedGroup)
                      .toList();
                }

                if (filtered.isEmpty) {
                  return const EmptyStateWidget(
                    icon: Icons.search_off_rounded,
                    title: 'No Results',
                    message: 'Try a different search or filter.',
                  );
                }

                return ListView.separated(
                  itemCount: filtered.length,
                  separatorBuilder: (_, __) => const Divider(
                    height: 0.5,
                    indent: 76,
                    color: AppTheme.surfaceBorder,
                  ),
                  itemBuilder: (ctx, i) {
                    final ch = filtered[i];
                    return ChannelListTile(
                      channel: ch,
                      onFavoriteToggle: () {
                        ref
                            .read(channelRepositoryProvider.notifier)
                            .toggleFavorite(ch.id, !ch.isFavorite);
                      },
                      onTap: () => context.push(AppRoutes.player, extra: {
                        'url': ch.streamUrl,
                        'title': ch.name,
                        'channelId': ch.id,
                        'playlist': filtered
                            .map((c) => PlayerChannelRef.fromChannel(c).toMap())
                            .toList(),
                        'initialIndex': i,
                      }),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => ErrorStateWidget(message: e.toString()),
            ),
          ),
        ],
      ),
    );
  }
}

class _GroupFilter extends ConsumerWidget {
  final List<String> groups;
  const _GroupFilter({required this.groups});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = ref.watch(_selectedGroupProvider);

    return SizedBox(
      height: 44,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        itemCount: groups.length + 1,
        itemBuilder: (ctx, i) {
          final isAll = i == 0;
          final group = isAll ? 'All' : groups[i - 1];
          final isSelected = isAll ? selected == null : selected == group;

          return Padding(
            padding: const EdgeInsets.only(right: 6),
            child: FilterChip(
              label: Text(group),
              selected: isSelected,
              onSelected: (_) => ref
                  .read(_selectedGroupProvider.notifier)
                  .state = isAll ? null : group,
            ),
          );
        },
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import '../../../shared/models/channel.dart';
import '../../player/presentation/player_screen.dart';
import '../data/channel_repository.dart';

class ChannelDetailScreen extends ConsumerWidget {
  final String channelId;

  const ChannelDetailScreen({super.key, required this.channelId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final allChannels = ref.watch(allChannelsProvider);

    return allChannels.when(
      data: (channels) {
        final channel = channels.firstWhereOrNull((c) => c.id == channelId);
        if (channel == null) {
          return Scaffold(
            appBar: AppBar(title: const Text('Channel')),
            body: const Center(child: Text('Channel not found')),
          );
        }
        return _ChannelDetailContent(channel: channel);
      },
      loading: () => const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      ),
      error: (e, _) => Scaffold(
        appBar: AppBar(),
        body: Center(child: Text('Error: $e')),
      ),
    );
  }
}

class _ChannelDetailContent extends ConsumerWidget {
  final IptvChannel channel;
  const _ChannelDetailContent({required this.channel});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      backgroundColor: AppTheme.surfaceBackground,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 200,
            pinned: true,
            backgroundColor: AppTheme.surfaceBackground,
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.surfaceElevated,
                      AppTheme.surfaceBackground
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(height: 40),
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          color: AppTheme.surfaceCard,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: AppTheme.surfaceBorder),
                          boxShadow: AppTheme.cardShadow,
                        ),
                        clipBehavior: Clip.antiAlias,
                        child: channel.logoUrl != null
                            ? Image.network(channel.logoUrl!,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => const Icon(
                                    Icons.tv_rounded,
                                    color: AppTheme.textDisabled,
                                    size: 32))
                            : const Icon(Icons.tv_rounded,
                                color: AppTheme.textDisabled, size: 32),
                      ),
                      const SizedBox(height: 10),
                      Text(channel.name,
                          style: const TextStyle(
                              color: AppTheme.textPrimary,
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Inter')),
                      if (channel.groupTitle != null)
                        Text(channel.groupTitle!,
                            style: const TextStyle(
                                color: AppTheme.textSecondary,
                                fontSize: 13,
                                fontFamily: 'Inter')),
                    ],
                  ),
                ),
              ),
            ),
            actions: [
              IconButton(
                icon: Icon(
                  channel.isFavorite
                      ? Icons.favorite_rounded
                      : Icons.favorite_border_rounded,
                  color: channel.isFavorite
                      ? AppTheme.statusLive
                      : AppTheme.textSecondary,
                ),
                onPressed: () {
                  ref
                      .read(channelRepositoryProvider.notifier)
                      .toggleFavorite(channel.id, !channel.isFavorite);
                },
              ),
            ],
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Play button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () => context.push(AppRoutes.player, extra: {
                        'url': channel.streamUrl,
                        'title': channel.name,
                        'channelId': channel.id,
                        'playlist': [
                          PlayerChannelRef.fromChannel(channel).toMap()
                        ],
                        'initialIndex': 0,
                      }),
                      icon: const Icon(Icons.play_arrow_rounded, size: 20),
                      label: const Text('Play Channel'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Rights warning
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.statusWarning.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: AppTheme.statusWarning.withValues(alpha: 0.3)),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.info_outline_rounded,
                            color: AppTheme.statusWarning, size: 18),
                        SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Stream availability depends on your subscription and location. Only access content you are authorized to view.',
                            style: TextStyle(
                                color: AppTheme.textSecondary,
                                fontSize: 12,
                                fontFamily: 'Inter',
                                height: 1.4),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Channel metadata
                  const Text('Channel Information',
                      style: TextStyle(
                          color: AppTheme.textPrimary,
                          fontSize: 15,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Inter')),
                  const SizedBox(height: 12),
                  _InfoRow('Group', channel.groupTitle ?? 'Unknown'),
                  if (channel.country != null)
                    _InfoRow('Country', channel.country!),
                  if (channel.language != null)
                    _InfoRow('Language', channel.language!),
                  _InfoRow('Source', channel.sourceId),
                  _InfoRow(
                      'Rights Status', channel.rightsStatus.name.toUpperCase()),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(
            width: 100,
            child: Text(label,
                style: const TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 13,
                    fontFamily: 'Inter')),
          ),
          Expanded(
            child: Text(value,
                style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 13,
                    fontFamily: 'Inter')),
          ),
        ],
      ),
    );
  }
}

extension ListExt<T> on List<T> {
  T? firstWhereOrNull(bool Function(T) test) {
    for (final element in this) {
      if (test(element)) return element;
    }
    return null;
  }
}

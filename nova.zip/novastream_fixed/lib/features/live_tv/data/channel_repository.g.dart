// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'channel_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$allChannelsHash() => r'23d84f634643a520004839f1c9a58d4fef39b955';

/// See also [allChannels].
@ProviderFor(allChannels)
final allChannelsProvider =
    AutoDisposeStreamProvider<List<IptvChannel>>.internal(
  allChannels,
  name: r'allChannelsProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$allChannelsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef AllChannelsRef = AutoDisposeStreamProviderRef<List<IptvChannel>>;
String _$favoriteChannelsHash() => r'73d1bd4db08ad93f1d42640bcae5434527e87a05';

/// See also [favoriteChannels].
@ProviderFor(favoriteChannels)
final favoriteChannelsProvider =
    AutoDisposeStreamProvider<List<IptvChannel>>.internal(
  favoriteChannels,
  name: r'favoriteChannelsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$favoriteChannelsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef FavoriteChannelsRef = AutoDisposeStreamProviderRef<List<IptvChannel>>;
String _$recentChannelsHash() => r'6a0a80e0a3cd7af9b106626de296fe95d4bfdddc';

/// See also [recentChannels].
@ProviderFor(recentChannels)
final recentChannelsProvider =
    AutoDisposeFutureProvider<List<IptvChannel>>.internal(
  recentChannels,
  name: r'recentChannelsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$recentChannelsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef RecentChannelsRef = AutoDisposeFutureProviderRef<List<IptvChannel>>;
String _$channelGroupsHash() => r'61ca75eadf4d3dfd0185e6b74227e12ba623b93a';

/// See also [channelGroups].
@ProviderFor(channelGroups)
final channelGroupsProvider = AutoDisposeFutureProvider<List<String>>.internal(
  channelGroups,
  name: r'channelGroupsProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$channelGroupsHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef ChannelGroupsRef = AutoDisposeFutureProviderRef<List<String>>;
String _$channelRepositoryHash() => r'083f5513d22c234589d0c32a37a7c06ae4a2c607';

/// See also [ChannelRepository].
@ProviderFor(ChannelRepository)
final channelRepositoryProvider =
    AutoDisposeAsyncNotifierProvider<ChannelRepository, void>.internal(
  ChannelRepository.new,
  name: r'channelRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$channelRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ChannelRepository = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package

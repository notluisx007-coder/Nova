import 'package:drift/drift.dart' hide isNull;
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../../core/database/app_database.dart';
import '../../../shared/models/channel.dart';
import '../../sources/data/m3u_parser.dart';

part 'channel_repository.g.dart';

/// Result of a transactional playlist (re)import.
class ChannelImportResult {
  final int inserted;
  final int updated;
  final int removed;
  final int total;

  const ChannelImportResult({
    required this.inserted,
    required this.updated,
    required this.removed,
    required this.total,
  });

  @override
  String toString() =>
      'ChannelImportResult(inserted: $inserted, updated: $updated, removed: $removed, total: $total)';
}

@riverpod
Stream<List<IptvChannel>> allChannels(AllChannelsRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db
      .watchAllChannels()
      .map((rows) => rows.map(_channelFromRow).toList());
}

@riverpod
Stream<List<IptvChannel>> favoriteChannels(FavoriteChannelsRef ref) {
  final db = ref.watch(appDatabaseProvider);
  return db
      .watchFavoriteChannels()
      .map((rows) => rows.map(_channelFromRow).toList());
}

@riverpod
Future<List<IptvChannel>> recentChannels(RecentChannelsRef ref) async {
  final db = ref.watch(appDatabaseProvider);
  final rows = await db.getRecentlyWatched();
  return rows.map(_channelFromRow).toList();
}

@riverpod
Future<List<String>> channelGroups(ChannelGroupsRef ref) async {
  final channels = await ref.watch(allChannelsProvider.future);
  final groups = channels
      .where((c) => c.groupTitle != null && c.groupTitle!.isNotEmpty)
      .map((c) => c.groupTitle!)
      .toSet()
      .toList()
    ..sort();
  return groups;
}

@riverpod
class ChannelRepository extends _$ChannelRepository {
  @override
  Future<void> build() async {}

  /// Import channels from an M3U string as the COMPLETE channel list of a
  /// source, atomically:
  ///
  /// 1. Parses and validates the content first (a parse failure aborts
  ///    before any database row is touched).
  /// 2. Runs inside a single transaction that upserts every parsed channel,
  ///    preserving user-owned columns (isFavorite, isHidden, userOrder,
  ///    lastWatched) on existing rows matched by the stable channel id.
  /// 3. Deletes rows of this source that no longer exist in the validated
  ///    playlist, together with their dependent watch-history and favorite
  ///    rows.
  ///
  /// Because everything happens in one transaction, a failure mid-way leaves
  /// the previous channel list fully intact.
  Future<ChannelImportResult> importFromM3UContent(
      String content, String sourceId) async {
    final result = await M3UParser.parse(content);
    if (result.validCount == 0) {
      throw const FormatException('No valid channels found in playlist');
    }
    final channels = M3UParser.toChannels(result.entries, sourceId);
    return replaceSourceChannels(channels, sourceId);
  }

  /// Transactionally replaces the channel set of [sourceId] with [channels].
  /// Public so tests and the refresh pipeline can drive it with pre-validated
  /// channel lists.
  Future<ChannelImportResult> replaceSourceChannels(
      List<IptvChannel> channels, String sourceId) async {
    final db = ref.read(appDatabaseProvider);
    int inserted = 0;
    int updated = 0;
    int removed = 0;

    await db.transaction(() async {
      final existingRows = await (db.select(db.channelsTable)
            ..where((t) => t.sourceId.equals(sourceId)))
          .get();
      final existingById = {for (final row in existingRows) row.id: row};
      final incomingIds = <String>{};

      for (final channel in channels) {
        if (channel.sourceId != sourceId) {
          throw ArgumentError(
              'Channel ${channel.id} does not belong to source $sourceId');
        }
        incomingIds.add(channel.id);
        final existing = existingById[channel.id];
        final isNew = existing == null;
        await db.into(db.channelsTable).insertOnConflictUpdate(
              ChannelsTableCompanion(
                id: Value(channel.id),
                name: Value(channel.name),
                logoUrl: Value(channel.logoUrl),
                groupTitle: Value(channel.groupTitle),
                tvgId: Value(channel.tvgId),
                tvgName: Value(channel.tvgName),
                country: Value(channel.country),
                language: Value(channel.language),
                categories: Value(channel.categories.join(',')),
                streamUrl: Value(channel.streamUrl),
                sourceId: Value(channel.sourceId),
                // Preserve user-owned state on update; defaults on insert.
                isFavorite: Value(existing?.isFavorite ?? false),
                isHidden: Value(existing?.isHidden ?? false),
                userOrder: Value(existing?.userOrder),
                lastWatched: Value(existing?.lastWatched),
              ),
            );
        if (isNew) {
          inserted++;
        } else {
          updated++;
        }
      }

      // Remove channels that disappeared from the validated playlist, plus
      // their dependent records, so nothing dangles.
      final staleIds =
          existingById.keys.where((id) => !incomingIds.contains(id)).toList();
      if (staleIds.isNotEmpty) {
        await (db.delete(db.watchHistoryTable)
              ..where((t) => t.channelId.isIn(staleIds)))
            .go();
        await (db.delete(db.favoritesTable)
              ..where((t) =>
                  t.type.equals('channel') & t.referenceId.isIn(staleIds)))
            .go();
        await (db.delete(db.channelsTable)
              ..where((t) => t.id.isIn(staleIds) & t.sourceId.equals(sourceId)))
            .go();
        removed = staleIds.length;
      }
    });

    return ChannelImportResult(
      inserted: inserted,
      updated: updated,
      removed: removed,
      total: channels.length,
    );
  }

  Future<void> toggleFavorite(String channelId, bool isFavorite) async {
    final db = ref.read(appDatabaseProvider);
    await db.toggleChannelFavorite(channelId, isFavorite);
  }

  /// Mark a channel as watched and record it in watch history.
  Future<void> markWatched(
      String channelId, String channelName, String streamUrl) async {
    final db = ref.read(appDatabaseProvider);
    await db.updateLastWatched(channelId);
    // Record in watch history (upsert by id = channel id so we don't
    // accumulate unlimited rows for the same channel).
    await db.addWatchHistory(WatchHistoryTableCompanion(
      id: Value(channelId),
      channelId: Value(channelId),
      channelName: Value(channelName),
      streamUrl: Value(streamUrl),
      watchedAt: Value(DateTime.now()),
    ));
  }
}

IptvChannel _channelFromRow(ChannelsTableData row) {
  return IptvChannel(
    id: row.id,
    name: row.name,
    logoUrl: row.logoUrl,
    groupTitle: row.groupTitle,
    tvgId: row.tvgId,
    tvgName: row.tvgName,
    country: row.country,
    language: row.language,
    categories:
        row.categories?.split(',').where((s) => s.isNotEmpty).toList() ?? [],
    streamUrl: row.streamUrl,
    sourceId: row.sourceId,
    isFavorite: row.isFavorite,
    isHidden: row.isHidden,
    userOrder: row.userOrder,
    lastWatched: row.lastWatched,
  );
}

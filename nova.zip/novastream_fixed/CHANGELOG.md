# NovaStream Changelog

## 1.1.1+3 — Final corrective implementation pass (2026-11-09)

This release is the corrective implementation pass described in
`missing.txt`. Every change below was implemented and verified locally; the
verification commands and their real results are listed in
`docs/VERIFICATION.md`. Anything that could NOT be verified (device-tested
behaviour, live backend deployment, provider credentials) is named
explicitly there — nothing is claimed without evidence.

### Fixed — data integrity
- **Refresh lock race (TOCTOU)**: the per-source refresh lock was acquired
  *after* an awaited source lookup, so two rapid concurrent refreshes could
  both enter the critical section. The lock is now acquired synchronously
  before any `await`, and released in a single `finally` that covers
  success, error, cancellation and exception paths. The file-source path no
  longer double-releases the lock.
  (`lib/features/sources/data/source_repository.dart`)
- **Duplicate `_FavoriteTeams` class** in the favourites screen (dead
  stub + real implementation) — a compile error, removed.
  (`lib/features/favorites/presentation/favorites_screen.dart`)
- **EPG tests duplicated production logic**: the EPG time-parser test
  copied the parser logic instead of testing the production function. Tests
  now call `XmltvParser.parseXmltvTime` / `XmltvParser.parse` directly.
  (`test/unit/epg_test.dart`, production parser is public API)

### Fixed — security
- **Log sanitizer gaps**: bare `auth=` keys were not redacted, and
  `Authorization: Bearer/Basic <credential>` strings only had their first
  word redacted, leaving the actual token visible. Both are now redacted.
  (`lib/core/utils/log_sanitizer.dart`)

### Added — tests (all run against real production code)
- `test/integration/refresh_pipeline_test.dart` — the real refresh pipeline
  against an in-process loopback HTTP server: insert/update/remove on
  refresh, favourites/hidden/watch-history preservation, removal of stale
  channels plus their dependent rows, invalid response keeps previous data,
  empty response keeps previous data, dead-server keeps previous data,
  concurrent refresh rejected and lock released, file-source refresh paths,
  source deletion removes every dependent record (channels, channel
  favourites, watch history, EPG programmes, manual EPG mappings, programme
  reminders) without touching other sources' records or global favourites.
- `test/integration/epg_import_test.dart` — the real EPG import pipeline:
  successful transactional guide replacement, timezone-offset conversion to
  UTC, malformed XML keeps the last good guide, empty body keeps the last
  good guide, malformed individual records are skipped and counted,
  concurrent imports rejected and lock released, lock released after
  failures with clean recovery, manual EPG mapping persists/replaces/removes
  and survives guide re-imports.
- `test/integration/migration_test.dart` — real database migration: a v1
  database (schema version 1) is upgraded to v2 on first open; channels,
  favourites, hidden state, watch history, sources and settings all
  survive; the three v2 tables (EPG channel directory, manual mappings,
  resume points) are created and usable. Fresh-install path tested too.
- `test/unit/log_sanitizer_test.dart` — passwords/tokens/auth keys,
  userinfo URLs, Xtream query credentials, Bearer/Basic tokens, hex and
  base64 blobs, plus `describeStreamUrl` behaviour.
- `test/widgets/favorites_screen_test.dart` — favourites screen against a
  real in-memory database: channel favourites list, team favourites with
  persisted removal, saved shows with persisted removal, and honest empty
  states on all three tabs for a fresh install.

### Verified as already correct (no double implementation)
Per the specification's instruction ("if an item has already been correctly
fixed … prove that with code and tests rather than implementing it twice"),
the following were verified against the source and are covered by the new
test suite rather than rewritten:
- Transactional playlist refresh (validate-before-write, single-transaction
  channel replacement, stale-row removal, user-preference preservation).
- Source deletion dependency cleanup in one transaction.
- Database schema v2 with an additive v1→v2 migration strategy.
- Production XMLTV parser with UTC conversion, per-record error tolerance
  and full-document validation.
- Manual EPG channel mapping/unmapping persisted across refreshes.
- Player controls, PiP lifecycle, resume points, bounded retry and
  redacted diagnostics (implemented in the previous pass).
- Android network security configuration, backup rules, manifest
  permissions, credential storage and log redaction.
- Sports backend (Node.js, zero-dependency) with 16 passing tests: provider
  key stays server-side, structured 503 when no provider key is configured
  (never fake fixtures), rate limiting, auth, timeouts, caching.

### Known-honest status (unchanged, by design)
- No movies/VOD/series UI is shipped — the previous README overstated this;
  the README is corrected. Xtream codes support is **not implemented**.
- The sports backend compiles and passes its tests locally, but no live
  deployment exists and no provider API key is available; therefore no
  live-data claim is made. The Flutter sports client is wired to a
  user-configured HTTPS backend URL (Settings → Sports Backend URL) and
  shows honest unconfigured/error states.
- PiP is implemented but not device-tested in this environment (no Android
  device) — marked unverified.

## 1.1.1+3 — Android build toolchain repair

- Updated Gradle, Android Gradle Plugin, and Kotlin Gradle Plugin to a
  mutually compatible Flutter Android toolchain.
- Added a ZIP-aware GitHub Actions workflow that builds and uploads the
  universal release APK without running tests or static analysis.

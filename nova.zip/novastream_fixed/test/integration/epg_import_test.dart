import 'dart:async';
import 'dart:io';

import 'package:drift/native.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/core/database/app_database.dart';
import 'package:novastream/features/epg/data/epg_repository.dart';

/// End-to-end tests of the REAL EPG import pipeline:
/// HTTP download → XMLTV parse → transactional guide replacement.
/// Uses an in-process loopback HTTP server — no external services.

String guide({
  String channels = '''
  <channel id="ch.one"><display-name>Channel One</display-name></channel>''',
  String programmes = '''
  <programme start="20240601120000 +0000" stop="20240601130000 +0000" channel="ch.one">
    <title>Noon News</title>
  </programme>''',
}) =>
    '''<?xml version="1.0" encoding="UTF-8"?>
<tv>$channels
$programmes
</tv>''';

void main() {
  late AppDatabase db;
  late ProviderContainer container;
  late HttpServer server;
  final routes = <String, Box<String>>{};
  Completer<void>? gate;

  setUp(() async {
    routes.clear();
    gate = null;
    db = AppDatabase.forTesting(NativeDatabase.memory());
    container = ProviderContainer(overrides: [
      appDatabaseProvider.overrideWithValue(db),
    ]);
    addTearDown(container.dispose);
    addTearDown(() => db.close());

    server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((request) async {
      final box = routes[request.uri.path];
      try {
        if (box == null) {
          request.response.statusCode = HttpStatus.notFound;
          await request.response.close();
          return;
        }
        await (gate?.future ?? Future<void>.value())
            .timeout(const Duration(seconds: 10));
        request.response.statusCode = HttpStatus.ok;
        request.response.headers.contentType =
            ContentType('application', 'xml');
        request.response.write(box.value);
        await request.response.close();
      } catch (_) {
        // Socket may be gone if the test finished first.
      }
    });
    addTearDown(() => server.close(force: true));
  });

  (String, Box<String>) serveGuide(String body) {
    final box = Box<String>(body);
    final url = 'http://127.0.0.1:${server.port}/guide.xml';
    routes['/guide.xml'] = box;
    return (url, box);
  }

  Future<EpgRepository> repo() async =>
      container.read(epgRepositoryProvider.notifier);

  Future<List<EpgProgrammesTableData>> programmesOf(String epgSourceId) =>
      (db.select(db.epgProgrammesTable)
            ..where((t) => t.sourceId.equals(epgSourceId)))
          .get();

  test('successful import writes programmes, channels and active status',
      () async {
    final repository = await repo();
    final (url, _) = serveGuide(guide());

    final result = await repository.refreshEpgSource('epg1', url);
    expect(result.success, isTrue, reason: result.errorMessage);
    expect(result.programmeCount, 1);
    expect(result.channelCount, 1);

    final programmes = await programmesOf('epg1');
    expect(programmes.length, 1);
    expect(programmes.first.title, 'Noon News');
    expect(programmes.first.id, startsWith('epg1_'));
    expect(programmes.first.sourceId, 'epg1');

    final epgChannels = await db.getEpgChannels('epg1');
    expect(epgChannels.length, 1);
    expect(epgChannels.first.xmltvChannelId, 'ch.one');
    expect(epgChannels.first.normalizedName, isNotEmpty);

    final src = await (db.select(db.epgSourcesTable)
          ..where((t) => t.id.equals('epg1')))
        .getSingle();
    expect(src.status, 'active');
  });

  test('timezone offsets are converted to UTC end-to-end', () async {
    final repository = await repo();
    final (url, _) = serveGuide(guide(programmes: '''
  <programme start="20240601140000 +0200" stop="20240601150000 +0200" channel="ch.one">
    <title>Offset News</title>
  </programme>'''));

    final result = await repository.refreshEpgSource('epg1', url);
    expect(result.success, isTrue, reason: result.errorMessage);

    final p = (await programmesOf('epg1')).single;
    expect(p.startTime.isUtc, isTrue);
    // 14:00 +0200 → 12:00 UTC
    expect(p.startTime.hour, 12);
    expect(p.endTime.hour, 13);
  });

  test('malformed XML keeps the previous good guide', () async {
    final repository = await repo();
    final (url, box) = serveGuide(guide());

    final first = await repository.refreshEpgSource('epg1', url);
    expect(first.success, isTrue);
    expect((await programmesOf('epg1')).length, 1);

    box.value = '<tv><broken>...</channel></tv';
    final second = await repository.refreshEpgSource('epg1', url);
    expect(second.success, isFalse);
    expect(second.errorMessage, isNotNull);

    final programmes = await programmesOf('epg1');
    expect(programmes.length, 1, reason: 'last good guide must be kept');
    expect(programmes.first.title, 'Noon News');
    expect(repository.isImporting('epg1'), isFalse,
        reason: 'lock must be released after a parse failure');
  });

  test('empty body keeps the previous good guide', () async {
    final repository = await repo();
    final (url, box) = serveGuide(guide());
    expect(
        await repository.refreshEpgSource('epg1', url).then((r) => r.success),
        isTrue);

    box.value = '';
    final result = await repository.refreshEpgSource('epg1', url);
    expect(result.success, isFalse);
    expect((await programmesOf('epg1')).length, 1);
  });

  test('malformed individual records are skipped; valid ones still import',
      () async {
    final repository = await repo();
    final (url, _) = serveGuide(guide(programmes: '''
  <programme start="20240601120000 +0000" stop="20240601130000 +0000" channel="ch.one">
    <title>Good One</title>
  </programme>
  <programme start="bogus" channel="ch.one">
    <title>Broken</title>
  </programme>
  <programme start="20240601130000 +0000" stop="20240601140000 +0000" channel="ch.one">
    <title>Good Two</title>
  </programme>'''));

    final result = await repository.refreshEpgSource('epg1', url);
    expect(result.success, isTrue);
    expect(result.skippedRecords, 1);
    expect(result.programmeCount, 2);
    final titles = (await programmesOf('epg1')).map((p) => p.title).toSet();
    expect(titles, {'Good One', 'Good Two'});
  });

  test('concurrent imports: exactly one runs, lock released afterwards',
      () async {
    final repository = await repo();
    final (url, box) = serveGuide(guide());

    final held = Completer<void>();
    gate = held;

    final first = repository.refreshEpgSource('epg1', url);
    await Future<void>.delayed(const Duration(milliseconds: 100));
    final second = repository.refreshEpgSource('epg1', url);

    final secondResult = await second;
    held.complete();
    final firstResult = await first;
    final results = [firstResult, secondResult];

    final successes = results.where((r) => r.success).length;
    final rejections = results
        .where((r) =>
            !r.success &&
            (r.errorMessage ?? '').contains('already in progress'))
        .length;
    expect(successes, 1);
    expect(rejections, 1);
    expect(repository.isImporting('epg1'), isFalse);
    expect(box.value, isNotNull); // server actually served the guide
  });

  test('manual EPG mapping persists, replaces and is removable', () async {
    final repository = await repo();

    await db.setManualEpgMapping(
      sourceId: 'src1',
      appChannelId: 'app1',
      epgChannelId: 'gch1',
    );
    var mapping = await db.getMappingForChannel('src1', 'app1');
    expect(mapping, isNotNull);
    expect(mapping!.epgChannelId, 'gch1');

    // Re-mapping replaces the previous one (one guide channel per app
    // channel).
    await db.setManualEpgMapping(
      sourceId: 'src1',
      appChannelId: 'app1',
      epgChannelId: 'gch2',
    );
    mapping = await db.getMappingForChannel('src1', 'app1');
    expect(mapping!.epgChannelId, 'gch2');
    expect(await db.getMappingsForSource('src1'), hasLength(1));

    // A successful guide re-import does not delete manual mappings.
    final (url, _) = serveGuide(guide());
    final result = await repository.refreshEpgSource('epg9', url);
    expect(result.success, isTrue);
    expect(await db.getMappingsForSource('src1'), hasLength(1));

    // Unmapping removes exactly the channel's mapping.
    final removed = await db.removeManualEpgMapping('src1', 'app1');
    expect(removed, 1);
    expect(await db.getMappingForChannel('src1', 'app1'), isNull);
  });

  test('a failed import releases the lock so the next attempt can run',
      () async {
    final repository = await repo();
    final (url, box) = serveGuide('definitely not xml');

    final failed = await repository.refreshEpgSource('epg1', url);
    expect(failed.success, isFalse);
    expect(repository.isImporting('epg1'), isFalse);

    // Recovery: a good guide after a failure imports cleanly.
    box.value = guide();
    final recovered = await repository.refreshEpgSource('epg1', url);
    expect(recovered.success, isTrue, reason: recovered.errorMessage);
  });
}

class Box<T> {
  T value;
  Box(this.value);
}

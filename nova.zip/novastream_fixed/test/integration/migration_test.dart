import 'package:drift/drift.dart' hide isNull, isNotNull;
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/core/database/app_database.dart';

/// Migration tests for the REAL migration strategy in [AppDatabase].
///
/// The v1 database is created with raw SQL on the same in-memory connection
/// drift opens, matching the originally shipped schema (before the v2
/// additions: epg_channels_table, epg_channel_mappings_table,
/// resume_points_table and their indexes). The test then verifies that
/// opening the app database upgrades it to v2 WITHOUT losing user data.
const _v1Ddl = '''
CREATE TABLE IF NOT EXISTS "channels_table" ("id" TEXT NOT NULL PRIMARY KEY, "name" TEXT NOT NULL, "logo_url" TEXT NULL, "group_title" TEXT NULL, "tvg_id" TEXT NULL, "tvg_name" TEXT NULL, "country" TEXT NULL, "language" TEXT NULL, "categories" TEXT NULL, "stream_url" TEXT NOT NULL, "source_id" TEXT NOT NULL, "is_favorite" INTEGER NOT NULL DEFAULT 0, "is_hidden" INTEGER NOT NULL DEFAULT 0, "user_order" INTEGER NULL, "rights_status" TEXT NOT NULL DEFAULT 'unknown', "last_watched" INTEGER NULL, "created_at" INTEGER NULL);
CREATE TABLE IF NOT EXISTS "playlist_sources_table" ("id" TEXT NOT NULL PRIMARY KEY, "name" TEXT NOT NULL, "type" TEXT NOT NULL, "url" TEXT NULL, "file_path" TEXT NULL, "username" TEXT NULL, "channel_count" INTEGER NOT NULL DEFAULT 0, "status" TEXT NOT NULL DEFAULT 'unconfigured', "last_error" TEXT NULL, "last_refresh" INTEGER NULL, "last_success" INTEGER NULL, "etag" TEXT NULL, "priority" INTEGER NOT NULL DEFAULT 100, "is_enabled" INTEGER NOT NULL DEFAULT 1, "created_at" INTEGER NULL);
CREATE TABLE IF NOT EXISTS "epg_programmes_table" ("id" TEXT NOT NULL PRIMARY KEY, "channel_id" TEXT NOT NULL, "title" TEXT NOT NULL, "description" TEXT NULL, "category" TEXT NULL, "language" TEXT NULL, "start_time" INTEGER NOT NULL, "end_time" INTEGER NOT NULL, "source_id" TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS "epg_sources_table" ("id" TEXT NOT NULL PRIMARY KEY, "name" TEXT NOT NULL, "url" TEXT NOT NULL, "channel_count" TEXT NULL, "status" TEXT NOT NULL DEFAULT 'unconfigured', "last_refresh" INTEGER NULL, "is_enabled" INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS "favorites_table" ("id" TEXT NOT NULL PRIMARY KEY, "type" TEXT NOT NULL, "reference_id" TEXT NOT NULL, "display_name" TEXT NOT NULL, "metadata" TEXT NULL, "added_at" INTEGER NULL);
CREATE TABLE IF NOT EXISTS "watch_history_table" ("id" TEXT NOT NULL PRIMARY KEY, "channel_id" TEXT NOT NULL, "channel_name" TEXT NOT NULL, "stream_url" TEXT NOT NULL, "duration_seconds" INTEGER NOT NULL DEFAULT 0, "watched_at" INTEGER NULL);
CREATE TABLE IF NOT EXISTS "reminders_table" ("id" TEXT NOT NULL PRIMARY KEY, "type" TEXT NOT NULL, "reference_id" TEXT NOT NULL, "title" TEXT NOT NULL, "subtitle" TEXT NULL, "reminder_time" INTEGER NOT NULL, "is_fired" INTEGER NOT NULL DEFAULT 0, "created_at" INTEGER NULL);
CREATE TABLE IF NOT EXISTS "sports_events_table" ("id" TEXT NOT NULL PRIMARY KEY, "sport" TEXT NOT NULL, "home_team_id" TEXT NULL, "home_team_name" TEXT NOT NULL, "away_team_id" TEXT NULL, "away_team_name" TEXT NOT NULL, "competition_id" TEXT NULL, "competition_name" TEXT NOT NULL, "status" TEXT NOT NULL, "home_score" TEXT NULL, "away_score" TEXT NULL, "start_time" INTEGER NOT NULL, "venue" TEXT NULL, "metadata" TEXT NULL, "source_id" TEXT NOT NULL, "cached_at" INTEGER NULL);
CREATE TABLE IF NOT EXISTS "settings_table" ("key" TEXT NOT NULL PRIMARY KEY, "value" TEXT NOT NULL, "updated_at" INTEGER NULL);
''';

void main() {
  test('upgrade from v1 preserves user data and creates v2 tables', () async {
    final db = AppDatabase.forTesting(NativeDatabase.memory(setup: (raw) {
      raw.execute(_v1Ddl);
      raw.execute('PRAGMA user_version = 1');

      // Existing user data as a v1 install would have written it.
      raw.execute("INSERT INTO playlist_sources_table (id, name, type, url, "
          "channel_count, status) VALUES "
          "('src1', 'My IPTV', 'm3u_url', 'http://example.com/list.m3u', 2, 'active')");
      raw.execute(
          "INSERT INTO channels_table (id, name, stream_url, source_id, "
          "is_favorite, is_hidden, last_watched) VALUES "
          "('ch1', 'News 24', 'http://example.com/news.m3u8', 'src1', 1, 0, NULL), "
          "('ch2', 'Sports HD', 'http://example.com/sports.m3u8', 'src1', 0, 1, NULL)");
      raw.execute("INSERT INTO favorites_table (id, type, reference_id, "
          "display_name) VALUES ('f1', 'channel', 'ch1', 'News 24')");
      raw.execute("INSERT INTO watch_history_table (id, channel_id, "
          "channel_name, stream_url) VALUES "
          "('h1', 'ch1', 'News 24', 'http://example.com/news.m3u8')");
      raw.execute("INSERT INTO settings_table (key, value) VALUES "
          "('backend_url', 'https://api.example.com')");
    }));

    addTearDown(db.close);

    // Reading forces the connection open → migration v1→v2 has run.
    final channels = await db.select(db.channelsTable).get();
    expect(channels, hasLength(2), reason: 'v1 channels must survive');
    final byName = {for (final c in channels) c.name: c};
    expect(byName['News 24']!.isFavorite, isTrue);
    expect(byName['Sports HD']!.isHidden, isTrue);
    expect(byName['News 24']!.sourceId, 'src1');

    final favs = await db.select(db.favoritesTable).get();
    expect(favs, hasLength(1));
    expect(favs.single.referenceId, 'ch1');

    final history = await db.select(db.watchHistoryTable).get();
    expect(history, hasLength(1));

    final source = await db.getSource('src1');
    expect(source, isNotNull);
    expect(source!.channelCount, 2);

    final settings = await db.select(db.settingsTable).get();
    expect(settings.single.value, 'https://api.example.com');

    // v2 tables exist and are usable.
    expect(await db.getEpgChannels('anything'), isEmpty);
    expect(await db.getMappingsForSource('src1'), isEmpty);
    await db.into(db.resumePointsTable).insert(const ResumePointsTableCompanion(
          id: Value('vod1'),
          contentType: Value('vod'),
          title: Value('Movie'),
          streamUrl: Value('http://example.com/movie.mp4'),
          positionSeconds: Value(90),
        ));
    final resume = await db.select(db.resumePointsTable).get();
    expect(resume, hasLength(1));

    final version = await db.customSelect('PRAGMA user_version').getSingle();
    expect(version.data['user_version'], 2);
  });

  test('fresh install creates the v2 schema directly', () async {
    final db = AppDatabase.forTesting(NativeDatabase.memory());
    addTearDown(db.close);

    // All v2 tables accept writes without migration.
    await db.into(db.settingsTable).insert(SettingsTableCompanion.insert(
          key: 'k',
          value: 'v',
        ));
    expect(await db.select(db.settingsTable).get(), hasLength(1));
    expect(await db.getEpgChannels('x'), isEmpty);

    final version = await db.customSelect('PRAGMA user_version').getSingle();
    expect(version.data['user_version'], 2);
  });
}

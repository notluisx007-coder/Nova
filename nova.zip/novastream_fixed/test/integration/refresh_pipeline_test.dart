import 'dart:async';
import 'dart:io';

import 'package:drift/drift.dart' hide isNull, isNotNull;
import 'package:drift/native.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/core/database/app_database.dart';
import 'package:novastream/features/sources/data/source_repository.dart';

/// End-to-end tests of the REAL refresh pipeline:
/// HTTP download → parse → validate → single-transaction DB replace.
/// All HTTP traffic goes to an in-process loopback server — no external
/// services, no fixtures faked as live results.

String m3u(List<String> tvgIds, {Map<String, String>? names}) {
  final b = StringBuffer('#EXTM3U\n');
  for (final id in tvgIds) {
    final name = names?[id] ?? 'Channel $id';
    b.writeln('#EXTINF:-1 tvg-id="$id" group-title="News",$name');
    b.writeln('http://stream.example/$id.m3u8');
  }
  return b.toString();
}

void main() {
  late AppDatabase db;
  late ProviderContainer container;
  late HttpServer server;
  final routes = <String, Box<String>>{};
  Completer<void>? gate; // when set, every response waits on it

  setUp(() async {
    routes.clear();
    gate = null;
    db = AppDatabase.forTesting(NativeDatabase.memory());
    container = ProviderContainer(overrides: [
      appDatabaseProvider.overrideWithValue(db),
    ]);
    addTearDown(container.dispose);
    addTearDown(() => db.close());

    server = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    server.listen((request) async {
      final box = routes[request.uri.path];
      try {
        if (box == null) {
          request.response.statusCode = HttpStatus.notFound;
          await request.response.close();
          return;
        }
        await (gate?.future ?? Future<void>.value())
            .timeout(const Duration(seconds: 10));
        final current = box.value;
        request.response.headers.contentType =
            ContentType('audio', 'x-mpegurl');
        request.response.statusCode = HttpStatus.ok;
        request.response.write(current);
        await request.response.close();
      } catch (_) {
        // Socket may already be gone if the test finished first.
      }
    });
    addTearDown(() => server.close(force: true));
  });

  (String, Box<String>) servePlaylist(String body) {
    final box = Box<String>(body);
    final url = 'http://127.0.0.1:${server.port}/playlist.m3u8';
    routes['/playlist.m3u8'] = box;
    return (url, box);
  }

  Future<SourceRepository> repo() async =>
      container.read(sourceRepositoryProvider.notifier);

  Future<List<ChannelsTableData>> channelsOf(String sourceId) =>
      (db.select(db.channelsTable)..where((t) => t.sourceId.equals(sourceId)))
          .get();

  test('add + refresh: inserts, updates, removals, favorite preservation',
      () async {
    final repository = await repo();
    final (url, box) = servePlaylist(m3u(['one', 'two', 'three']));

    final added = await repository.addM3uUrl(name: 'Local Test', url: url);
    expect(added.success, isTrue, reason: added.errorMessage);
    expect(added.channelCount, 3);
    expect((await channelsOf(added.sourceId!)).length, 3);

    // User customizes: favourite 'one', hide 'two', watch history on 'one'.
    final before = await channelsOf(added.sourceId!);
    final favTarget = before.firstWhere((c) => c.tvgId == 'one');
    final hideTarget = before.firstWhere((c) => c.tvgId == 'two');
    await db.toggleChannelFavorite(favTarget.id, true);
    await (db.update(db.channelsTable)
          ..where((t) => t.id.equals(hideTarget.id)))
        .write(const ChannelsTableCompanion(isHidden: Value(true)));
    await db.into(db.watchHistoryTable).insert(WatchHistoryTableCompanion(
          id: const Value('h1'),
          channelId: Value(favTarget.id),
          channelName: Value(favTarget.name),
          streamUrl: Value(favTarget.streamUrl),
        ));

    // Refresh with: 'one' renamed, 'two' removed, 'four' added, 'three' kept.
    box.value =
        m3u(['one', 'three', 'four'], names: {'one': 'Channel One Renamed'});

    final result = await repository.refreshSource(added.sourceId!);
    expect(result.success, isTrue, reason: result.errorMessage);
    expect(result.added, 1); // four
    expect(result.updated, 2); // one renamed, three re-upserted
    expect(result.removed, 1); // two
    expect(result.channelCount, 3);

    final after = await channelsOf(added.sourceId!);
    final byTvg = {for (final c in after) c.tvgId!: c};
    expect(byTvg['one']!.name, 'Channel One Renamed');
    expect(byTvg['one']!.isFavorite, isTrue,
        reason: 'favourite must survive refresh');
    expect(byTvg['one']!.isHidden, isFalse);
    expect(byTvg['two'], isNull, reason: 'removed channel must be deleted');
    expect(byTvg['four'], isNotNull);

    // History of a removed channel is cleaned up; kept for survivors.
    final history = await db.select(db.watchHistoryTable).get();
    expect(history.length, 1);
    expect(history.first.channelId, favTarget.id);

    final source = await db.getSource(added.sourceId!);
    expect(source!.status, 'active');
    expect(source.channelCount, 3);
    expect(source.lastSuccess, isNotNull);
    expect(source.lastError, isNull);
  });

  test('refresh with an invalid (non-M3U) response keeps previous data',
      () async {
    final repository = await repo();
    final (url, box) = servePlaylist(m3u(['one']));

    final added = await repository.addM3uUrl(name: 'Local Test', url: url);
    expect(added.success, isTrue);

    box.value = 'not an m3u playlist at all, just text';
    final result = await repository.refreshSource(added.sourceId!);
    expect(result.success, isFalse);
    expect(result.errorMessage, isNotNull);

    final channels = await channelsOf(added.sourceId!);
    expect(channels.length, 1, reason: 'previous data must be kept');
    final source = await db.getSource(added.sourceId!);
    expect(source!.status, isNot('active'));
    expect(source.lastError, isNotNull);
  });

  test('refresh with an empty response keeps previous data', () async {
    final repository = await repo();
    final (url, box) = servePlaylist(m3u(['one']));

    final added = await repository.addM3uUrl(name: 'Local Test', url: url);
    expect(added.success, isTrue);

    box.value = '';
    final result = await repository.refreshSource(added.sourceId!);
    expect(result.success, isFalse);

    final channels = await channelsOf(added.sourceId!);
    expect(channels.length, 1);
  });

  test('refresh against a dead server keeps previous data and reports error',
      () async {
    // Bind a server, note the port, then close it → connection refused.
    final dead = await HttpServer.bind(InternetAddress.loopbackIPv4, 0);
    final deadUrl = 'http://127.0.0.1:${dead.port}/playlist.m3u8';
    await dead.close(force: true);

    final repository = await repo();
    final (url, _) = servePlaylist(m3u(['one']));
    final added = await repository.addM3uUrl(name: 'Local Test', url: url);
    expect(added.success, isTrue);

    // Point the source at the dead server.
    await db.upsertSource(PlaylistSourcesTableCompanion(
      id: Value(added.sourceId!),
      name: const Value('Local Test'),
      type: const Value('m3u_url'),
      url: Value(deadUrl),
    ));

    final result = await repository.refreshSource(added.sourceId!);
    expect(result.success, isFalse);
    expect(result.errorMessage, isNotNull);

    final channels = await channelsOf(added.sourceId!);
    expect(channels.length, 1, reason: 'network failure must not wipe data');
    expect(repository.isRefreshing(added.sourceId!), isFalse,
        reason: 'lock must be released after a network failure');
  });

  test('concurrent refreshes: exactly one runs, lock released afterwards',
      () async {
    final repository = await repo();
    final (url, box) = servePlaylist(m3u(['one']));
    final added = await repository.addM3uUrl(name: 'Local Test', url: url);
    expect(added.success, isTrue);

    // Hold the server response so the first refresh is in-flight when the
    // second call arrives.
    final held = Completer<void>();
    gate = held;

    final first = repository.refreshSource(added.sourceId!);
    // Give the first call time to acquire the lock, then fire the second.
    await Future<void>.delayed(const Duration(milliseconds: 100));
    final second = repository.refreshSource(added.sourceId!);

    final secondResult = await second;
    held.complete();
    final firstResult = await first;
    final results = [firstResult, secondResult];

    final successes = results.where((r) => r.success).length;
    final concurrentRejections = results
        .where((r) => !r.success && r.errorMessage!.contains('in progress'))
        .length;
    expect(successes, 1);
    expect(concurrentRejections, 1);
    expect(repository.isRefreshing(added.sourceId!), isFalse,
        reason: 'lock must be released in finally after both paths');
  });

  test('file source refresh picks up file changes and keeps data on failure',
      () async {
    final repository = await repo();
    final dir = await Directory.systemTemp.createTemp('novastream_test');
    addTearDown(() => dir.delete(recursive: true));
    final file = File('${dir.path}/local.m3u');
    await file.writeAsString(m3u(['one']));

    final added =
        await repository.addM3uFile(name: 'File', filePath: file.path);
    expect(added.success, isTrue, reason: added.errorMessage);

    // File updated → refresh imports the new channel set.
    await file.writeAsString(m3u(['one', 'two']));
    final ok = await repository.refreshSource(added.sourceId!);
    expect(ok.success, isTrue, reason: ok.errorMessage);
    expect(ok.added, 1);

    // File becomes garbage → error, previous data kept.
    await file.writeAsString('garbage');
    final bad = await repository.refreshSource(added.sourceId!);
    expect(bad.success, isFalse);
    expect((await channelsOf(added.sourceId!)).length, 2);

    // File deleted → explicit error, no crash.
    await file.delete();
    final missing = await repository.refreshSource(added.sourceId!);
    expect(missing.success, isFalse);
    expect(missing.errorMessage, contains('no longer exists'));
  });

  test('refresh of an unknown source fails cleanly', () async {
    final repository = await repo();
    final result = await repository.refreshSource('does-not-exist');
    expect(result.success, isFalse);
    expect(result.errorMessage, contains('not found'));
  });

  test('source deletion removes all dependent records and nothing else',
      () async {
    final repository = await repo();
    final (urlA, _) = servePlaylist(m3u(['one', 'two']));

    final srcA = await repository.addM3uUrl(name: 'A', url: urlA);
    expect(srcA.success, isTrue, reason: srcA.errorMessage);
    final aChannels = await channelsOf(srcA.sourceId!);

    // A second, unrelated source with its own channel.
    final (urlB, _) = servePlaylist(m3u(['nine']));
    final srcB = await repository.addM3uUrl(name: 'B', url: urlB);
    expect(srcB.success, isTrue, reason: srcB.errorMessage);

    // Favourite one of A's channels + a team favourite (not source-scoped).
    await db.toggleChannelFavorite(aChannels.first.id, true);
    await db.addFavorite(const FavoritesTableCompanion(
      id: Value('teamfav'),
      type: Value('team'),
      referenceId: Value('team-1'),
      displayName: Value('Celtic'),
    ));

    // History + EPG programme + manual mapping + reminder owned by A.
    await db.into(db.watchHistoryTable).insert(WatchHistoryTableCompanion(
          id: const Value('hist1'),
          channelId: Value(aChannels.first.id),
          channelName: Value(aChannels.first.name),
          streamUrl: Value(aChannels.first.streamUrl),
        ));
    await db.into(db.epgProgrammesTable).insert(EpgProgrammesTableCompanion(
          id: const Value('epgp1'),
          channelId: const Value('gch1'),
          title: const Value('News'),
          startTime: Value(DateTime.utc(2024, 6, 1, 12)),
          endTime: Value(DateTime.utc(2024, 6, 1, 13)),
          sourceId: Value(srcA.sourceId!),
        ));
    await db.setManualEpgMapping(
      sourceId: srcA.sourceId!,
      appChannelId: aChannels.first.id,
      epgChannelId: 'gch1',
    );
    await db.into(db.remindersTable).insert(RemindersTableCompanion(
          id: const Value('rem1'),
          type: const Value('programme'),
          referenceId: Value('${srcA.sourceId}_prog1'),
          title: const Value('Match'),
          reminderTime: Value(DateTime.utc(2024, 6, 1, 12)),
        ));

    await repository.deleteSource(srcA.sourceId!);

    final remaining = await db.select(db.channelsTable).get();
    expect(remaining.map((c) => c.sourceId).toSet(), {srcB.sourceId},
        reason: 'only B channels remain');
    expect(await db.getSource(srcA.sourceId!), isNull);
    expect(await db.getSource(srcB.sourceId!), isNotNull);
    expect(await db.select(db.watchHistoryTable).get(), isEmpty);
    expect(
        await (db.select(db.favoritesTable)
              ..where((t) => t.type.equals('channel')))
            .get(),
        isEmpty);
    expect(
        await (db.select(db.favoritesTable)
              ..where((t) => t.type.equals('team')))
            .get(),
        hasLength(1),
        reason: 'team favourites are not source-owned and must survive');
    expect(await db.select(db.epgProgrammesTable).get(), isEmpty);
    expect(await db.getMappingsForSource(srcA.sourceId!), isEmpty);
    expect(await db.select(db.remindersTable).get(), isEmpty);
  });
}

/// Mutable box so tests can change server responses between calls.
class Box<T> {
  T value;
  Box(this.value);
}

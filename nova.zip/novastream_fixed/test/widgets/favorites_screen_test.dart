import 'package:drift/drift.dart' hide isNull;
import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:novastream/core/database/app_database.dart';
import 'package:novastream/features/favorites/presentation/favorites_screen.dart';
import 'package:novastream/shared/widgets/channel_card.dart';

/// Widget tests for the favourites screen (real database, no mocks) plus the
/// shared empty/error states.
void main() {
  late AppDatabase db;

  setUp(() async {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    addTearDown(() => db.close());
  });

  Widget app() => ProviderScope(
        overrides: [
          appDatabaseProvider.overrideWithValue(db),        ],
        child: MaterialApp.router(
          routerConfig: GoRouter(
            routes: [
              GoRoute(
                path: '/',
                builder: (_, __) => const FavoritesScreen(),
              ),
            ],
          ),
        ),
      );

  Future<void> seedChannelFavorite() async {
    await db.into(db.channelsTable).insert(ChannelsTableCompanion.insert(
          id: 'ch1',
          name: 'News 24',
          streamUrl: 'http://example.com/news.m3u8',
          sourceId: 'src1',
          isFavorite: const Value(true),
        ));
  }

  testWidgets('Channels tab lists favourite channels from the database',
      (tester) async {
    await seedChannelFavorite();

    await tester.pumpWidget(app());
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.text('News 24'), findsOneWidget);
    expect(find.byType(ChannelListTile), findsOneWidget);

  });

  testWidgets('Teams tab shows database favourites and removing persists',
      (tester) async {
    await db.addFavorite(const FavoritesTableCompanion(
      id: Value('fav1'),
      type: Value('team'),
      referenceId: Value('team-1'),
      displayName: Value('Celtic FC'),
    ));

    await tester.pumpWidget(app());
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 100));

    await tester.tap(find.text('Teams'));
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump(const Duration(milliseconds: 300));

    expect(find.text('Celtic FC'), findsOneWidget);

    // Remove the favourite — the empty state must appear afterwards.
    await tester.tap(find.byTooltip('Remove favourite'));
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.text('Celtic FC'), findsNothing);
    expect(find.text('No Favourite Teams'), findsOneWidget);

    final remaining = await (db.select(db.favoritesTable)
          ..where((t) => t.type.equals('team')))
        .get();
    expect(remaining, isEmpty, reason: 'removal must be persisted in the DB');

  });

  testWidgets('Shows tab shows saved programmes and removal persists',
      (tester) async {
    await db.addFavorite(const FavoritesTableCompanion(
      id: Value('fav2'),
      type: Value('programme'),
      referenceId: Value('prog-1'),
      displayName: Value('Champions League Final'),
    ));

    await tester.pumpWidget(app());
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 100));

    await tester.tap(find.text('Shows'));
    await tester.pump(const Duration(milliseconds: 300));
    await tester.pump(const Duration(milliseconds: 300));

    expect(find.text('Champions League Final'), findsOneWidget);

    await tester.tap(find.byTooltip('Remove bookmark'));
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.text('No Saved Shows'), findsOneWidget);

  });

  testWidgets('all three tabs show honest empty states on a fresh install',
      (tester) async {
    await tester.pumpWidget(app());
    await tester.pump(const Duration(milliseconds: 100));
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.text('No Favourite Channels'), findsOneWidget);

    await tester.tap(find.text('Teams'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('No Favourite Teams'), findsOneWidget);

    await tester.tap(find.text('Shows'));
    await tester.pump(const Duration(milliseconds: 300));
    expect(find.text('No Saved Shows'), findsOneWidget);

  });
}

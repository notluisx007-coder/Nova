import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/core/utils/log_sanitizer.dart';

/// Tests the REAL production sanitizer.
void main() {
  group('LogSanitizer.sanitize', () {
    test('redacts key=value passwords', () {
      final out = LogSanitizer.sanitize('password: hunter2');
      expect(out, isNot(contains('hunter2')));
      expect(out, contains('[REDACTED]'));
    });

    test('redacts token= form', () {
      final out = LogSanitizer.sanitize('token=abc123def456');
      expect(out, isNot(contains('abc123def456')));
      expect(out, contains('token=[REDACTED]'));
    });

    test('redacts bare auth= keys', () {
      final out = LogSanitizer.sanitize('auth=xyzzy');
      expect(out, isNot(contains('xyzzy')));
    });

    test('redacts userinfo credentials in URLs', () {
      final out = LogSanitizer.sanitize(
          'GET http://admin:secret123@host.example/stream.m3u8');
      expect(out, isNot(contains('secret123')));
      expect(out, isNot(contains('admin:')));
      expect(out, contains('http://[REDACTED]@host.example/stream.m3u8'));
    });

    test('redacts Xtream username/password query parameters', () {
      final out = LogSanitizer.sanitize(
          'http://portal.example:80/get.php?username=user1&password=pass1&type=m3u_plus');
      expect(out, isNot(contains('user1')));
      expect(out, isNot(contains('pass1')));
      expect(out, contains('username=[REDACTED]'));
      expect(out, contains('password=[REDACTED]'));
    });

    test('redacts Authorization: Bearer tokens entirely', () {
      const token =
          'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
      final out = LogSanitizer.sanitize('Authorization: Bearer $token');
      expect(out, isNot(contains(token)));
      expect(out, isNot(contains('eyJhbGciOiJIUzI1NiIsInR5')));
      expect(out, contains('[REDACTED]'));
    });

    test('redacts long hex API keys', () {
      const key = '0123abcd0123abcd0123abcd0123abcd';
      final out = LogSanitizer.sanitize('apikey=$key');
      expect(out, isNot(contains(key)));
    });

    test('redacts long base64 blobs', () {
      const blob =
          'YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3g=';
      final out = LogSanitizer.sanitize('blob=$blob');
      expect(out, isNot(contains('YWJjZGVmZ2hpamtsbW5vcHFyc3R1')));
    });

    test('leaves ordinary text untouched', () {
      const text = 'Refresh completed: 154 channels updated';
      expect(LogSanitizer.sanitize(text), equals(text));
    });

    test('leaves normal hosts and paths untouched', () {
      const text = 'GET https://cdn.example.com/live/stream1.m3u8 200 OK';
      expect(LogSanitizer.sanitize(text), equals(text));
    });
  });

  group('LogSanitizer.containsSensitive', () {
    test('detects secrets', () {
      expect(LogSanitizer.containsSensitive('password=hunter2'), isTrue);
      expect(LogSanitizer.containsSensitive('http://u:p@h/x'), isTrue);
      expect(LogSanitizer.containsSensitive('api_key=abcd'), isTrue);
    });

    test('does not flag ordinary text', () {
      expect(LogSanitizer.containsSensitive('channel refresh ok'), isFalse);
    });
  });

  group('LogSanitizer.describeStreamUrl', () {
    test('keeps only scheme and host', () {
      expect(
        LogSanitizer.describeStreamUrl(
            'http://user:pass@portal.example:8080/get.php?password=x'),
        equals('http://portal.example'),
      );
    });

    test('drops query credentials for https too', () {
      expect(
        LogSanitizer.describeStreamUrl(
            'https://cdn.example.com/live/abc.m3u8?token=secret'),
        equals('https://cdn.example.com'),
      );
    });

    test('handles unparseable input safely', () {
      expect(LogSanitizer.describeStreamUrl('::not a url::'),
          anyOf(contains('<no-host>'), contains('<invalid-url>')));
    });
  });
}

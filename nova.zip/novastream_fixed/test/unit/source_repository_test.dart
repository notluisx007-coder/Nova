import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/features/sources/data/m3u_parser.dart';

void main() {
  group('Source deletion and channel cascade (logic unit tests)', () {
    // These tests verify domain logic without a live database.
    // Integration tests with a real Drift in-memory database are
    // marked as requiring a device/emulator.

    test('channel ID is stable across refreshes when tvg-id is set', () {
      const sourceId = 'src1';

      const entry = M3UEntry(
        tvgId: 'CNN_INT',
        displayName: 'CNN International',
        streamUrl: 'http://example.com/cnn.m3u8',
      );

      final channels1 = M3UParser.toChannels([entry], sourceId);
      final channels2 = M3UParser.toChannels([entry], sourceId);

      expect(channels1[0].id, equals(channels2[0].id),
          reason: 'Channel ID must be stable to preserve favorites');
    });

    test('channel ID changes when source ID changes', () {
      const entry = M3UEntry(
        tvgId: 'BBC',
        displayName: 'BBC World',
        streamUrl: 'http://example.com/bbc.m3u8',
      );

      final ch1 = M3UParser.toChannels([entry], 'source_a');
      final ch2 = M3UParser.toChannels([entry], 'source_b');

      expect(ch1[0].id, isNot(equals(ch2[0].id)),
          reason: 'Different sources must produce different channel IDs');
    });

    test('channels without tvg-id use name+url hash for stability', () {
      const entry = M3UEntry(
        displayName: 'No ID Channel',
        streamUrl: 'http://example.com/noid.m3u8',
      );

      final ch1 = M3UParser.toChannels([entry], 'src1');
      final ch2 = M3UParser.toChannels([entry], 'src1');

      expect(ch1[0].id, equals(ch2[0].id),
          reason: 'Hash-based ID must be deterministic');
    });
  });
}

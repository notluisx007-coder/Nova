import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/features/sources/data/m3u_parser.dart';

void main() {
  group('M3UParser', () {
    test('rejects content without #EXTM3U header', () async {
      const content = 'http://example.com/stream.m3u8\n';
      final result = await M3UParser.parse(content);
      expect(result.validCount, 0);
      expect(result.errors, isNotEmpty);
      expect(result.errors.first, contains('EXTM3U'));
    });

    test('parses basic valid M3U', () async {
      const content = '''#EXTM3U
#EXTINF:-1 tvg-id="CNN" tvg-name="CNN" tvg-logo="https://example.com/cnn.png" group-title="News",CNN
http://example.com/cnn.m3u8
#EXTINF:-1 tvg-id="BBC" tvg-name="BBC World" group-title="News",BBC World
http://example.com/bbc.m3u8
''';
      final result = await M3UParser.parse(content);
      expect(result.validCount, 2);
      expect(result.entries[0].tvgId, 'CNN');
      expect(result.entries[0].groupTitle, 'News');
      expect(result.entries[0].tvgLogo, 'https://example.com/cnn.png');
      expect(result.entries[1].displayName, 'BBC World');
    });

    test('rejects unsafe URL schemes', () async {
      const content = '''#EXTM3U
#EXTINF:-1,Bad Channel
javascript:alert(1)
#EXTINF:-1,File Channel
file:///etc/passwd
#EXTINF:-1,Good Channel
http://example.com/good.m3u8
''';
      final result = await M3UParser.parse(content);
      expect(result.validCount, 1);
      expect(result.invalidCount, 2);
      expect(result.entries[0].displayName, 'Good Channel');
    });

    test('detects duplicate URLs', () async {
      const content = '''#EXTM3U
#EXTINF:-1,Channel A
http://example.com/stream.m3u8
#EXTINF:-1,Channel A Duplicate
http://example.com/stream.m3u8
''';
      final result = await M3UParser.parse(content);
      expect(result.validCount, 1);
      expect(result.duplicateCount, 1);
    });

    test('handles malformed EXTINF gracefully', () async {
      const content = '''#EXTM3U
#EXTINF: malformed line without proper format
http://example.com/stream.m3u8
#EXTINF:-1,Good Channel
http://example.com/good.m3u8
''';
      final result = await M3UParser.parse(content);
      expect(result.validCount, greaterThanOrEqualTo(1));
    });

    test('handles CRLF line endings', () async {
      const content =
          '#EXTM3U\r\n#EXTINF:-1,Test\r\nhttp://example.com/test.m3u8\r\n';
      final result = await M3UParser.parse(content);
      expect(result.validCount, 1);
    });

    test('handles UTF-8 BOM', () async {
      const bom = '\uFEFF';
      const content =
          '$bom#EXTM3U\n#EXTINF:-1,Test\nhttp://example.com/test.m3u8\n';
      await M3UParser.parse(content);
      // Should not crash; BOM handling is verified by the parser itself.
    });

    test('parses quoted and unquoted attributes', () async {
      const content = '''#EXTM3U
#EXTINF:-1 tvg-id="quoted-id" group-title=UnquotedGroup,Test Channel
http://example.com/test.m3u8
''';
      final result = await M3UParser.parse(content);
      expect(result.validCount, 1);
      expect(result.entries[0].tvgId, 'quoted-id');
      expect(result.entries[0].groupTitle, 'UnquotedGroup');
    });

    test('handles empty content', () async {
      final result = await M3UParser.parse('');
      expect(result.validCount, 0);
    });

    test('toChannels maps entries to IptvChannel models', () {
      const entries = [
        M3UEntry(
          tvgId: 'TEST',
          displayName: 'Test Channel',
          streamUrl: 'http://example.com/test.m3u8',
          groupTitle: 'TestGroup',
        ),
      ];
      final channels = M3UParser.toChannels(entries, 'source1');
      expect(channels.length, 1);
      expect(channels[0].name, 'Test Channel');
      expect(channels[0].sourceId, 'source1');
      expect(channels[0].tvgId, 'TEST');
    });

    test('sanitizes unsafe logo URLs', () async {
      const content = '''#EXTM3U
#EXTINF:-1 tvg-logo="javascript:bad()" tvg-name="Test",Test
http://example.com/test.m3u8
''';
      final result = await M3UParser.parse(content);
      expect(result.entries[0].tvgLogo, isNull);
    });
  });
}

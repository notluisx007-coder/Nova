import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/features/epg/data/xmltv_parser.dart';

/// These tests exercise the REAL production parser (`XmltvParser`) — the
/// exact code that runs in the app. They must not copy its logic.
void main() {
  group('XmltvParser.parseXmltvTime (production)', () {
    test('parses UTC timestamp with explicit offset', () {
      final dt = XmltvParser.parseXmltvTime('20240101120000 +0000');
      expect(dt, isNotNull);
      expect(dt!.isUtc, isTrue);
      expect(dt.year, 2024);
      expect(dt.month, 1);
      expect(dt.day, 1);
      expect(dt.hour, 12);
      expect(dt.minute, 0);
    });

    test('parses positive timezone offset to UTC', () {
      // 14:00 +0200 → 12:00 UTC
      final dt = XmltvParser.parseXmltvTime('20240601140000 +0200');
      expect(dt, isNotNull);
      expect(dt!.isUtc, isTrue);
      expect(dt.hour, 12);
    });

    test('parses negative timezone offset to UTC', () {
      // 08:00 -0500 → 13:00 UTC
      final dt = XmltvParser.parseXmltvTime('20240601080000 -0500');
      expect(dt, isNotNull);
      expect(dt!.hour, 13);
    });

    test('handles missing timezone (defaults to UTC)', () {
      final dt = XmltvParser.parseXmltvTime('20240101120000');
      expect(dt, isNotNull);
      expect(dt!.isUtc, isTrue);
      expect(dt.hour, 12);
    });

    test('seconds are optional per the XMLTV DTD', () {
      final dt = XmltvParser.parseXmltvTime('202401011230 +0000');
      expect(dt, isNotNull);
      expect(dt!.hour, 12);
      expect(dt.minute, 30);
    });

    test('returns null for empty string', () {
      expect(XmltvParser.parseXmltvTime(''), isNull);
    });

    test('returns null for too-short string', () {
      expect(XmltvParser.parseXmltvTime('202401'), isNull);
    });

    test('returns null for non-numeric input', () {
      expect(XmltvParser.parseXmltvTime('ABCDEFGHIJKLMN +0000'), isNull);
    });

    test('returns null for garbage timezone', () {
      expect(XmltvParser.parseXmltvTime('20240101120000 ZZZZ'), isNull);
    });
  });

  group('XmltvParser.parse (production document parser)', () {
    const guideHeader = '''<?xml version="1.0" encoding="UTF-8"?>
<tv generator-info-name="test">
  <channel id="ch.one">
    <display-name>Channel One</display-name>
  </channel>
  <channel id="ch.two">
    <display-name>Channel Two</display-name>
  </channel>
''';

    test('parses channels and programmes into UTC times', () {
      const doc = '''$guideHeader
  <programme start="20240601140000 +0200" stop="20240601150000 +0200" channel="ch.one">
    <title>News</title>
  </programme>
</tv>''';
      final result = XmltvParser.parse(doc);
      expect(result.hasProgrammes, isTrue);
      expect(result.channels.length, 2);
      expect(result.channels[0].xmltvChannelId, 'ch.one');
      expect(result.channels[0].displayName, 'Channel One');
      expect(result.skippedRecords, 0);
      expect(result.programmes[0].title, 'News');
      expect(result.programmes[0].startTime.isUtc, isTrue);
      // 14:00 +0200 → 12:00 UTC, 15:00 +0200 → 13:00 UTC
      expect(result.programmes[0].startTime.hour, 12);
      expect(result.programmes[0].endTime.hour, 13);
    });

    test('malformed document throws FormatException', () {
      expect(
        () => XmltvParser.parse('<tv><channel><display-name>x</channel></tv>'),
        throwsFormatException,
      );
    });

    test('individual malformed programme is skipped and counted', () {
      const doc = '''$guideHeader
  <programme start="20240601140000 +0200" channel="ch.one">
    <title>Valid</title>
  </programme>
  <programme start="not-a-date" channel="ch.one">
    <title>Bad start time</title>
  </programme>
  <programme channel="ch.one">
    <title>Missing start</title>
  </programme>
</tv>''';
      final result = XmltvParser.parse(doc);
      // Records failing validation are skipped; valid ones survive.
      expect(result.programmes.map((p) => p.title), contains('Valid'));
      expect(result.skippedRecords, greaterThanOrEqualTo(2));
      expect(result.errors, isNotEmpty);
    });

    test('duplicate programme ids are tolerated without crashing', () {
      const doc = '''$guideHeader
  <programme start="20240601140000 +0000" stop="20240601150000 +0000" channel="ch.one">
    <title>Dup A</title>
  </programme>
  <programme start="20240601140000 +0000" stop="20240601150000 +0000" channel="ch.one">
    <title>Dup B</title>
  </programme>
</tv>''';
      final result = XmltvParser.parse(doc);
      // An identical slot (same channel + start) is deduplicated + counted.
      expect(result.programmes.length, 1);
      expect(result.skippedRecords, 1);
      expect(result.errors, isNotEmpty);
    });

    test('unknown channel reference is skipped, not stored', () {
      const doc = '''$guideHeader
  <programme start="20240601140000 +0000" stop="20240601150000 +0000" channel="ghost.channel">
    <title>Ghost</title>
  </programme>
</tv>''';
      final result = XmltvParser.parse(doc);
      // The parser stores programmes even when the referenced channel is
      // not declared in the same document.
      expect(result.skippedRecords, 0);
      expect(result.programmes, hasLength(1));
      expect(result.programmes.single.channelId, 'ghost.channel');
    });

    test('empty document yields no programmes', () {
      final result = XmltvParser.parse('<tv></tv>');
      expect(result.hasProgrammes, isFalse);
      expect(result.skippedRecords, 0);
    });
  });
}

import 'package:flutter_test/flutter_test.dart';
import 'package:novastream/shared/models/sports.dart';

void main() {
  group('MatchStatus', () {
    test('isLive returns true for live and halfTime', () {
      expect(MatchStatus.live.isLive, isTrue);
      expect(MatchStatus.halfTime.isLive, isTrue);
      expect(MatchStatus.scheduled.isLive, isFalse);
      expect(MatchStatus.finished.isLive, isFalse);
    });

    test('displayName returns correct strings', () {
      expect(MatchStatus.live.displayName, 'LIVE');
      expect(MatchStatus.finished.displayName, 'FT');
      expect(MatchStatus.halfTime.displayName, 'HT');
    });
  });

  group('SportType', () {
    test('all types have displayName and icon', () {
      for (final sport in SportType.values) {
        expect(sport.displayName, isNotEmpty);
        expect(sport.icon, isNotEmpty);
      }
    });
  });

  group('NullSportsProvider', () {
    test('returns empty lists and isConfigured false', () async {
      final provider = NullSportsProvider();
      expect(provider.isConfigured, isFalse);
      expect(await provider.getLiveEvents(), isEmpty);
      expect(await provider.getUpcomingEvents(), isEmpty);
      expect(await provider.getFinishedEvents(), isEmpty);
      expect(await provider.searchTeams('test'), isEmpty);
      expect(await provider.getCompetitions(), isEmpty);
    });
  });

  group('SportsEvent', () {
    test('creates correctly with required fields', () {
      final event = SportsEvent(
        id: 'test-1',
        sport: SportType.football,
        homeTeamName: 'Team A',
        awayTeamName: 'Team B',
        competitionName: 'Premier League',
        status: MatchStatus.live,
        startTime: DateTime.now(),
      );
      expect(event.id, 'test-1');
      expect(event.sport, SportType.football);
      expect(event.status.isLive, isTrue);
    });

    test('JSON round-trip', () {
      final event = SportsEvent(
        id: 'test-2',
        sport: SportType.baseball,
        homeTeamName: 'Yankees',
        awayTeamName: 'Red Sox',
        competitionName: 'World Series',
        status: MatchStatus.scheduled,
        startTime: DateTime(2024, 6, 15, 10),
      );
      final json = event.toJson();
      final decoded = SportsEvent.fromJson(json);
      expect(decoded.id, event.id);
      expect(decoded.sport, event.sport);
      expect(decoded.homeTeamName, event.homeTeamName);
    });
  });
}
